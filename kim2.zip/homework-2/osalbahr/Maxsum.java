import java.util.ArrayList;
import java.util.Scanner;

/**
 * Calculate the maximum sum in a subarray of length >= 1
 * given an arbitrary-length array
 */
public class Maxsum {
  // Stores the entire values
  private static ArrayList<Integer> vArray = new ArrayList<Integer>();

  /*
   * Calculates the maximum sum in some subarrays
   * The thread knows what to calculate based on
   * the starting index and the number of workers
   */
  static class Worker extends Thread {
    private int startIdx;
    private int workers;
    private boolean report;
    public int localMaxSum;

    // Initialize fields
    public Worker( int startIdx, int workers, boolean report ) {
      this.startIdx = startIdx;
      this.workers = workers;
      this.report = report;
      this.localMaxSum = vArray.get( 0 );
    }

    // Do the calculatins, store local max sum
    public void run() {
      for ( int i = startIdx; i < vArray.size(); i += workers ) {
        int currSum = 0;
        for ( int j = i; j < vArray.size(); j++ ) {
          currSum += vArray.get( j );
          localMaxSum = Math.max( localMaxSum, currSum );
        }
      }
      if ( report )
        System.out.println( "thread " + this.getId() + " The maximum sum I found is " + this.localMaxSum );
    }
  }

  // Print usage message and exit
  private static void usage() {
    System.out.println( "usage: Maxsum <workers>" );
    System.out.println( "       Maxsum <workers> report" );
    System.exit( 1 );
  
  }

  public static void main( String[] args ) {
    // Tell the user how to use the program
    if ( args.length <= 0 || args.length >= 3 )
      usage();
    
    
    // The first arg better be a number
    int workers = -1;
    try {
      workers = Integer.parseInt( args[ 0 ] );
    } catch ( NumberFormatException e ) {
      usage();
    }

    // If there is a second arg, it better be report
    boolean report = false;
    if ( args.length == 2 )
      if ( args[ 1 ].equals( "report" ) )
        report = true;
      else
        usage();
  
  
    // Read input
    try( Scanner in = new Scanner( System.in ) ) {
      while ( in.hasNextInt() ) {
        vArray.add( in.nextInt() );
      }
    }
  
    // Make threads
    ArrayList<Worker> threads = new ArrayList<Worker>( workers );
    for ( int i = 0; i < workers; i++ ) {
        Worker worker = new Worker( i, workers, report );
        threads.add( worker );
        worker.start();
    }

    // Join threads and find global max sum
    int globalMaxSum = vArray.get( 0 );
    for ( Worker worker : threads ) {
      try {
        worker.join();
      } catch ( InterruptedException e ) {
        System.out.println( e.getMessage() );
      }
      globalMaxSum = Math.max( globalMaxSum, worker.localMaxSum );
    }
    System.out.println( "Maximum Sum: " + globalMaxSum );
  }
}
