#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message )
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Attach the shared memory.
static void *myShmat()
{
  key_t key = ftok( HOME, 1 );
  if ( key == -1 )
    fail( "Can't create key" );
  int shmid = shmget( key, sizeof( GameState ), 0666 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  GameState *info = (GameState *)shmat( shmid, 0, 0 );
  if ( info == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
  return info;
}

// Prints the board
static void report( GameState *info )
{
  for ( int i = 0; i < GRID_SIZE; i++ )
    printf( "%s\n", info->board[ i ] );
}

// Inverts the current location, if it is valid
static bool invert( GameState *info, int r, int c )
{
  if ( r < 0 || r >= GRID_SIZE
    || c < 0 || c >= GRID_SIZE ) {
    return false;
  }
  
  if ( info->board[ r ][ c ] == '.' ) {
    info->board[ r ][ c ] = '*';
  } else {
    info->board[ r ][ c ] = '.';
  }

  return true;
}

// Converts string to int
// Returns -100 on error
static int parseInt( char *str )
{
  int result;
  char check;
  int matches = sscanf( str, "%d %c", &result, &check );
  if ( matches != 1 )
    return -100;
  
  return result;
}

// Simulates clicking on a spot
// Returns false on error, otherwise returns true
// This version requires ints for row and column
static bool _move( GameState *info, int r, int c )
{
  if ( !invert( info, r, c ) )
    return false;

  invert( info, r + 1, c );
  invert( info, r - 1, c );
  invert( info, r, c + 1 );
  invert( info, r, c - 1 );

  // For a later undo() call
  info->canUndo = true;
  info->lastMove[ 0 ] = r;
  info->lastMove[ 1 ] = c;

  return true;
}
// Simulates clicking on a spot
// Returns false on error, otherwise returns true
// This version requires strings for row and column
static bool move( GameState *info, char *rstr, char *cstr )
{
  int r = parseInt( rstr );
  if ( r == -100 )
    return false;
  int c = parseInt( cstr );
  if ( c == -100 )
    return false;

  return _move( info, r, c );
}

// Undoes the last move if possible and returns true
// Otherwise returns false
static bool undo( GameState *info )
{
  if ( !info->canUndo )
    return false;

  _move( info, info->lastMove[ 0 ], info->lastMove[ 1 ] );

  // Overwrite canUndo since _move() always sets canUndo=true
  info->canUndo = false;

  return true;
}

// Prints the success message
static void success()
{
  printf( "success\n" );
}

// Prints the error message and exits
static void error()
{
  printf( "error\n" );
  exit( 1 );
}

int main( int argc, char *argv[] )
{
  // Attach the shared memory
  GameState *info = myShmat();

  // Validate command name, argc
  // Let the commands do the rest
  // report/undo: argc == 2
  // move r c   : argc == 4
  if ( argc == 2 )
    if ( strcmp( argv[ 1 ], "report" ) == 0 )
      report( info );
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 )
      if ( undo( info ) )
        success();
      else
        error();
    else
      error();
  else if ( argc == 4 && strcmp( argv[ 1 ], "move" ) == 0 )
    if ( move( info, argv[ 2 ], argv[ 3 ] ) )
      success();
    else
      error();
  else
    error();
  
  return 0;
}
