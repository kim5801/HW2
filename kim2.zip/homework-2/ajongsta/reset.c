#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Error checking to see how many arguments we have
  if( argc != 2 ) {
    // Print error message
    usage();
  }

  // Make a shared memory segment
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/a/ajongsta", 0), sizeof(struct GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Initialize struct using shared memory
  struct GameState *gs = ( struct GameState* )shmat( shmid, 0, 0 );
  if ( gs == ( struct GameState* )-1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // Load in a file passed through as an argument given that we have an argument for it
  FILE *fp = fopen( argv[ 1 ], "r" );

  // Null check for bad open
  if( fp == NULL ) {
    // ERROR BAD FILE
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  // Big loop to fill out our board completely based on the file
  for( int i = 0; i < 5; i++ ) {
    char c = fgetc( fp );
    for( int j = 0; j < 5; j++ ) {
      // Let's get the value from the file to add to our array board
      if( c != '\n' ) {
        gs->board[ j ][ i ] = c;
      }
      if( c != '*' && c != '.') {
        fprintf( stderr, "%s %s\n", "Invalid input file:", argv[ 1 ] );
        exit( 1 );
      }
      c = fgetc( fp );
    }
  }

  // Setting our last action values to ensure no undos off the getgo or just unset values in general...
  gs->lastAction[0] = 6;
  gs->lastAction[1] = 6;

  // Release our reference to the shared memory segment
  shmdt( gs );
  
  // Don't forget to close the file
  fclose( fp );

  return 0;
}
