#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include "common.h"

struct GameState *gs;

int running = 1;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
* Flips the tile selected and all surrounding tiles.
* @param x the x coordinate on the board
* @param y the y coordinate on the board
*/
void flipTiles( int x, int y ) {
  // Doing middle first, edge cases as else
  if( x != 4 && x != 0 ) {
    // Flips the value depending on what it already was (X)
    if( gs->board[ y ][ x ] == '*' ) {
      gs->board[ y ][ x ] = '.';
    } else {
      gs->board[ y ][ x ] = '*';
    }

    // Flips the value depending on what it already was (X+1)
    if( gs->board[ y ][ x + 1 ] == '*' ) {
      gs->board[ y ][ x + 1 ] = '.';
    } else {
      gs->board[ y ][ x + 1 ] = '*';
    }

    // Flips the value depending on what it already was (X-1)
    if( gs->board[ y ][ x - 1 ] == '*' ) {
      gs->board[ y ][ x - 1 ] = '.';
    } else {
      gs->board[ y ][ x - 1 ] = '*';
    }
        
  } else {
    // If X is 0
    if( x == 0 ) {
      // Flips the value depending on what it already was (X)
      if( gs->board[ y ][ x ] == '*' ) {
        gs->board[ y ][ x ] = '.';
      } else {
        gs->board[ y ][ x ] = '*';
      }

      // Flips the value depending on what it already was (X + 1)
      if( gs->board[ y ][ x + 1 ] == '*' ) {
        gs->board[ y ][ x + 1 ] = '.';
      } else {
        gs->board[ y ][ x + 1 ] = '*';
      }
    } 
    // If X is 4
    else {
      // Flips the value depending on what it already was (X)
      if( gs->board[ y ][ x ] == '*' ) {
        gs->board[ y ][ x ] = '.';
      } else {
        gs->board[ y ][ x ] = '*';
      }

      // Flips the value depending on what it already was (X - 1)
      if( gs->board[ y ][ x - 1 ] == '*' ) {
        gs->board[ y ][ x - 1 ] = '.';
      } else {
        gs->board[ y ][ x - 1 ] = '*';
      }
    }
  }
  
  // Rinse and repeat for Y

  // Doing middle first, edge cases as else
  if( y != 4 && y != 0 ) {

    // Flips the value depending on what it already was (Y-1)
    if( gs->board[ y - 1 ][ x ] == '*' ) {
      gs->board[ y - 1 ][ x ] = '.';
    } else {
      gs->board[ y - 1 ][ x ] = '*';
    }

    // Flips the value depending on what it already was (Y+1)
    if( gs->board[ y + 1 ][ x ] == '*' ) {
      gs->board[ y + 1 ][ x ] = '.';
    } else {
      gs->board[ y + 1 ][ x ] = '*';
    }
        
  } else {
    // If Y is 0
    if( y == 0 ) {

      // Flips the value depending on what it already was (Y + 1)
      if( gs->board[ y + 1 ][ x ] == '*' ) {
        gs->board[ y + 1 ][ x ] = '.';
      } else {
        gs->board[ y + 1 ][ x ] = '*';
      }
    } 
    // If Y is 4
    else {

      // Flips the value depending on what it already was (Y - 1)
      if( gs->board[ y - 1 ][ x ] == '*' ) {
        gs->board[ y - 1 ][ x ] = '.';
      } else {
        gs->board[ y - 1 ][ x ] = '*';
      }
    }
  }
}

/**
* @param c the string being converted to an int
* @return c as an integer value
*/
int stringToInt( char c[] ) {
    int retVal = 0;
    for( int i = 0; c[i] != '\0'; i++ ) {
        if(c[i] > '9' || c[i] < '0') {
            return -1;
        }
        retVal = ( retVal * 10 ) + c[i] - '0';
    }
    return retVal;
}

/**
* Prints the board to standard output
*/
void printBoard() {
  // If we want to view the current board we can iterate and print everything
  for( int i = 0; i < 5; i++ ) {
    for( int j = 0; j < 5; j++ ) {
      printf( "%c", gs->board[ j ][ i ] );
    }
    printf( "\n" );
  }
}

/**
* Handles our alarm -- reactive
*/
void exitProgramHandler() {
  // Print a newline and then the board
  printf("\n");
  printBoard();
  exit( EXIT_SUCCESS );
}

int main( int argc, char *argv[] ) {

  // Make a shared memory segment
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/a/ajongsta", 0 ), 0, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  // Map the shared memory
  gs = ( struct GameState* )shmat( shmid, 0, 0 );
  if ( gs == ( struct GameState* )-1 )
    fail( "Can't map shared memory segment into address space" );

  // Create our sig action struct and set the alarm handler
  struct sigaction act;
  act.sa_handler = exitProgramHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Our initial error checking for if we're getting the right arguments...
  if(argc > 4 || argc < 2 ) {
    fail("error");
  }

  // Secondary error checking for correct argument values
  if( ( ( strcmp( argv[ 1 ], "report" ) != 0 ) && ( strcmp( argv[ 1 ], "undo" ) != 0 ) ) && ( strcmp( argv[ 1 ], "move" ) != 0 ) ) {
    fail("error");
  }

  // Our action item
  char * action;

  // Stores inputted x value
  int x;

  // Stores inputted y value
  int y;

  // Repeatedly read and process  messages.
  while ( running ) {

    // Tracks how many times we've iterated through the list
    int passNum = 0;

    action = argv[ 1 ];
      
    // If we want to perform a new action
    if( strcmp( action, "move" ) == 0 ) {
      //Okay so we know we need an X and a Y...so we're going to go ahead and expect additional parameters
      for( int i = 2; i < argc; i++ ) {
        if( ( argv[ i ] == '\0' && i != ( argc - 1 ) ) && ( passNum == 0 ) ) {
          x = stringToInt( argv[ i + 1 ] );
          passNum++;
        } else if( ( argv[ i ] == '\0' && i != ( argc - 1 ) ) && ( passNum == 1 ) ) {
          y = stringToInt( argv[ i + 1 ] );
          passNum++;
        }
      } 

      if( ( x > 4 || x < 0 ) || ( y > 4 ) || ( y < 0 ) ) {
        fail("error");
      } else {
        // And now we execute the necessary functions
        flipTiles( x, y );
        gs->lastAction[ 0 ] = x;
        gs->lastAction[ 1 ] = y;
        
        // Success! Let's leave the program now
        printf( "success\n" );
        exit( 0 );
      } 
    }

    // If we want to undo our last action
    else if( strcmp( action, "undo" ) == 0 ) {
      // Check to see if an Undo action is valid
      if( gs->lastAction[ 0 ] == 6 ) {
        fail("error");
      } else {
        flipTiles( gs->lastAction[ 0 ], gs->lastAction[ 1 ] );
        gs->lastAction[ 0 ] = 6;
        gs->lastAction[ 1 ] = 6;
        // Send succes through to the queue
        printf( "success\n" );
        exit( 0 );
      }
      
    }

    // Print if we have a print action call
    else if( strcmp( action, "report" ) == 0 ) {
      for( int i = 0; i < 5; i++ ) {
        for( int j = 0; j < 5; j++ ) {
          printf( "%c", gs->board[ j ][ i ] );  
        }
        printf( "%c", '\n' );    
      }
      // Exit our program
      exit( 0 );
    }

    // Otherwise let's just fail
    else {
      fail("error");
    }  
  }  

  // Release our reference to the shared memory segment.
  shmdt( gs );

  // Tell the OS we no longer need the segment.
  shmctl( shmid, IPC_RMID, 0 );

  return 0;
}
