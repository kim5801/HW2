// Height and width of the playing area.
#define GRID_SIZE 5

struct GameState {
    char board[5][5];
    int lastAction[2];
};