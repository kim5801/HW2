import java.util.Scanner;
import java.io.IOException;
import java.util.ArrayList;

public class Maxsum {

    private static ArrayList<Integer> array = new ArrayList<Integer>();

    private static int maxSum;
    
    // Print out a usage message.
    public static void usage() {
        System.out.println("usage: maxsum <workers>");
        System.out.println("       maxsum <workers> report" );
        System.exit(1);
    }

    /**
     * Finds and returns the max value in the subsequence dedicated to that thread
     * @param startIndex the index in the array we should start at.
     * @param numThreads the number of threads iterating over our array.
     * @return the maximum value in the subsequence assigned to the thread.
     */
    static class ThreadProj extends Thread {

        //Fields that are initialized on creation of this inner class
        private int startIndex;
        private int numThreads;

        //Stores the value that our thread will need to return to the parent
        int returnValueMax;

        /**
         * Constructor that builds out our runnable object with specific
         * properties such as the starting index and the number of threads
         * that exist
         * @param startIndex the starting index of the iteration
         * @param numThreads the number of threads that the user would like to use.
         */
        public ThreadProj(int startIndex, int numThreads) {
            this.startIndex = startIndex;
            this.numThreads = numThreads;
        }

        /**
         * The run method is inhereted from Runnable and will be run
         * by each threads created
         */
        public void run() {
            int returnValue = array.get(startIndex);
            int tempValue;
            for(int i = startIndex; i < array.size(); i += numThreads) {
                tempValue = 0;
                for( int j = i; j < array.size(); j++ ) {
                    tempValue += array.get(j);
                    if( tempValue > returnValue ) {
                      returnValue = tempValue;
                    }
                  }
            }
            
            returnValueMax = returnValue;
        }
    }
    

    public static void main(String args[]) {
        // Set our default values...can be changed later
        boolean report = false;
        int numThreads = 4;
        // Check if we're getting the right number of arguments
        if(args.length < 1 || args.length > 2)
            usage();

        // Can the number of children be parsed as an integer?
        try {
            numThreads = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            usage();
        }

        // If the user inputs a negative number of worker threads
        if(numThreads < 0) {
            usage();
        }

        // Make sure our third argument is report (if anything)
        if(args.length == 2) {
            if(args[1].equals("report")) {
                report = true;
            } else {
                usage();
            }
        }

        // Read in our list
        Scanner inputList = new Scanner(System.in);
        while (inputList.hasNextInt()) {
            array.add(inputList.nextInt());
        }
        inputList.close();

        // The thread we're going to continuously recreate
        ThreadProj [] threads = new ThreadProj [ numThreads ];

        // Initialize maxSum value to the first value in the array and create our local max variable
        maxSum = array.get(0);
        int readValue;

        // Okay now we make a bunch of threads and have them all pass through to the findMax function
        // but we just pass different parameter through
        for(int i = 0; i < numThreads; i++) {
            // Initialize the thread with the correct parameters
            threads[i] = new ThreadProj(i, numThreads);
            // Start the thread and get our max
            threads[i].start();
        }
        for(int i = 0; i < numThreads; i++) {
            // Try to join threads
            try {
                threads[i].join();
                readValue = threads[i].returnValueMax;
                // Larger? Update our value
                if( readValue > maxSum ) {
                    maxSum = readValue;
                }
                // If we're reporting our threads we should print the thread ids
                // and then individual maxes by accessing the thread fields
                if(report) {
                    System.out.println("I'm thread " + threads[i].getId() + ". The maximum sum I found is " + threads[i].returnValueMax + ".");
                }
            } catch ( InterruptedException e ) {
                System.out.println( "Interrupted during join!" );
            }
            
        }
        System.out.println("Maximum Sum: " + maxSum );
        System.exit(0);
    }
}
