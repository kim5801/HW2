#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out the usage message and exit
static void usage() {
  printf("usage: lightsout move <row> <column>\n");
  printf("       lightsout undo\n");
  printf("       lightsout rpeort\n");
  exit(1);
}

// Print out the current state of the board
int printBoard(GameState *game) {
  // Add characters from each row and column
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", '*' + (*(*(game->current + i) + j) - 1) * -4);
    }
    // Add a newline at the end of each row
    printf("\n");
  }

  return 0;
}

// Make a move on a board and populate a status message
int move(GameState *game, int row, int col) {
  // Check if the positions are in bounds
  if (row < 0 || col < 0 || row >= GRID_SIZE || col >= GRID_SIZE) {
    return -1;
  }

  // Set the previous board to the current one before a move is made
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      game->previous[i][j] = game->current[i][j];
    }
  }

  // Invert the corrent spots on the board
  *(*(game->current + row) + col) = !*(*(game->current + row) + col);
  if (col > 0) *(*(game->current + row) + col - 1) = !*(*(game->current + row) + col - 1);
  if (col < GRID_SIZE - 1) *(*(game->current + row) + col + 1) = !*(*(game->current + row) + col + 1);
  if (row > 0) *(*(game->current + row - 1) + col) = !*(*(game->current + row - 1) + col);
  if (row < GRID_SIZE - 1) *(*(game->current + row + 1) + col) = !*(*(game->current + row + 1) + col);

  // Return success and update undo status
  game->undo = true;

  return 0;
}

// Undo the latest move
int undo(GameState *game) {
  // Return error if the board cannot be undone
  if (!(game->undo)) {
    return -1;
  }
  game->undo = false;

  // Change every element from previous to current
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      game->current[i][j] = game->previous[i][j];
    }
  }

  return 0;
}

int main( int argc, char *argv[] ) {
  // Sanity check and get the arguments
  if (argc != 2 && argc != 4) {
    usage();
  }

  int row = -1, col = -1;
  if (argc == 4 &&
      (sscanf(argv[2], "%d", &row) == -1 || sscanf(argv[3], "%d", &col) == -1)) {
    usage();
  }

  // Get the id for the shared memory segment
  key_t key = ftok(PATH, PROJ_ID);

  // Get the shared memory segment id
  int shmid = shmget(key, 0, 0);
  if (shmid == -1) {
    fail("Cannot get memory");
  }

  // Map the shared memory into address space
  GameState *game = (GameState *) shmat(shmid, 0, 0);
  if (game == (GameState *) -1) {
    fail("Cannot map shared memory segment");
  }

  // Parse the command, exit if the command is successful, return if not
  if (
      (strcmp(argv[1], "move") == 0 && move(game, row, col) == 0) ||
      (strcmp(argv[1], "undo") == 0 && undo(game) == 0)
    ) {
    printf("success\n");
  } else if (strcmp(argv[1], "report") == 0 && printBoard(game) == 0) {
    // Don't print success for report queries
  } else {
    printf("error\n");
  }

  if (shmdt(game) == -1) {
    fail("Cannot detach from shared memory");
  }

  return 0;
}
