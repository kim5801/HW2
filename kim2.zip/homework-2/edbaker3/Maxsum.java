import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Integer;

public class Maxsum {
  /**
   * Print out the usage string for the command
   */
  private static void usage() {
    System.out.println("usage: maxsum <workers>");
    System.out.println("       maxsum <workers> report");
  }

  /**
   * A thread that is used to calculate a maximum size from a given range
   */
  public static class SubThread extends Thread {
    /** The ArrayList of integers to calculate a maximum sum */
    private ArrayList<Integer> list;

    /** The starting index to calculate a maximum sum */
    private int startIndex;

    /** The repeat offset used to calculate the next sum */
    private int repeat;

    /** The ArrayList of maximum sums */
    private ArrayList<Integer> sums;

    /** Whether or not the thread should report */
    private boolean report;

    /**
     * Default constructor for a thread, used to get information for the max sum to compute
     *
     * @param list The ArrayList of integers to calculate with
     * @param startIndex The starting index to start calculating the max sum with
     * @param repeat The repeat offset to calculate maximum sums with
     * @param sums The ArrayList of maximum sums
     */
    public SubThread(ArrayList<Integer> list, int startIndex, int repeat, ArrayList<Integer> sums, boolean report) {
      this.list = list;
      this.startIndex = startIndex;
      this.repeat = repeat;
      this.sums = sums;
      this.report = report;
    }

    /**
     * Calculate a maximum sum
     *
     * @param start The starting index
     */
    public int findLargestSum(int start) {
      int sum = 0;
      int max = this.list.get(start);

      // Repeat for the given length of input numbers
      for (int i = start; i < this.list.size(); i++) {
        sum += this.list.get(i);

        if (sum > max) {
          max = sum;
        }
      }

      return max;
    }


    /**
     * The function to run when the thread starts
     */
    public void run() {
      int largest = this.findLargestSum(this.startIndex);

      int sum;
      for (int i = this.startIndex; i < this.list.size(); i += this.repeat) {
        // Determine if the given sum is larger than the value we already have
        sum = this.findLargestSum(i);

        if (sum > largest) {
          largest = sum;
        }
      }

      this.sums.add(largest);

      if (this.report) {
        System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", this.getId(), largest);
      }
    }
  }

  /**
   * Main runner to parse command line arguments and calculate maximum sums
   *
   * @param args The command line arguments
   */
  public static void main(String[] args) {
    // Check the command line arguments
    if (args.length < 1 || args.length > 2) {
      Maxsum.usage();
      return;
    }

    // Make sure the second argument is the word report
    boolean report = false;
    if (args.length == 2) {
      if (!"report".equals(args[1])) {
        Maxsum.usage();
        return;
      }
      report = true;
    }

    // Parse the number of workers
    int workers = Integer.parseInt(args[0]);
    if (workers < 1) {
      Maxsum.usage();
      return;
    }

    // Read in the data
    ArrayList<Integer> list = new ArrayList<Integer>();
    Scanner reader = new Scanner(System.in);

    while (reader.hasNextInt()) {
      list.add(reader.nextInt());
    }

    ArrayList<Integer> sums = new ArrayList<Integer>();
    ArrayList<Thread> threads = new ArrayList<Thread>();

    // Start the threads
    for (int i = 0; i < workers; i++) {
      Thread t = new Maxsum.SubThread(list, i, workers, sums, report);

      t.start();
      threads.add(t);
    }

    // Join the threads
    try {
      for (int i = 0; i < threads.size(); i++) {
        threads.get(i).join();
      }
    } catch (InterruptedException e) {
      System.out.println("Interrupted join");
    }

    // Find the maximum sum
    int largest = sums.get(0);
    for (int i = 1; i < sums.size(); i++) {
      if (sums.get(i) > largest) {
        largest = sums.get(i);
      }
    }

    System.out.printf("Maximum Sum: %d\n", largest);
  }
}
