#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//Struct that keeps track of the game state
struct GameState {
  char state[GRID_SIZE][GRID_SIZE + 1];
  char prevState[GRID_SIZE][GRID_SIZE+ 1];
  char undo;
};

int main( int argc, char *argv[] ) {
  struct GameState *game;
  key_t id = ftok("/afs/unity.ncsu.edu/users/j/jtcirinc/hw246/hw2", 1);
  int shmid = shmget( id, sizeof(struct GameState), 0666 | IPC_CREAT );
  //point game to shared memory
  game = shmat(shmid, 0, 0);


  if (argc == 1) {
    fail("error");
  }

  if (strcmp(argv[1], "move") == 0) {
    if (argc == 4) {
      int rowIpt = atoi(argv[2]);
      int colIpt = atoi(argv[3]);
      if (rowIpt >= 5 || colIpt >= 5 || rowIpt < 0 || colIpt < 0) {
        fail("error");
      }

      //copies contents of state into the old state
      memcpy(game->prevState, game->state, sizeof(char) * GRID_SIZE * (GRID_SIZE + 1));
      game->undo = 1;

      //update the state
      if (game->state[rowIpt][colIpt] == '.') {
        game->state[rowIpt][colIpt] = '*';
      }
      else {
        game->state[rowIpt][colIpt] = '.';
      }
      //change state above
      if (rowIpt - 1 >= 0) {
        if (game->state[rowIpt - 1][colIpt] == '.') {
          game->state[rowIpt - 1][colIpt] = '*';
        }
        else {
          game->state[rowIpt - 1][colIpt] = '.';
        }
      }
      //change state below
      if (rowIpt + 1 <= 4) {
        if (game->state[rowIpt + 1][colIpt] == '.') {
          game->state[rowIpt + 1][colIpt] = '*';
        }
        else {
          game->state[rowIpt + 1][colIpt] = '.';
        }
      }
      //change state to the left
      if (colIpt - 1 >= 0) {
        if (game->state[rowIpt][colIpt - 1] == '.') {
          game->state[rowIpt][colIpt - 1] = '*';
        }
        else {
          game->state[rowIpt][colIpt - 1] = '.';
        }
      }
      //change state to the right
      if (colIpt + 1 <= 4) {
        if (game->state[rowIpt][colIpt + 1] == '.') {
          game->state[rowIpt][colIpt + 1] = '*';
        }
        else {
          game->state[rowIpt][colIpt + 1] = '.';
        }
      }

      
      printf("%s\n", "success");
    }
    else {
      fail("error");
    }
  }
  else if (strcmp(argv[1], "report") == 0) {
    if (argc == 2) {
      for (int i = 0; i < GRID_SIZE; i++) {
        printf("%s\n", game->state[i]);
      }
    }
    else {
      fail("error");
    }
  }
  else if (strcmp(argv[1], "undo") == 0 && game->undo == 1) {
    if (argc == 2) {
      //copy over old state to new state
      memcpy(game->state, game->prevState, sizeof(char) * GRID_SIZE * (GRID_SIZE + 1));
      game->undo = 0;
    }
    else {
      fail("error");
    }
  }
  else {
    fail("error");
  } 


  return 0;
}
