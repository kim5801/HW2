#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "Invalid input file: %s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

//struct that keeps track of the game state
struct GameState {
  char state[GRID_SIZE][GRID_SIZE + 1];
  char prevState[GRID_SIZE][GRID_SIZE+ 1];
  char undo;
};

int main( int argc, char *argv[] ) {

  if (argc != 2) {
    usage();
  }
  struct GameState *game;
  char buff[30];
  int fd = open(argv[1], O_RDONLY);
  if (fd < 0) {
    fail(argv[1]);
  }
  read(fd, buff, 30);

  int count = 0;
  key_t id = ftok("/afs/unity.ncsu.edu/users/j/jtcirinc/hw246/hw2", 1);
  int shmid = shmget( id, sizeof(struct GameState), 0666 | IPC_CREAT );

  game = shmat(shmid, 0, 0);

  //store original file into struct
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 6; j++) {
      if (buff[count] != '\n') {
        game->state[i][j] = buff[count];
      }
      count++;
    }
  }

  // Release our reference to the shared memory segment.
  shmdt( game );


  return 0;
}
