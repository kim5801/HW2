import java.util.*;

public class Maxsum {

  public static int max(int one, int two) {
    if (one > two) {
      return one;
    }
    else if (two > one) {
      return two;
    }
    else {
      return one;
    }
  }


  // Print out a usage message, then exit.
public static void usage() {
  System.out.println( "usage: maxsum <workers>" );
  System.out.println( "       maxsum <workers> report" );
  System.exit(1);
}

  
    /** Something for my new tread to do. */
  static class MyThread extends Thread {
    private int numThreads;
    private long threadValue;
    private int idx;
    private int[] arr;
    private int count;
    private int mySum;
    public MyThread(int numThreads, int idx, int[] arr) {
        this.numThreads = numThreads;
        this.idx = idx;
        this.arr = arr;
        this.count = arr.length;
        this.mySum = 0;
        this.threadValue = getId();
    }
    public void run() {
      int sum = 0;
      int totalSum = 0;
      // Periodically increment the shared variable.
      // for ( int i = 0; i < count; i++ ) {
        

      // }
      while (idx <= count) {
        for(int j = idx; j < count; j++) {
          sum = max(sum, (totalSum + arr[j]));
          totalSum = totalSum + arr[j];
        }
        idx += numThreads;
        totalSum = 0;
      }
      this.mySum = sum;
    }
  }

  

  public static void main( String[] args ) {
    int vCap = 5;
    int[] vList = new int[vCap];
    boolean report = false;
    if (args.length == 1 || args.length == 2) {
      if (args.length == 2) {
        if (!args[1].equals("report")) {
          usage();
        }
        report = true;
      }
    }
    else {
      usage();
    }


    int numThreads = Integer.parseInt(args[0]);
    //keeps track of index of array of values
    int count = 0;
    // make the new thread and start it up.
    MyThread myThread[] = new MyThread[numThreads];

    //read in input from the file
    Scanner scnr = new Scanner(System.in);
    while (scnr.hasNextInt()) {
      //grow the array
      if (count == vCap) {
        vCap *= 2;
        int[] newArr = new int[vCap];
        for(int i = 0; i < vList.length; i++) {
          newArr[i] = vList[i];
        }
        vList = newArr;
      }
      //read into array at index "count"
      vList[count] = scnr.nextInt();
      count++;
    }
    scnr.close();



    //run each thread
    for(int i = 0; i < numThreads; i++) {
        myThread[i] = new MyThread(numThreads, i, vList);
        myThread[i].start();
    }

    int finalSum = 0;
    //wait for each thread to finish
    try {
      for ( int i = 0; i < myThread.length; i++ ) {
        myThread[ i ].join();
        finalSum = max(myThread[i].mySum, finalSum);
        if (report) {
          System.out.println("I'm thread " + myThread[i].threadValue + ". The maximum sum I found is " + myThread[i].mySum);
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }

    System.out.println("Maximum Sum: " + finalSum);

  }

  // public void growArray(int[] arr) {
  //   for (int i = 0; i < )
  // }
}