#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

bool makeMove( struct Board * board, int row, int col, bool undo );
void printBoard( struct Board * board );

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/g/gtbachel", 256 ), sizeof(struct Board), 0 );
  struct Board * board = (struct Board *)shmat( shmid, 0, 0 );
  
  if( strcmp( argv[1], "move" ) == 0 ) {
    makeMove( board, atoi( argv[2] ), atoi( argv[3] ), false );
  }
  
  if( strcmp( argv[1], "report" ) == 0 ) {
    printBoard( board );
  }
  
  if( strcmp( argv[1], "undo" ) == 0 ) {
    makeMove( board, 0, 0, true );
  }
  
  return 0;
}

bool makeMove( struct Board * board, int row, int col, bool undo ) {
  //Undo by setting the current move to the last move, because making a move and undoing it is symmetric
  if( undo ) {
    //Error (return false) if there is not a previous move
    if( board->lastMove[0] == -1 ) {
      return false;
    }
    row = board->lastMove[0];
    col = board->lastMove[1];
    //Set previous move to empty
    board->lastMove[0] = -1;
    board->lastMove[1] = -1;
  }
  //Make the move if in bounds
  if(row >= 0 && row <= GRID_SIZE - 1 && col >= 0 && col <= GRID_SIZE - 1 ) {
    board->boardState[row][col] = !board->boardState[row][col];
    
    //Make sure we can act on the grid space in each direction
    if( row > 0 ) {
      board->boardState[row - 1][col] = !board->boardState[row - 1][col];
    }
    
    if( row < GRID_SIZE - 1 ) {
      board->boardState[row + 1][col] = !board->boardState[row + 1][col];
    }
    
    if( col > 0 ) {
      board->boardState[row][col - 1] = !board->boardState[row][col - 1];
    }
    
    if( col < GRID_SIZE - 1 ) {
      board->boardState[row][col + 1] = !board->boardState[row][col + 1];
    }
    
    //If its not an undo, set the last move to this move
    if( !undo ) {
      board->lastMove[0] = row;
      board->lastMove[1] = col;
    }
    //No errors!
    return true;
  }
  //Out of bounds!
  else return false;
}

void printBoard( struct Board * board ) {
  //Create string with space for newlines
  char boardString[GRID_SIZE * (GRID_SIZE + 1)];
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      //Set next char in string to * or . for true or false
      boardString[i * (GRID_SIZE + 1) + j] = board->boardState[i][j] ? '*' : '.';
    }
    //Add a newline after GRID_SIZE characters
    boardString[i * (GRID_SIZE + 1) + GRID_SIZE] = '\n';
  }
  //Last character as a nuller terminator
  boardString[GRID_SIZE * (GRID_SIZE + 1) - 1] = '\0';
  
  printf( "%s\n", boardString );
}
