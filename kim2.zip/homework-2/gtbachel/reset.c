#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

void openBoard(struct Board * board, char * filename );

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/g/gtbachel", 256 ), sizeof(struct Board), 0600 | IPC_CREAT );
  struct Board * board = (struct Board *)shmat( shmid, 0, 0 );
  if( argc != 2 ) {
    fail( "Bad syntax" );
    usage();
  }
  openBoard( board, argv[1] );
  return 0;
}

void openBoard(struct Board * board, char * filename ) {
  //Open the given filename
  FILE * fp;
  fp = fopen( filename, "r" );
  //Couldn't find the file?
  if( !fp ) {
    printf( "Invalid input file: %s\n", filename );
    fail( "Invalid filename" );
  }
  int i = 0;
  char c;
  //Read in 25 * or .
  while( i < 25 ) {
    c = fgetc(fp);
    if( feof( fp ) ) {
      //Reached end of file without 25 * or .    invalid file format
      printf( "Invalid input file: %s\n", filename );
      fail( "Invalid file" );
    }
    if( c == '*' ) {
      i++;
      board->boardState[i/5][i%5] = true;
    }
    else if( c == '.' ) {
      i++;
      board->boardState[i/5][i%5] = false;
    }
    else if( c != '\n' ) {
      //Found a character that wasn't a * . or newline
      printf( "Invalid input file: %s\n", filename );
      fail( "Invalid file" );
    }
  }
  //Close the file, it's not needed.
  fclose( fp );
}
