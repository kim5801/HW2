import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {
	static ArrayList<Integer> numbers = new ArrayList<Integer>();
	static ArrayList<MaxsumThread> threads = new ArrayList<MaxsumThread>();
	static int threadCount;
	static boolean report = false;
	public static void main(String args[]) {
		Scanner fileReader;
		fileReader = new Scanner(System.in);
		
		threadCount = Integer.valueOf(args[0]);
		
		while(fileReader.hasNext()) {
			numbers.add(fileReader.nextInt());
		}
		
		if(args.length > 1 && args[1].equals("-report")) {
			report = true;
		}
		
		for(int i = 0; i < threadCount; i++) {
			threads.add(new MaxsumThread(i));
			threads.get(i).start();
		}
		
		for(int i = 0; i < threadCount; i++) {
			try {
				threads.get(i).join();
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		}
		int trueMax = Integer.MIN_VALUE;
		for(int i = 0; i < threadCount; i++) {
			if(threads.get(i).maxSum > trueMax) {
				trueMax = threads.get(i).maxSum;
			}
		}
		System.out.println("Maximum sum: " + trueMax);
	}
	
	private static class MaxsumThread extends Thread {
		
		private int id;
		
		public int maxSum;
		
		public MaxsumThread(int id) {
			this.id = id;
		}
		
		@Override
		public void run() {
			int sum;
			maxSum = Integer.MIN_VALUE;
			for(int i = id; i < numbers.size(); i += threadCount) {
				sum = 0;
				for(int j = i; j < numbers.size(); j++) {
					sum += numbers.get(j);
					if(sum > maxSum) {
						maxSum = sum;
					}
				}
			}
			if(report) {
				System.out.println("I'm process " + this.getId() + ". The maximum sum I found is " + maxSum + ".");
			}
		}
	}
}
