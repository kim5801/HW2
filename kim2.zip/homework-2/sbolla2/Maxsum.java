import java.util.Scanner;
import java.util.*;

/**
 * The maxsum.java class creates worker threads to divide up an array and find the max sum of values
 * inside the array.
 * Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter04/HelloThreads.java
 * Using https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter04/ThreadArguments.java
 * Using class slides for Threads
 */
public class Maxsum {
  // Integer ArrayList that contains the list of integers read in from input
  volatile static ArrayList<Integer> vList = new ArrayList<Integer>();

  // Integer ArrayList that holds the maximum values found from all the helper threads
  volatile static ArrayList<Integer> resultArr = new ArrayList<Integer>();

  // Number of values on the list.
  volatile static int vCount = 0;

  // Number of workers that the user wants to be created
  volatile static int workers = 0;

  /** Print out a usage message, then exit. */
  public static void usage() {
    System.out.print( "usage: maxsum <workers>\n" );
    System.out.print( "       maxsum <workers> report\n" );
  }

  /** 
   * Read the list of values using a scanner
   * Store the values that are read in from the input into the vList array
   */
  public static void readList() {
    Scanner read = new Scanner(System.in);

    int v;
    while ( read.hasNextInt() ) {
        v = read.nextInt();
        
        // Store the latest value in the next array slot.
        vList.add(v);
        vCount++;
    }
    read.close();
  }

  /**
   * @brief Class used by the threads to go through the array starting at the point they are assigned, all the 
   * way to the end. As they traverse through they find the maxSum in that array
   */
  static class maxSubArray implements Runnable {
    // The start value for where in the vList array the thread needs to start finding the maximum sum
    private int start = 0;
    /**
     * Constructor for this class that will set the value of start based on the specific thread that is being used
     */
    public maxSubArray(int startOrig) {
      start = startOrig;
    }
    /**
     * Finds the maxSum of the sub-array (decided by start value)
     * @param start is the starat index of the small subarray created from the vList array
     * @return the maximum sum from the subarray
     */
    public int maxNum(int start) {
      int maxSum = vList.get(start);
      int currentSum = 0;
      for (int i = start; i < vCount; i++) {
          currentSum = currentSum + vList.get(i);
          if (currentSum > maxSum) {
              maxSum = currentSum;
          }
      }
      return maxSum;
    }
    /**
     * Run method that will be used (runnable)
     * It is used by the thread to compute the maxSum out of all the subArrays it will be assigned to.
     * The thread is assigned a subarray that increments its' start index by how many workers are wanted
     */
    public void run() {
      int currMax = 0;
      int realMax = 0;
      int threadStart = start;
      while (threadStart < vCount) {
        // Finds the max of one array it is assigned and keeps going through all its assignments
        // It provides the maxSum it could find through all the arrays it checked
        currMax = maxNum(threadStart);
        if (currMax > realMax) {
          realMax = currMax;
        }
        threadStart += workers;
      }
      resultArr.set(start, realMax);
    }
  }

  /**
   * @brief Forks the child workers and creates assignments for them based on how many workers the user specified.
   * Each worker goes through the array and reports back the maxSum it found. All those maxes are then put into an array
   * and the max (out of all of those) is then found.
   * 
   * @param args is the array of command line arguments
   * @return int exit status
  */
  public static void main( String[] args ) {
    boolean report = false;
    try {
      workers = Integer.parseInt(args[0]);
    } catch (Exception e) {
      usage();
      System.exit(1);
    }

    if ( args.length < 1 || args.length > 2 || workers < 1 ) {
      usage();
      System.exit(1);
    }

    // If there's a second argument, it better be the word, report
    if ( args.length == 2 && args[ 1 ].compareTo("report") == 0) {
        report = true;
    }

    readList();

    // ...
    Thread[] thread = new Thread[workers];
    // Creating as many children/workers as the user wants
    for (int i = 0; i < workers; i++) {
      resultArr.add(null);
      thread[i] = new Thread(new maxSubArray(i));
      thread[i].start();
    }

    // Waiting for all the workers to finish
    try{
      for (int i = 0; i < workers; i++) {
        thread[i].join();
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }

    // If the user wants a child report
    for (int i = 0; i < workers; i++) {
      if (report) {
        int threadID = (int) thread[i].getId();
        int workersMaximum = resultArr.get(i);
        System.out.print("I'm thread " + threadID + ". The maximum sum I found is " + workersMaximum + ".\n");
      }
    }

    // Finding the overall maxSum from all the maxSum's that the workers found
    int finalMax = 0;
    Collections.sort(resultArr);
    finalMax = resultArr.get(workers - 1);
    // Printing the finalSum
    System.out.print("Maximum Sum: " + finalMax + "\n");
  }
}
