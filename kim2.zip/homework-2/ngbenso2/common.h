// Height and width of the playing area.
#define GRID_SIZE 5

/** Struct for holding the information of the game board including
 * a diagram, the last move made, and whether a move was made or not 
 */
typedef struct {
    char boardDiagram[ GRID_SIZE ][ GRID_SIZE ];
    int lastMove[ 2 ];
    bool moveMade;
} GameState;