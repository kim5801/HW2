/**
  * @author Natasha Benson
  * @file lightsout.c
  * Opens shared memory segment for the GameState struct and uses the 
  * uploaded information to perform commands that change the GameState
  */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Max number of arguments for move command */
#define MAX_ARGS_MOVE 4
/** Max number of arguments for report and undo */
#define MAX_ARGS_OTHER 2
/** Max number for the row and columns */
#define MAX_RC_NUM 4
/** ASCII to decimal value conversion for numbers */
#define CHAR_TO_DEC 48

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  * Switches the lights on the board
  * 
  * Function based off code in client.c which was completed on 9/15/22
  * @param row row number of selected cell
  * @param col column number of selected cell
  * @param board board containing the diagram of the lights
  */
void switchLights( int row, int col, GameState *board )
{
  // Middle square switch
  board->boardDiagram[ row ][ col ] = board->boardDiagram[ row ][ col ] == '*' ? '.' : '*';
  // Left square switch
  if ( col - 1 > -1 ) {
    board->boardDiagram[ row ][ col - 1 ] = board->boardDiagram[ row ][ col - 1 ] == '*' ? '.' : '*';
  }
  // Right square switch
  if ( col + 1 < GRID_SIZE ) {
    board->boardDiagram[ row ][ col + 1 ] = board->boardDiagram[ row ][ col + 1 ] == '*' ? '.' : '*';
  }
  // Top square switch
  if ( row - 1 > - 1 ) {
    board->boardDiagram[ row - 1 ][ col ] = board->boardDiagram[ row - 1 ][ col ] == '*' ? '.' : '*';
  }
  // Bottom square switch
  if ( row + 1 < GRID_SIZE ) {
    board->boardDiagram[ row + 1 ][ col ] = board->boardDiagram[ row + 1 ][ col ] == '*' ? '.' : '*';
  }
}

/**
  * Opens and attaches the shared memory segment to perform commands
  * and update the game state at the user's request
  * 
  * Function based off code in client.c and server.c which was completed 
  * on 9/15/22
  * @param row row number of selected cell
  * @param col column number of selected cell
  * @param board board containing the diagram of the lights
  * @return exit status
  */
int main( int argc, char *argv[] ) {

  key_t key = ftok( "/afs/unity.ncsu.edu/users/n/ngbenso2", 'a' );
  int shmID = shmget( key, 0, 0 );
  if ( shmID == -1 ) {
    fail( "Can't create shared memory" );
  }
  GameState *sboard = ( GameState * )shmat( shmID, 0 , 0 );
  if ( sboard == ( GameState * )-1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  if ( argc == MAX_ARGS_MOVE && strcmp( argv[ 1 ], "move" ) == 0 && strlen( argv[ MAX_ARGS_OTHER ] ) == 1 
    && strlen( argv[ MAX_ARGS_OTHER + 1 ] ) == 1 ) {
    // Convert char values to decimal values
    int rowVal = argv[ 2 ][ 0 ] - CHAR_TO_DEC;
    int colVal = argv[ 3 ][ 0 ] - CHAR_TO_DEC;
    if ( rowVal < 0 || rowVal > MAX_RC_NUM || colVal < 0 || colVal > MAX_RC_NUM ) {
      fail( "error" );
    } else {
      switchLights( rowVal, colVal, sboard );
      sboard->lastMove[ 0 ] = rowVal;
      sboard->lastMove[ 1 ] = colVal;
      sboard->moveMade = true;
      printf("success\n");
    }
  } else if ( argc == MAX_ARGS_OTHER && strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if ( !sboard->moveMade ) {
      fail( "error" );
    } else {
      // Move is undone and board status for moveMade changed to false
      switchLights( sboard->lastMove[ 0 ], sboard->lastMove[ 1 ], sboard );
      sboard->moveMade = false;
      printf("success\n");
    }
  } else if ( argc == MAX_ARGS_OTHER && strcmp( argv[ 1 ], "report" ) == 0 ) {
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        printf( "%c", sboard->boardDiagram[ i ][ j ] );
      }
      printf( "\n" );
    }
  } else {
    fail( "error" );
  }

  return 0;
}
