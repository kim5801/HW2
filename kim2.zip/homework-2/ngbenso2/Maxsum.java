import java.util.Scanner;

/**
 * Reads in integers and creates a specified number of threads
 * to divide the work for the summation of the integers
 * @author Natasha Benson (ngbenso2)
 */
public class Maxsum {

    /** Starting capacity of array */
    private static final int START_CAPACITY = 5;

    /** Max arg length */
    private static final int ARG_LENGTH = 2;

    /**
     * Creates worker threads and holds information about the maximum sum the thread found,
     * the id number of the thread, and the increments needed for iterating through the array
     */
    static class WorkerThread extends Thread {
        
        /** Maximum sum found by the worker */
        private int maxSum;
        /** Increments for index as thread iterates through the numbers */
        private int increments;
        /** Starting index for integer array */
        private int startIndex;
        /** Numbers in the array */
        private int intCount;
        /** Array of inetgers from file */
        private int[] intArray;
        /** Report flag */
        private boolean report;

        /**
         * Worker thread consturctor the Initialzes the needed values for the integer
         * summations and report
         * @param workers number of specified workers
         * @param start starting index for summation
         * @param numCount numbers in integer array
         * @param intArray  integer array
         * @param status report status
         * @return new worker thread
         */
        public WorkerThread (int workers, int start, int numCount, int[] intArray, boolean status) {
            increments = workers;
            startIndex = start;
            intCount = numCount;
            this.intArray = intArray;
            report = status;
        }

        /**
         * Returns maximum sum found by thread
         * @return calculated maximum sum
         */
        public int getMax(){
            return maxSum;
        }

        /*
         * Runs summation algorithm and prints report of its ID and max sum when finished
         */
        public void run() {
            int max = 0;
            while (startIndex <= intCount) {
                int sum = 0;
                for (int i = startIndex; i < intCount; i++) {
                  sum += intArray[ i ];
                  max = sum > max ? sum : max;
                }
                startIndex += increments; // Moves to next assigned index for the worker
            }
            if (report) {
                System.out.println("I am thread " + getId() + ". The maximum sum I found is " + max + ".");
            }
            maxSum = max;
        }
    }

    /**
     * Doubles the capacity of the specified array
     * @param oldArray array that will double in size
     * @return new array with twice the capacity
     */
    public static int[] growArray(int[] oldArray) {
        int[] newArray = new int[oldArray.length * 2];
        for (int i = 0; i < oldArray.length; i++) {
            newArray[i] = oldArray[i];
        }
        return newArray;
    }
    
    /**
     * Reads numbers from the directed input
     * @return array holding the integers
     */
    public static int[] readNumbers() {
        int capacity = START_CAPACITY;
        int[] array = new int[capacity];
        Scanner scan = new Scanner(System.in);
        boolean end = false;
        int i = 0;
        // Scans until no more integers are found
        while (!end) {
            if (i >= capacity) {
                array = growArray(array);
                capacity *= ARG_LENGTH;
            }
            try {
                array[i++] = scan.nextInt();
            } catch (Exception e) {
                end = true;
            }
        }
        scan.close();
        return array;
    }
    
    /**
     * Creates the worker threads and prints report of the maximum sums found
     * by each worker
     * @param args command line arguments
     */
    public static void main (String args[]) {
        
        // Checks for the appropraite number of arguments and place of report flag
        if (args.length < 1 || args.length > ARG_LENGTH || args[0].equals("report")) {
            System.out.print("usage: maxsum <workers>\n" + "       maxsum <workers> report\n");
            System.exit(1);
        }

        // Ensures worker number is valid
        if (args.length == ARG_LENGTH && Integer.valueOf(args[0]) < 0) {
            System.out.print("usage: maxsum <workers>\n" + "       maxsum <workers> report\n");
            System.exit(1);
        }

        boolean report = false;
        if ( args.length > 1 && args[1].equals("report")) {
            report = true;
        }

        int[] intArray = readNumbers();
        int intCount = intArray.length;
        int workers = Integer.valueOf(args[0]);

        int[] maxSums = new int[workers];
        // Creates the specified number of worker threads and each calculates sums for specific index ranges
        WorkerThread[] workThreads = new WorkerThread[workers];
        for (int i = 0; i < workers; i++) {
            workThreads[i] = new WorkerThread(workers, i, intCount, intArray, report);
            workThreads[i].start();
        }
        // Joins threads and collects final maxes from each
        for (int i = 0; i < workers; i++) {
            try {
                workThreads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            maxSums[i] = workThreads[i].getMax();
        }
        int finalMax = maxSums[0];
        for (int i = 0; i < workers; i++) {
            finalMax = maxSums[i] > finalMax ? maxSums[i] : finalMax;
        }
        System.out.println("Maximum Sum: " + finalMax);
    }
}