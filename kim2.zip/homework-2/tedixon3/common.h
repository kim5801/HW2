// Height and width of the playing area.
#define GRID_SIZE 5


typedef struct GameState{
  char board[5][5];
  int lastR;
  int lastC;
  int numMoves;
} GameState;