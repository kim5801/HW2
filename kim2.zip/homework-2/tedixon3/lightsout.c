#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}







void report(GameState *game) {
  for(int i = 0; i < 5; i++) {
    printf("%c%c%c%c%c\n", game->board[i][0], game->board[i][1], game->board[i][2], game->board[i][3], game->board[i][4]);
  }
}

char flipOne (char c) {
  if (c == '.') {
    return '*';
  } else {
    return '.';
  }
}

void flip(GameState *game, int r, int c) {
  if (r == 0) {
    if (c == 0) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
      return;
    } else if (c == 4) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
      return;
    } else {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
      return;
    }
  } else if (r == 4) {
    if (c == 0) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
      return;
    } else if (c == 4) {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
      return;
    } else {
      game->board[r][c] = flipOne(game->board[r][c]);
      game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
      game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
      game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
      return;
    }
  }

  if (c == 0) {
    game->board[r][c] = flipOne(game->board[r][c]);
    game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
    game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
    game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
    return;
  } else if (c == 4) {
    game->board[r][c] = flipOne(game->board[r][c]);
    game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
    game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
    game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
    return;
  } else {
    game->board[r][c] = flipOne(game->board[r][c]);
    game->board[r - 1][c] = flipOne(game->board[r - 1][c]);
    game->board[r + 1][c] = flipOne(game->board[r + 1][c]);
    game->board[r][c - 1] = flipOne(game->board[r][c - 1]);
    game->board[r][c + 1] = flipOne(game->board[r][c + 1]);
    return;
  }
}



void undo(GameState *game) {
  flip(game, game->lastR, game->lastC);
}




int main( int argc, char *argv[] ) {

  // int key = ftok("/afs/unity.ncsu.edu/users/t/tedixon3", 69420);

  int shmid;
  GameState *game;
  shmid = shmget(ftok("/afs/unity.ncsu.edu/users/t/tedixon3", 4), sizeof(GameState), 0644);
  if (shmid == -1) {
    fail("Could not create shared memory.");
  }

  game = (GameState *)shmat(shmid, 0, 0);
  if (game == (void *) -1) {
    fail("Could not attach shared memory.");
  }

  if (argc > 4 || argc == 1) fail("error");

  if (strcmp("undo", argv[1]) == 0) {
    if (game->numMoves < 1) fail("error");
    undo(game);
  } else if (strcmp("report", argv[1]) == 0) {
    report(game);
  } else if (strcmp("move", argv[1]) == 0) {
    if (!isdigit(*argv[2]) || !isdigit(*argv[3])) fail("error");
    int r = *argv[2] - '0';
    int c = *argv[3] - '0';
    if (r < 0 || r > 4|| c < 0 || c > 4) fail("error");
    flip(game, r, c);
    game->lastR = r;
    game->lastC = c;
    printf("success\n");
    game->numMoves++;
    return EXIT_SUCCESS;

  } else {
    fail("error");
  }
  





  return 0;
}
