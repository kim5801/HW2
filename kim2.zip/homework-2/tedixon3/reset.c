#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}



// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}


int main( int argc, char *argv[] ) {

  if (argc != 2) {
    usage();
  }

  // int key = ftok("/afs/unity.ncsu.edu/users/t/tedixon3", 69420);

  int shmid;
  GameState *game;
  shmid = shmget(ftok("/afs/unity.ncsu.edu/users/t/tedixon3", 4), sizeof(GameState), IPC_CREAT | 0666);
  if (shmid == -1) {
    fail("Could not create shared memory.");
  }

  game = (GameState *)shmat(shmid, 0, 0);
  if (game == (void *) -1) {
    fail("Could not attach shared memory.");
  }

  FILE *stream = fopen(argv[1], "r");
  if (!stream) {
    fprintf(stderr, "Invalid input file: %s", argv[1]);
    exit(1);
  }
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      char c = fgetc(stream);
      if (c != '\n' && c != '.' && c != '*') fprintf(stderr, "Invalid input file: %s", argv[1]);
      if (c == '\n') c = fgetc(stream);
      game->board[i][j] = c;
    }
  }
  game->numMoves = 0;



  return 0;
}



