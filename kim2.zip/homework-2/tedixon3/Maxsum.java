import java.lang.Thread;
import java.lang.Runnable;
import java.util.Scanner;
import java.util.ArrayList;





public class Maxsum {

  public static ArrayList<Integer> values;

  static class checker extends Thread {

    private boolean report;
    private int start;
    private int end;
    public int max;

    public checker(boolean report, int start, int end) {
      this.report = report;
      this.start = start;
      this.end = end;
    }

    // public int getMax() {
    //   return max;
    // }

    public void run() {
      
      boolean maxA = false;
      
      for (int i = start; i < end; i++) {
        int temp = values.get(i);
        boolean tempA = false;
        for (int j = i; j < values.size(); j++) {
          
          
          if (!tempA || i == j) {
            temp = values.get(i);
            tempA = true;
          } else {
            temp += values.get(j);
          }



          if (tempA && (!maxA || temp > max)) {
            max = temp;
            maxA = true;
          }
        }
        
      }
      if (report) System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", Thread.currentThread().getId(), max);
    }
  }



  public static void main(String[] args) {

    Scanner scnr = new Scanner(System.in);
    int workers = Integer.parseInt(args[0]);
    boolean report = "report".equals(args[1]);
    values = new ArrayList<Integer>();
    
    while (scnr.hasNext()) {
      values.add(scnr.nextInt());
    }

    // int numValues = values.size();
    int limit = values.size() / workers;
    int extra = values.size() % workers;

    checker[] threads = new checker[workers];

    // int tempMax;
    int max = values.get(0);
    boolean maxA = false;

    boolean even = (values.size() % workers == 0);

    for (int h = 0; h < workers; h++) {

      if (!even && h == workers - 1) {
        threads[h] = new checker(report, h * limit, (h + 1) * limit + extra);
      } else {
        threads[h] = new checker(report, h * limit, (h + 1) * limit);
      }
      
      threads[h].start();
      

      try {
        threads[h].join();
      } catch (InterruptedException e) {
        System.out.println("Interruped during join!");
      }

      if (!maxA || threads[h].max > max) {
        max = threads[h].max;
        maxA = true;
      }
      
    }
    System.out.printf("Maximum Sum: %d\n", max);
  }

}


