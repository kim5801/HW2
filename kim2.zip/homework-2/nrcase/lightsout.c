#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <ctype.h>

/**
 * @brief Id of the global memory
 */
int shmid;
/**
 * @brief Game state pointer that will 
 * point to the GameState object that will be in shared memory
 */
GameState *state;

// Print out an error message and exit. Written by Dr. Sturgill
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Replaces the current 
 * board with the board that was saved
 * previously
 */
static void restoreBoard() {
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    { // just replace the board with board that was saved previously
      state->board[i][j] = state->previous[i][j];
    }
  }
}

/**
 * @brief Saves the current board to
 * the global variable of the previous board, used for undo
 */
static void savePrevious()
{
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      state->previous[i][j] = state->board[i][j];
    }
  }
}

/**
 * @brief Takes in two coordinates and then checks
 * that location and switches the symbol there
 *
 * @param x the x coordinate
 * @param y the y coordinate
 */
static void switchToOther(int x, int y)
{
  if (state->board[x][y] == '*')
  {
    state->board[x][y] = '.';
  }
  else if (state->board[x][y] == '.')
  {
    state->board[x][y] = '*';
  }
}

/**
 * @brief Checks to see if the up, down, middle, right and center
 * are valid spaces in the board and turns them on if they are.
 *
 * @param x the x coordinate
 * @param y the y coordinate
 */
static void turnOn(int x, int y)
{ // 0-4 are valid values
  if ((x >= 0 && x < 5) && (y >= 0 && y < 5))
  { // middle
    switchToOther(x, y);
  }
  if (x + 1 <= 4)
  { // checking right
    switchToOther(x + 1, y);
  }
  if (x - 1 >= 0)
  { // checking left
    switchToOther(x - 1, y);
  }
  if (y + 1 <= 4)
  { // checking up
    switchToOther(x, y + 1);
  }
  if (y - 1 >= 0)
  { // checking down
    switchToOther(x, y - 1);
  }
}

int main( int argc, char *argv[] ) {

  //opening the shared memory
  shmid = shmget(ftok("/afs/unity.ncsu.edu/users/n/nrcase", 0), 0, 0);
  if (shmid == -1) // Written by Dr. Sturgill
    fail("Can't create shared memory");

  state = (GameState *)shmat(shmid, 0, 0); // map address

  if (state == (GameState *)-1) //checking if can map
    fail("Can't map shared memory segment into address space"); // Written by Dr. Sturgill

  // checking the first argument
  if (strcmp(argv[1], "move") == 0)
  {
    // start of all the error checking
    if (argc != 4)
    {
      fail("error");
    }
    if (!isdigit(argv[2][0]))
    {
      fail("error");
    }
    if (!isdigit(argv[3][0]))
    {
      fail("error");
    }
    if (atoi(argv[2]) < 0 || atoi(argv[2]) > 4)
    {
      fail("error");
    }
    if (atoi(argv[3]) < 0 || atoi(argv[3]) > 4)
    {
      fail("error");
    }

    state->canUndo = true; //can now do undo after doing a move
    int x = atoi(argv[2]); //third arg is the x
    int y = atoi(argv[3]); //fourth arg is the y
    
    savePrevious(); //save the previous board state

    turnOn(x, y); // do the moves
    printf("success\n");
  }
  else if (strcmp(argv[1], "undo") == 0)
  {
    if (!(state->canUndo)) { //checks if can do undo
      printf("error\n");
      return EXIT_FAILURE;
    }
    state->canUndo = false; //make sure no undo 2 in a row
    restoreBoard(); //restore the board
    printf("success\n");
  }
  else if (strcmp(argv[1], "report") == 0)
  {
    for (int i = 0; i < GRID_SIZE; i++)                // printing line by line
    {
      for (int j = 0; j < GRID_SIZE; j++) {
        printf("%c", state->board[i][j]);
      }
      putchar('\n');
    }
    putchar('\n');
  }
  else
  {
    printf("error\n"); // if does fit any of the above commands, error out and return;
    return EXIT_FAILURE;
  }

  shmdt(state); //release the pointer
  //keeps the memory, but releases the pointer.
  //will get the pointer again with shmgetv

  return EXIT_SUCCESS;
}
