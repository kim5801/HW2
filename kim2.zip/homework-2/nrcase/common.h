// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * @brief Struct to define the game state
 * this is what is in shared memory
 */
struct {
    char board[GRID_SIZE][GRID_SIZE];
    char previous[GRID_SIZE][GRID_SIZE];
    bool canUndo;
} typedef GameState;
