#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit. Written by Dr. Sturgill
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit. Written by Dr. Sturgill
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int shmid;
GameState *state;

/**
 * @brief Method that creates the board from the input file
 *
 * @param board the board to fill
 * @param filename the filename to get from
 */
static void initalBoard(char board[GRID_SIZE][GRID_SIZE], char *filename)
{
  FILE *input = fopen(filename, "r");

  if (input == NULL) {
    printf("Invalid input file: %s\n", filename); // error
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      int c = fgetc(input);
      if (c != '.' && c != '*' && c != '\n' && c != ' ') // if the char is not something we have in input files
      {
        printf("Invalid input file: %s\n", filename); // error
        exit(EXIT_FAILURE);
      }
      if (c == '\n' || c < 32) // if it is a new line or space, skip it and go back a iteration of the loop
      {
        j--;
        continue;
      }
      board[i][j] = c; // set char to be in the array
    }
  }
}

int main( int argc, char *argv[] ) {

  if (argc != 2) { //making sure args are right
    usage();
  }

  shmid = shmget(ftok("/afs/unity.ncsu.edu/users/n/nrcase", 0), sizeof(GameState), 0666 | IPC_CREAT); //make id 

  if (shmid == -1) //checking that can create the memory
    fail("Can't create shared memory");

  state = (GameState *) shmat(shmid, 0, 0); //map address

  if ( state == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  initalBoard(state->board, argv[1]); //initialize the board
  state->canUndo = false; //set the global canUndo to false to start

  return EXIT_SUCCESS;
}
