import java.util.ArrayList;
import java.util.Scanner;

/**
 * Maxsum class that holds all the functionality for maxsum program
 */
public class Maxsum {
    /**
     * method to provide failure messages, provided from Dr. Sturgill
     */
    private static void fail(String message) {
        System.err.println(message);
        System.exit(1); // 1 is failure
    }

    /**
     * Method to provide when wrong usage of the arguments, provided from
     * Dr.Sturgill
     */
    private static void usage() {
        System.out.println("usage: maxsum <workers>");
        System.out.println("       maxsum <workers> report");
        System.exit(1);
    }

    /**
     * ArrayList to hold the values that are being read in
     */
    static ArrayList<Integer> list = new ArrayList<Integer>();
    // vCount is list.length
    // vcap don't need
    static int workers = 4; // number of workers to start and variable to change
    static boolean report = false; // whether report is needed, is checked later in main

    /**
     * Reads in the list from stdin and adds it to the list
     */
    private static void readList() {
        Scanner input = new Scanner(System.in);
        while (input.hasNextInt()) {
            int var = input.nextInt();
            list.add(var);
        }
        input.close();
    }

    /**
     * Static inner class that is the threads for this program
     * Contains class variables, constructor and start method
     * that provides functionality of the threads.
     */
    static class Worker extends Thread {
        int endMax;
        int startPlace;

        public Worker(int startP) {
            this.startPlace = startP;
        }

        @Override
        public void start() {
            int max = 0;
            endMax = list.get(0);
            for (int i = startPlace; i < list.size(); i = i + workers) {
                for (int j = i; j < list.size(); j++) {
                    max += list.get(j);
                    if (max > endMax) {
                        endMax = max;
                    }
                }
                max = 0;
            }

            if (report) {
                System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + endMax + ". ");
            }
        }

        /**
         * Getter that gets the endMax of each worker to compare, just doing the dot
         * notation is so messy
         */
        public int getEndMax() {
            return endMax;
        }
    }

    /**
     * Main method that runs the maxsum program, checking for correct usage and then
     * creating workers
     * and finding the maxsum
     */
    public static void main(String args[]) {
        report = false;

        // System.out.println(args.length); // length is 2 with all, 1 with just worker
        // num
        // System.out.println(args[0]); //number of workers
        // System.out.println(args[1]); //report or no report

        if (args.length < 1 || args.length > 2) { // check for right arguments
            usage();
        }

        if (args.length == 2) { // if should contain report, check that actually report and then set var
            if (!(args[1].equals("report"))) {
                usage();
            }
            report = true;
        }
        try {
            workers = Integer.parseInt(args[0]); // parsing number of workers, if fail, print usage
        } catch (NumberFormatException e) {
            usage();
        }

        if (workers < 1) { // checking for right number of workers, can't have 0 or negative
            usage();
        }

        readList(); // reads the list in

        if (workers > list.size()) { // error checking
            fail("More workers than values");
        }

        ArrayList<Worker> workersList = new ArrayList<Worker>(); // ArrayList for the workers

        for (int i = 0; i < workers; i++) { // create and instantiate all the workers
            workersList.add(new Worker(i));
        }

        for (int i = 0; i < workers; i++) { // start all the workers
            workersList.get(i).start();
        }

        for (int i = 0; i < workers; i++) { // waits for all the workers to end
            try {
                workersList.get(i).join();
            } catch (InterruptedException e) {
                System.err.println("Interrupted while joining with " + i);
            }
        }
        int totalMax = workersList.get(0).getEndMax();
        for (int i = 0; i < workers; i++) { // finds the total max of all the workers by accessing their class variables
                                            // and comparing them.
            if (totalMax < workersList.get(i).getEndMax()) {
                totalMax = workersList.get(i).getEndMax();
            }
        }

        System.out.println("Maximum Sum: " + totalMax);
    }
}
