#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Required number of arguments for 'move' command */
#define MOVE_NUM_ARGS 4

/** Number of arguments for 'undo' and 'report' commands */
#define NUM_ARGS 2

/** row number argv index for 'move' command */
#define ROW_IDX 2 

/** col number argv index for 'move' command */
#define COL_IDX 3

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
* Change the char at the specified index
* in the board as well as adjacent chars
*
* @param game pointer the GameState struct in shared memory
* @param row index of the row in the board
* @param col index of the column in the board
*/
static void move( GameState *game, int row, int col ) 
{

  for ( int i = row - 1; i <= row + 1; i++ ) {

    //Flip "on/off" at the named index,
    //the index above (if in bounds), and
    //the index below (if in bounds) 

    if ( i >= 0 && i < GRID_SIZE ) { //Bound check
      if ( game->cells[ i ][ col ] == '.' ) {
        game->cells[ i ][ col ] = '*'; //Switch on
      }
      else {
        game->cells[ i ][ col ] = '.'; //Switch off
      }
    }
  }

  for ( int i = col - 1; i <= col + 1; i += 2 ) {

    //Flip "on/off" at the left and
    //the right of the named index
    //if they are in bounds

    if ( i >= 0 && i < GRID_SIZE ) { //Bound check
      if ( game->cells[ row ][ i ] == '.' ) {
        game->cells[ row ][ i ] = '*'; //Switch on
      }
      else {
        game->cells[ row ][ i ] = '.'; //Switch off
      }
    }
  }
}

/**
* Access the shared memory created by reset.c and 
* handle a game-related command by parsing command line arguments
* 
* @param argc Number of command line arguments
* @param argv Array of command line arguments
* @return 1 upon successful execution
*/
int main( int argc, char *argv[] ) {

  //Access shared memory
  key_t key = ftok( SHM_PATH, 0 );
  int shmid = shmget( key, sizeof( GameState ), 0 );

  //Create a pointer to the shared memory
  GameState *game = ( GameState * ) shmat( shmid, 0, 0 );

  if ( strcmp( argv[ 1 ], "move" ) == 0 ) { //"move" command

    if ( argc != MOVE_NUM_ARGS ) { 
      //Invalid number of command line args
      fail("error");
    }

    //Check for valid row and column indeces
    int row = 0;
    int col = 0;
    int rmatch = sscanf( argv[ ROW_IDX ], "%d", &row );
    int cmatch = sscanf( argv[ COL_IDX ], "%d", &col );

    if ( !rmatch || !cmatch ) {
      //Not an integer
      fail("error");
    }
    else if ( row < 0 || col < 0 ) {
      //Negative index
      fail("error");
    }
    else if ( row >= GRID_SIZE || col >= GRID_SIZE ) {
      //Index too large
      fail("error");
    }
    else {
      //Command is valid

      //Initialize/update the previous state of the board
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        strcpy( game->prev[ i ], game->cells[ i ] );
      }

      //Helper method will handle "flipping" the chars
      move( game, row, col );

      //User can undo this move
      game->flag = 1;

      printf( "success\n" ); //Move was successful
    }
  } 
  else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) { //"undo" command

    if ( argc != NUM_ARGS ) {
      //Invalid number of command line args
      fail("error");
    }

    if ( game->flag ) {

      //Copy the previous state to the current state
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        strcpy( game->cells[ i ], game->prev[ i ] );
      }

      //Cannot undo twice in a row
      game->flag = 0;

      printf( "success\n" ); //Undo was successful
    }
    else {
      printf( "error\n" ); //Undo was not successful
    }
  }
  else if ( strcmp( argv[ 1 ], "report" ) == 0 ) { //"report" command

    if ( argc != NUM_ARGS ) {
      //Invalid number of command line args
      fail( "error" );
    }
    else {

      //Print out the game board char by char
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          printf( "%c", game->cells[ i ][ j ] );
        }
        printf( "\n" );
      }

    }
  }
  else { //Invalid command
    fail( "error" );
  }

  return 0;
}
