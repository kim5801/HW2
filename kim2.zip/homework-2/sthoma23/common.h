/** Height and width of the playing area. */
#define GRID_SIZE 5

/** Default max size for a general message */
#define MESSAGE_LIMIT 1024

/** Path for shared memory */
#define SHM_PATH "/afs/unity.ncsu.edu/users/s/sthoma23"

#ifndef GAMESTATE
#define GAMESTATE

/**
* Struct holding current state of the board,
* previous state, and a flag indicating whether
* the last move can be undone
*/
typedef struct GameState
{
  char cells[ GRID_SIZE ][ GRID_SIZE ];
  char prev[ GRID_SIZE ][ GRID_SIZE ];
  int flag;
} GameState;

#endif