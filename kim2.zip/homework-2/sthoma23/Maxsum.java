import java.util.Scanner;

/**
* Take a series of integers from input and find the largest 
* sum that can be made by adding the numbers sequentially
*/
public class Maxsum {

  /** Initial capacity for the buffer reading in numbers */
  private static final int INIT_CAP = 10;

  /**
  * Private class of a Thread object which gets used
  * like a worker
  */
  private static class Worker extends Thread {
    
    /** Maximum value found in the list of integers */
    public int maxsum;

    /** Array of integers being traversed */
    private int[] list;

    /** Index to start searching from */
    private int idx;

    /** Number of workers being used */
    private int workers;

    /** Whether 'report' was specified in command line */
    private boolean report;
    
    /** 
    * Make a new Thread and initialize private fields
    *
    * @param list Array of integers being traversed
    * @param idx Index to start searching from
    * @param workers Number of workers being used
    * @param report Whether 'report' was specified in command line
    */
    public Worker(int[] list, int idx, int workers, boolean report) {
      this.maxsum = 0;
      this.list = list;
      this.idx = idx;
      this.workers = workers;
      this.report = report;
    }

    /**
    * Search through the provided list at certain indeces and find 
    * a maximum sum
    */
    public void run() {
      int size = list.length;
      if ( size > workers ) { 

        //Make sure each worker gets an equal workload
        for ( int i = 0; i < size / workers; i++ ) {
          int sum = 0;
          int start = idx + ( i * workers ); //Index in list to start at

          for ( int x = start; x < size; x++ ) { 
            //Start at assigned index and continue to the end
            sum += list[x];

            if (maxsum < sum) {
              //A larger sum has been found!
              maxsum = sum;
            }
          }
        }
      }
      else if (idx < size) { //Prevent looking out of bounds

        //( workers >= size ) == true , so workers can just
        //get one task each (until there are no more indeces)

        int sum = 0;
        for ( int j = idx; j < size; j++ ) {   

          //Just keep assigning one start index
          //to each worker until we run out of 
          //indeces in list

          sum += list[ j ];
          if ( maxsum < sum ) {

            //A larger sum has been found!
            maxsum = sum;
          }
        }
      }

      //Report thread id and the maxsum that this thread found
      if (report) {
        System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + this.maxsum + ".");
      }

    }
  }

  /**
  * Handle bad command line input
  */
  private static void usage() {
    System.out.print( "usage: maxsum <workers>\n" );
    System.out.print( "       maxsum <workers> report\n" );
    System.exit(1);
  }

  /**
  * Read the list of numbers from the input which
  * has been redirected to an text file
  *
  * @return integer values provided in the text file
  */
  private static int[] readList() {

    // Set up initial list and capacity.
    int cap = INIT_CAP;
    int[] buffer = new int[cap];

    //Create scanner to read in the input
    Scanner scnr = new Scanner(System.in);

    
    int val = 0; //Hold the most recent value taken from file
    int count = 0; //Number of integers found in the file

    //Keep reading as many values as we can.
    while (scnr.hasNextInt()) {

      //Get the next integer
      val = scnr.nextInt();

      // Grow the list if needed.
      if (count >= buffer.length) {
        cap += cap;
        int[] newBuffer = new int[cap];
        for (int i = 0; i < buffer.length; i++) {
          newBuffer[i] = buffer[i];
        }
        buffer = newBuffer;
      }

      // Store the latest value in the next array slot.
      buffer[count++] = val;
    }

    //Create an array that is the perfect size for holding all the values
    //This will allow list.length to give the number of values no matter 
    //where we are in this program
    int[] list = new int[count];

    //Copy everything from buffer to the new 
    for (int i = 0; i < count; i++) {
      list[i] = buffer[i];
    }

    //Return array of provided integers
    return list;
  }

  /**
  * Accept and handle command line arguments, create 
  * the specified number of threads, and report the
  * absolute maximum found in the provided integer array
  *
  * @param args Command line arguments
  */
  public static void main(String[] args) {

    // Parse command-line arguments.
    if (args.length < 1 || args.length > 2) {
      usage();
    }

    //Declare workers variable
    int workers = 0;

    try { 
      
      //Get the number of workers from the command line
      workers = Integer.parseInt(args[0]);

    } catch (NullPointerException e) {
      usage(); //Make sure that command arguments are provided
    } catch (NumberFormatException e) {
      usage(); //Make sure the first argument is an integer
    }

    //Need at least 1 worker
    if (workers < 1) {
      usage();
    }

    //Boolean value indicating whether 'report' was specified in command line
    boolean report = false;

    // If there's a second argument, it better be the word, report
    if ( args.length == 2 ) {
      if ( !(args[1]).equals("report") ) {
        usage();
      }
      report = true;
    }

    //Read list of integers from the input file
    int[] list = readList(); 

    //Create array of worker objects
    //and declare the workers
    Worker[] thread = new Worker[workers];

    //Create n amount of worker threads
    for ( int i = 0; i < thread.length; i++ ) {
      thread[ i ] = new Worker(list, i, workers, report); //Initialize thread
      thread[ i ].start(); //Run the thread
    }

    //Variable to hold max of thread maximums
    int max = 0;

    // Wait for each of the threads to terminate.
    try {
      for (int i = 0; i < thread.length; i++) {

        thread[ i ].join(); //End the thread

        //Compare current maximum to the max of recent thread
        if (max < thread[i].maxsum) {

          //Take the maxsum the thread found
          max = thread[i].maxsum;
        }

      }
    } catch (InterruptedException e) {

      //Something went wrong and thread could't join 
      System.out.println( "Interrupted during join!" );
      System.exit(1);
    }

    //Report absolute maximum
    System.out.println("Maximum Sum: " + max);

  }
}