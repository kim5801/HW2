#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// returns a string representation of the board ready for printing, takes in the
// board to print and a malloced string to be stored in
char *boardToString(struct gameState *gs, char *str)
{
    for (size_t i = 0; i < GRID_SIZE; i++) {
        strncat(str, gs->board[i], GRID_SIZE);
        strncat(str, "\n", 1);
    }
    str[31] = '\0'; // sets the null terminator of the string
    return str;
}

// helper function to swap a char from '*' to '.' and vis versa
void swapChar(char *swapee)
{
    if (*swapee == '.') {
        *swapee = '*';
    } else {
        *swapee = '.';
    }
}

// performs a move operation on the specified row and col on the board in the si
// param
void move(struct gameState *gs, int r, int c)
{
  // printf("r: %d, c: %d\n", r, c);
    if (r > 0) {
        swapChar(&(gs->board[r - 1][c]));
    }
    if (r < 4) {
        swapChar(&(gs->board[r + 1][c]));
    }
    if (c > 0) {
        swapChar(&(gs->board[r][c - 1]));
    }
    if (c < 4) {
        swapChar(&(gs->board[r][c + 1]));
    }
    swapChar(&(gs->board[r][c]));
    gs->lastMove[0] = r;
    gs->lastMove[1] = c;
}

int main(int argc, char *argv[])
{

    // attempts to get the shared memory
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/aecada2", 0), sizeof(struct gameState), 0);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }
    struct gameState *sbuffer = (struct gameState *)shmat(shmid, 0, 0);

    if (argc < 2 || argc > 4) { // fail if wrong number of args
        shmdt(sbuffer);
        fail("error");
    }

    // Move command:
    if (strcmp(argv[1], "move") == 0) {
        if (argc !=
            4) { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }

        // ensures that the indices are in a valid range
        if (*(argv[2]) < '0' || *(argv[2]) > '4' || *(argv[3]) < '0' ||
            *(argv[3]) > '4') {
            shmdt(sbuffer);
            fail("error");
        }

        // makes the move at that location
        move(sbuffer, (int)(*argv[2] - '0'), (int)(*argv[3] - '0'));

        sbuffer->undoOk = true; // you can now undo
        printf("success\n");

        // Undo command:
    } else if (strcmp(argv[1], "undo") == 0) { // undo command: sends "u"
        if (argc !=
            2) { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }
        if (sbuffer->undoOk) { // if you're allowed to undo move at the location
                               // of the last move and then set undoOk to false
            move(sbuffer, sbuffer->lastMove[0], sbuffer->lastMove[1]);
            sbuffer->undoOk = false;
            printf("success\n");
        } else { // if you arent allowed to undo right now, fail
            fail("error");
        }

        // Report command:
    } else if (strcmp(argv[1], "report") == 0) {
        if (argc !=
            2) { // checks if you have the right number of args for the command
            shmdt(sbuffer);
            fail("error");
        }

        // string to contain the board to print
        char boardStr[(GRID_SIZE) * (GRID_SIZE + 1) + 1];
        // puts the correct board string into the board
        boardToString(sbuffer, boardStr);
        // prints the board
        printf("%s", boardStr);

    } else { // if not a valid command, fail
        shmdt(sbuffer);
        fail("error");
    }

    shmdt(sbuffer);
    return 0;
}
