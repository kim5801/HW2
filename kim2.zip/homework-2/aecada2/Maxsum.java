import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum { // class header

    /** calculate a set of numbers. */
    static class CalcThread extends Thread implements Runnable {

        int threadCount; // field to keep track of the count of threads
        ArrayList<Integer> values; // a list of the values to count through
        int thisThread; // the value of this thread, used for indexing
        boolean report; // if to report its findings or not
        int maxSum = 0; // the max sume to calculate

        // constructor for calcThread that takes in an int for the total count of
        // threads
        // it also takes in a reference to the values list, an int of which thread it is
        // and if to report or not
        CalcThread(int threadCount, ArrayList<Integer> values, int thisThread, boolean report) {
            this.threadCount = threadCount;
            this.values = values;
            this.thisThread = thisThread;
            this.report = report;
        }

        public void run() {
            // functionality for finding the sum for each offsetted
            // index
            for (int i = thisThread; i < values.size(); i += threadCount) {
                int sum = 0;
                for (int j = i; j < values.size(); j++) { // cycles through the rest of the list at varying lengths
                    if (j < values.size()) {
                        sum += values.get(j);
                        // if the newest found sum > the max sum found so
                        // far then set it = to that OR if a sum has not
                        // been found yet then set it
                        if (sum > maxSum || maxSum == -1) {
                            maxSum = sum;
                        }
                    }
                }
            }

            if (report) {
                System.out.println(
                        "I'm thread " + Integer.toString(thisThread) + ". The maximum sum I found is " + maxSum + ".");
            }
        }

        public int getMaxSum() {
            return maxSum;
        }
    }

    public static void main(String[] args) { // main function
        boolean report = false; // if you should report the thread's fomdomgs or not
        final int threadCount = Integer.parseInt(args[0]); // the number of threads to create
        int maxSum = -1;

        if (args[1].equals("report")) {
            report = true;
        }

        ArrayList<Integer> values = new ArrayList<Integer>();

        java.util.Scanner input = new Scanner(System.in); // scanner to read in the input

        input.useDelimiter("\n");// sets the delimiter to get each number
        while (input.hasNextInt()) { // reads in all the values into values arraylist
            values.add(input.nextInt());
        }

        CalcThread threads[] = new CalcThread[threadCount];

        for (int i = 0; i < threadCount; i++) { // creates an array of the threads to use
            threads[i] = new CalcThread(threadCount, values, i, report);
            threads[i].start(); // starts each thread
        }

        try { // joins each thread
            for (int index = 0; index < threadCount; index++) {
                threads[index].join();
            }
        } catch (Exception e) {
            System.out.println("Interrupted during join!");
        }

        for (int i = 0; i < threadCount; i++) {// checks each thread's found sum agains the maxSum variable
            int threadSum = threads[i].getMaxSum();
            if (threadSum > maxSum || maxSum == -1) {
                maxSum = threadSum;
            }
        }

        System.out.println("Maximum Sum: " + Integer.toString(maxSum));
        input.close();
    } // end of main
} // end of class header
