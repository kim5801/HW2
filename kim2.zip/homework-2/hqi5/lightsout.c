#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

int main( int argc, char *argv[] ) {


    //uses unique generated key by path to home directory
    key_t key = ftok("/afs/unity.ncsu.edu/users/h/hqi5", 1);
    //key_t key = ftok("C:/Users/Hongwei Qi", 1);
    if(key == -1){
        fail("Cannot create ftok key");
    }



    // make a shared memory segment
    int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);

    //casts the pointer to a gamestate
    GameState *board = (GameState *)shmat(shmid, 0, 0);
    if(board == (GameState *) -1){
        fail("Cannot map shared memory into address space");
    }

    //no board loaded = error
    if(board->flag != 1){
        fail("error");
    }

    //report command, just prints, no additional checks
    if(strcmp(argv[1], "report") == 0 && argc == 2){
        //prints the board
        for(int i = 0; i < GRID_SIZE; i++){
            for(int j = 0; j < GRID_SIZE; j++){
                fprintf(stdout, "%c", board->board[i][j]);
            }
            fprintf(stdout, "\n");
        }
    }
    //move command, checks for the next two to be integers
    else if(strcmp(argv[1], "move") == 0 && argc == 4){

        //assign row and col to variables
        char *rowSC= argv[2];
        char *columnSC = argv[3];

        if(strcmp(rowSC, "0") == 0 || strcmp(rowSC, "1") == 0 ||
                strcmp(rowSC, "2") == 0 || strcmp(rowSC, "3") == 0
                || strcmp(rowSC, "4") == 0){
            //do nothing
        }
        else{
            fail("error");
        }

        char rowS = rowSC[0];
        char columnS = columnSC[0];

        //checks row col for validity
        if(rowS >= '0' && rowS <= '4' && columnS >= '0' && columnS <= '4'){
            //converts row and column into integers

            int row = rowS - '0';
            int column = columnS - '0';

            //flips middle
            if(board->board[row][column] == '*'){
                board->board[row][column] = '.';
            }
            else{
                board->board[row][column] = '*';
            }

            //flips top
            if(row - 1 >= 0){
                if(board->board[row - 1][column] == '*'){
                    board->board[row - 1][column] = '.';
                }
                else{
                    board->board[row - 1][column] = '*';
                }
            }
            //flips left
            if(column - 1 >= 0){
                if(board->board[row][column - 1] == '*'){
                    board->board[row][column - 1] = '.';
                }
                else{
                    board->board[row][column - 1] = '*';
                }
            }
            //flips bottom
            if(row + 1 <= 4){
                if(board->board[row + 1][column] == '*'){
                    board->board[row + 1][column] = '.';
                }
                else{
                    board->board[row + 1][column] = '*';
                }
            }
            //flips right
            if(column + 1 <= 4){
                if(board->board[row][column + 1] == '*'){
                    board->board[row][column + 1] = '.';
                }
                else{
                    board->board[row][column + 1] = '*';
                }
            }
            // enables undo after a move
            if(board->ableToUndo != 'y'){
                board->ableToUndo = 'y';
            }
            board->lastMoveRow = row;
            board->lastMoveColumn = column;
            printf("success\n");
            return 0;
        }
        else{
            fail("error");
        }
    }
    //undo command, checks for ableToUndo
    else if(strcmp(argv[1], "undo") == 0 && argc == 2){
        //checks conditions for undo
        if(board->ableToUndo == 'y'){
            board->ableToUndo = 'n';
            int lastMoveRow = board->lastMoveRow;
            int lastMoveColumn = board->lastMoveColumn;
            //does an undo by moving the row/col from last move

            //flips middle
            if(board->board[lastMoveRow][lastMoveColumn] == '*'){
                board->board[lastMoveRow][lastMoveColumn] = '.';
            }
            else{
                board->board[lastMoveRow][lastMoveColumn] = '*';
            }

            //flips top
            if(lastMoveRow - 1 >= 0){
                if(board->board[lastMoveRow - 1][lastMoveColumn] == '*'){
                    board->board[lastMoveRow - 1][lastMoveColumn] = '.';
                }
                else{
                    board->board[lastMoveRow - 1][lastMoveColumn] = '*';
                }
            }
            //flips left
            if(lastMoveColumn - 1 >= 0){
                if(board->board[lastMoveRow][lastMoveColumn - 1] == '*'){
                    board->board[lastMoveRow][lastMoveColumn - 1] = '.';
                }
                else{
                    board->board[lastMoveRow][lastMoveColumn - 1] = '*';
                }
            }
            //flips bottom
            if(lastMoveRow + 1 <= 4){
                if(board->board[lastMoveRow + 1][lastMoveColumn] == '*'){
                    board->board[lastMoveRow + 1][lastMoveColumn] = '.';
                }
                else{
                    board->board[lastMoveRow + 1][lastMoveColumn] = '*';
                }
            }
            //flips right
            if(lastMoveColumn + 1 <= 4){
                if(board->board[lastMoveRow][lastMoveColumn + 1] == '*'){
                    board->board[lastMoveRow][lastMoveColumn + 1] = '.';
                }
                else{
                    board->board[lastMoveRow][lastMoveColumn + 1] = '*';
                }
            }
            printf("success\n");
            return 0;
        }
        else{
            fail("error");
        }
    }
    else{
        fail("error");
    }
    return 0;
}
