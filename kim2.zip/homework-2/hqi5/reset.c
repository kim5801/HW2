#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
extern int errno ;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

int main( int argc, char *argv[] ) {

    //Fail with usage message: not 2 arguments
    if(argc != 2){
        usage();
    }

    //initializing the local board
    //variables, board, file, temp get c, and count
    int boardLocal[GRID_SIZE][GRID_SIZE];
    FILE *boardFile;
    char c;
    int count = 0;

    //open file to read using fopen
    boardFile = fopen(argv[1], "r");
    if(boardFile == NULL){
        usage();
    }
    //reads the text file onto the board, fails with error if bad input
    while(1){
        c = fgetc(boardFile);
        if(c == '*' || c == '.'){
            boardLocal[count / GRID_SIZE][count % GRID_SIZE] = c;
            count++;
        }
        else if(c == '\n' && count % GRID_SIZE == 0){
            continue;
        }
        else if(c == EOF && count == GRID_SIZE * GRID_SIZE){
            break;
        }
        else{
            fprintf( stderr, "Invalid input file: %s\n", argv[1] );
            exit( 1 );
        }
    }

    //uses unique generated key by path to home directory
    key_t key = ftok("/afs/unity.ncsu.edu/users/h/hqi5", 1);
    //key_t key = ftok("C:/Users/Hongwei Qi", 1);
    if(key == -1){
        fail("Cannot create ftok key");
    }
//    printf("%d\n", key);
//
//    printf("%llu\n", sizeof(GameState));
    int errnum;
    // make a shared memory segment
    int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
    if(shmid == -1){
        errnum = errno;
        fprintf(stderr, "Value of errno: %d\n", errno);
        perror("Error printed by perror");
        fprintf(stderr, "Meow meow: %s\n", strerror( errnum ));

        fail("Cannot complete shmget");
    }

    //casts the pointer to a gamestate
    GameState *board = (GameState *)shmat(shmid, 0, 0);
    if(board == (GameState *) -1){
        fail("Cannot map shared memory into address space");
    }

    //fills the GameState struct with our local read
    for(int i = 0; i < 5; i++){
        for(int j = 0; j < 5; j++){
            board->board[i][j] = boardLocal[i][j];
        }
    }
    // tells the receiver that we have filled board
    board->flag = 1;

    return 0;
}
