import java.io.*;
import java.util.*;

/**
 * Maxsum reads an input source of a lot of integers, uses threads as workers to find the 
 * contiguous non-empty subsequence within the sequence of integers that has the largest sum.
 * @author Hongwei Qi
 */
public class Maxsum {
	
	/**
	 * prints out the usage of the command lines,
	 */
	public static void usage() {
		System.out.print("usage: maxsum <workers>\n");
		System.out.print("       maxsum <workers> report\n");
		System.exit(1);
	}
	/**global variable to keep track of count in the list read*/
	public static int vCount = 0;
	/**global variable to keep track of capacity in the input list*/
	public static int vCap = 0;
	/**global variable of an array for the elements read from input*/
    public static int vList[];
    
    /**
     * reads integers from standard input and stores it into an array
     * uses array and resizes when it reaches max
     */
	public static void readList() {
		vCap = 5;
		vList = new int[vCap];
		Scanner scnr = new Scanner(System.in);
		while(scnr.hasNextInt()) {
			if(vCount >= vCap) {
				vCap *= 2;
				int vListTemp[] = new int[vCap];
				for(int i = 0; i < vCount; i++) {
					vListTemp[i] = vList[i];
				}
				vList = vListTemp;
			}
			vList[vCount++] = scnr.nextInt();
		}
	}
	
	/** Thread that calculates the max continuous sum of integers from range min to max */
	public static class CatThread extends Thread{
		private int min;
		private int max;
		private int totalSum;
		public CatThread(int minRange, int maxRange) {
			min = minRange;
			max = maxRange;
			totalSum = 0;
		}
		public int getSum() {
			return totalSum;
		}
		/** adds every subsequent value for each value in range, changes sum based on results */
		public void run() {
			for(int a = min; a < max; a++) {
				int index = a;
				int localSum = 0;
				while(index < vCount) {
					localSum += vList[index];
					if(localSum > totalSum) {
						totalSum = localSum;
					}
					index++;
				}
			}
		}
	}

	/**
	 * main method, reads an input source of a lot of integers, uses threads as workers to find the 
	 * contiguous non-empty subsequence within the sequence of integers that has the largest sum. 
	 * @param args command line arguments
	 */
	public static void main( String[] args ) {
		
		//arg variables
	    boolean report = false;
	    int workers = 4;
	    
	    //checks for invalid argument length
	    if(args.length < 1 || args.length > 2){
	    	usage();
	    }
	    
	    //parses workers to integer, checks for validity
	    try {
	    	int i = Integer.parseInt(args[0]);
	    	if(i < 1){
	    		usage();
	    	}
	    	workers = i;
	    }
	    catch (NumberFormatException e){
            usage();
        }
	    
	    //checks for report argument validity
	    if(args.length == 2) {
	    	if(!(args[1].equals("report"))) {
	    		usage();
	    	}
	    	else {
	    		report = true;
	    	}
	    }
	    
	    //reads input
	    readList();
	    
	    //variables declaration
	    int parentSum = 0;
	    int arrayDivide = vCount / workers;
	    
	    //makes worker amount of threads, 
	    CatThread[] threadArray = new CatThread[workers];
	    for (int i = 0; i < workers; i++) {
	    	if(i == workers - 1) {
	    		threadArray[i] = new CatThread(i * arrayDivide, vCount);
	    	}
	    	else {
	    		threadArray[i] = new CatThread(i * arrayDivide, (i + 1) * arrayDivide);
	    	}
	    	threadArray[i].start();
	    }
	    
	    //joins the threads
	    try {
	    	for(int i = 0; i < threadArray.length; i++) {
	    		threadArray[i].join();
	    		System.out.println("I'm thread " + threadArray[i].getId() + ". The maximum sum I found is " + threadArray[i].getSum() + ".");
	    		if(threadArray[i].getSum() > parentSum) {
	    			parentSum = threadArray[i].getSum(); 
	    		}
	    	}
	    } catch(InterruptedException e) {
	    	//do nothing
	    }
	    System.out.println("Maximum Sum: " + parentSum);
	    
	}
}
