// Height and width of the playing area.
#define GRID_SIZE 5
//id number for ftok
#define ID 7
//path to home directory
#define HOME_PATH "/afs/unity.ncsu.edu/users/m/mdsnyde3"

/** Struct representation for a GameState, with a board and the undo board, along with an int for whether we can undo or not */
typedef struct {
  char board[ GRID_SIZE ][ GRID_SIZE ];
  char undoBoard[ GRID_SIZE ][ GRID_SIZE ];
  int undoBit;
} GameState;
