/*
   Takes in a list of integer values and finds the largest possible sum using multiple threads.
   @file Maxsum.java
   @author Madeline Snyder (mdsnyde3)
*/
import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {
  // Creating a subclass of Thread
  static class MyThread extends Thread {
    // max sum found
    public int max;
    
    //boolean for reporting
    private boolean report;
    //thread number in the array it came from
    private int x;
    /** Make a new Thread, giving it parameter values to store. */
    public MyThread( int x, boolean report ) {
      this.x = x;
      this.report = report;
    }

    /** When run, computes the maximum sum found through different passes through the ArrayList of values */
    public void run() {
      //start the max value at the first value this thread will access in the list
      int subMax = vList.get( x );
      //sum on each pass through the arraylist
      int miniSum = 0;
      //counter for how many times each thread must check the arraylist
      int divCount = 0;
      
      //for loop to iterate through the arrayList of values, starting at the index of the thread in the Thread ArrayList
      for( int i = x; i < vList.size(); i++ ) {
        //add the current value to the sum
        miniSum += vList.get( i );
        //if we have found something greater than our current max, replace it
        if( miniSum > subMax ) {
          subMax = miniSum;
        }
        //if we have reached the end of the array, adjust the starting position
        if( i == vList.size() - 1 ) {
          divCount++;
          // we now start the loop at our original point plus the product of how many workers we have and how many times we will use the worker
          i = x + ( workers * divCount );
          //reset the minisum
          miniSum = 0;
        }
      }
      //set the max variable in the thread to the greatest value we found
      max = subMax;
      //if we're supposed to report, do it.
      if( report ) {
      System.out.println( "I'm thread " + this.getId() + ". The maximum sum I found is " + max + "." );
      }
    }
  }
  //global array of integer values passed in from standard input/a given file
  private static ArrayList<Integer> vList;
  //global int for the number of threads we need to create
  private static int workers;
  
  /** Make a thread and wait for it to do something. */
  public static void main( String[] args ) {
    //create a boolean for whether or not to report
    boolean report = false;
    /**
      Originally had error checking statements for incorrect command line arguments,
      but since the writeup had no specification I deleted them.
    */
    
    //parse the command line argument into an integer
    try{
      workers = Integer.parseInt(args[0]);
    }catch( NumberFormatException e ){
      System.out.println("Not a valid number of workers!");
    }
    //set report flag if appropriate
    if( args.length == 2 ) {
      if(args[1].compareTo("report") == 0 ) {
        report = true;
      }
    }
    //initialize the arrayList of values from input
    vList = new ArrayList<Integer>();
    //scan them in and add them to the arrayList
    Scanner scan = new Scanner(System.in);
    while( scan.hasNextInt() ) {
      vList.add( scan.nextInt() );
    }
    
    //create an arrayList of threads
    ArrayList<MyThread> threadList = new ArrayList<MyThread>();
    // Make threads and start them running
    for ( int i = 0; i < workers; i++ ) {
      //add the new thread to the arrayList of threads
      threadList.add( new MyThread( i, report ) );
      threadList.get( i ).start();
    }
    //create an ArrayList of the max sums from each thread
    ArrayList<Integer> maxList = new ArrayList<Integer>();
    // Wait for each of the threads to terminate.
    try {
      for ( int j = 0; j < threadList.size(); j++ ) {
        threadList.get( j ).join();
        //add the max value each thread found to an arrayList of all the maxSums
        maxList.add( threadList.get( j ).max );
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    //populate an arrayList of the maximums each thread found, then find the biggest and print it out
    int maxSum = maxList.get( 0 );
    for( int m = 1; m < maxList.size(); m++ ) {
      if( maxList.get( m ) > maxSum ) {
        maxSum = maxList.get( m );
      }
    }
    //print out the maximum sum from the input
    System.out.println(" Maximum Sum: " + maxSum );
    //close your scanner!!
    scan.close();
  }
}
