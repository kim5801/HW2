/*
   Uses shared memory with reset.c to run the lightsout game, taking in command line
   arguments to either report, undo, or move, while updating the state of the board in
   the shared memory.
   @file lightsout.c
   @author Madeline Snyder (mdsnyde3)
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>
#include <ctype.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Main method, uses command line arguments to decide what command to run, updating the board as needed
int main( int argc, char *argv[] ) {
  //use ftok to create a key for the shared memory
  key_t key = ftok(HOME_PATH, ID);
  //get id to use for shared memory, using key from above
  int shmid = shmget( key, sizeof( GameState ), 0 );
  //if we get 1, we couldn't create the shared memory
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }
  //cast the pointer from shmat into a shared GameState struct
  GameState *gameBoard = (GameState *)shmat( shmid, 0, 0 );
  
  //if we have less than 2 command line arguments (including ./lightsout), we have an error
  if ( argc < 2 ) {
    printf( "error\n" );
    exit( 1 );
  }
  
  // see if we have the report command
  if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // if we do not have exactly 2 args, we have an error
    if ( argc != 2 ) {
      printf( "error\n" );
      exit( 1 );
    } 
    
    //print out the state of the board character by character with newlines when appropriate
    for( int i = 0; i < GRID_SIZE; i++ ) {
      for( int j = 0; j < GRID_SIZE; j++ ) {
        printf( "%c", gameBoard->board[ i ][ j ] );
      }
      printf( "\n" );
    }
  
  }
  //case for the undo command
  else if( strcmp( argv[ 1 ], "undo" ) == 0) {
    //if we have previously called undo, this is an error
    if( gameBoard->undoBit ) {
      printf( "error\n" );
    }
    else {
      //put values from undoBoard into the regular board
      for( int i = 0; i < GRID_SIZE; i++ ) {
        for( int j = 0; j < GRID_SIZE; j++ ) {
          gameBoard->board[ i ][ j ] = gameBoard->undoBoard[ i ][ j ];
        }
      }
      //indicate we have just called undo
      gameBoard->undoBit = 1;
      printf( "success\n" );
    }
  }
  //case for move command
  else if( strcmp( argv[ 1 ], "move" ) == 0) {
    //if we don't have exactly 4 arguments, this is invalid
    if( argc != 4 ) {
      printf( "error\n" );
      exit( 1 );
    }
    // if the args are not valid digits, print an error
    if ( ( (strlen( argv[ 2 ] ) != 1) && !isdigit( argv[ 2 ][ 0 ] ) ) || ( (strlen( argv[ 3 ] ) != 1) && !isdigit( argv[ 3 ][ 0 ] ) ) ) {
      printf( "error\n" );
      exit( 1 );
    }
    //get int values for row and column
    int row = atoi( argv[ 2 ] );
    int col = atoi( argv[ 3 ] );
    //make sure they are within the bounds of our board
    if( ( row < 0 || row > 4 ) || ( col < 0 || col > 4 ) ) {
      printf( "error\n" );
      exit( 1 );
    }   
    //populate state of undo board
    for( int i = 0; i < GRID_SIZE; i++ ) {
      for( int j = 0; j < GRID_SIZE; j++ ) {
        gameBoard->undoBoard[ i ][ j ] = gameBoard->board[ i ][ j ];
      }
    }
    //make it safe to undo
    gameBoard->undoBit = 0;     
    //change surrounding spaces on the board
    for( int k = -1; k < 2; k++ ) {
      //make sure we are in bounds for the array, then flip the . to * and vice versa
      if( (row + k ) >= 0 && (row + k) < GRID_SIZE ) {
        if ( gameBoard->board[ row + k ][ col ] == '.' ) {
          gameBoard->board[ row + k ][ col ] = '*';
        }
        else {
          gameBoard->board[ row + k ][ col ] = '.';
        }
      }
      //make sure we are in bounds and we haven't already changed the space, then flip the characters
      if( ( ( col + k ) >= 0 && ( col + k) < GRID_SIZE ) && k != 0 ) {
        if ( gameBoard->board[ row ][ col + k ] == '.' ) {
          gameBoard->board[ row ][ col + k ] = '*';
        }
        else {
          gameBoard->board[ row ][ col + k ] = '.';
        }
      }
    } 
    printf( "success\n" ); 
  }
  //case for invalid command
  else {
    printf( "error\n" );
    exit( 1 );
  }
  //exit successfully!
  return 0;
}
