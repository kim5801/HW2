import java.util.*;
import java.util.concurrent.*;

public class Maxsum {
  // Print out an error message and exit.
  public static void fail( String message ) {
    System.err.println(message);
    System.exit(0);
  }
  
  // Print out a usage message, then exit.
  public static void usage() {
    System.out.print( "usage: maxsum <workers>\n" );
    System.out.print( "       maxsum <workers> report\n" );
    System.exit(1);
  }
  
  // Input sequence of values.
  public static volatile int vList[];

  // Number of values on the list.
  public static volatile int vCount = 0;

  // Capacity of the list of values.
  public static volatile int vCap = 0;
  
  public static volatile Semaphore sem;
  
  public static volatile boolean report = false;
  
  public static volatile int numChildren = 0;
  
  public static volatile int maxValue = 0;
  
  public static volatile int startIndex = 0;
  
  static class Thread1 implements Runnable {
    public void run() {
      //Lock
      try {
        sem.acquire();
      } catch (Exception e) {
        //nothing 
      }
      
      //Critical Section <--- Finding MaxSum
      int lastIndex = vCount - 1;
      int startForChild = startIndex;
      int endForChild = startIndex;
      int childMaxValue = 0;
      int finalChildMaxValue = vList[0];

      while (startForChild <= lastIndex) {
        for (int j = startForChild; j <= endForChild; j++) {
          childMaxValue += vList[j];
        }
        if (finalChildMaxValue < childMaxValue) {
          finalChildMaxValue = childMaxValue;
        }
        childMaxValue = 0;
        if (endForChild == lastIndex) {
          startForChild += numChildren;
          //System.out.println(numChildren);
          endForChild = startForChild;
        }
        else {
          endForChild++;
          
        }
       }

      if(report == true) {
        System.out.println("I’m thread " + Thread.currentThread().getId() + 
          ". The maximum sum I found is " + finalChildMaxValue + ".");
      }
      
      startIndex++;

      if (maxValue < finalChildMaxValue) {
        maxValue = finalChildMaxValue;
      }
      
      //Release
      sem.release();
    }
  }
  
  // Read the list of values.
  public static void readList() {
    // Set up initial list and capacity.
    vCap = 5;
    vList = new int[vCap];

    Scanner scan = new Scanner(System.in);

    // Keep reading as many values as we can.
    int v = 0;
    while ( scan.hasNext() == true ) {
      v = scan.nextInt();
      // Grow the list if needed.
      if ( vCount >= vCap ) {
        vCap *= 2;
        vList = Arrays.copyOf(vList, vCap);
      }

      // Store the latest value in the next array slot.
      vList[ vCount ] = v;
      vCount++;
    }
  }
  
  public static void main( String[] args ) {
    report = false;
    int workers = 4;
    sem = new Semaphore(1);

    // Parse command-line arguments.
    if ( args.length < 1 || args.length > 2 )
      usage();

    workers = Integer.parseInt(args[ 0 ]);

    if (workers < 1 )
      usage();

    // If there's a second argument, it better be the word, report
    if ( args.length == 2 ) {
      if ( !args[ 1 ].equals("report") ) 
        usage();
      report = true;
    }

  readList();
  
  numChildren = Integer.parseInt(args[ 0 ]);
  maxValue = vList[0];

  for (int i = 0; i < numChildren; i++) {
    Thread t1 = new Thread( new Thread1() );
    t1.start();
    try {
      t1.join();
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted!" );
    }
  }

  System.out.println("Maximum Sum: " + maxValue);
  
  }

}