// Height and width of the playing area.
#define GRID_SIZE 5

//GameState error
typedef struct GameState {
  char gameState[GRID_SIZE][GRID_SIZE];
  int previous[2];
} GameState;