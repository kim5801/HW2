#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Switches the light associated with the row and col 
// to be the opposite state of what it was
static void witch( GameState *gm, int row, int col ) {
  //check if row is valid
  if(row < 0 || row > GRID_SIZE - 1) {
    //nothing
  } 
  //check if column is valid
  else if (col < 0 || col > GRID_SIZE - 1) {
    //nothing
  }
  //change from * to .
  else if(gm -> gameState[row][col] == '*') {
    gm -> gameState[row][col] = '.';
  } 
  //change from . to *
  else if(gm -> gameState[row][col] == '.') {
    gm -> gameState[row][col] = '*';
  }
}

/**
 * interpret a user command given in the command- line arguments and make 
 * requested changes to the game board stored in shared memory
 * @param argc number of chars in argv
 * @param argv char array
 * @return success
 */
int main( int argc, char *argv[] ) {
  //get key
  key_t key = ftok("/afs/unity.ncsu.edu/users/s/sfatima3", 1);

  //get shared memory identifier associated w/key
  int smi = shmget(key, sizeof(GameState), 0);

  //if shmget returns -1, call fail
  if(smi == -1) {
    fail("Unable to get shared memory identifier for given key");
  }

  //connects shared memory segment with shared memory identifier
  GameState *gm = (GameState *) shmat( smi, 0, 0 );

  if(gm == (GameState *) -1) {
    fail("Unable to connect shared memory segment with shared memory identifier");
  }

  //move command
  if( argc == 4 && strcmp( argv[1], "move" )  == 0 ) {

    int row = atoi(argv[2]);
    int col = atoi(argv[3]);

    if(row < 0 || row > GRID_SIZE - 1 || col < 0 || col > GRID_SIZE - 1) {
      fail("error");
    }

    //switch the correct row and columns in the array
    witch(gm, row, col);
    witch(gm, row, col + 1);
    witch(gm, row, col - 1);
    witch(gm, row + 1, col);
    witch(gm, row - 1, col);

    gm -> previous[0] = row;
    gm -> previous[1] = col;

    printf("success\n");
  }
  //undo command
  else if( argc == 2 && strcmp( argv[1], "undo" ) == 0) {

    if(gm -> previous[0] < 0) {
      fail("error");
    }

    //switch the correct row and columns in the array back to the original state
    witch(gm, gm -> previous[0], gm -> previous[1]);
    witch(gm, gm -> previous[0], gm -> previous[1] + 1);
    witch(gm, gm -> previous[0], gm -> previous[1] - 1);
    witch(gm, gm -> previous[0] + 1, gm -> previous[1]);
    witch(gm, gm -> previous[0] - 1, gm -> previous[1]);

    //makes sure two undos don't happen at once
    gm -> previous[0] = -1;
    gm -> previous[1] = -1;

    printf("success\n");
  }
  //report command
  else if( argc == 2 && strcmp( argv[1], "report" ) == 0) {

    for(int i = 0; i < GRID_SIZE; i++ ) {
      for(int j = 0; j < GRID_SIZE; j++) {
        printf("%c", gm -> gameState[i][j] );
      }
      printf("\n");
    }
  }
  else {
    fail("error");
  }

  shmdt( gm );
  return 0;
}