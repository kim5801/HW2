#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * Read the initial game board state just like the server did in the previous 
 * assignment and create a shared memory segment containing any needed information 
 * about the game
 * @param argc number of chars in argv
 * @param argv char array
 * @return success
 */
int main( int argc, char *argv[] ) {
  //checks is command line has the right amount of arguments
  if(argc != 2) {
    usage();
  }

  //Create GameState struct object
  GameState *gm = (GameState*) malloc(sizeof(GameState));

  //get key
  key_t key = ftok( "/afs/unity.ncsu.edu/users/s/sfatima3", 1 );

  //get shared memory identifier associated w/key
  int smi = shmget( key, sizeof(GameState), 0666 | IPC_CREAT );

  //if shmget returns -1, call fail
  if( smi == -1 ) {
    fail( "Unable to get shared memory identifier for given key" );
  }

  //connects shared memory segment with shared memory identifier
  gm = (GameState *) shmat( smi, 0, 0 );
  
  //if gm returns -1, call fail
  if( gm == (GameState *) -1 ) {
    fail( "Unable to connect shared memory segment with shared memory identifier" );
  }
  
  //open file and see if the filename is correct
  FILE *fp = fopen( argv[1], "r" );
  if(!fp) {
    printf( "Invalid input file: %s\n", argv[1]);
    exit( 1 );
  }
  
  //for undo to make sure two undos do not occur at once
  gm -> previous[0] = -1;
  gm -> previous[1] = -1;
  
  //char that will read in each character from the input file
  char c;
  
  //reads file into struct's array
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {

      c = fgetc(fp);

      if( c != '*' && c != '.' && c == ' ' && c != EOF ) {
        printf( "Invalid input file: %s\n", argv[1]);
        exit( 1 );
      }

      if( c == EOF ) {
        break;
      }
      else if (c == '\n') {
        c = fgetc(fp);
      }

      gm -> gameState[i][j] = c;
    }
  }

  //detach shared memory
  shmdt( gm );
  return 0;
}