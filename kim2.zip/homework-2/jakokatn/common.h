// Height and width of the playing area.
#define GRID_SIZE 5

struct GameState {
  bool state[ GRID_SIZE ][ GRID_SIZE ];
  int prevX;
  int prevY;
};
