#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <ctype.h> 

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // check cl arg count
  if ( argc >= 5 || argc <= 1 ) {
    fail( "error" );
  }

  // Get shared memory slot
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/j/jakokatn", 0 ), sizeof( struct GameState ), 0 );

  // Add shared memory and cast to GameState pointer
  struct GameState *gameState = (struct GameState *)shmat(shmid, 0, 0);

  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {

    // check number validity
    if ( strlen( argv[ 2 ] ) > 1 || strlen( argv[ 3 ] ) > 1 || !isdigit( argv[ 2 ][ 0 ] ) || !isdigit( argv[ 3 ][ 0 ] ) ) {
      fail( "error" );
    }

    // parse row and column numbers
    int r = atoi( argv[ 2 ] );
    int c = atoi( argv[ 3 ] );

    // r and c are guaranteed greater than or equal to 0 already, check validity
    if ( r > 4 || c > 4 ) {
      fail( "error" );
    }

    // flip lights
    gameState->state[ r ][ c ] = !gameState->state[ r ][ c ];
    if ( r - 1 >= 0 ) {
      gameState->state[ r - 1 ][ c ] = !gameState->state[ r - 1 ][ c ];
    }
    if ( r + 1 <= 4 ) {
      gameState->state[ r + 1 ][ c ] = !gameState->state[ r + 1 ][ c ];
    }
    if ( c - 1 >= 0 ) {
      gameState->state[ r ][ c - 1 ] = !gameState->state[ r ][ c - 1 ];
    }
    if ( c + 1 <= 4 ) {
      gameState->state[ r ][ c + 1 ] = !gameState->state[ r ][ c + 1 ];
    }

    // store position for undo command
    gameState->prevX = r;
    gameState->prevY = c;

    printf( "success\n" );
  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    // undo command (only if history exists)
    int r = gameState->prevX;
    int c = gameState->prevY;

    if ( r == -1 || c == -1 ) {
      fail( "error" );
    }
    
    // flip lights
    gameState->state[ r ][ c ] = !gameState->state[ r ][ c ];
    if ( r - 1 >= 0 ) {
      gameState->state[ r - 1 ][ c ] = !gameState->state[ r - 1 ][ c ];
    }
    if ( r + 1 <= 4 ) {
      gameState->state[ r + 1 ][ c ] = !gameState->state[ r + 1 ][ c ];
    }
    if ( c - 1 >= 0 ) {
      gameState->state[ r ][ c - 1 ] = !gameState->state[ r ][ c - 1 ];
    }
    if ( c + 1 <= 4 ) {
      gameState->state[ r ][ c + 1 ] = !gameState->state[ r ][ c + 1 ];
    }

    // clear position history
    gameState->prevX = -1;
    gameState->prevY = -1;

    printf( "success\n" );
  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    char statusString[ 31 ];
    
    // get status string
    int i = 0;
    for ( int j = 0; j < 5; j++ ) {
      for ( int k = 0; k < 5; k++ ) {
        if ( gameState->state[ j ][ k ] == true ) {
          statusString[ i ] = '*';
        } else {
          statusString[ i ] = '.';
        }
        i++;
      }
      statusString[ i ] = '\n';
      i++;
    }

    statusString[ i ] = '\0';

    printf( "%s\n", statusString );   
  } else {
    fail( "error" );
  }

  return 0;
}
