import java.util.Scanner;

public class Maxsum {

    // Print out an error message and exit.
    static void fail(String message) {
        System.err.println(message);
        System.exit(1);
    }

    // Print out a usage message, then exit.
    static void usage() {
        System.out.println("usage: Maxsum <workers>");
        System.out.println("       Maxsum <workers> report");
        System.exit(1);
    }

    // Input sequence of values.
    static int vList[];

    // Number of values on the list.
    static int vCount = 0;

    // Capacity of the list of values.
    static int vCap = 0;

    // Read the list of values.
    static void readList() {
        // Set up initial list and capacity.
        vCap = 5;
        vList = new int[vCap];

        // Create scanner
        Scanner scan = new Scanner(System.in);

        // Keep reading as many values as we can.
        while (scan.hasNextInt()) {
            // Grow the list if needed.
            if (vCount >= vCap) {
                vCap *= 2;
                int[] copy = new int[vCap];
                System.arraycopy(vList, 0, copy, 0, vList.length);
                vList = copy;
            }

            // Store the latest value in the next array slot.
            vList[vCount++] = scan.nextInt();
        }

        scan.close();
    }

    static class MyThread extends Thread {
        private boolean report;
        private int i;
        private int workers;

        public int max = 0;

        public MyThread(boolean report, int i, int workers) {
            this.report = report;
            this.i = i;
            this.workers = workers;
        }

        public void run() {
            // iterate over evenly spaced starting indices
            for (int j = i; j < vCount; j += workers) {
                int currentSum = 0;

                // iterate from starting index to end of array
                for (int k = j; k < vCount; k++) {
                    currentSum += vList[k];
                    if (currentSum > max) {
                        max = currentSum;
                    }
                }
            }

            // if requested, report max from this worker
            if (report) {
                System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + max + ".");
            }
        }
    }

    public static void main(String[] args) {
        boolean report = false;
        int workers = 4;

        // Parse command-line arguments
        if (args.length < 1 || args.length > 2) {
            usage();
        }

        try {
            workers = Integer.parseInt(args[0]);

            if (workers == 0) {
                usage();
            }
        } catch (NumberFormatException e) {
            usage();
        }

        // If there's a second argument, it better be the word, report
        if (args.length == 2) {
            if (!args[1].equals("report")) {
                usage();
            }
            report = true;
        }

        readList();

        // Create workers
        // reference: ThreadArguments.java from class lecture
        MyThread[] thread = new MyThread[workers];
        for (int i = 0; i < workers; i++) {
            thread[i] = new MyThread(report, i, workers);
            thread[i].start();
        }

        // Wait for each of the threads to terminate.
        int globalMax = 0;
        try {
            for (int i = 0; i < thread.length; i++) {
                thread[i].join();
                if (thread[i].max > globalMax) {
                    globalMax = thread[i].max;
                }
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        }

        // Report max sum
        System.out.println("Maximum Sum: " + globalMax);
    }
}