/**
 * @file lightsout.c
 * @author Eduardo Martinez (elmarti4)
 * @brief Allows a user to change the Lights Out board through moves,
 *        report the current board, or undo a previous move.
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Prints the provided board to standard output
 * 
 * @param board 2D array of board chosen
 */
void printBoard( char board[ GRID_SIZE ][ GRID_SIZE + 1 ] ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE + 1; j++ ) {
      printf( "%c", board[ i ][ j ] );
    }
  }
  printf( "\n" );
}

/**
 * @brief Starting point of the program
 * 
 * @param argc Amount of arguments
 * @param argv List of arguments
 * @return 0 on success or 1 on failure 
 */
int main( int argc, char *argv[] ) {
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/e/elmarti4", 'a' ), sizeof( GameState ), 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  GameState *gS = (GameState *) shmat( shmid, 0, 0 );

  if ( gS == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if ( argc == 4 && strcmp( argv[ 1 ], "move" ) == 0 ) {
    for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
          gS->oldBoard[ i ][ j ] = gS->currentBoard[ i ][ j ];
        }
      }
      // Find the x and y that has been chosen by
      int value1;
      int value2;
      if ( strlen( argv[ 2 ] ) != 1 ) {
            fail( "error" );
        } else {
            value1 = argv[ 2 ][ 0 ] - '0';
            // Check if the value fits in the 0 -> 4 range
            if ( 0 <= value1 && value1 < GRID_SIZE ) {
                // Check if the first provided value is a single digit
                if ( strlen( argv[ 3 ] ) != 1 ) {
                    fail( "error" );
                } else {
                    value2 = argv[ 3 ][ 0 ] - '0';
                    // Check if the value fits in the 0 -> 4 range
                    if ( 0 <= value2 && value2 < GRID_SIZE ) {
                    } else {
                        fail( "error" );
                    }
                }
            } else {
                fail( "error" );
            }
        }
      // Change the center of the cross
      if ( gS->currentBoard[ value1 ][ value2 ] == '*' ) {
        gS->currentBoard[ value1 ][ value2 ] = '.';
      } else {
        gS->currentBoard[ value1 ][ value2 ] = '*';
      }
      // Change the value above the center
      if ( value1 - 1 >= 0 && value1 - 1 < GRID_SIZE ) {
        if ( gS->currentBoard[ value1 - 1 ][ value2 ] == '*' ) {
          gS->currentBoard[ value1 - 1 ][ value2 ] = '.';
        } else {
          gS->currentBoard[ value1 - 1 ][ value2 ] = '*';
        }
      }
      // Change the value below the center
      if ( value1 + 1 >= 0 && value1 + 1 < GRID_SIZE ) {
        if ( gS->currentBoard[ value1 + 1 ][ value2 ] == '*' ) {
          gS->currentBoard[ value1 + 1 ][ value2 ] = '.';
        } else {
          gS->currentBoard[ value1 + 1 ][ value2 ] = '*';
        }
      }
      // Change the value to the left of the center
      if ( value2 - 1 >= 0 && value2 - 1 < GRID_SIZE ) {
        if ( gS->currentBoard[ value1 ][ value2 - 1 ] == '*' ) {
          gS->currentBoard[ value1 ][ value2 - 1 ] = '.';
        } else {
          gS->currentBoard[ value1 ][ value2 - 1 ] = '*';
        }
      }
      // Change the value to the right of the center
      if ( value2 + 1 >= 0 && value2 + 1 < GRID_SIZE ) {
        if ( gS->currentBoard[ value1 ][ value2 + 1 ] == '*' ) {
          gS->currentBoard[ value1 ][ value2 + 1 ] = '.';
        } else {
          gS->currentBoard[ value1 ][ value2 + 1 ] = '*';
        }
      }
      gS->undoStatus = true;
      printf( "success\n" );
  } else if ( argc == 2 && strcmp( argv[ 1 ], "report" ) == 0 ) {
    printBoard( gS->currentBoard );
  } else if ( argc == 2 && strcmp( argv[ 1 ], "undo" ) == 0 && gS->undoStatus == true ) {
    for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          gS->currentBoard[ i ][ j ] = gS->oldBoard[ i ][ j ];
        }
      }
      gS->undoStatus = false;
      printf( "success\n" );
  } else {
    fail( "error" );
  }

  shmdt( gS );

  return 0;
}
