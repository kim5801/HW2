import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {
  static class MyThread extends Thread {
    /** Effectively, a parameter we're passing the thread, which fibonacci
        number it's supposed to compute.  Here, we can just store this in
        a field of the thread itself. */
    private int currentWorker;
    private int workers;
    private ArrayList<Integer> list;

    /** Effectively, the return value from the thread.  We can just leave it
        in a field. */
    public int greatestValue = 0;
    
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( int currentWorker, int workers, ArrayList<Integer> list ) {
      this.currentWorker = currentWorker;
      this.workers = workers;
      this.list = list;
    }

    public void run() {
      int currentValue = 0;
      int p = currentWorker;
      while ( p < list.size() ) {
        for ( int k = p; k < list.size(); k++ ) {
          currentValue += (int) list.get(k);
          if ( greatestValue < currentValue ) {
            greatestValue = currentValue;
          }
        }
        currentValue = 0;
        p += workers;
      }
    }
  }
  /** Make a thread and wait for it to do something. */
  public static void main( String[] args ) {
    boolean report = false;

    if ( args.length <= 0 || args.length >= 3 ) {
      throw new IllegalStateException("\nusage: maxsum <workers>\n" +
                                      "       maxsum <workers> report");
    }

    if ( args.length == 2 && args[ 1 ].equals("report") ) {
      report = true;
    }

    // Read the file
    ArrayList<Integer> integers = new ArrayList<Integer>();
    Scanner scanner = new Scanner( System.in );
    while (scanner.hasNext()) {
      if (scanner.hasNextInt()) {
          integers.add(scanner.nextInt());
      } else {
        throw new IllegalStateException("\nusage: maxsum <workers>\n" +
        "       maxsum <workers> report");
      }
    }
    scanner.close();

    int currentWorker = 0;
    // Make 10 threads and let them start running.
    MyThread[] thread; 
    try {
      thread = new MyThread [ Integer.parseInt( args[ 0 ] ) ];
    } catch (NumberFormatException nfe) {
      throw new IllegalStateException("\nusage: maxsum <workers>\n" +
      "       maxsum <workers> report");
    }
    for ( int i = 0; i < thread.length; i++ ) {
      thread[ i ] = new MyThread( currentWorker, Integer.parseInt( args[ 0 ] ), integers );
      thread[ i ].start();
      currentWorker++;
    }

    // Wait for each of the threads to terminate.
    int value = 0;
    int greatValue = 0;
    try {
      for ( int i = 0; i < thread.length; i++ ) {
        thread[ i ].join();
        value = thread[ i ].greatestValue;
        if ( value > greatValue ) {
          greatValue = value;
        }
        if ( report == true ) {
          System.out.println( "I’m thread " + thread[ i ].getId() + ". The maximum sum I found is " + value + "." );
        }
      }
      System.out.println( "Maximum value: " + greatValue );
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
  }
}
