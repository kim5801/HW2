/**
	@file lightsout.c
	@author Eric Samuel (ejsamuel)
	Performs the operations on the lightsout program game
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

/**
 * The game state struct of the board
 */
struct GameState {
  char current[GRID_SIZE][GRID_SIZE + 1];
  char past[GRID_SIZE][GRID_SIZE + 1];
};


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * This functions brings everything together and performs operations
 * @param argc the number of command line arguments
 * @param argv the array of command line arguments
 * @return exit or failure
 */
int main( int argc, char *argv[] ) {
    //error checks for command line
    if(argc > 4) 
    fail("error");

    if(strcmp(argv[1], "move") != 0 &&strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0)
    fail("error");
        
    if(strcmp(argv[1], "move") == 0 && argc != 4) {
    fail("error");
    }

    if((strcmp(argv[1], "report") == 0 || strcmp(argv[1], "undo") == 0 ) && argc > 2) {
      fail("error");
    }

   

    //start shared memory stuff
    struct GameState *board;
    key_t key = ftok("/afs/unity.ncsu.edu/users/e/ejsamuel/CSC246/hw2", 1);
    int shmid = shmget(key, sizeof(struct GameState), 0666 | IPC_CREAT);
     if(shmid == -1) {
      fail("Can't create shared memory.");
    }
    board = shmat(shmid, NULL, 0);
    //error check baord

    //check what to do 
    if(strcmp(argv[1], "move") == 0) {

      
      int row = argv[2][0] - '0';
      int col = argv[3][0] - '0';
 

      if(isdigit(argv[2][0]) > 0 && isdigit( argv[3][0]) > 0 && row <= 4 && row >= 0 && col <= 4 && col >= 0 ) {

        //copy current to undo array
        //perform the move
        
        memcpy(board->past, board->current, sizeof (char) * 5 * 6);
        if(board->current[row][col] == '.') {
          board->current[row][col] = '*';
        } else {
          board->current[row][col] = '.';
        }
        //bottom piece
        if((row - 1) >= 0 && (row - 1) <= 4){
          if(board->current[row - 1][col] == '.') {
          board->current[row - 1][col] = '*';
          } else {
          board->current[row - 1][col] = '.';
          }
        }

        //top piece
        if((row + 1) >= 0 && (row + 1) <= 4){
          if(board->current[row + 1][col] == '.') {
          board->current[row + 1][col] = '*';
          } else {
          board->current[row + 1][col] = '.';
          }
        }
        //right piece
        if((col + 1) >= 0 && (col + 1) <= 4){
          if(board->current[row][col + 1] == '.') {
          board->current[row][col + 1] = '*';
          } else {
          board->current[row][col + 1] = '.';
          }
        }
        //left piece
        if((col - 1) >= 0 && (col - 1) <= 4){
          if(board->current[row][col - 1] == '.') {
          board->current[row][col - 1] = '*';
          } else {
          board->current[row][col - 1] = '.';
          }
        }
              printf("success\n");
        } else {
              printf("error\n");
        }
              
    } else if(strcmp(argv[1], "report") == 0) {
      
      
      // char reportBoard[30];
      // int counter = 0;
      for(int i = 0; i < GRID_SIZE; i++) {
        for(int j = 0; j < GRID_SIZE + 1; j++) {
          // reportBoard[counter] = board->current[i][j];
          printf("%c", board->current[i][j]);
          // counter++;
        }
      }

    } else if(strcmp(argv[1], "undo") == 0) {
      
      if(memcmp(board->past, board->current, sizeof(board->current)) == 0) {
        printf("error\n");
      } else {
        memcpy(board->current, board->past, sizeof(char) * 5 * 6);
        printf("success\n");
      } 
    }

    shmdt(board);

  return 0; 
}
