import java.util.*;
import java.io.*;
import java.lang.*;
public class Maxsum {

    
    /** the array list of numbers from the input file */
    private static List<Integer> numbers;
    /** the flag that checks if the threads need to report */
    private static boolean reporting;
    /** the number of numbers in the input file */
    private static int lengthOfNums;

    /** Subclass thread to tell the thread what to do */
    static class MyThread extends Thread {
        
        /** the number of thread workers */
        private int threadNumbers;
        /** the index of the worker */
        private int index;
       /** the max sum found by thread */
        public int threadMax;

        
        /**
         * The constructor for the thread
         * @param threadNumbers the number of workers
         * @param index the index of worker
         */
        public MyThread(int threadNumbers, int index) {
            this.threadNumbers = threadNumbers;
            this.index = index;
           
        }
        /**
         * The bulk of computations take place here.
         */
        public void run() {
            int testMax = numbers.get(index);
            int current = numbers.get(index);
            int total = numbers.get(index);

            for(int j = index; j < lengthOfNums; j+= threadNumbers) {
                current = numbers.get(j);
                total = numbers.get(j);
                for(int k = j + 1; k < lengthOfNums; k++) {
                    current = Math.max(current, total + numbers.get(k));
                    total += numbers.get(k);
                }
                testMax = Math.max(testMax, current);
            }
            if(reporting) {
                System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + testMax + ".");
                threadMax = testMax;
            } else {
                threadMax = testMax;
            }
            
            
            

        }
    }

    /**
     * Reads the input file to an arraylist
     */
    public static void readList() {
        Scanner scan = new Scanner(System.in);
        while(scan.hasNext()) {
            
            numbers.add(scan.nextInt());
            // System.out.println(Integer.parseInt(scan.next()));
            
        }
        scan.close();
    }

    /**
     * The main where the threads are created and ran
     * @param args the command line arguments
     */
    public static void main( String[] args ) {

        numbers = new ArrayList<>();
        int numThreads = Integer.parseInt(args[0]);
        
        int finalMax = 0;

        if(args.length > 1 && args[1].equals("report")) {
            reporting = true;
        }
        MyThread workers[] = new MyThread[numThreads];
        readList();
        lengthOfNums = numbers.size();
        for(int i = 0; i < numThreads; i++) {
            workers[i] = new MyThread(numThreads, i);
            workers[i].start();
        }
        try {
            for(int i = 0; i < workers.length; i++) {
                workers[i].join();
                finalMax = Math.max(workers[i].threadMax, finalMax);

            }
        } catch (InterruptedException e){
            System.out.println("Interrupted during join!");
        }
        System.out.println("Maximum Sum: " + finalMax);
    }
}