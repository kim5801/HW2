// Height and width of the playing area.
#define GRID_SIZE 5

//define struct
struct GameState{

  //stores current board
  char board[GRID_SIZE][GRID_SIZE];

  //stores previous move
  char undo[2];

};
