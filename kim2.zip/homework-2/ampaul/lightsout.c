#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

struct GameState *state;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}


//Turns . to * or * to . given a coordinate
void toggle(int r, int c) {
  if(state->board[r][c] == '.') {
    state->board[r][c] = '*';
  }
  else {
    state->board[r][c] = '.';
  }
}

int main( int argc, char *argv[] ) {

  if(argc > 4 || argc < 2) { //check number of args
    fail("error");
  }

  //Accesses shared memory
  int id = shmget(ftok("/afs/unity.ncsu.edu/users/a/ampaul", 0), sizeof( struct GameState), 0666);
  state = (struct GameState *)shmat(id, 0, 0);

  if( strcmp(argv[1], "undo") == 0) {

    if(state->undo[0] != '\0') { //if there is a saved move, perform move
      int r = state->undo[0];
      int c = state->undo[1];

      //toggles lights  of coordinate and near coordinates
      toggle(r,c);

      if(r - 1 >= 0) {
        toggle(r - 1, c);
      }
      if(r + 1 < GRID_SIZE) {
        toggle(r + 1, c);
      }
      if(c - 1 >= 0) {
        toggle(r, c - 1);
      }
      if(c + 1 < GRID_SIZE) {
        toggle(r, c + 1);
      }

      //clear undo
      state->undo[0] = '\0';
      state->undo[1] = '\0';

    }
    else {
      fail("error")
    }

  }
  else if( strcmp(argv[1], "report") == 0) {

    for(int i = 0; i < GRID_SIZE; i++) {
      for(int ii = 0; ii < GRID_SIZE; ii++) {server
        printf("%c", state->board[i][ii]); //print character from board
      }
      printf("\n"); //print new line after 5 chars
    }
    printf("\n");

  }
  else if( strcmp(argv[1], "move") == 0 && argc == 4) {


    //check for correct number of args
    if(argc < 4) {
      fail("error");
    }

    //converts passed args to int
    int r = atoi(argv[2]);
    int c = atoi(argv[3]);

    if(r < GRID_SIZE && r >= 0 && c < GRID_SIZE && c >= 0) { //checks coordinate is in bounds

      //toggles coordinate and near by spaces
      toggle(r,c);

      if(r - 1 >= 0) {
        toggle(r - 1, c);
      }
      if(r + 1 < GRID_SIZE) {
        toggle(r + 1, c);
      }
      if(c - 1 >= 0) {
        toggle(r, c - 1);
      }
      if(c + 1 < GRID_SIZE) {
        toggle(r, c + 1);
      }

      //save performed move for undo function
      state->undo[0] = r;
      state->undo[1] = c;
    }
    else {
      fail("error");
    }

  }
  else {
    fail("error"); //error if unrecognized command
  }


  shmdt( state );

  return 0;
}
