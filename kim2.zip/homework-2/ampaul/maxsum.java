import java.util.ArrayList;
import java.util.Scanner;

public class maxsum {

	// Array list to store read values.
	static ArrayList<Integer> vList = new ArrayList<Integer>();

	// Number of values on the list.
	static int vCount = 0;

	// Capacity of the list of values.
	static int vCap = 0;

	//boolean for board print out
	static boolean report;

	//Store and update the maxsum
 	public static int maxsum = 0;

	//Define worker thread with appropriate values and run method
	static class worker extends Thread {

			//Start of range to calculate
	    private int start;

			//End of range to calculate
	    private int end;

			//Max found within range
	    public int max;

	    // Initialize worker with passed args
	    public worker( int start, int end) {
	      this.start = start;
	      this.end = end;
				this.max = 0;
	    }

	    //Finds max sum within given range
	    public void run() {

				//current sum
				int sum = 0;

				//current max sum
				int findMax = 0;

				//loop with range to end of list
			  for(int i = start; i < end; i++) {
			    for(int j = i; j < vCount;  j++) {


			    	sum = sum + vList.get(j); //calculate sum

			      if(sum > findMax) {
			        findMax = sum; //replaces previous max
			      }
			    }

			    sum = 0; //reset sum
			  }

				//If report is requested, thread prints ID and max
				if(report) {
					System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + findMax + ".");
				}

				max = findMax; //reports max found within thread

	    }
	  }

	public static void main( String[] args ) {


		//checks valid number of args
		if(args.length < 2 || args.length > 3) {
			System.out.println("usage: maxsum <workers>"");
		}

		//Checks for report arg
		if(args.length == 2) {
			report = args[1].equals("report");
		}

		//reads number of workers
		int workers = Integer.parseInt(args[0]);


		//Fill list from input file
		Scanner in = new Scanner(System.in);
		while(in.hasNextInt()) {
			int num = in.nextInt();
			vList.add(num);
			vCount++;
		}

		in.close(); //close scanner

		//calculates range of values to calculate
		int diff = vCount / workers;
		int start = 0;
		int end = diff;

		//Array of all workers created
		worker[] threads = new worker [ workers ];

		for(int i = 0; i < workers; i++) {

			//last thread calculates sum to the end of the list
			if(i == workers - 1) {
				end = vCount;
			}

			//create thread and run it
			threads[i] = new worker(start, end);
			threads[i].start();

			//update range to calculate
			start = end;
			end += diff;
		}


		//Waits for threads to end and checks for max sum
		try {
			for ( int i = 0; i < workers; i++ ) {
		        threads[ i ].join();
						if(threads[i].max > maxsum) {
							maxsum = threads[i].max;
						}
		    }

		} catch ( InterruptedException e ) {
				System.out.println( "Interrupted during join" );
		}

		//Print max
		System.out.println("Maximum sum: " + maxsum);

	}
}
