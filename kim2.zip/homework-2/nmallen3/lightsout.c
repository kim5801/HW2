#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

int main( int argc, char *argv[] ) {

  // get key for shmget function
  key_t key; 
  if ((key = ftok("/afs/unity.ncsu.edu/users/n/nmallen3", 2)) == -1) {
    fprintf( stderr, "Key could not be generated\n");
    exit( 1 );
  }

  // create shared memory space
  int shmid; 
  if ((shmid = shmget(key, sizeof(GameState), 0)) == -1) {
    fprintf( stderr, "Could not get shared memory handle\n");
    exit( 1 );
  }

  // attach GameState struct address to shared memory space
  GameState *sbuffer;
  if ((sbuffer = (GameState *)shmat(shmid, 0, 0)) == (void *)-1) {
    fprintf( stderr, "Could not attach shared memory to address space\n");
    exit( 1 );
  }

  // if command is the move command
  if (strcmp(argv[1], "move") == 0) {

    // make sure arguments are valid
    if (argc != 4) {
      printf("error\n");
      exit( 1 );
    }
    int r = atoi(argv[2]);
    int c = atoi(argv[3]);

    // make sure r and c are valid integers
    if (r < 0 || r > 4) {
      printf("error\n");
      exit( 1 );
    }
    if (c < 0 || c > 4) {
      printf("error\n");
      exit( 1 );
    }

    // save previous state before updating board
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        sbuffer->prevBoard[i][j] = sbuffer->gameBoard[i][j];
      }
    }

    // update board contents
    if (sbuffer->gameBoard[r][c] == '.') {
      sbuffer->gameBoard[r][c] = '*';
    } else {
      sbuffer->gameBoard[r][c] = '.';
    }
    if (r - 1 >= 0) {
      if (sbuffer->gameBoard[r - 1][c] == '.') {
        sbuffer->gameBoard[r - 1][c] = '*';
      } else {
        sbuffer->gameBoard[r - 1][c] = '.';
      }
    }
    if (r + 1 <= 4) {
      if (sbuffer->gameBoard[r + 1][c] == '.') {
        sbuffer->gameBoard[r + 1][c] = '*';
      } else {
        sbuffer->gameBoard[r + 1][c] = '.';
      }
    }

    if (c + 1 <= 4) {
      if (sbuffer->gameBoard[r][c + 1] == '.') {
        sbuffer->gameBoard[r][c + 1] = '*';
      } else {
        sbuffer->gameBoard[r][c + 1] = '.';
      }
    }

    if (c - 1 >= 0) {
      if (sbuffer->gameBoard[r][c - 1] == '.') {
        sbuffer->gameBoard[r][c - 1] = '*';
      } else {
        sbuffer->gameBoard[r][c - 1] = '.';
      }
    }

    // update undoneBefore variable after move
    sbuffer->undoneBefore = false;

    // print success statement
    printf("success\n");

    // if command is the undo command
  } else if (strcmp(argv[1], "undo") == 0) {

    // restore current board to previous board state
    if (!sbuffer->undoneBefore) {
      for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
          sbuffer->gameBoard[i][j] = sbuffer->prevBoard[i][j];
        }
      }
      sbuffer->undoneBefore = true;
      printf("success\n");
    } else {
      printf("error\n");
    } 

    // if command is the report command
  } else if (strcmp(argv[1], "report") == 0) {

    // print current game board contents
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        printf("%c", sbuffer->gameBoard[i][j]);
      }
      printf("\n");
    }

    // if argument is invalid
  } else {
    printf("error\n");
  }
  
  // detach from shared memory
  shmdt(sbuffer);
  return 0;
}
