#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // if argument is invalid
  if (argc != 2) {
    usage();
  }

  // get key for shmget function
  key_t key; 
  if ((key = ftok("/afs/unity.ncsu.edu/users/n/nmallen3", 2)) == -1) {
    fprintf( stderr, "Key could not be generated\n");
    exit( 1 );
  }

  // create shared memory space
  int shmid;
  if ((shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT)) == -1) {
    fprintf( stderr, "Could not create shared memory\n");
    exit( 1 );
  }

  // attach GameState struct address to shared memory space
  GameState *sbuffer;
  if ( (sbuffer = (GameState *)shmat(shmid, 0, 0)) == (void *)-1) {
    fprintf( stderr, "Could not attach shared memory to address space\n");
    exit( 1 );
  }

  // set undoneBefore field to true at start of game
  sbuffer->undoneBefore = true;

  // open game file
  int fileD;
  if ((fileD = open(argv[1], O_RDONLY, S_IRUSR)) == -1) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1]);
    exit( 1 );
  }

  // make sure file is valid
  if (lseek(fileD, 0, SEEK_END) != 30) { 
    fprintf( stderr, "Invalid input file: %s\n", argv[1]);
    exit( 1 );
  }
  
  // reset file pointer to beginnning
  if (lseek(fileD, 0, SEEK_SET) == -1) {
    fprintf( stderr, "Could not offset file location");
    exit( 1 );
  }

  // add file contents to gameBoard field
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      if (read(fileD, &sbuffer->gameBoard[i][j], 1) == -1) {
        fprintf( stderr, "Couldn't read in file contents");
        exit( 1 );
      }
      if (sbuffer->gameBoard[i][j] != '.' && sbuffer->gameBoard[i][j] != '*') {
        fprintf( stderr, "Invalid input file: %s\n", argv[1]);
        exit( 1 );
      }
    }

    if (lseek(fileD, SEEK_CUR, 1) == -1) {
      fprintf( stderr, "Could not offset file location");
      exit( 1 );
    }
  }

  // update prevBoard field to match gameBoard at beginning of game
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      sbuffer->prevBoard[i][j] = sbuffer->gameBoard[i][j];
    }
  }

  return 0;
}
