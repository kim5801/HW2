import java.util.Scanner;
import java.util.*;

public class Maxsum {

    // If input specifies reporting local sums
    public static boolean report;

    // Input sequence of values
    public static ArrayList<Integer> list = new ArrayList<Integer>();

    // Number of thread workers to use
    public static int workers;

    // Object class representing a Thread
    static class MyThread extends Thread {

        // starting index of list
        private int idx;

        // largest sum of thread
        public int sum;

        // Thread class constructor, sets parameter index to private index field
        public MyThread(int idx) {
            this.idx = idx;
        }

        // Thread executes given code
        public void run() {
            int maxSum = list.get(idx);
            int tempSum = 0;
            int i = idx;
            int size = list.size();

            // look for maximum sum in given indexes
            while (i < size) {
                tempSum = list.get(i);
                if (tempSum > maxSum) {
                    maxSum = list.get(i);
                }
                for (int j = i + 1; j < size; j++) {
                    tempSum += list.get(j);
                    if (tempSum > maxSum) {
                        maxSum = tempSum;
                    }
                }
                i += workers;
            }

            // assigns local maximum sum to global sum field
            sum = maxSum;

            // if report was specified then print out worker's thread id and the local sum they found
            if (report) {
                System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + maxSum + ".");
            }
        }

    }

    public static void main( String[] args ) {

        // get number of worker threads to create
        workers = Integer.parseInt(args[0]);

        // if given report option, set report boolean to true
        if (args.length > 1 && args[1].equals("report")) {
            report = true;
        } else {
            report = false;
        }

        Scanner scn = new Scanner(System.in);

        // parse file contents into list
        while ( scn.hasNextInt()) {
            list.add(scn.nextInt());
        }
        
        // loop to create thread workers and increment starting index with each new worker.
        MyThread[] thread = new MyThread[workers];
        for (int i = 0; i < thread.length; i++) {
            thread[i] = new MyThread(i);
            thread[i].start();
        }

        int totalSum = 0;

        // wait for all workers to terminate then print out the highest local sum returned
        try {
            for (int i = 0; i < thread.length; i++) {
                thread[i].join();
                if (thread[i].sum > totalSum) {
                    totalSum = thread[i].sum;
                }
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        }

        System.out.println("Maximum Sum: " + totalSum);

    }
    
}