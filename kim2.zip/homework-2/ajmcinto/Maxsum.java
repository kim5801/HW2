import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class that can use multiple workers to compute the maximum sum 
 * of a sequence of integers in an input file
 * @author Adam McIntosh
 *
 */
public class Maxsum {
	
	/** the default number of workers */
	private static final int DEFAULT_WORKERS = 5;
	
	/** the return code for failure */
	private static final int EXIT_FAILURE = 1;
	
	/** list of integer input values */
	private static ArrayList<Integer> vList;
	
	/** the maximum sum found by all workers */
	private static int maxSum = 0;
	
	/** a flag to tell whether each thread should report its sum */
	private static boolean report = false;
	
	/**
	 * Start the program
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		
		int workers = DEFAULT_WORKERS;
		vList = new ArrayList<Integer>();
		
		//error check the number of arguments
		if (args.length < 1 || args.length > 2) {
			usage();
		}
		
		//parse the input arguments
		Scanner workerScanner = new Scanner(args[0]);
		try {
			workers = workerScanner.nextInt();
			if (workers < 1) {
				usage();
			}
		} catch (Exception e) {
			workerScanner.close();
			usage();
		}
		if (args.length == 2 && !args[1].equals("report")) {
			usage();
		}
		if (args.length == 2 && args[1].equals("report")) {
			report = true;
		}
		workerScanner.close();
		
		//parse the input integers
		Scanner intScanner = new Scanner(System.in);
		while (intScanner.hasNextInt()) {
			vList.add(intScanner.nextInt());
		}
		intScanner.close();
		
		ArrayList<SumFinder> workerList = new ArrayList<SumFinder>();
		
		//create the workers
		for (int i = 0; i < workers; i++) {
			SumFinder worker = new SumFinder(workers, i, vList, report);
			workerList.add(worker);
			worker.start();
		}
		
		//wait for the workers and check their reported sums to find a global maximum
		for (int i = 0; i < workers; i++) {
			try {
				workerList.get(i).join();
				int currSum = workerList.get(i).getMaxSum();
				if (currSum > maxSum) {
					maxSum = currSum;
				}
			} catch (Exception e) {
				System.exit(EXIT_FAILURE);
			}
		}
		System.out.println("Maximum Sum: " + maxSum);

	}
	
	/**
	 * Prints out a message for proper usage
	 */
	private static void usage() {
		System.out.println("usage: maxsum <workers>");
		System.out.println("       maxsum <workers> report");
		System.exit(EXIT_FAILURE);
	}

}

/**
 * Class that multiple threads will run to find the maximum integer sum within a specific 
 * subset of possible sequences of integers within a larger sequence
 * @author adam
 *
 */
class SumFinder extends Thread{
	
	/** the number of threads being created in main */
	private int numWorkers;
	
	/** the id of this thread */
	private int threadID;
	
	/** the maximum sum found by this thread */
	private int maxSum;
	
	/** a list of integers from which to compute sums */
	private ArrayList<Integer> intList;
	
	/** whether or not to report this thread's max sum */
	private boolean report;
	
	/**
	 * Creates a SumFinder thread
	 * @param numWorkers the number of threads being created in main
	 * @param threadID the id of this thread
	 * @param intList a list of integers from which to compute sums
	 * @param report whether or not the thread should report its max sum
	 */
	public SumFinder(int numWorkers, int threadID, ArrayList<Integer> intList, boolean report) {
		this.numWorkers = numWorkers;
		this.threadID = threadID;
		this.maxSum = 0;
		this.intList = intList;
		this.report = report;
	}
	
	/**
	 * The method that actually runs the inspection of integer sequences and the storage of sums
	 */
	public void run() {
		int maxSum = 0;
		for (int i = this.threadID; i < intList.size(); i += this.numWorkers) {
			int currSum = 0;
			for (int j = i; j < intList.size(); j++) {
				currSum += intList.get(j);
				if (currSum > maxSum) {
					maxSum = currSum;
				}
			}
		}
		this.maxSum = maxSum;
		if (this.report) {
			System.out.println("I'm thread " + this.threadID + ". The maximum sum I found is " + this.maxSum + ".");
		}
	}
	
	/**
	 * Returns the maximum sum this thread found
	 * @return the maximum sum this thread found
	 */
	public int getMaxSum() {
		return this.maxSum;
	}
}
