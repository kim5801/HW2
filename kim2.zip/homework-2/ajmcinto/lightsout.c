/**
 * @file lightsout.c
 * @author Adam McIntosh
 * A file with functionality for playing the lights out game
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** the number of arguments expected for the move command */
#define EXPECTED_ARGS_MOVE 4

/** the number of arguments expected for the report command */
#define EXPECTED_ARGS_REPORT 2

/** the number of arguments expected for the undo command */
#define EXPECTED_ARGS_UNDO 2

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * SOURCE: I took this function from my HW1 implementation
 * Retrieves a string representation of a board
 * 
 * @param board the board for which a string representation is desired
 * @return char* the string representation of the board
 */
char* getBoardString(GameState* board) {
  //room for GRID_SIZE rows of GRID_SIZE length, each with a newline. One null terminator at the end
  char* boardString = (char*) malloc(GRID_SIZE * GRID_SIZE + GRID_SIZE + 1);
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      boardString[i * (GRID_SIZE + 1) + j] = board->boardArr[i][j];
    }
    boardString[i * (GRID_SIZE + 1) + GRID_SIZE] = '\n';
  }
  boardString[GRID_SIZE * GRID_SIZE + GRID_SIZE] = '\0';
  return boardString;
}

/**
 * SOURCE: I took this function from my HW1 implementation
 * Changes the status of a light at a coordinate
 * 
 * @param board the board whose light will be toggled
 * @param row the row number of the light
 * @param col the col numher of the light
 */
void toggleTile(GameState* board, int row, int col) {
  //if a tile is off of the board, we will do nothing
  if (row < 0 || row > GRID_SIZE - 1) {
    return;
  }
  if (col < 0 || col > GRID_SIZE - 1) {
    return;
  }
  if (board->boardArr[row][col] == '*') {
    board->boardArr[row][col] = '.';
  }
  else {
    board->boardArr[row][col] = '*';
  }
}

/**
 * SOURCE: I took this function from my HW1 implementation
 * Makes a move, switching all adjacent lights, on a board
 * 
 * @param board the board on which the move is made
 * @param row the row coordinate of the move
 * @param col the col coordinate of the move
 */
void makeMove(GameState* board, int row, int col) {
  //toggle at this coordinate
  toggleTile(board, row, col);
  //toggle the tile above this one
  toggleTile(board, row - 1, col);
  //toggle the tile below this one
  toggleTile(board, row + 1, col);
  //toggle the tile to the right of this one
  toggleTile(board, row, col + 1);
  //toggle the tile to the left of this one
  toggleTile(board, row, col - 1);
}

/**
 * Error checks the input and starts the program
 * 
 * @param argc the number of command-line arguments
 * @param argv an array of command-line arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {

  //error checking
  if (strcmp(argv[1], "move") == 0) {
      //there should be 3 arguments after ./client
      if (argc != EXPECTED_ARGS_MOVE) {
        fail("error");
      }
  }
  //we received an undo command
  else if (strcmp(argv[1], "undo") == 0) {
      if (argc != EXPECTED_ARGS_UNDO) {
        fail("error");
      }
  }
  //we received a report command
  else if (strcmp(argv[1], "report") == 0) {
      if (argc != EXPECTED_ARGS_REPORT) {
        fail("error");
      }
  }
  int key = ftok("/afs/unity.ncsu.edu/users/a/ajmcinto", 0);
  int shmid = shmget(key, sizeof(GameState), 0);
  if (shmid == -1) {
    fail("Could not attach to shared memory.");
  }

  GameState* ourGame = (GameState*) shmat(shmid, 0, 0);

  //we received a move command
  if (strcmp(argv[1], "move") == 0) {
    //there should be 3 arguments after ./client
    if (argc != 4) {
      fail("error");
    }
    int row = -1;
    int col = -1;
    int ret = sscanf(argv[2], "%d", &row);
    int ret2 = sscanf(argv[3], "%d", &col);
    if (ret == 0 || ret2 == 0) {
      fail("error");
    }
    if (row < 0 || row > 4 || col < 0 || col > 4) {
      fail("error");
    }
    else {
      makeMove(ourGame, row, col);
      ourGame->lastMove[0] = row;
      ourGame->lastMove[1] = col;
      printf("success\n");
      return 0;
    }
  }
  //we received an undo command
  else if (strcmp(argv[1], "undo") == 0) {
    if (argc != 2) {
      fail("error");
    }
    if (ourGame->lastMove[0] == -1) {
      //there is not a move to undo
      fail("error");
    }
    else {
      makeMove(ourGame, ourGame->lastMove[0], ourGame->lastMove[1]);
      ourGame->lastMove[0] = -1;
      ourGame->lastMove[1] = -1;
      printf("success\n");
    }
  } 
  //we received a report command
  else if (strcmp(argv[1], "report") == 0) {
    if (argc != 2) {
      fail("error");
    }
    printf("%s", getBoardString(ourGame));
  }
  else {
    fail("error");
  }

  int detachReturn = shmdt(ourGame);
  if (detachReturn == -1) {
    fail("Could not detach from shared memory.");
  }
  return EXIT_SUCCESS;
}
