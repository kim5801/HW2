/**
 * @file reset.c
 * @author Adam McIntosh
 * File with functionality for reading a game board from
 * a file and storing it in memory that lightsout.c can access
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

/**
 * Takes an input message and breaks it up into individual words based on spaces.
 * The message is null terminated.
 * SOURCE INFO: this code is based on code I wrote for parseCommand() in the first homework
 *
 * @param line the input command
 * @param words an array of pointers to the words that are read in
 * @return int the number of words read in
 */
int parseInput(char *message, char *words[])
{
  int index = 0;
  int wordCount = 0;
  // traverse until we hit the end of the message
  while (message[index] != '\0')
  {
    while (isspace(message[index]))
    {
      index++;

      // we may have just pushed ourself to the very end of the line
      if (message[index] == '\0')
      {
        return wordCount;
      }
    }
    int wordLen = 0;
    while (!isspace(message[index + wordLen]) && message[index + wordLen] != '\0')
    {
      wordLen++;
    }
    char *word = (char *)malloc(wordLen + 1);
    for (int i = 0; i < wordLen; i++)
    {
      word[i] = message[index + i];
    }
    word[wordLen] = '\0';
    index += wordLen;
    words[wordCount] = word;
    wordCount++;
  }
  return wordCount;
}

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message and exit.
static void usage()
{
  fprintf(stderr, "usage: reset <board-file>\n");
  exit(1);
}

/**
 * SOURCE: I took this function from my HW1 implementation
 * Parses a board file, storing its contents in a Board struct
 *
 * @param filename the name of the input file
 * @param board a pointer to the struct to be filled in
 */
void parseInputFile(char *filename, GameState *game)
{
  FILE *boardFile = fopen(filename, "r");
  if (boardFile == NULL)
  {
    char beginning[] = "Invalid input file: ";
    char *failMessage = strcat(beginning, filename);
    fail(failMessage);
  }
  char buffer[(GRID_SIZE + 1) * GRID_SIZE + 1];
  int bytesRead = fread(buffer, 1, ((GRID_SIZE + 1) * GRID_SIZE + 1), boardFile);
  if (bytesRead < (GRID_SIZE + 1) * GRID_SIZE)
  {
    char beginning[] = "Invalid input file: ";
    char *failMessage = strcat(beginning, filename);
    fail(failMessage);
  }
  // generate each row of our board
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      if (buffer[i * (GRID_SIZE + 1) + j] != '*' && buffer[i * (GRID_SIZE + 1) + j] != '.')
      {
        char beginning[] = "Invalid input file: ";
        char *failMessage = strcat(beginning, filename);
        fail(failMessage);
      }
      game->boardArr[i][j] = buffer[i * (GRID_SIZE + 1) + j];
    }
    // make sure there is a newline at every GRID_SIZE + 1th character
    if (buffer[i * (GRID_SIZE + 1) + GRID_SIZE] != '\n')
    {
      char beginning[] = "Invalid input file: ";
      char *failMessage = strcat(beginning, filename);
      fail(failMessage);
    }
  }
}

/**
 * Starts the program.
 * Parses an input file and stores it in shared memory
 * 
 * @param argc 
 * @param argv 
 * @return int 
 */
int main(int argc, char *argv[])
{
  //make sure we got one extra argument that provides the input file
  if (argc != 2)
  {
    usage();
  }
  int key = ftok("/afs/unity.ncsu.edu/users/a/ajmcinto", 0);
  //retrieve the shared memory segment
  int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
  if (shmid == -1) {
    fail("Could not attach to shared memory.");
  }

  //attach to the shared memory
  GameState* ourGame = (GameState*) shmat(shmid, 0, 0);
  parseInputFile(argv[1], ourGame);

  int detachReturn = shmdt(ourGame);
  if (detachReturn == -1) {
    fail("Could not detach from shared memory.");
  }
  // shmctl(shmid, IPC_RMID, 0);

  return 0;
}
