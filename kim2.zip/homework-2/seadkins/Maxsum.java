import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;
import java.util.concurrent.Semaphore;

public class Maxsum {

    // Input sequence of values.
    private static ArrayList<Integer> vList;

    // Number of values on the list.
    private static int vCount = 0;

    // Boolean to keep track of if the user uses the "report" command
    private static boolean report = false;

    // In that determines how many worker threads to use
    private static int workers = 0;
    
    // The accumulative, total max found so far
    private static int totalMax = Integer.MIN_VALUE;

    // Semaphore blocking threads from editing the max at the same time
    private static final Semaphore locked = new Semaphore(1);

    // Worker thread constructor
    static class tWorker implements Runnable {
        // the value at which each thread should run, will be passed in as a parameter
        private int startVal;

        //constructor allows me to use the start value in the run()
        public tWorker (int start) {
            this.startVal = start;
        }

        public void run() {
            
            int tempMax = Integer.MIN_VALUE;

            // Calculate the maxes here:
            for ( int i = this.startVal; i < vCount; i += workers ) {
                int childMax = 0;
                
                for ( int j = i; j < vCount; j++ ) {
                    childMax += vList.get(j);

                    if (tempMax < childMax) {
                        tempMax = childMax;
                    }

                }
                
            }
            // Use semaphore to lock other threads out of the calculation
            try {
                locked.acquire();
            } catch ( InterruptedException e ) {
                System.out.println( "Interrupted!" );
            }
            
            if (report) {
                System.out.println("I'm " + Thread.currentThread().getId() 
                                    + ". The maximum sum I found is " + tempMax + ".");
            }

            if (tempMax > totalMax) {
                totalMax = tempMax;
            }

            locked.release();            
            
        }
    }

    public static void main( String[] args ) {

        // check that there are a correct amount of arguments.
        if (args.length < 1 || args.length > 2) {
            throw new IllegalArgumentException("usage: maxsum <workers>\n       maxsum <workers> report\n");
        }

        // checks that the first argument is an int for number of requested workers.
        try {
            workers = Integer.parseInt(args[0]);
        } catch (Exception e) {
            throw new IllegalArgumentException("usage: maxsum <workers>\n       maxsum <workers> report\n");
        }

        // Makes sure that there is a positive number of workers requested
        if (workers <= 0) {
            throw new IllegalArgumentException("usage: maxsum <workers>\n       maxsum <workers> report\n");
        }

        // check that if there is a second argument that it is "report"
        if (args.length == 2) {
            if (args[1].equals("report")) {
                report = true;
            }
        }

        vList = new ArrayList<Integer>();
        // try to read in the values in the given input file.
        try {
            Scanner reader = new Scanner(System.in);
            int toAdd;
            // the scanner can still read integers from the input file, it should add them to the arrayList.
            while (reader.hasNext()) {
                toAdd = reader.nextInt();
                vList.add(vCount, toAdd);
                vCount++;
            }
        } catch(Exception e) {
			throw new IllegalArgumentException("Unable to load file.");
		}

        // Create an array of threads
        Thread workerThreads[] = new Thread[workers];

        // Loop to initialize and start each thread
        for( int i = 0; i < workers; i++ ) {
            workerThreads[i] = new Thread( new tWorker(i) );
            workerThreads[i].start();
        }

        // Loop to join each thread
        for( int i = 0; i < workers; i++ ) {
            
            try {
                workerThreads[i].join();
            } catch ( InterruptedException e ) {
                System.out.println( "Interrupted!" );
            }
            
        }
        // Print out the total max found
        System.out.println("Maximum Sum: " + totalMax);

    }



}