#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // Parse the command-line arguments, and initialize the board.
  if ( argc != 2 ) {
    usage();
  }

  // Open a file to read.
  int readFile = open( argv[1], O_RDONLY );

  // Check that the input file is valid.
  if ( readFile < 0 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit(1);
  }

  // Read in the input from the input file:
  char longBoard[25];
  int i = 0;
  int readLen = read( readFile, &longBoard[i], 1 );

  while ( readLen > 0) {
    if (longBoard[i] != '\n') {
      i++;
    }
    readLen = read( readFile, &longBoard[i], 1 );
  }

  // Make sure that the file being read in has only '.' and '*' characters
  for (int i = 0; i < GRID_SIZE * GRID_SIZE; i++) {
    if (longBoard[i] != '.' && longBoard[i] != '*'){
      fprintf( stderr, "Invalid input file: %s\n", argv[1] );
      exit(1);
    }
  }

  // Make a shared memory segment as big as the GameState struct, named key
  key_t key = ftok("/afs/unity.ncsu.edu/users/s/seadkins", 0);
  int shmid = shmget( key, sizeof(struct GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Initialize the GameState and map the shared memory into my address space
  struct GameState *gs = (struct GameState *)shmat( shmid, 0, 0 );
  if ( gs == (struct GameState *) - 1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  gs->moved = false;
  gs->undone = false;

  // Empty board is a 2D array of length and width 5. The loop should read in rows of input to initialize the board
  //char board[GRID_SIZE][GRID_SIZE];
  int count = 0;
  for (int row = 0; row < GRID_SIZE; row ++)
  {
    for(int col = 0; col < GRID_SIZE; col++)
    {
      gs->board[row][col] = longBoard[count];
      count++;
    }
  }

  return 0;
}
