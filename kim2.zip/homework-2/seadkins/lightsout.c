#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  bool report = false;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 4 ) {
    fail("error");
  }

  // If the second argument is "move" it should have 2 more commands for row and collumn. 
  if ( argc == 4 ) {
    if ( strcmp( argv[ 1 ], "move" ) != 0 ) {
      fail("error");
    }
  }

  // Determine what command was given by the user
  char *command = argv[1];
  int row1 = 0;
  int col1 = 0;

  // if the user command was "move", then assign the following integers as the row and col of the tile to move
  if (strcmp( command, "move" ) == 0 && argc == 4) {
    char possRow[2];
    char possCol[2];
    strcpy(possRow, argv[2]);
    strcpy(possCol, argv[3]);
    if (!isdigit(possRow[0]) || !isdigit(possCol[0])) {
      fail("error");
    }
    row1 = atoi(argv[2]);
    col1 = atoi(argv[3]);
    if (row1 < 0 || row1 > 4 || col1 < 0 || col1 > 4) {
      fail("error");
    }
  }
  else if (strcmp( command, "move" ) == 0 && argc != 4) {
    fail("error");
  }

  // if the user requested a report, set report to true
  if (strcmp( argv[ 1 ], "report" ) == 0) {
    report = true;
  }

  // Make a shared memory segment as big as the GameState struct, named key
  key_t key = ftok("/afs/unity.ncsu.edu/users/s/seadkins", 0);
  int shmid = shmget( key, 0, 0 );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Initialize the GameState and map the shared memory into my address space
  struct GameState *gs = (struct GameState *)shmat( shmid, 0, 0 );
  if ( gs == (struct GameState *) - 1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // If the user requests a move, move the requested board tile
  if (strcmp(command, "move") == 0) {

    // save the original state of the board
    gs->rowMoved = row1;
    gs->colMoved = col1;

    // switches the selected light
    if (gs->board[row1][col1] == '*') {
      gs->board[row1][col1] = '.';
    }
    else {
      gs->board[row1][col1] = '*';
    }
    // switches the light below the selected light
    if (row1 < GRID_SIZE - 1) {
      if (gs->board[row1 + 1][col1] == '*') {
        gs->board[row1 + 1][col1] = '.';
      }
      else {
        gs->board[row1 + 1][col1] = '*';
      }
    }
    // switches the light above the selected light
    if (row1 > 0) {
      if (gs->board[row1 - 1][col1] == '*') {
        gs->board[row1 - 1][col1] = '.';
      }
      else {
        gs->board[row1 - 1][col1] = '*';
      }
    }
    // switches the light to the right of the selected light
    if (col1 < GRID_SIZE - 1) {
      if (gs->board[row1][col1 + 1] == '*') {
        gs->board[row1][col1 + 1] = '.';
      }
      else {
        gs->board[row1][col1 + 1] = '*';
      }
    }
    // switches the light to the left of the selected light
    if (col1 > 0) {
      if (gs->board[row1][col1 - 1] == '*') {
        gs->board[row1][col1 - 1] = '.';
      }
      else {
        gs->board[row1][col1 - 1] = '*';
      }
    }

    gs->moved = true;
    
    gs->undone = false;
    printf("success\n");
  }

  // if the user requests to undo the last move, then preform the previous move again to reset it
  if (strcmp(command, "undo") == 0 && !gs->undone && gs->moved) {
    
    // save the original state of the board
    row1 = gs->rowMoved;
    col1 = gs->colMoved;

    // switches the selected light
    if (gs->board[row1][col1] == '*') {
      gs->board[row1][col1] = '.';
    }
    else {
      gs->board[row1][col1] = '*';
    }
    // switches the light below the selected light
    if (row1 < GRID_SIZE - 1) {
      if (gs->board[row1 + 1][col1] == '*') {
        gs->board[row1 + 1][col1] = '.';
      }
      else {
        gs->board[row1 + 1][col1] = '*';
      }
    }
    // switches the light above the selected light
    if (row1 > 0) {
      if (gs->board[row1 - 1][col1] == '*') {
        gs->board[row1 - 1][col1] = '.';
      }
      else {
        gs->board[row1 - 1][col1] = '*';
      }
    }
    // switches the light to the right of the selected light
    if (col1 < GRID_SIZE - 1) {
      if (gs->board[row1][col1 + 1] == '*') {
        gs->board[row1][col1 + 1] = '.';
      }
      else {
        gs->board[row1][col1 + 1] = '*';
      }
    }
    // switches the light to the left of the selected light
    if (col1 > 0) {
      if (gs->board[row1][col1 - 1] == '*') {
        gs->board[row1][col1 - 1] = '.';
      }
      else {
        gs->board[row1][col1 - 1] = '*';
      }
    }

    gs->moved = false;
    
    gs->undone = true;
    printf("success\n");
  }
  else if (strcmp(command, "undo") == 0 && (gs->undone || !gs->moved)) {
    fail("error");
  }

  // If the user has requested a report, print out the report
  if (report) {
    printf("\n");
    int count = 0;
    for (int row = 0; row < GRID_SIZE; row ++)
    {
      for(int col = 0; col < GRID_SIZE; col++)
      {
        printf("%c", gs->board[row][col]);
        count++;
      }
      printf("\n");
    }
  }

  return 0;
}
