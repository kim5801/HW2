#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

const int BLOCK_SIZE = GRID_SIZE * GRID_SIZE;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  if ( argc < 2 || argc > 2 )
    usage();

  FILE *fp = fopen( argv[ 1 ], "r" );
  if ( !fp ) {
    printf( "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }
  
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/j/jrbrefka", 1 ), sizeof( GameState ), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Failed to create memory" );
  
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Failed to map shared memory segment into address space" );
  
  //read in board from input file
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j <= GRID_SIZE; j++ ) {
      int ch = fgetc( fp );
      if ( ch == '.' ) {
        game->grid[ i ][ j ] = 0;
      } else if ( ch == '*' ) {
        game->grid[ i ][ j ] = 1;
      }
    }
  }
  game->lastY = -1;
  game->lastX = -1;
  
  shmdt( game );
  
  return 0;
}
