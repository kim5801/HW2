import java.util.*;

/**
  * @File Maxsum.java
  * Calculates the max sum of a series of numbers in a file
  * @Author Joey Brefka (jrbrefka)
  */
public class Maxsum {
  
  /**
    * Thread class for threads to break up the work of the program
    */
  static class SumThread extends Thread {
    
    /** The current max sum of the thread */
    public int max;
    
    /** The first index the thread should consider in the list of ints*/
    private int startIdx;
    
    /** The list of ints for finding the largest sum of consecutive ints*/
    private ArrayList<Integer> nums;
    
    /** The number of threads so that this thread knows which indexes to start at in the list */
    private int numWorkers;
    
    /** The constructor */
    public SumThread( int numWorkers, int startIdx, ArrayList<Integer> nums ) {
      this.numWorkers = numWorkers;
      this.startIdx = startIdx;
      this.nums = nums;
    }
    
    /** The execution method for the thread */
    public void run() {
      for ( int i = startIdx; i < nums.size(); i += numWorkers ) {
        int sum = 0;
        for ( int j = i; j < nums.size(); j++ ) {
          sum += nums.get( j );
          if ( sum > max ) {
            max = sum;
          }
        }
      }
    }
    
  }
  

  /**
    * Main method of the program
    * @param args for the command line arguments
    */
  public static void main( String[] args ) {
    
    int numWorkers;
    boolean report = false;
    
    if ( args.length == 2 ) {
      if ( args[ 1 ].equals( "report" ) ) {
        report = true;
      }
    }
    numWorkers = Integer.parseInt( args[ 0 ] );
    
    
    SumThread[] threads = new SumThread[ numWorkers ];
    int max = 0;
    
    //read the numbers from the input file to a list
    ArrayList<Integer> nums = new ArrayList<Integer>();
    Scanner in = new Scanner( System.in );
    while ( in.hasNextInt() ) {
      nums.add( nums.size(), in.nextInt() );
    }
    in.close();
    
    //make the threads
    for ( int i = 0; i < numWorkers; i++ ) {
      threads[ i ] = new SumThread( numWorkers, i, nums );
      threads[ i ].start();
    }
    
    try {
      //join the threads
      for ( int i = 0; i < numWorkers; i++ ) {
        threads[ i ].join();
        //check if the threads max is greater than the overall max
        if ( threads[ i ].max > max ) {
          max = threads[ i ].max;
        }
        if ( report ) {
          System.out.println( "I'm thread " + threads[ i ].getId() + ". The maximum sum I found is " + 
                              threads[ i ].max + "." );
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    
    //print the final max sum
    System.out.println("Maximum Sum: " + max);
  }

}