#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/j/jrbrefka", 1 ), 0, 0 );
  if ( shmid == -1 )
    fail( "Failed to create memory" );
  
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Failed to map shared memory segment into address space" );
  
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    if ( argc != 4 ) {
      fail("error");
    }
    
    int x = atoi( argv[ 2 ] );
    int y = atoi( argv[ 3 ] );
    //make sure it did not parse garbage
    if ( x == 0 && !( strcmp( argv[ 2 ], "0" ) == 0 ) ) {
      fail("error");
    } else if ( y == 0 && !( strcmp( argv[ 3 ], "0" ) == 0 ) ) {
      fail("error");
    } else if ( x >= GRID_SIZE || x < 0 || y >= GRID_SIZE || y < 0 ) {
      //make sure x and y are valid
      fail("error");
    } else {
      //flip lights
      if ( x - 1 >= 0 ) {
        if ( game->grid[ x - 1 ][ y ] == 0 ) {
          game->grid[ x - 1 ][ y ] = 1 ;
        } else {
          game->grid[ x - 1 ][ y ] = 0 ;
        }
      }
      if ( x + 1 < GRID_SIZE ) {
        if ( game->grid[ x + 1 ][ y ] == 0 ) {
          game->grid[ x + 1 ][ y ] = 1 ;
        } else {
          game->grid[ x + 1 ][ y ] = 0 ;
        }
      }
      if ( y - 1 >= 0 ) {
        if ( game->grid[ x ][ y - 1 ] == 0 ) {
          game->grid[ x ][ y - 1 ] = 1 ;
        } else {
          game->grid[ x ][ y - 1 ] = 0 ;
        }
      }
      if ( y + 1 < GRID_SIZE ) {
        if ( game->grid[ x ][ y + 1 ] == 0 ) {
          game->grid[ x ][ y + 1 ] = 1 ;
        } else {
          game->grid[ x ][ y + 1 ] = 0 ;
        }
      }
      if ( game->grid[ x ][ y ] == 0 ) {
          game->grid[ x ][ y ] = 1 ;
      } else {
          game->grid[ x ][ y ] = 0 ;
      }
      game->lastX = x;
      game->lastY = y;
      printf("success\n");
    } 
    
  } else if ( strcmp( argv[ 1 ], "undo" ) == 0  ) {
    if ( argc != 2 )
      fail("error");
    //check if an undo can be done
    if ( game->lastX < 0 || game->lastY < 0 ) {
      fail("error");
    } else {
      
      //flip lights
      if ( game->lastX - 1 >= 0 ) {
        if ( game->grid[ game->lastX - 1 ][ game->lastY ] == 0 ) {
          game->grid[ game->lastX - 1 ][ game->lastY ] = 1 ;
        } else {
          game->grid[ game->lastX - 1 ][ game->lastY ] = 0 ;
        }
      }
      if ( game->lastX + 1 < GRID_SIZE ) {
        if ( game->grid[ game->lastX + 1 ][ game->lastY ] == 0 ) {
          game->grid[ game->lastX + 1 ][ game->lastY ] = 1 ;
        } else {
          game->grid[ game->lastX + 1 ][ game->lastY ] = 0 ;
        }
      }
      if ( game->lastY - 1 >= 0 ) {
        if ( game->grid[ game->lastX ][ game->lastY - 1 ] == 0 ) {
          game->grid[ game->lastX ][ game->lastY - 1 ] = 1 ;
        } else {
          game->grid[ game->lastX ][ game->lastY - 1 ] = 0 ;
        }
      }
      if ( game->lastY + 1 < GRID_SIZE ) {
        if ( game->grid[ game->lastX ][ game->lastY + 1 ] == 0 ) {
          game->grid[ game->lastX ][ game->lastY + 1 ] = 1 ;
        } else {
          game->grid[ game->lastX ][ game->lastY + 1 ] = 0 ;
        }
      }
      if ( game->grid[ game->lastX ][ game->lastY ] == 0 ) {
          game->grid[ game->lastX ][ game->lastY ] = 1 ;
      } else {
          game->grid[ game->lastX ][ game->lastY ] = 0 ;
      }
      
      game->lastX = -1;
      game->lastY = -1;
      
      printf("success\n");
    }
  } else if ( strcmp( argv[ 1 ], "report" ) == 0  ) {
    if ( argc != 2 )
      fail("error");
    
    //report lights
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        if ( game->grid[ i ][ j ] ) {
          printf( "%c", '*' );
        } else {
          printf( "%c", '.' );
        }
      }
      printf( "\n" );
    }
    
  } else {
    fail("error");
  }
  
  shmdt(game);
  
  return 0;
}
