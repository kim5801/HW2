/**
 * @file lightsout.c
 * @author Christina Albores (ccalbore)
 * @brief  This program's job is to interpret a user command given in
 * the commandline arguments and make requested changes to the game board
 * stored in shared memory.
 * @date 2022-09-22
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/**
 * @brief Print out an error message and exit.
 * 
 * @param message the message to print
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Prints out the game board
 * 
 * @param board the board to print
 */
void printGameBoard(GameState* board)
{
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            char c = board->board[i][j];
            printf("%c", c);
            
        }
        printf("\n");
    }
}

/**
 * @brief Updates the game board by performing the given move
 * 
 * @param board the board to update
 * @param row the row the move is on
 * @param col the column the move is on
 * @return int returns status
 */
int updateGameBoard(GameState* board, int row, int col) 
{
    // Alwasy return successful since the moves are checked before hand
    int status = 0;

    // Toggles the on/off for row and col
    if (board->board[row][col] == '.') {
        board->board[row][col] = '*';
    } else {
        board->board[row][col] = '.';
    }

    // Toggles the on/off for row - 1 and col if possible
    if ((row - 1) >= 0) {
      if (board->board[(row - 1)][col] == '.') {
        board->board[(row - 1)][col] = '*';
      } else {
          board->board[(row - 1)][col] = '.';
      }
    }

    // Toggles the on/off for row + 1 and col if possible
    if ((row + 1) <= 4) {
      if (board->board[(row + 1)][col] == '.') {
        board->board[(row + 1)][col] = '*';
      } else {
          board->board[(row + 1)][col] = '.';
      }
    }

    // Toggles the on/off for row and col + 1 if possible
    if ((col + 1) <= 4) {
      if (board->board[row][(col + 1)] == '.') {
        board->board[row][(col + 1)] = '*';
      } else {
          board->board[row][(col + 1)] = '.';
      }
    }

    // Toggles the on/off for row and col - 1 if possible
    if ((col - 1) >= 0) {
      if (board->board[row][(col - 1)] == '.') {
        board->board[row][(col - 1)] = '*';
      } else {
          board->board[row][(col - 1)] = '.';
      }
    }
    return status;
}

/**
 * @brief Takes in arguments from command line for game commands,
 * executes them and messages back if they are successful or not.
 * 
 * @param argc the number of arguments
 * @param argv the list of arguments
 * @return int returns success
 */
int main( int argc, char *argv[] ) {

  // The GameState struct pointer
  GameState *gameState;

  // Personal key for shared memory
  key_t key;
  // Set the key with personal afs pathname
  key = ftok("/afs/unity.ncsu.edu/users/c/ccalbore", 'b');

  // Get the shared memory segment of one GameState struct
  int shmid = shmget(key, sizeof(GameState), 0);
  // Call fail if error
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Set the GameState pointer to the shared memory
  gameState = (GameState *) shmat(shmid, 0, 0);


  // If there are 4 arguments, that means its a move command
  if (argc == 4) {
    // Error checking. If the command is not move, print error
    if (strcmp(argv[1], "move") != 0) {
        printf("error\n");
    } else {
        // Get the int values for row and column
        int row = atoi(argv[2]);
        int col = atoi(argv[3]);

        // If the row or col are not betwee 0-4 print error
        if ((row < 0 || row > 4 || (col < 0 || col> 4))) {
            printf("error\n");
        } else {
          // Update the game state with the valid  move
          updateGameBoard(gameState, row, col);
          printf("success\n");
          // Update the last move row and column
          gameState->lastRow = row;
          gameState->lastCol = col;
          // Set the undoFlag to indicate that an undo has not been done
          gameState->undoFlag = 0;
        }     
    }
  } else if (argc == 2) {
    // If there are 2 arguments, that means its a report or undo command
    if (strcmp(argv[1], "report") == 0) {
      // Print the game board state
      printGameBoard(gameState);
          
    } else if (strcmp(argv[1], "undo") == 0) {
      // If the undoFlag is true, print an error
      if (gameState->undoFlag == 1) {
          printf("error\n");
      } else {
        // Update the game board state with the previous moves
        updateGameBoard(gameState, gameState->lastRow, gameState->lastCol);
        printf("success\n");
        // Set the undoFlag to indicate that an undo has been done
        gameState->undoFlag = 1;
      }
    } else {
        printf("error\n");
    }
  } else {
      printf("error\n");
      exit(1);
  }

  // Release our reference to the shared memory segment.
  shmdt(gameState);

  return 0;
}
