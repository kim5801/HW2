import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * This program takes in a list of integers and finds a contiguous 
 * non-empty subsequence within the sequence that has the largest sum.
 * 
 * @author Christina Albores (ccalbore)
 */
public class Maxsum {

    // Print out a usage message, then exit.
    public static void usage() {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit( 1 );
    }

    /**
     * Class for the main thread to create the other thread workers
     * and to find the final max sum.
     */
    static class MyMainThread extends Thread {
        
        /** The number of workers */
        private int numWorkers = 0;
        /** Flag for if the user wants a report */
        private boolean report =  false;
        /** The final max sum found */
        private int finalMaxSum = 0;

        /**
         * Sets the number of workers and report flag
         * @param workers The number of workers
         * @param report Flag for report
         */
        public MyMainThread(int workers, boolean report) {
            this.numWorkers = workers;
            this.report = report;

            if (numWorkers > size) {
                numWorkers = size;
            }
        }
        
        /**
         * Creates n amount of worker threads, finds the final
         * max sum, and terminates the workers.
         */
        public void run() {
            // Make n threads and let them start running.
            //Array of threads with size of numWorkers
            MyThread[] threads = new MyThread [ numWorkers ];
            for ( int i = 0; i < threads.length; i++ ) {
                threads[ i ] = new MyThread(i, numWorkers, report );
                threads[ i ].start();
            }

            // Wait for each of the threads to terminate.
            try {
                for ( int i = 0; i < threads.length; i++ ) {
                    threads[ i ].join();
                    // The max found by the worker
                    int workerMax = threads[i].maxSum;
                    
                    if (workerMax > finalMaxSum) {
                        finalMaxSum = workerMax;
                    }
                }
            } catch ( InterruptedException e ) {
                System.out.println( "Interrupted during join!" );
            }

            //Print out the final max sum found
            System.out.println("Maximum Sum: " + finalMaxSum);
        }
    }

    /**
     * Class for worker threads to calculate their 
     * ranges based on their starting index and to find
     * the max sum range.
     */
    static class MyThread extends Thread {
        
        /** The given starting index for the worker */
        int startIndex;
        /** The max sum found by the worker */
        int maxSum = 0;
        /** The number of workers */
        int workers;
        /** Flag for if the user wants a report */
        boolean report;

        /**
         * Sets the startIndex, worker, and report variables
         * @param startIndex The given starting index for the worker
         * @param numWorkers he number of workers
         * @param report Flag for if the user wants a report
         */
        public MyThread(int startIndex, int numWorkers, boolean report) {
            this.startIndex = startIndex;
            this.workers = numWorkers;
            this.report = report;
        }

        /**
         * Finds the max sum of the given index ranges.
         */
        public void run()
        {
            //For each index this worker has to calculate the range
            for (int j = 0; j < (size / workers); j++) {
                
                // Keeps track of the current sum of the range
                int totalSum = 0;
                
                // For each k get the sum of the range from j to k
                for (int k = 0; k < size - startIndex; k++) {
                    // The current sum of the range
                    int sumRange = totalSum;
                    
                    // Add the value at the index to the range
                    sumRange += numList.get(startIndex + k);
                    
                    // Add that sum range to the total range
                    totalSum = sumRange;
                        
                    // If the current sum range is bigger than the max sum
                        // make that the new max sum range
                    if (sumRange > maxSum) {
                        maxSum = sumRange;
                    }
                }
                // Move the start index forward based on worker position
                startIndex += workers;
            }

            // If the report flag is true, make each worker print its id
            if (report == true) {
                try {
                    // Displaying the thread that is running
                    System.out.println( "I'm thread " + Thread.currentThread().getId()
                    + " .The maximum sum I found is " + maxSum + ".");
                }
                catch (Exception e) {
                    // Throwing an exception
                    System.out.println("Exception is caught");
                }
            } else {
                System.out.println("The maximum sum I found is " + maxSum + ".");
            }
        }
    }

    /** Global list of integers from standard input */
    private static List<Integer> numList;
    /** The global size of the list from standard input */
    private static int size = 0;

/**
 * Checks if the command line arguments are valid, reads in the list
 * of integers from standard input, and starts the main thread.
 * @param args list of command line arguments
 * @throws Exception throws an exception if the file does not exist/trouble with the file
 */
    public static void main(String[] args) throws Exception {

        /** The number of worker threads */
        int workers = 4;
        /** Flag for if the user wants a report */
        boolean reportFlag = false;

        // Check if the user wants to report
        if (args.length == 1) {
            reportFlag = false;

        } else if (args.length == 2) {
            // Check that the second argument is report
            if (args[1].compareTo("report") != 0){
                System.exit( 1 );
            }
            reportFlag = true;

        } else {
            // If invalid arguments, print error and exit
            usage();
        }

        // Try to get the number of workers
        try {
            workers = Integer.parseInt(args[0]);
        } catch (Exception e) {
             // If invalid arguments, print error and exit
            usage();
        }

        // Set the Arraylist of integers
        numList = new ArrayList<>();
        
        // Set the scanner
        Scanner scanner = new Scanner(System.in);

        // While the scanner still has a next int
        while (scanner.hasNextInt()) {
            // The number scanned in
            int num = scanner.nextInt();
            // Add the number to the list
            numList.add(num);
            // Increase size of the list
            size++;
        }

        // Close the scanner
        scanner.close();
    
        // Create the main thread
        Thread mainThread  = new Thread( new MyMainThread( workers, reportFlag ));
        // Start the thread
        mainThread.start();

        //Wait for main thread to terminate
        try {
            mainThread.join();
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
    }
}
