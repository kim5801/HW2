/**
 * @file reset.c
 * @author Christina Albores (ccalbore)
 * @brief  This program's job is to read the initial game board state just like
 * and create a shared memory segment containing any needed information about the game.
 * The reset.c program will just exit after creating the shared memory
 * segment and initializing it based on the board description file.
 * @date 2022-09-22
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message with file name and exit.
static void failFile( char const *message, char const *fileName ) {
  fprintf( stderr, "%s%s\n", message, fileName);
  exit( 1 );
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

/**
 * @brief Takes in arguments from command line for file use,
 * checks for valid arguments, creates the shared memory for the 
 * GameState struct, and initializes it.
 * 
 * @param argc the number of arguments
 * @param argv the list of arguments
 * @return int returns success
 */
int main( int argc, char *argv[] ) {

  // If the argc is not exactly 2, exit
  if (argc != 2) {
      usage();
  }

  // The file name of the board
  char* fileName = argv[1];
  // Read the board file
  FILE *readFile = fopen(fileName, "r");

  // If problem opening the file, print error and exit
  if(readFile == NULL)
  {
      failFile("Invalid input file: ", fileName);
  }

  //Create the shared memory segment
  // The shared memory id
  int shmid;
  // The GameState struct pointer
  GameState *gameState;
  // Personal key for shared memory
  key_t key;
  // Set the key with personal afs pathname
  key = ftok("/afs/unity.ncsu.edu/users/c/ccalbore", 'b');
  // Create a shared memory segment of one GameState struct in size.
  shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Set the GameState pointer to the shared memory
  gameState = (GameState *) shmat(shmid, NULL, 0);

  // initializing it based on the board description file.
  // Get the char in the file
    char c = fgetc(readFile);
  
    // Keeps count of row 
    int rowIndex = 0; 
     // Keeps count of column 
    int colIndex = 0;
    // While the char is not EOF
    while (c != EOF) {
        
        // If the symbol is valid, print error and exit
        if (c != '.' && c != '*' && c != '\n') {
            failFile("Invalid input file: ", fileName);
        }
        // If the char is a new line
        if (c == '\n') {
            
            // If there has not been exactly 5 chars, print error and exit
            if (colIndex != 5) {
                failFile("Invalid input file: ", fileName);
            } else {
                // Rewind the column index
                colIndex = 0;
                // Update the row index
                rowIndex++;
                // If the row index is about 5, print error and exit
                if (rowIndex > 5) {
                    failFile("Invalid input file: ", fileName);
                }
            }
        } else {
            // Keep printing the char to the board and update column index
            gameState->board[rowIndex][colIndex] = c;
            colIndex++;
        }
        // Get the next char
        c = fgetc(readFile);
    }

  // Set the undoFlag to 0, since no undo has happend
  gameState->undoFlag = 0;

  // The reset.c program will just exit
  // Release our reference to the shared memory segment.
  shmdt(gameState);
  return 0;
}