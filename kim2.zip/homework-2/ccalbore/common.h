// Height and width of the playing area.
#define GRID_SIZE 5

// GameState representation for storing the state of the board in the server. 
typedef struct game_state
{
    // The game board to use
    char board[GRID_SIZE][GRID_SIZE];
    // The last row move
    int lastRow;
    // The last column move
    int lastCol;
    // Flag for if an undo has happend. 0 means 
    // no, 1 means yes.
    int undoFlag;

}GameState;
