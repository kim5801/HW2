import java.util.*;

public class Maxsum {

  /** String for the report command line argument */
  private static final String REPORT = "report";

  /** Dynamically expanding arraylist to hold all number inputs */
  private static ArrayList<Integer> numbers;

  /** Number of total threads created */
  private static int numThreads;

  /** Thread to calculate max sum of a certain dataset */
  static class MaxSumRunnableThread extends Thread {
    /** Starting index to check for maxsum at. */
    private int indexCheck;

    /** Whether or not to report max sum to stdout */
    private Boolean isReport;

    /** Maximum sum from thread */
    public int maxSum;

    /**
     * Constructor for maxSumRunnable
     * 
     * @param indexCheck Starting index to check for maxsum at.
     * @param isReport
     */
    public MaxSumRunnableThread(int indexCheck, Boolean isReport) {
      this.indexCheck = indexCheck;
      this.isReport = isReport;
    }

    /**
     * Computation that threads does to find the maximum sum at a certain
     * 
     * @param indexCheck Starting index to check for maxsum at.
     */
    public void run() {
      int maxSum = numbers.get(0);
      for (int j = indexCheck; j < numbers.size(); j += numThreads)
      {
      int currentSum = 0;
        // currentIndex keeps track of the previous index of the last currentSum val
        // This ensures we get a better runtime by not having to re-add the previous values
        int currentIndex = j;
        for (int range = j; range < numbers.size(); range++)
        {

         currentSum += numbers.get(currentIndex).intValue();
          if (currentSum > maxSum)
          {
            maxSum = currentSum;
          }
          currentIndex++;
        }
      }
      if (isReport) {
        System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", (int) this.getId(), maxSum);
      }
      this.maxSum = maxSum;

    }
  }

  /**
   * Main method of the program.
   * 
   * @param args command line arguments (not used)
   */
  public static void main(String[] args) {

    numThreads = 5;
    Boolean isReport = false;

    // Make sure valid number of args
    if (args.length > 2 || args.length < 1) {
      System.out.println("usage: maxsum <workers>\nmaxsum <workers> report");
      System.exit(1);
    }

    // Test for valid thread number
    if (args.length >= 1) {
      try {
        numThreads = Integer.parseInt(args[0]);
      } catch (NumberFormatException e) {
        System.out.println("usage: maxsum <workers>\nmaxsum <workers> report");
        System.exit(1);
      }
    }

    // Test for report command
    if (args.length == 2) {
      if (args[1].equals(REPORT)) {
        isReport = true;
      } else {
        System.out.println("usage: maxsum <workers>\nmaxsum <workers> report");
        System.exit(1);
      }
    }

    //Read number list from standard input
    numbers = new ArrayList<Integer>();
    Scanner scnr = new Scanner(System.in);;
    while (scnr.hasNextLine())  {
      try {
        numbers.add(Integer.parseInt(scnr.nextLine()));
      } catch (Exception e) {
        System.out.println("usage: maxsum <workers>\nmaxsum <workers> report");
        System.exit(1);
      }

    }
    scnr.close();

    // DEBUG, LIST CONTENTS:
    // System.out.println(numbers.toString());

    // The threads we make.
    MaxSumRunnableThread[] threads;
    threads = new MaxSumRunnableThread[numThreads];

    for (int i = 0; i < numThreads; i++) {
      threads[i] = new MaxSumRunnableThread(i, isReport);
      threads[i].run();
    }
    // Join with our threads.
    try {
      for (int i = 0; i < numThreads; i++) {
        threads[i].join();
      }
    } catch (InterruptedException e) {
      System.out.println("Interrupted during join!");
    }

    // Find the max of the thread maxsums
    int maxSum = threads[0].maxSum;
    for (int i = 1; i < numThreads; i++) {
      if (threads[i].maxSum > maxSum) {
        maxSum = threads[i].maxSum;
      }
    }
    System.out.printf("Maximum Sum: %d\n", maxSum);

    System.exit(0);
  }
}