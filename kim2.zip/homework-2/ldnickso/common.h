/**
  @file common.h
  @author Lane Nickson (ldnickso)
  @author Dr. Sturgill
  Homework 2, Problem 3
*/

//Libraries being used
#include <stdbool.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// Star and Period symbols
#define STAR '*'
#define PERIOD '.'

// Move command
#define MOVE "move"

// Undo command
#define UNDO "undo"

// Report command
#define REPORT "report"

// PATH and ID used by ftok() to generate a unique shmid
#define PATH "/afs/unity.ncsu.edu/users/l/ldnickso"
#define ID 0001

// Holds all data for the game board
typedef struct {
  // Positions of all stars in periods in a 2d board array
  char board[GRID_SIZE][GRID_SIZE];
  // T/F if an undo move can be made
  bool canUndo;
  // The last X move made
  int lastX;
  // The last Y move made
  int lastY;
} GameState;
