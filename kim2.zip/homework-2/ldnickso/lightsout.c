/**
  @file lightsout.c
  @author Lane Nickson (ldnickso)
  @author Dr. Sturgill
  Homework 2, Problem 3
*/

// Includes all libraries and definitions
#include "common.h"

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Toggles the state of the cell and surrounding cells
static void makeMove(int xPos, int yPos, char (*board)[GRID_SIZE])
{
  // Update left, right, and center
  for (int i = xPos - 1; i <= xPos + 1; i++)
  {
    if (i >= 0 && i < GRID_SIZE)
    {
      if (board[i][yPos] == STAR)
      {
        board[i][yPos] = PERIOD;
      }
      else
      {
        board[i][yPos] = STAR;
      }
    }
  }
  // Update top and down
  for (int i = yPos - 1; i <= yPos + 1; i += 2)
  {
    if (i >= 0 && i < GRID_SIZE)
    {
      if (board[xPos][i] == STAR)
      {
        board[xPos][i] = PERIOD;
      }
      else
      {
        board[xPos][i] = STAR;
      }
    }
  }
}

// Convert the board array into a string
static char *reportBoard(char (*board)[GRID_SIZE])
{
  // This malloc will be freed once the report printed.
  char *boardString = (char *)malloc((GRID_SIZE + 1) * (GRID_SIZE));
  int currentBoardX = 0;
  int currentBoardY = 0;
  // For each board tile, add its status and place newlines when needed
  for (int i = 0; i < (GRID_SIZE + 1) * (GRID_SIZE); i++)
  {
    boardString[i] = board[currentBoardX++][currentBoardY];
    if (currentBoardX == GRID_SIZE)
    {
      if (currentBoardY != GRID_SIZE - 1)
      {
        boardString[++i] = '\n';
      }
      else
      {
        // End the string with a null terminator
        boardString[++i] = '\0';
      }
      currentBoardX = 0;
      currentBoardY++;
    }
  }
  return boardString;
}

int main(int argc, char *argv[])
{
  // Get a unique ID
  key_t shareKey = ftok(PATH, ID);

  // Get the board from shared memory
  int shmid = shmget(shareKey, sizeof(GameState), 0);
  if (shmid == -1)
  {
    fail("Error locating shared memory. Please make sure ./reset has been executed before running this program.");
  }
  GameState *state = (GameState *)shmat(shmid, 0, 0);
  GameState currentState = *state;

  // DEBUG:
  // printf("CanUndo: %d\n", currentState.canUndo);
  // printf("X: %d\n", currentState.lastX);
  // printf("Y: %d\n", currentState.lastY);

  // Initial error handling - wrong number of args
  if (argc < 2 || argc > 4)
  {
    fail("error");
  }

  // Initial error handling - invalid command prefix
  if (strcmp(argv[1], MOVE) != 0 &&
      strcmp(argv[1], UNDO) != 0 &&
      strcmp(argv[1], REPORT) != 0)
  {
    fail("error");
  }
  // Handle undo command
  if (strcmp(argv[1], UNDO) == 0 && argc == 2)
  {
    if (currentState.canUndo)
    {
      // Revert to old board by making the same move again
      makeMove(currentState.lastX, currentState.lastY, currentState.board);
      printf("success\n");
      currentState.canUndo = false;
    }
    else
    {
      printf("error\n");
    }
  }
  // Handle report command
  else if (strcmp(argv[1], REPORT) == 0 && argc == 2)
  {
    char *boardString = reportBoard(currentState.board);
    printf("%s\n", boardString);
    free(boardString);
  }
  // Handle move command
  else if (strcmp(argv[1], MOVE) == 0 && argc == 4)
  {
    // Integer Check
    for (int i = 2; i <= 3; i++)
    {
      int number;
      int isNum = sscanf(argv[i], "%d", &number);
      if (isNum == 0 || number >= GRID_SIZE)
      {
        fail("error");
      }
    }

    int x = atoi(argv[3]);
    int y = atoi(argv[2]);

    // Make the move
    makeMove(x, y, currentState.board);
    currentState.lastX = x;
    currentState.lastY = y;
    currentState.canUndo = true;
  }
  else
  {
    fail("error");
  }

  // Push any changes to the struct to shared memory
  *state = currentState;

  return 0;
}
