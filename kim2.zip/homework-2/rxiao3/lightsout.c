/**
 *@file lightsout.c
 * @author Rose Xiao
 * @brief Will interpret a user command given in the command-line args and make requested changes to the game board stored in shared memory. Other copies of this program running on the same host will automatcally see the changes in the game.
 * @date 2022-09-15
 *
 * @copyright Copyright (c) 2022
 *
 */
#include <stdbool.h>
#include <stdlib.h> //to include the exit macros
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

#define MASK 4
#define STR_LEN 8
 // gcc -Wall -std=c99 -D_SVID_SOURCE lightsout.c -o lightsout

// Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

/**
 * @brief function for the move command
 *
 * @param row the row value
 * @param col the column value
 * @param buffer the GameState struct for the game
 */
static void moveOperation( int row, int col, GameState* buffer )
{
	//decimal value of the open bracket
	//this is the mask used to toggle between '*' and '.'
	int mask = MASK;

	//check where the move requested is located at the corner
	if ( ( row == FIRST_ROW || row == LAST_ROW ) && ( col == FIRST_COL || col == LAST_COL ) ) {
		if ( row == FIRST_ROW && col == FIRST_COL ) {
			//upper left
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else if ( row == FIRST_ROW && col == LAST_COL ) {
			//upper right
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		}
		else if ( row == LAST_ROW && col == FIRST_COL ) {
			//lower left
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else {
			//lower right
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		}

	}
	//check where the move requested is located at the sides
	else if ( row == FIRST_ROW || row == LAST_ROW || col == FIRST_COL || col == LAST_COL ) {
		if ( row == 0 ) {
			//top row
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;

		}
		else if ( row == LAST_ROW ) {
			//bottom row
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else if ( col == FIRST_COL ) {
			//left col
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;
		}
		else {
			//right col
			buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
			buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
			buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		}
	}
	//the move requested is inner
	else {
		buffer->board [ row - 1 ][ col ] = ( buffer->board [ row - 1 ][ col ] ) ^ mask;
		buffer->board [ row + 1 ][ col ] = ( buffer->board [ row + 1 ][ col ] ) ^ mask;
		buffer->board [ row ][ col - 1 ] = ( buffer->board [ row ][ col - 1 ] ) ^ mask;
		buffer->board [ row ][ col + 1 ] = ( buffer->board [ row ][ col + 1 ] ) ^ mask;

	}
	//change the center symbol
	buffer->board [ row ][ col ] = ( buffer->board [ row ][ col ] ) ^ mask;

}

int main( int argc, char* argv [ ] )
{
	// //generate a unique key
	key_t key = ftok( "/afs/unity.ncsu.edu/users/r/rxiao3/CSC246/HW/HW2", 0 );
	if ( key < 0 ) {
		exit( 1 );
	}
	// Make a shared memory segment 1024KB in size
	int shmid = shmget( key, BLOCK_SIZE, 0666 | IPC_CREAT );
	if ( shmid < 0 ) {
		fail( "Can't create shared memory" );
	}

	//Mapping the shared memory struct into the address space
	GameState* buffer = ( GameState* )shmat( shmid, 0, 0 );
	if ( buffer == ( GameState* )-1 ) {
		fail( "Can't map the memory segment into address space." );
	}

	//have the row & col numbers outside so that the undo operation can call the move function
	
	//string to return if the command is invalid
	char status [] = "error";

	//checking if the command was move
	if ( strcmp( "move", argv [ 1 ] ) == 0 ) {

		//read in the two int values that will be used
		int rowScan = sscanf( argv [ 2 ], "%d", &( buffer->rowMove ) );
		int colScan = sscanf( argv [ 3 ], "%d", &( buffer->colMove ) );

		//if not an integer
		if ( rowScan != 1 || colScan != 1 ) {
			fail( "error" );
		}

		//if the integers read in are out of bounds for the board
		if ( buffer->rowMove < FIRST_ROW || buffer->rowMove > LAST_ROW || buffer->colMove < FIRST_COL || buffer->colMove > LAST_COL ) {
			fail( "error" );
		}
		// printf( "MOVE\n" );
		
		//call the move function
		moveOperation( buffer->rowMove, buffer->colMove, buffer );
		//set the undo boolean to true
		buffer->undo = true;
		strncpy( status, "success", STR_LEN );
		printf( "%s\n", status );
	}
	//the client requests to undo 
	else if ( strcmp( "undo", argv [ 1 ] ) == 0 ) {
		// printf( "UNDO\n" );
		if ( buffer->undo ) {
			//call the move function to undo it
			moveOperation( buffer->rowMove, buffer->colMove, buffer );
			buffer->undo = false;
			strncpy( status, "success", STR_LEN );
		}
		printf( "%s\n", status );
	}
	//the client requests to report the board state
	else if ( strcmp( "report", argv [ 1 ] ) == 0 ) {
		// printf( "REPORT\n" );
		for ( int i = 0; i < GRID_SIZE; i++ ) {
			for ( int j = 0; j < GRID_SIZE; j++ ) {
				printf( "%c", buffer->board [ i ][ j ] );
			}
			printf( "\n" );
		}
	}

	//if the user did not input a valid cmd
	else {
		fail( "error" );
	}

	// // Release our reference to the shared memory segment.
	// shmdt( buffer );

	return EXIT_SUCCESS;
}
