// Height and width of the playing area.
#define GRID_SIZE 5

//size of the memory allocated for the key
#define BLOCK_SIZE 1024

//the macros for the first and last rows and columns
#define FIRST_ROW 0
#define FIRST_COL 0
#define LAST_ROW 4
#define LAST_COL 4

//init a struct to contain the board information
//contain values based on move operations and the 2D array of the board
typedef struct {
	bool undo;
	int rowMove;
	int colMove;
	char board[GRID_SIZE][GRID_SIZE];
}GameState;