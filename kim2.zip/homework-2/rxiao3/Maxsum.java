import java.io.File; // Import the File class
import java.io.FileNotFoundException; // Import this class to handle errors
import java.util.ArrayList; // import the ArrayList class
import java.util.Scanner; // Import the Scanner class to read text files

/**
@author Rose Xiao
It will take a command-line argument giving the number of workers to use to find
the contiguous non-empty subsequence within the sequence of integers that has
the largest sum. It will also take an optional argument, report, that tells it
to report the largest sum each worker finds from its own part of the work.
 */


public class Maxsum {
    // max sum shared with all the trheads
    private static volatile int workers = 0;
	//boolean to keep track if user wants the children to print their ids
    private static boolean report = false;
	//A list to store the input values
    private static volatile ArrayList<Integer> numbers =
        new ArrayList<Integer>();

    // A subclass of Thread that computes the largest sum based on a sequence of
    // numbers
    static class Worker extends Thread {
        public int maxSum = 0;
        private int pos;

        public Worker(Integer pos) {
            this.pos = pos;
        }

		//will find the maximun sum calculated from a sequence in the list
        public void run() {
            for (int i = pos; i < numbers.size(); i += workers) {
                // System.out.println(sum);
                int sum = 0;
                for (int j = i; j < numbers.size(); j++) {
                    sum += numbers.get(j);
                    if (sum > maxSum) {
                        maxSum = sum;
                    }
                }
            }
			//prints out the id
            if (report) {
                System.out.println("I'm thread "
                    + Thread.currentThread().getId()
                    + ". The maximum sum I found is " + maxSum + ".");
            }
        }
    }

    // prints error message if failed
    public static void printError(String msg) {
        System.out.println("Error: " + msg);
    }


    public static void main(String args[]) {
		//checks to see if valid command-line arguments were passed
        if (args.length < 1 || args.length > 3) {
            printError("Invalid number of args");
        }

		//checks to see report was given
        if (args.length == 2) {
            if (!args[1].equals("report")) {
                System.out.println(args[1]);
                printError("Invalid args for 2");
            } else {
                report = true;
            }
        }

		//reads in the stream of integers
        Scanner in = new Scanner(System.in);
        while (in.hasNextInt()) {
            int val = in.nextInt();
            numbers.add(val);
        }

		//parse in the number of workers requested
        workers = Integer.parseInt(args[0]);
        Worker[] workerThread = new Worker[workers];

        
        for (int i = 0; i < workers; i++) {
            workerThread[i] = new Worker(i);
            workerThread[i].start();
        }

		//variable to store the largest sum between all threads
        int maxSumPar = 0;
		//finds the largest sum between all threads
        for (int i = 0; i < workerThread.length; i++) {
            try {
                workerThread[i].join();
                if (workerThread[i].maxSum > maxSumPar) {
                    maxSumPar = workerThread[i].maxSum;
                }
            } catch (InterruptedException e) {
                System.out.println("Interrupted during join.");
            }
        }
        System.out.println("Maximun Sum: " + maxSumPar);
    }
}