/**
 * @file reset.c
 * @author Rose Xiao
 * @brief Read inthe initial game board state and create a shared memory segment containing any needed information about the game. Will exit after creating the the memory segment and initialize it based on the board description file
 * @date 2022-09-15
 *
 * @copyright Copyright (c) 2022
 *
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#define _XOPEN_SOURCE


 //run the following command
 //  gcc -D_SVID_SOURCE -Wall -g -std=c99 -o reset reset.c -lrt

  //the required number of command-line arguments
#define NUM_ARGS 2

// Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

// Print out a usage message and exit.
static void usage()
{
	fprintf( stderr, "usage: reset <game-state-file>\n" );
	exit( EXIT_FAILURE );
}

int main( int argc, char* argv [ ] )
{

	// If given too many arguements or missing a board file name
	if ( argc != NUM_ARGS ) {
		usage();
	}

	//opening the board file
	FILE* fp = fopen( argv [ 1 ], "r" );
	if ( fp == NULL ) { //checks if file exists
		fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
		exit( EXIT_FAILURE );
	}

	//generate a unique key
	key_t key = ftok( "/afs/unity.ncsu.edu/users/r/rxiao3/CSC246/HW/HW2", 0 );
	if ( key < 0 ) {
		exit( 1 );
	}
	// Make a shared memory segment 1KB in size
	// The shmget() function returns the shared memory identifier associated with key.
	int shmid = shmget( key, BLOCK_SIZE, 0666 | IPC_CREAT );
	if ( shmid < 0 ) {
		fail( "Failed to create shared memory" );
	}

	//Mapping the shared memory struct into the address space
	GameState* buffer = ( GameState* )shmat( shmid, 0, 0 );
	if ( buffer == ( GameState* )-1 ) {
		fail( "Can't map the memory segment into address space." );
	}

	char str [ GRID_SIZE + 2 ]; //7 to account for that extra space after each row and/or to account for the \n 
	int row = 0;

	//reading in the board line by line
	while ( fgets( str, sizeof( str ), fp ) ) {
		//error checking to see the row only has 5 chars
		if ( strlen( str ) != ( GRID_SIZE + 1 ) ) { //check with 6 since strlen doesn't account for \n
			fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
			exit( EXIT_FAILURE );
		}
		for ( int j = 0; j < strlen( str ) - 1; j++ ) { //check only the first 5 chars
			//error checking to see that the right chars are used
			if ( str [ j ] != '*' && str [ j ] != '.' ) {
				fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
				exit( EXIT_FAILURE );
			}
			else {
				if ( str [ j ] == '*' ) {
					buffer->board [ row ][ j ] = '*';
				}
				else {
					buffer->board [ row ][ j ] = '.';
				}
			}
		}
		row++;
	}

	//error checking to there are only 5 rows
	if ( row != GRID_SIZE ) {
		fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
		exit( EXIT_FAILURE );
	}

	// printf("success\n");

	// // Release our reference to the shared memory segment.
	shmdt( buffer );

	// // Tell the OS we no longer need the segment.
	// shmctl( shmid, IPC_RMID, 0 );

	return EXIT_SUCCESS;
}
