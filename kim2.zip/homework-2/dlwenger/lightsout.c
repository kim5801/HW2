/**
 * @file lightsout.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * The source file lightsout.c contains methods for interacting with a board that lives in
 * shared memory. A user can move the board, get a report, or undo their last move. The boards are
 * loaded by the main function in the reset.c source file.
 *
 */
#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}
/**
 * Function for changing the board when  provided a valid move command
 *
 * @param b the struct containing the board
 * @param r the row of the tile that will be changed
 * @param c the column of the tile that will be changed
 */
static void moveBoard(Board *b, int r, int c)
{
    b->board[r][c] = b->board[r][c] == '.' ? '*' : '.';
    if (r != 0) {
        b->board[r - 1][c] = b->board[r - 1][c] == '.' ? '*' : '.';
    }
    if (c != 0) {
        b->board[r][c - 1] = b->board[r][c - 1] == '.' ? '*' : '.';
    }
    if (r != GRID_SIZE - 1) {
        b->board[r + 1][c] = b->board[r + 1][c] == '.' ? '*' : '.';
    }
    if (c != GRID_SIZE - 1) {
        b->board[r][c + 1] = b->board[r][c + 1] == '.' ? '*' : '.';
    }

    b->lastMove[0] = r;
    b->lastMove[1] = c;
}

/**
 * Converts the 2D array of the board in the board struct to a string that can be used for printing.
 *
 * @param b the board struct containing the 2D array
 * @param buffer the string that the board will be entered into
 */
static void boardToString(Board *b, char *buffer)
{
    int idx = 0;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            buffer[idx] = b->board[i][j];
            idx++;
        }
        buffer[idx] = '\n';
        idx++;
    }
}
/**
 * Helper function for converting the argument to an integer
 *
 * @param num the number that will be the base of the exponent
 * @param power the number that will be the exponent
 * @return the result of the operation
 */
static int power(int num, int power)
{
    int retval = 1;
    for (int i = 0; i < power; i++) {
        retval *= num;
    }
    return retval;
}
/**
 * Converts a string argument into an int or fails if the string contains
 * characters that aren't numbers.
 *
 * @param arg The string argument
 * @return int the integer that was parsed
 */
static int argToInt(char *arg)
{
    int retval = 0;
    for (int i = 0; i < strlen(arg); i++) {
        if (arg[i] < '0' || arg[i] > '9') {
            fail("error");
        }
        retval += (arg[i] - '0') * power(10, strlen(arg) - 1 - i);
    }
    return retval;
}
/**
 * The main function for lightsout which handles tasks specified in the user arguments.
 *
 * @param argc the number of arguments
 * @param argv the strings containing the arguments
 * @return int the exit status of the program
 */
int main(int argc, char *argv[])
{
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/d/dlwenger", 1), sizeof(Board), 0);
    Board *b = (Board *)shmat(shmid, 0, 0);
    if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail("error");
        }
        if (argToInt(argv[2]) >= GRID_SIZE || argToInt(argv[2]) < 0 || argToInt(argv[3]) >= GRID_SIZE || argToInt(argv[3]) < 0) {
            fail("error");
        }
        moveBoard(b, argToInt(argv[2]), argToInt(argv[3]));
        b->canUndo = true;
        printf("success\n");
    }
    else if (strcmp(argv[1], "report") == 0) {
        char buffer[GRID_SIZE * (GRID_SIZE + 1)];
        boardToString(b, buffer);
        printf("%s", buffer);
    }
    else if (strcmp(argv[1], "undo") == 0) {
        if (b->canUndo) {
            moveBoard(b, b->lastMove[0], b->lastMove[1]);
            b->canUndo = false;
            printf("success\n");
        }
        else {
            fail("error");
        }
    }
    else {
        fail("error");
    }

    return 0;
}
