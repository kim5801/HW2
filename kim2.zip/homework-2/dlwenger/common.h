#include <stdbool.h>
// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * Struct containing the board that is being played and the last move the player took.
 *
 */
typedef struct {
    // 2D array of chars representing the board
    char board[GRID_SIZE][GRID_SIZE];
    // The row and column of the last move
    int lastMove[2];
    // Boolean representing whether undo is a legal move
    bool canUndo;
} Board;
