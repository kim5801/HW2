import java.util.ArrayList;
import java.util.Scanner;

/**
 * Maxsum.java
 * Daniel Wenger (dlwenger@ncsu.edu)
 * The Maxsum.java source file contains code that uses threads to efficiently
 * find the maximum sum
 * in a list.
 */
public class Maxsum {
    /** List containing the numbers */
    private static ArrayList<Integer> vList;

    /**
     * Class for a worker thread that will search through a specific section of the
     * list
     */
    private static class WorkerThread extends Thread {
        /**
         * Number of the worker and total number of workers
         */
        private int workerIdx, workerNum;
        /** The largest number the worker has found */
        private int largest;

        /**
         * Constructor for the worker thread
         * 
         * @param workerIdx the index of the worker
         * @param workerNum the total number of workers
         */
        private WorkerThread(int workerIdx, int workerNum) {
            this.workerIdx = workerIdx;
            this.workerNum = workerNum;
            this.largest = 0;
        }

        /**
         * Function that the worker thread will execute.
         */
        public void run() {
            for (int i = 0; i < vList.size(); i++) {
                if (i % workerNum == workerIdx) {
                    int localLargest = 0;
                    int sum = 0;
                    for (int j = i; j < vList.size(); j++) {
                        sum += vList.get(j);
                        if (sum > localLargest) {
                            localLargest = sum;
                        }
                    }
                    if (localLargest > largest) {
                        largest = localLargest;
                    }
                }
            }

        }
    }

    /**
     * Main method of Maxsum.java, reads in the list from a file, creates workers,
     * and find the maximum sum of the
     * sums that the workers return
     * 
     * @param args
     */
    public static void main(String[] args) {
        boolean report = false;
        int workers = 4;
        vList = new ArrayList<Integer>();
        if (args.length < 1 || args.length > 2)
            usage();

        if ((workers = Integer.parseInt(args[0])) < 1) {
            usage();
        }
        if (args.length == 2) {
            if (!args[1].equals("report")) {
                usage();
            }
            report = true;
        }

        readList(vList);

        WorkerThread[] workerArray = new WorkerThread[workers];
        for (int i = 0; i < workers; i++) {
            workerArray[i] = new WorkerThread(i, workers);
            workerArray[i].start();
        }
        int largest = 0;
        try {
            for (int i = 0; i < workers; i++) {
                workerArray[i].join();
                largest = workerArray[i].largest > largest ? workerArray[i].largest : largest;
                if (report) {
                    System.out.printf("I'm thread %d. The max sum I found is %d.\n", workerArray[i].getId(),
                            workerArray[i].largest);
                }
            }
            System.out.printf("Maximum Sum: %d\n", largest);
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join.");
        }

    }

    /**
     * Prints out a message showing how to use maxsum.
     */
    public static void usage() {
        System.out.println("usage: Maxsum <workers>\n       Maxsum <workers> report");
        System.exit(1);
    }

    /**
     * Reads in a list of integers into a file.
     * 
     * @param vList The arraylist that will hold the integers
     */
    public static void readList(ArrayList<Integer> vList) {
        try {
            Scanner fin = new Scanner(System.in);
            while (fin.hasNextInt()) {
                vList.add(fin.nextInt());
            }
            fin.close();
        } catch (Exception e) {
            usage();
        }
    }
}
