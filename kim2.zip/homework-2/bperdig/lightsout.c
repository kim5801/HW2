#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

//Struct with the board information.
typedef struct GameStateStruct {
    char grid[GRID_SIZE][GRID_SIZE];
    int lastX;
    int lastY;
}GameState;

/**  Function to make a move on the board, toggling the lights on or off based on their
  *  previous state.
  */
static void toggleLights(GameState* b, int x, int y) {

    //Toggles the desired location on the grid.
    (b->grid[x][y] == '.') ? (b->grid[x][y] = '*') : (b->grid[x][y] = '.');

    //All subsequent checks toggle the positions adjacent to the desired location if it exists.
    if (x + 1 < GRID_SIZE) {
        (b->grid[x + 1][y] == '.') ? (b->grid[x + 1][y] = '*') : (b->grid[x + 1][y] = '.');
    }
    if (x - 1 >= 0) {
        (b->grid[x - 1][y] == '.') ? (b->grid[x - 1][y] = '*') : (b->grid[x - 1][y] = '.');
    }

    if (y + 1 < GRID_SIZE) {
        (b->grid[x][y + 1] == '.') ? (b->grid[x][y + 1] = '*') : (b->grid[x][y + 1] = '.');
    }

    if (y - 1 >= 0) {
        (b->grid[x][y - 1] == '.') ? (b->grid[x][y - 1] = '*') : (b->grid[x][y - 1] = '.');
    }
}

int main(int argc, char *argv[]) {

    //Lightsout only takes 2 arguments
    if (argc < 2) {
        fail("error");
    }

    //Gets the location of the existing shared memory space created by the reset program.
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/b/bperdig", 2), sizeof(GameState), 0);

    //Creates a buffer to read and write to/from the shared memory
    GameState *b = (GameState *)shmat(shmid, 0, 0);

    if (strcmp(argv[1], "move") == 0) {
        //move must be accompanied by 2 numbers representing the position to receive the move
        if(argc == 4) {
            //Must be single digit numbers
            if (strlen(argv[2]) == 1 && strlen(argv[3]) == 1) {
                int x, y;
                x = argv[2][0] - '0';
                y = argv[3][0] - '0';

                //Must be numbers between 0 and 4
                if (x < 0 || x > GRID_SIZE - 1 || y < 0 || y > GRID_SIZE - 1) {
                    fail("error");
                }
                //Makes the move with the values received.
                toggleLights(b, x, y);

                //Last move is updated to reflect this move.
                b->lastX = x;
                b->lastY = y;

                printf("success\n");
            }
            else {
                fail("error");
            }
        }

        else {
            fail("error");
        }
    }

    else if (strcmp(argv[1], "report") == 0) {
        //report does not accept any extra arguments
        if (argc == 2) {
            //Prints the board
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    printf("%c", b->grid[i][j]);
                }
                printf("\n");
            }
            printf("\n");
        }

        else {
            fail("error");
        }
    }

    else if (strcmp(argv[1], "undo") == 0) {
        //undo does not accept any extra arguments
        if (argc == 2) {
            //A value of -1 means that either this is the first move or the previous move was an undo.
            if (b->lastX == -1 || b->lastY == -1) {
                fail("error");
            }
            else {
                toggleLights(b, b->lastX, b->lastY);
                b->lastX = -1;
                b->lastY = -1;
                printf("success\n");
            }
        }

        else {
            fail("error");
        }
    }

    //Detaches the program from the shared memory but leaves it there.
    shmdt(b);

    return 0;
}
