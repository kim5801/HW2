#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

//Struct with the board information.
typedef struct GameStateStruct {
    char grid[GRID_SIZE][GRID_SIZE];
    int lastX;
    int lastY;
}GameState;

// Print out a usage message and exit.
static void usage() {
    fprintf(stderr, "usage: reset <board-file>\n");
    exit(1);
}

int main(int argc, char *argv[]) {

    //Opens and reads the board file.
    FILE *in;
    if (argc == 2) {
        in = fopen(argv[1], "r");
        if (!in) {
            fprintf(stderr, "Invalid input file: %s\n", argv[1]);
            exit(1);
        }
    }

    else {
        usage();
    }

    //Creates the shared memory segment with a unique key using ftok
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/b/bperdig", 2), sizeof(GameState), 0600 | IPC_CREAT);

    //Creates a buffer that writes  into the shared memory
    GameState *b = (GameState *)shmat(shmid, 0, 0);

    b->lastX = -1;
    b->lastY = -1;
    char c;
    int x = 0;
    int y = 0;

    //Takes the data from the text file and converts it into something acceptable by the GameState structure
    while (c = fgetc(in), c != EOF) {
        if (c == '\n')
            c = fgetc(in);

        //c can only be '*' or '.'. If the file carries on after reaching the maximum size of the board, the file is invalid.
        if ((c != '*' && c != '.') && (x >= GRID_SIZE && c != EOF)) {
            fprintf(stderr, "Invalid input file: %s\n", argv[1]);
            shmdt(b);
            exit(1);
        }

        b->grid[x][y] = c;
        y++;
        //Reset y as if it were a while loop.
        if (y == GRID_SIZE) {
            y = 0;
            x++;
        }
    }

    //Detaches the program from the shared memory, leaving it in the memory to be accessed by the lightsout program
    shmdt(b);

    return 0;
}
