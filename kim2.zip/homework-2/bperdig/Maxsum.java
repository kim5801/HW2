import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {

	// Print out an error message and exit.
	public static void fail(String message) {
		System.out.println(message);
		System.exit(1);
	}

	// Print out a usage message, then exit.
	public static void usage() {
		System.out.println("usage: Maxsum <workers>");
		System.out.println("usage: Maxsum <workers> report");
		System.exit(1);
	}

	// Input sequence of values.
	static ArrayList<Integer> vList = new ArrayList<Integer>();

	// Read the list of values.
	public static void readList() {

		int v;
		Scanner scnr = new Scanner(System.in);

		// Keep reading as many values as we can.
		while (scnr.hasNextInt()) {
			// Grow the list if needed.
			v = scnr.nextInt();

			// Store the latest value in the next array slot.
			vList.add(v);
		}
		scnr.close();
	}

	public static class WorkerThread extends Thread {

		// Which index to start from when reading the array of numbers
		private int startIdx;

		// How many workers there are in total, represents the size of the reading range
		// jump
		private int workers;

		// The max sum found by the thread to be returned as a value to compare with the
		// other sums
		public int maxSum;

		// Indicator to print the maxsum found by the thread
		private boolean report;

		public WorkerThread(int startIdx, int workers, boolean report) {
			this.startIdx = startIdx;
			this.workers = workers;
			this.report = report;
		}

		@Override
		public void run() {
			maxSum = vList.get(0);
			int sum = 0;

			for (int i = startIdx; i < vList.size(); i += workers) {

				for (int j = 0; j < vList.size() - i; j++) {

					sum += vList.get(i + j);

					if (sum > maxSum) {
						maxSum = sum;
					}
				}
				sum = 0;
			}
			if (report)
				System.out.println(
						"I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + maxSum);
		}

	}

	public static void main(String[] args) {
		boolean report = false;
		int workers = 0;

		if (args.length < 1 || args.length > 2) {
			usage();
		}

		if (args.length == 2) {
			if (!args[1].equals("report"))
				usage();

			report = true;
		}

		Scanner workerScanner = new Scanner(args[0]);
		if (!workerScanner.hasNextInt())
			usage();

		else {
			workers = workerScanner.nextInt();
			if (workers < 1)
				usage();
		}
		workerScanner.close();

		readList();

		int max = vList.get(0);

		// Create an array of threads to read from different ranges
		WorkerThread[] thread = new WorkerThread[workers];

		for (int i = 0; i < workers; i++) {
			thread[i] = new WorkerThread(i, workers, report);
			thread[i].start();
		}

		try {
			for (int i = 0; i < thread.length; i++) {
				thread[i].join();
				if (thread[i].maxSum > max)
					max = thread[i].maxSum;
			}
		} catch (InterruptedException e) {
			System.out.println("Interrupted during join");
		}

		System.out.println("Maximum sum: " + max);
	}
}
