import java.util.Scanner;
import java.util.ArrayList;

public class Maxsum {
  
 private static ArrayList<Integer> list;
 private static Integer maximum;
 private static int workers;
 private static boolean report;

  static class MyThread implements Runnable {
    private int index;

    public MyThread( int index) {
      this.index = index;
    }

    public void run() {
      int maxSum = 0;

      for (int j = index; j < list.size(); j += workers) {
        int sum = 0;

        for (int k = j; k < list.size(); k++) {
          sum += list.get(k);
          if (sum > maxSum) {
            maxSum = sum;
          }
        }
      }

      if(maximum == null || maximum < maxSum){
        maximum = maxSum;
      }

      if(report){
        System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + maxSum + ".");
      }

    }
  }

  public static void main( String[] args ) {
   report = false;
   
   if(args.length != 1 && args.length != 2){
      error();
    }

    try {
      workers = Integer.parseInt(args[0]);
    } catch (Exception e) {
      error();
    }

    if(args.length == 2){
      if(args[1].equals("report")){
        report = true;
      }
      else{
        error();
      }
    }

    list = readList();

    ArrayList<Thread> threads = new ArrayList<>();

    for(int i = 0; i < workers; i++){
      threads.add(new Thread(new MyThread(i)));
      (threads.get(i)).start();     
    }

    for(int i = 0; i < workers; i++){
      try {
        (threads.get(i)).join();  
      } catch (Exception e) {
        error("Interrupted");
      }   
    }
  
    System.out.println("Maximum Sum: " + maximum);

  }
   
  private static ArrayList<Integer> readList(){
    ArrayList<Integer> rtn = new ArrayList<>();
    try (Scanner in = new Scanner(System.in)) {
      while(in.hasNextInt()){
        rtn.add(in.nextInt());
      }
    } catch (Exception e) {
      error("Error reading file.");
    }
    return rtn;
  }

  private static void error(){
    System.out.println("usage: maxsum <workers>");
    System.out.println("       maxsum <workers> report");
    System.exit(1);
  }

  private static void error(String msg){
    System.out.println(msg);
    System.exit(1);
  }

}
