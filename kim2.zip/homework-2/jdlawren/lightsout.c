#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Fail with the generic message "error"
static void error()
{
  fail("error");
}

// Toggle a bulb and the surrounding lights. Used by move and undo
static void toggle(GameState *s, int row, int column)
{
  s->board[row][column] = !s->board[row][column];
  if (row != 0) {
    s->board[row - 1][column] = !s->board[row - 1][column];
  }
  if (column != 0) {
    s->board[row][column - 1] = !s->board[row][column - 1];
  }
  if (row != (s->size - 1)) {
    s->board[row + 1][column] = !s->board[row + 1][column];
  }
  if (column != (s->size - 1)) {
    s->board[row][column + 1] = !s->board[row][column + 1];
  }
}

// Make a move on the board, store information in the struct to allow the move
// to be undone
static bool move(GameState *s, int row, int column)
{
  if (column >= 0 && column < GRID_SIZE && row >= 0 && row < GRID_SIZE) {
    s->last_row = row;
    s->last_column = column;
    s->undo = true;
    toggle(s, row, column);
    return true;
  }
  return false;
}

// Undo the last move, return error if the move cannot be undone
static bool undo(GameState *s)
{
  if (s->undo) {
    s->undo = false;
    toggle(s, s->last_row, s->last_column);
    return true;
  }
  return false;
}

// Method to print the board in the lights struct to a string
static char *boardString(GameState *s)
{
  char *str = calloc(GRID_SIZE * GRID_SIZE * 2, sizeof(char));
  int count = 0;
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      if (s->board[i][j]) {
        str[count++] = '*';
      } else {
        str[count++] = '.';
      }
    }
    str[count++] = '\n';
  }
  return str;
}

int main(int argc, char *argv[])
{
  if (argc < 2) {
    error();
  }
  int key = ftok("/afs/unity.ncsu.edu/users/j/jdlawren", 0);
  int shmid = shmget(key, sizeof(GameState), 0);
  if (shmid == -1)
    fail("Can't create shared memory");

  GameState *s = (GameState *)shmat(shmid, 0, 0);
  if (s == (GameState *)-1)
    fail("Can't map shared memory segment into address space");

  if (strcmp(argv[1], "move") == 0) {
    if (argc != 4) {
      error();
    }
    // Get the row and column and convert to decimal
    char row = argv[2][0] - '0';
    char col = argv[3][0] - '0';

    // Ensure the x and y values are with-in bounds and no extra input is given
    if (col < 0 || col > GRID_SIZE - 1 || row < 0 || row > GRID_SIZE - 1 ||
        argv[2][1] || argv[3][1]) {
      error();
    }

    if (move(s, row, col)) {
      printf("success\n");
    } else {
      error();
    }

  } else if (strcmp(argv[1], "undo") == 0) {
    // Ensure no more arguments are given
    if (argc != 2) {
      error();
    }

    if (undo(s)) {
      printf("success\n");
    } else {
      error();
    }

  } else if (strcmp(argv[1], "report") == 0) {
    // Ensure no more arguments are given
    if (argc != 2) {
      error();
    }
    printf("%s", boardString(s));

  } else {
    // Exit the program with an error if one of the above commands is not given
    error();
  }

  shmdt(s);
  return 0;
}
