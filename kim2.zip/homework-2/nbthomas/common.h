/** 
  @file common.h
  @author Noah Thomas (nbthomas)
  header file that defines useful constants regarding the board rows/columns, program exits, and also the 
  GameState struct for use between lightsout and reset
  */
/** Height and width of the playing area. */
#define GRID_SIZE 5
/** Width of a line need to hold each row and perserve board state */
#define LINE_SIZE 6
/** Successful exit of program */
#define SUCCESSFUL_EXIT 0

typedef struct {
    bool cantUndo; //whethere state can't be undone
    char board_state[GRID_SIZE][GRID_SIZE + 1]; //current state
    char prevBoard[GRID_SIZE][GRID_SIZE + 1]; //previous state
} GameState;
