import java.util.ArrayList;
import java.util.Scanner;

/**
 * Maxsum finds the largest consecutive summ of value given a set of data by delegating various indexes to
 * search from to a specified amount of threads acting as workers. If desired, each thread will report the sum
 * they find but all sums are collected and a true max is shown and presented
 * @author Noah Thomas
 */
public class Maxsum {
    /** collection of input value */
    private static ArrayList<Integer> vList;
    /** collection of maxes found by each thread */
    private static ArrayList<Integer> maxes;
    /** collection of each thread */
    private static ArrayList<SumFinder> threadWrks;
    /** specified amount of workers */
    private static int workers;
    /** specification if threads should report their findings */
    private static boolean report = false;

    /** 
     * Custom class that extends the Thread object and allows for argument passing
     * such as the starting index a thread searches from and allows thread to effectively
     * report its id and sum found
     */
    static class SumFinder extends Thread {
        /** index thread searches from */
        private int starting;

        /** 
         * uses the index provided as a starting reference and uses the amount of workers
         * to reach other indexes assigned to it
         * @param starting index
         */
        public SumFinder(int starting) {
            this.starting = starting;
        }

        /** 
         * computes the consequtive sum from each index given and then stores the largest value as a local
         * max which is continuously compared to the current sum found
         */
        public void run() {
            int localMax = vList.get(starting); //starting local max value
            for(int i = starting; i < vList.size(); i+=workers) { //beginning from first assigned index then moving to next assigned index
                int currentSum = vList.get(i);
        
                for(int n = i + 1; n < vList.size(); n++) { //sum all following values together until end of values is reached
                    currentSum += vList.get(n);
                    if(currentSum > localMax) {
                        localMax = currentSum; //update local if current is bigger
                    }
                }
            }

            if(report) { //thread reporting
                System.out.println("I'm thread "  + this.getId() +  ". The maximum sum I found is " + localMax + ".");
            }

            maxes.add(localMax); //collect thread max found
        }
    }
    
    /** 
     * Processes the input file for each value to populate the value list and performs essential error checking
     * of worker amount or file provided. Then generates each thread to begin sum finding and stores each largest
     * sum found to eventually select a global max sum from
     * @param args collection of arguments
     */
    public static void main(String[] args) {
        vList = new ArrayList<Integer>(); //creates collection of values

        Scanner numReader = new Scanner(System.in); //reads input file

        while(numReader.hasNextInt()) { //takes in each number value present
            vList.add(numReader.nextInt());
        }

        if(args.length < 1 || args.length > 2) { //arguments check
            System.out.println("usage: maxsum <workers>\n       maxsum <workers> report");
            System.exit(1);
        }

        try { //checks to see if a number is provided for workers
            workers = Integer.parseInt(args[0]);
        } catch (NumberFormatException n) {
            System.out.println("usage: maxsum <workers>\n       maxsum <workers> report");
            System.exit(1);
        }

        if(args.length == 2 && args[1].equals("report")) { //checks to see if report is specified
            report = true;
        } else if(args.length == 2) { //checks for an invalid argument where there are two argument but the second isn't report
            System.out.println("usage: maxsum <workers>\n       maxsum <workers> report");
            System.exit(1);
        }

        maxes = new ArrayList<Integer>(); //collection of local maxes
        threadWrks = new ArrayList<SumFinder>(); //collection of threads

        for(int w = 0; w < workers; w++) { //initializes threads and has them run with the starting index
            SumFinder worker = new SumFinder(w);
            threadWrks.add(worker);

            worker.start();
        }

        try { //each thread collected is joined
            for(int i = 0; i < workers; i++) {
                threadWrks.get(i).join();
            }
        } catch ( InterruptedException e ) { //error handling
            System.out.println( "Interrupted during join!" );
        }

        int largestSum = maxes.get(0); //begin comparing local maxes

        for(int m = 1; m < maxes.size(); m++) { //finding local max
            if(maxes.get(m) > largestSum) {
                largestSum = maxes.get(m);
            }
        }

        System.out.println("Maximum Sum: " + largestSum); //providing local max
    }
}