/** 
  @file lightsout.c
  @author Noah Thomas (nbthomas)
  Lightsout executes valid commands to update and develop the lightsout game environment. It provides initial
  error checking for any invalid commands and will then read/print or modify the shared-memory game state 
  accordingly to the command given. report will print the board, move will update the board from the position
  given and undo will return the board to a previous state.
  */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** the most arguments that can be given in a client command*/
#define ARG_MAX 4
/** index of the argument that provides the column in move */
#define COLUMN_ARG 3
/** how many characters should be held in a string representation of the board */
#define BOARD_SIZE 31

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** 
  Performs error checking on arguments and then executes the properly executed commands. Also establishes a
  connection to the GameState shared in memory to refer to and perform edits on
  @param argc number of arguments
  @param argv collection of arguments
  @return exit status
  */
int main( int argc, char *argv[] ) {

  if(argc != ARG_MAX && argc != 2) {//checks to ensure they only provided 2 or 4 arguments on the command line
    fail("error");
  }

  if(strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0 && strcmp(argv[1], "move") != 0) {//makes sure the first argument is one of the client commands
    fail("error");
  }

  if((argc != 2 && (strcmp(argv[1], "undo") == 0 || strcmp(argv[1], "report") == 0)) || (argc != ARG_MAX && strcmp(argv[1], "move") == 0)) { //makes sure they did not give the wrong amount of arguments for each command
    fail("error");
  }

  if(strcmp(argv[1], "move") == 0) { //checks the coordinates given to move
    if(atoi(argv[2]) == 0 && strcmp(argv[2], "0") != 0) { //makes sure the row given is an actual number
        fail("error");
    }

    if(atoi(argv[COLUMN_ARG]) == 0 && strcmp(argv[COLUMN_ARG], "0") != 0) { //makes sure the column given is an actual number
        fail("error");
    }
  }

  if(strcmp(argv[1], "move") == 0 && (atoi(argv[2]) > ARG_MAX || atoi(argv[2]) < 0 || atoi(argv[COLUMN_ARG]) > ARG_MAX || atoi(argv[COLUMN_ARG]) < 0)) { //confirms that a valid row and column position are given to move
    fail("error");
  }

  key_t idKey = ftok("/afs/unity.ncsu.edu/users/n/nbthomas", 1); //unique key for identifying for forming shared memory

  int shmid = shmget(idKey, sizeof(GameState), 0); //requesting shared memory
  if(shmid < 0) { //checks for issues in providing memproty
    perror("problem getting shared memory: ");
  } 
  

  GameState *state = (GameState *)shmat(shmid, 0, 0); //attaches shared memory to lightsout

  if(state == (GameState *)-1) { //checks for attatchment issues
    perror("problem adding shared memory: ");
  }

  if(strcmp(argv[1], "move") == 0) { //performs move command
    for(int p = 0; p < 5; p++) { //saves the state of the board before this move
      strcpy(state->prevBoard[p], state->board_state[p]);
    }

    state->cantUndo = false; //once move has occurred, user should be able to undo most recent move made

    int row = atoi(argv[2]); //collect row
    int column = atoi(argv[3]); //collect column

    if(state->board_state[row][column] == '.') { //changes current position
      state->board_state[row][column] = '*';
    } else {
      state->board_state[row][column] = '.';
    }

    if(row + 1 <= GRID_SIZE - 1 ) { //changes position below
      if(state->board_state[row + 1][column] == '.') {
        state->board_state[row + 1][column] = '*';
      } else {
        state->board_state[row + 1][column] = '.';
      }
    }

    if(row - 1 >= 0) { //changes position above
      if(state->board_state[row - 1][column] == '.') {
        state->board_state[row - 1][column] = '*';
      } else {
        state->board_state[row - 1][column] = '.';
      }
    }

    if(column + 1 <= GRID_SIZE - 1) { //changes position to the right
      if(state->board_state[row][column + 1] == '.') {
        state->board_state[row][column + 1] = '*';
      } else {
        state->board_state[row][column + 1] = '.';
      }
    }

    if(column - 1 >= 0) { //changes position to the left
      if(state->board_state[row][column - 1] == '.') {
        state->board_state[row][column - 1] = '*';
      } else {
        state->board_state[row][column - 1] = '.';
      }
    }

    printf("success\n"); //successfully completed move
  }

  if(strcmp(argv[1], "undo") == 0) { //performs undo
    if(state->cantUndo) { //checks if the board can't be undone
      printf("error\n"); 
    } else {
      for(int u = 0; u < GRID_SIZE; u++) { //replaces current board with previous board state
        strcpy(state->board_state[u], state->prevBoard[u]);
      }

      state->cantUndo = true; // can no longer undo
      printf("success\n");
    }
  }

  if(strcmp(argv[1], "report") == 0) { //performs report
    char *board = (char *)malloc(BOARD_SIZE * sizeof(char)); //string to hold board representation

    strcpy(board, state->board_state[0]); //copies first row into representation

    for(int r = 1; r < GRID_SIZE; r++) { //appends the remaining portion of the board
      strcat(board, state->board_state[r]);
    }

    board[BOARD_SIZE - 1] = '\0'; //null terminates
    printf("%s", board); //print board
  }

  shmdt(state); //detatch shared memory


  return 0;
}
