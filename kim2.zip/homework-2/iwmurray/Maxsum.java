import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Homework 2 - Problem 2 - CSC 246
 * @author Ian Murray (iwmurray)
 */
public class Maxsum {

    /** The number of worker threads to create. */
    private static int numberWorkers = 0;

    /** If worker threads should report their pid and maximum value to the standard output.
     */
    private static boolean report = false;

    /** List of numbers read from standard input. */
    private static List<Integer> list = new ArrayList<Integer>();  

    /**
     * Worker that will calculate the maximum sum for a given subset of numbers. The ranges check by the worker are
     * those that start with index equal to: index % total number of workers = worker id. 
     */
    static class Worker extends Thread {
        /** The ID of this worker, used for calculating what values we are responable for. */
        private int workerID;

        /** The result maximum sum found by this worker. */
        public int resultSum;

        /** Constructor for worker class. */
        public Worker( int workerID ) {
            this.workerID = workerID;
        }

        /** The worker runable method. */
        public void run() {
            resultSum = Integer.MIN_VALUE;

            // Start number
            for (int i = 0; i < list.size(); i++) {
                // Skip starting index for ranges we are not responable for.
                if(i % numberWorkers != workerID) continue;

                int maxSum = Integer.MIN_VALUE;

                // The worker reduces the number of calculations by adding and removing numbers scanned from an
                // accumaltor.
                int accumlator = 0;

                for (int j = i; j < list.size(); j++) {
                    accumlator += list.get(j);

                    // Maximum value for this range?
                    if(accumlator > maxSum)
                        maxSum = accumlator;
                }

                // Was this range a bigger sum?
                if(maxSum > resultSum)
                    resultSum = maxSum;
            }

            // Send report text
            if(report)
                System.out.println("I’m thread " + this.getId() + ". The maximum sum I found is " + resultSum + ".");
        }
    }

    /**
     * Parses the command line arguments and prints usage if invalid.
     * @param args array of command line arguments.
     */
    private static void parseArguments( String[] args ) {
        boolean printUsage = false;

        // Invalid argument count.
        if(args.length != 1 && args.length != 2)
            printUsage = true;

        // Parse number of workers. 
        try {
            if(args.length > 0)
                numberWorkers = Integer.valueOf(args[0]);
        }
        catch (NumberFormatException ex) {
            printUsage = true;
        }

        // Invalid number of worker
        if(numberWorkers < 1)
            printUsage = true;

        // Make sure 2nd argument is report, if set
        if(args.length == 2) {
            if(args[1].equals("report"))
                report = true;
            else
                printUsage = true;
        }

        // Print usage and exit
        if(printUsage) {
            System.out.println("usage: java Maxsum.java <workers>");
            System.out.println("       java Maxsum.java <workers> report");
            System.exit(1);
        }
    }

    /**
     * Main entrypoint method.
     * @param args array of command line arguments.
     */
    public static void main( String[] args ) {
        parseArguments(args);

        // Read the numbers from the standard input.
        Scanner scanner = new Scanner(System.in);
        while( scanner.hasNextInt() )
            list.add(scanner.nextInt());
        scanner.close();

        // Create workers
        Worker[] workers = new Worker[numberWorkers];

        for (int i = 0; i < numberWorkers; i++) {
            workers[i] = new Worker(i);
            workers[i].start();
        }

        // Wait for all the processes to be complete and receive values int maxValue = INT_MIN;
        int maxValue = Integer.MIN_VALUE;

        for (int i = 0; i < numberWorkers; i++) {
            try {
                workers[ i ].join();

                if(workers[i].resultSum > maxValue)
                    maxValue = workers[i].resultSum;
            } catch ( InterruptedException e ) {
                System.out.println( "Interrupted during join on worker " + i );
            }
        }

        System.out.println("Maximum Sum: " + maxValue);
    }
}
