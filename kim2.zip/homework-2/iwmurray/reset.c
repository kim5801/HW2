/**
 * reset.c 
 * Homework 2 - Problem 3 - CSC 246
 * @author Ian Murray (iwmurray)
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * Load a game board from a file into a board.
 * Adapted from my Homework 1 problem 4 solution.
 * @param filename board file filename
 * @param game_state a pointer to the game state struct
 */
void load_board(char* filename, GameState* state) {
  char invalid_str[300];
  sprintf(invalid_str, "Invalid input file: %s", filename);

  // Open file
  FILE *fp = fopen(filename, "r");
  if(!fp)
    fail(invalid_str);

  // Read each character in rows and column order
  for (size_t i = 0; i < GRID_SIZE; i++) {
    for (size_t j = 0; j < GRID_SIZE; j++) {
      char ch = fgetc(fp);

      // Vaildate character and set board segment
      if(ch == '*')
        state->board[i][j] = true;
      else if(ch == '.')
        state->board[i][j] = false;
      else
        fail(invalid_str);
    }

    // Vaildate newline
    char ch = fgetc(fp);
    if(ch != '\n')
      fail(invalid_str);
  }
}

/**
 * Entrypoint of program.
 * @param argc count of arguments
 * @param argv array of arguments
 */
int main( int argc, char *argv[] ) {
  // Check arguments
  if ( argc != 2 )
    usage();

  // Create shared memory
  int shmid = shmget( SHM_KEY, sizeof(GameState), 0666 | IPC_CREAT );
  if( shmid < 0)
    fail("Failed to create shared memory.");

  // Map shared memory
  struct game_state *state = (struct game_state *) shmat( shmid, 0, 0 );
  if(state == NULL)
    fail("Failed to map shared memory.");

  // Load board from file
  load_board(argv[1], state);

  // Clear the last move
  state->last_move_row = -1;
  state->last_move_col = -1;

  return 0;
}
