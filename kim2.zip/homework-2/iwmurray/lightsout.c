/**
 * lightsout.c 
 * Homework 2 - Problem 3 - CSC 246
 * @author Ian Murray (iwmurray)
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Parse a string to an interger, with error checking.
 * Adapted from my Homework 1 problem 4 solution.
 * @return parsed interger, or -1 if error.
 */
int atoi_chk( char *str ) {
  char *ch = str;
  
  // Check for non digits
  while( *ch != '\0')
    if( isdigit(*ch) )
      ch++;
    else
      return -1;
  
  return atoi(str);
}

/**
 * Prints the current state of the game board.
 * @param state the current game state.
 */
void report( GameState *state ) {
  for (size_t i = 0; i < GRID_SIZE; i++) {
    for (size_t j = 0; j < GRID_SIZE; j++) {
      printf(state->board[i][j] ? "*" : ".");
    }

    printf("\n");
  }
}

/**
 * Inverts a cell at the given row and column. Invalid arguments are ignored.
 * Adapted from my Homework 1 problem 4 solution.
 * @param state the current game state.
 * @param row the row to make a move at.
 * @param col the column to make a move at.
 */
void invert( GameState *state, int row, int col ) {
  // Check for invaild coordinates
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE)
    return;

  state->board[row][col] = !state->board[row][col];
}

/**
 * Makes a move at the given row and column.
 * Adapted from my Homework 1 problem 4 solution.
 * @param state the current game state.
 * @param row the row to make a move at.
 * @param col the column to make a move at.
 */
void move( GameState *state, int row, int col ) {
  // Check for invaild coordinates
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE)
    fail("error");

  // Invert this cell and any adjacent cells, any invalid ones will be ignored.
  invert(state, row, col);
  invert(state, row-1, col);
  invert(state, row+1, col);
  invert(state, row, col-1);
  invert(state, row, col+1);

  // Clear the last move
  state->last_move_row = row;
  state->last_move_col = col;
}

/**
 * Undos the last move.
 * @param state the current game state.
 */
void undo( GameState *state ) {
  // Pass to move logic, it will preform checks
  move( state, state->last_move_row, state->last_move_col );

  // Clear the last move
  state->last_move_row = -1;
  state->last_move_col = -1;
}

/**
 * Entrypoint of program.
 * @param argc count of arguments
 * @param argv array of arguments
 */
int main( int argc, char *argv[] ) {
  // Create shared memory
  int shmid = shmget( SHM_KEY, 0, 0 );
  if( shmid < 0)
    fail("Failed to create shared memory.");

  // Map shared memory
  struct game_state *state = (struct game_state *) shmat( shmid, 0, 0 );
  if(state == NULL)
    fail("Failed to map shared memory.");

  // Parse arguments and call respective function
  if( argc == 2 && strcmp(argv[1], "report") == 0)
    report(state);
  else if( argc == 2 && strcmp(argv[1], "undo") == 0)
    undo(state);
  else if( argc == 4 && strcmp(argv[1], "move") == 0) {
    int row = atoi_chk(argv[2]);
    int col = atoi_chk(argv[3]);

    if(row == -1 || col == -1)
      fail("error"); // invalid non-number args

      move(state, row, col);
  } else
    fail("error"); // invalid argument 1 or count

  return 0;
}
