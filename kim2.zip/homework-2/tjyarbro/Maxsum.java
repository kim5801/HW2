import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {

    public static void main(String args[]) {

        // let report initially be false
        boolean report = false;

        // let there be 1 worker initially
        int workers = 1;

        // create the AL of numbers from Standard Input
        ArrayList<Integer> listOfNums = readList();

        // let maxSum initially be the least it could possibly be
        int maxSum = Integer.MIN_VALUE;

        // make sure there are exactly 1 or 2 arguments
        if(args.length < 1 || args.length > 2) {
            usage();
        }

        // make sure args[0] is an integer
        try {
            workers = Integer.parseInt(args[0]);
        } catch(NumberFormatException nfe) {
            // if args[1] is not an integer, Integer.parseInt() throws a NumberFormatException
            usage();
        }

        // make sure if args[1] exists it is "report"
        if(args.length == 2) {
            if("report".equals(args[1])) {
                // update report
                report = true;
            } else {
                // args[1] exited and was not report
                usage();
            }
        }

        // hold the WorkerThreads in an array so the main thread can wait on them
        WorkerThread workerThreads[] = new WorkerThread[workers];

        // create the WorkerThreads but do not create WorkerThreads than there are numbers in listOfNums
        // inclusive counting: (workers - 1) - 0 + 1 = workers
        // inclusive counting: (listOfNums.size() - 1) - 0 + 1 = listOfNums.size()
        for(int i = 0; i <= workers - 1 && i <= listOfNums.size() - 1; i++) {
            // create the WorkerThread
            workerThreads[i] = new WorkerThread(i, workers, listOfNums, report);

            // start the WorkerThread
            workerThreads[i].start();
        }

        // wait for all workers
        try {
            for(int i = 0; i < workerThreads.length; i++) {
                workerThreads[i].join();
            }
        } catch (InterruptedException ie) {
            // must catch the runtime exception InterruptedException that may be thrown by Thread.join()
            System.out.println("Interrupted during join.");
        }

        // find the maxSum from the workers and determine the overall maxSum
        for(int i = 0; i < workerThreads.length; i++) {
            if(workerThreads[i].maxSum > maxSum) {
                maxSum = workerThreads[i].maxSum;
            }
        }

        // print the maxSum
        System.out.println("Maximum Sum: " + maxSum);

    }

    // method used if the wrong number of arguments are passed in
    private static void usage() {
        System.out.println("usage: Maxsum <workers>");
        System.out.println("       Maxsum <workers> report");
        System.exit(1);
    }

    private static ArrayList<Integer> readList() {

        // create the AL that will be returned
        ArrayList<Integer> listOfNums = new ArrayList<Integer>();

        // create a scanner to read the file
        Scanner reader = new Scanner(System.in);

        // while there is an integer in the file, read it
        while(reader.hasNextInt()) {
            // add the integer to the AL
            listOfNums.add(reader.nextInt());
        }

        // close reader
        reader.close();

        // return the AL of nums from Standard Input
        return listOfNums;

    }

    static class WorkerThread extends Thread {

        // the starting index for the thread
        private int startIndex;

        // the total number of workers
        private int workers;

        // the pointer to the AL containing the nums
        private ArrayList<Integer> listOfNums;

        // the flag to see if the thread should report its maxSum
        private boolean report;

        // the maxSum the worker found
        // effectively, the thread's return value
        public int maxSum = Integer.MIN_VALUE;

        // constructor for a WorkerThread
        public WorkerThread(int startIndex, int workers, ArrayList<Integer> listOfNums, boolean report) {

            this.startIndex = startIndex;

            this.workers = workers;

            this.listOfNums = listOfNums;

            this.report = report;

        }

        // define a run() method for WorkerThreads
        public void run() {

            // outer loop that tells the thread what index to start at each time
            for(int i = startIndex; i < listOfNums.size(); i = i + workers) {

                // start possibleMaxSum at 0 because the first thing the for-loop below will do
                // is add the first number to possibleMaxSum
                int possibleMaxSum = 0;
                
                // loop from the starting index to the end of the AL and sum up the numbers
                for(int j = i; j < listOfNums.size(); j++) {

                    // add the next int to the possibleMaxSum
                    possibleMaxSum = possibleMaxSum + this.listOfNums.get(j);

                    // see if this.maxSum should be updated
                    if(possibleMaxSum > this.maxSum) {
                        this.maxSum = possibleMaxSum;
                    }

                }

            }

            // see if the thread should report its maxSum
            if(this.report) {
                System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + this.maxSum + ".");
            }

        }

    }

}