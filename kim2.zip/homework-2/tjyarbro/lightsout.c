#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// define a swap method
void swap(char* swapChar) {

  if(*swapChar == '.') {
    *swapChar = '*';
  } else {
    *swapChar = '.';
  }

}

// define a move method
void move(int r, int c, GameState* board) {

  // define new variables in the + pattern for moves
  // NOTE: if up, down, left, or right is out of the range of the board, their position is not swapped
  int up = r + 1;
  int down = r - 1;
  int left = c - 1;
  int right = c + 1;

  // make initial swap
  swap(&(board->boardLayout[r][c]));

  // make sure up index is valid then swap
  if(up >= 0 && up <= 4) {
    swap(&(board->boardLayout[up][c]));
  }

  // make sure down index is valid then swap
  if(down >= 0 && down <= 4) {
    swap(&(board->boardLayout[down][c]));
  }

  // make sure left index is valid then swap
  if(left >= 0 && left <= 4) {
    swap(&(board->boardLayout[r][left]));
  }

  // make sure right index is valid then swap
  if(right >= 0 && right <= 4) {
    swap(&(board->boardLayout[r][right]));
  }

}

// define a board toString method
void boardToString(char* boardString, GameState* board) {
  // clear junk in boardString
  for(int i = 0; i < 31; i++) {
    boardString[i] = '\0';
  }

  // add board->boardLayout strings to boardString
  // NOTE: strcat null terminates the string, so boardString is null terminated after this
  for(int i = 0; i < 5; i++) {
    strcat(boardString, board->boardLayout[i]);
    strcat(boardString, "\n");
  }
}

int main( int argc, char *argv[] ) {

    // make sure a command-line argument was given and it is "move", "undo", or "report"
    if(argc >= 2) {
        // argv[1] is the first command
        if(strcmp("move", argv[1]) != 0 && strcmp("undo", argv[1]) != 0 && strcmp("report", argv[1]) != 0) {
            printf("error\n");
            exit(1);
        } else {
            // do nothing, the command was valid
        }
    } else {
        printf("error\n");
        exit(1);
    }

    // at this point, "move", "undo", or "report" was received

    // make sure further arguments for move are ok
    if(strcmp("move", argv[1]) == 0) {
        // the command is move
        if(argc != 4) {
            // should be exactly 4 arguments, "client", "move", "r", "c"
            printf("error\n");
            exit(1);
        }

        // check argv[2]; r
        if(strlen(argv[2]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[2][0] >= 53 || argv[2][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

        // check argv[3]; c
        if(strlen(argv[3]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[3][0] >= 53 || argv[3][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

    }

    // open shared memory for GameState
    int shmid = shmget(ftok(PATHNAME, PROJ_ID), sizeof(GameState), 0);

    // make sure shared memory was opened
    if(shmid == -1) {
        fail("Can't create shared memory");
    }

    // cast the shared memory to a GameState
    GameState* board = (GameState*)shmat(shmid, 0, 0);

    // make sure proper space was allocated for a GameState
    if(board == (GameState*)-1) {
        fail("Can't map shared memory segment into address space");
    }

    // run the command

    // run report
    if(strcmp("report", argv[1]) == 0) {

        // to hold the board as a string
        char boardString[31];

        // see boardToString()
        boardToString(boardString, board);

        // print the string boardToString() created
        printf(boardString);

        // detatch from the shared memory
        shmdt(board);

        // exit with success
        exit(0);

    }

    // run move
    if(strcmp("move", argv[1]) == 0) {
        int r = atoi(argv[2]);
        int c = atoi(argv[3]);

        // call move with r and c
        move(r, c, board);

        // update lastR and lastC
        board->lastR = r;
        board->lastC = c;

        // update undoOK to true
        board->undoOK = 1;

        // NOTE: if move was not okay, it was handler properly earlier

        // move was successful, print
        printf("success\n");

        // detatch from the shared memory
        shmdt(board);

        // exit with success
        exit(0);

    }

    // run undo
    if(strcmp("undo", argv[1]) == 0) {

        // see if undo is valid
        if(board->undoOK == 1) {

        // undo will be completed by calling move on with lastR and lastC
        move(board->lastR, board->lastC, board);

        // update undoOK to 0 (false)
        board->undoOK = 0;
        
        // move was successful, print
        printf("success\n");

        // detatch from the shared memory
        shmdt(board);

        // exit with success
        exit(0);

        } else {

            // move was unsuccessful, print
            printf("error\n");

            // detatch from the shared memory
            shmdt(board);

            // exit with failure
            exit(1);

      }

    }

    return 0;
}
