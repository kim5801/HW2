#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  //if invalid args present
  if(argc < 2){
    fail("error");
  }
  //partition the shared memory
  key_t skey = PATH
  int shmid = shmget(skey, sizeof(GameState), 0);
  //create for the gamestate variable
  GameState *game = (GameState *) shmat(shmid, 0, 0);
  //print out the board upon command
  if(strcmp(argv[1], "report") == 0){
    for(int i=0; i<GRID_SIZE; i++){
      for(int j=0; j<GRID_SIZE; j++){
        printf("%c", game->board[i][j]);
      }
      printf("\n");
    }
    exit(0);
  }
  //move the light according to user
  if(strcmp(argv[1], "move") == 0 && argc == 4){
    //convert argv to integer
    int row = atoi(argv[2]);
    int col = atoi(argv[3]);
    //if the range is out of bounds
    if(row > 4 || row < 0) fail("error");
    if(col > 4 || col < 0) fail("error");
    //perform the flip operation
    for(int i=col-1; i<=col+1; i++){
      if(i < 0 || i > 4){
        //edge case
        continue;
      } else if(game->board[row][i] == '*'){
        game->board[row][i] = '.';
      } else{
        game->board[row][i] = '*';
      }
    }
    //do the column
    for(int i=row-1; i<=row+1; i++){
      if(i < 0 || i > 4){
        //edge case
        continue;
      } else if(game->board[i][col] == '*'){
        game->board[i][col] = '.';
      } else{
        game->board[i][col] = '*';
      }
    }
    //flip the center again
    if(game->board[row][col] == '*'){
      game->board[row][col] = '.';
    } else{
      game->board[row][col] = '*';
    }
    //allow for undo
    game->canUndo = true;
    game->lastRow = row;
    game->lastCol = col;
    printf("success\n");
    exit(0);
  }
  //undo the board
  if(strcmp(argv[1], "undo") == 0){
    //check if allowed to undo
    if(!game->canUndo) fail("error");
    //set the canUndo to false
    game->canUndo = false;
    //obtain row and col
    int row = game->lastRow;
    int col = game->lastCol;
    //perform the flip operation
    for(int i=col-1; i<=col+1; i++){
      if(i < 0 || i > 4){
        //edge case
        continue;
      } else if(game->board[row][i] == '*'){
        game->board[row][i] = '.';
      } else{
        game->board[row][i] = '*';
      }
    }
    //do the column
    for(int i=row-1; i<=row+1; i++){
      if(i < 0 || i > 4){
        //edge case
        continue;
      } else if(game->board[i][col] == '*'){
        game->board[i][col] = '.';
      } else{
        game->board[i][col] = '*';
      }
    }
    //flip the center again
    if(game->board[row][col] == '*'){
      game->board[row][col] = '.';
    } else{
      game->board[row][col] = '*';
    }
    printf("success\n");
    exit(0);
  }
  fail("error");
}
