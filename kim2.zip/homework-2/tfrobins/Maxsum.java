//needed imports
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class Maxsum {
    /** Thread to find the maximum sum */
    static class SumFinder extends Thread implements Runnable {
      //the numbered worker that this thread is implementing
      static int i;
      //main constructor
      public SumFinder(int num){
        i = num;
      }

      public void run(){
          //the amount added to the sum
          int amount = 0;
          //the local maximum of the thread
          int locmax = 0;
          //the number of inputs read by that thread
          int share = data.size()/workers;
          for(int j=(share * i); j<(share * i)+share; j++){
            //ensure the thread has not gone out of bounds
            if(j > data.size() - 1){
                //escape the loop if it has
                break;
            }
            for(int k=j; k<data.size(); k++){
                //add up the amount
                amount += data.get(k);
                if(amount > locmax){
                    //set the new locmax
                    locmax = amount;
                }
            }
            //reset the amount counter
            amount = 0;
          }
          if(report){
            //print out the thread output if was requested
            System.out.println("I'm process " + getId() + " The max sum I found is " + locmax);
          }
          //set the total maximum
          if(locmax > totalmax){
            totalmax = locmax;
          }
      }
    }
    //public variables for threads to access
    public static ArrayList<Integer> data;
    public static int workers;
    public static boolean report;
    public static int totalmax;

    /**
     * Takes in an input file and finds the maximum sum with the given threads
     * @param args input values to determine report and thread count
     */
    public static void main( String[] args ) {
        //report is set to false by default
        report = false;
        //the number of threads that will be made
        //int workers;
        //incorrect number of arguments
        //System.out.println(args.length);
        if(args.length < 1){
            throw new IllegalArgumentException("Invalid args");
        }
        //check if user wanted a report
        if(args.length == 2 && args[1].equals("report")){
            report = true;
        }
        //parse in the first arg for thread count
        workers = Integer.parseInt(args[0]);
        //Read in the inputs from the given file
        data = readList(System.in);
        //The total maximum output
        totalmax = 0;
        for(int i=0; i<workers; i++){
            //Create the thread
            Thread sumfind = new Thread(new SumFinder(i));
            sumfind.start();
            try{
                sumfind.join();
            } catch(InterruptedException e){
                System.out.println("Thread was interrupted");
            }
        }
        System.out.println("Maximum sum: " + totalmax);
    }

    /**Method used to read in the input list
     * @param file io stream
     * @return array of ints
     */
    private static ArrayList<Integer> readList(InputStream file){
        //open a file scanner to read the list
        Scanner scan = new Scanner(file);
        //create the array for inputs
        ArrayList<Integer> array = new ArrayList<Integer>();
        //add into the array
        while(scan.hasNext()){
            array.add(scan.nextInt());
        }
        //close the scanner
        scan.close();
        //return the array
        return array;
    }
  }
  