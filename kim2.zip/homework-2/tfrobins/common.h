// Height and width of the playing area.
#define GRID_SIZE 5
// Key used to identify shared memory
#define PATH ftok("afs/unity.ncsu.edu/users/t/tfrobins", 'e');
// Struct used to store the board
typedef struct GameState{
    char board[GRID_SIZE][GRID_SIZE];
    bool canUndo;
    int lastRow;
    int lastCol;
} GameState;