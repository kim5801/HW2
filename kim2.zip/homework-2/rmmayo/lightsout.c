#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Quick check to make sure the given string is a one digit num.
bool isNum(char *str)
{
  if (strlen(str) > 1)
  {
    return false;
  }
  return str[0] >= 48 || str[0] <= 57;
}

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

int main(int argc, char *argv[])
{

  if (argc < 2)
  { // before trying anything, double check there are arguments
    fail("error");
  }

  key_t key = ftok(HOME_PATH, PATH_ID); // Access the shared memory
  int shmid = shmget(key, sizeof(GameState), 0);
  GameState *instance = (GameState *)shmat(shmid, 0, 0);

  if (strcmp(argv[1], "move") == 0)
  { // If the command was move, perform the process.
    if (argc != 4 || strlen(argv[2]) != 1 || strlen(argv[3]) != 1)
    {
      fail("error\n");
    }

    if (!isNum(argv[2]) || !isNum(argv[3]))
    { // Make sure that the args for move are single digit numbers
      fail("error\n");
    }

    int val1 = atoi(argv[2]); // Find their values
    int val2 = atoi(argv[3]);
    if (val1 > 4 || val1 < 0)
    {
      fail("error\n");
    } // If they're greater than 5 or less than 0, they aren't valid.
    if (val2 > 4 || val2 < 0)
    {
      fail("error\n");
    }
    val1++;
    val2++;

    memmove(instance->prevGrid, instance->grid, sizeof(instance->grid)); // Copy the current state of the board to the previous state
    instance->undo = true;

    // Switch the specified lights
    instance->grid[val1][val2] = !(instance->grid[val1][val2]);
    instance->grid[val1 + 1][val2] = !(instance->grid[val1 + 1][val2]);
    instance->grid[val1 - 1][val2] = !(instance->grid[val1 - 1][val2]);
    instance->grid[val1][val2 + 1] = !(instance->grid[val1][val2 + 1]);
    instance->grid[val1][val2 - 1] = !(instance->grid[val1][val2 - 1]);

    printf("success\n");
  }

  else if (strcmp(argv[1], "report") == 0)
  { // Print the current state of the board

    for (int i = 1; i < GRID_SIZE + 1; i++)
    {
      for (int j = 1; j < GRID_SIZE + 1; j++)
      {
        if (instance->grid[i][j])
        {
          putchar('*');
        }
        else
        {
          putchar('.');
        }
      }
      putchar('\n');
    }
  }
  else if (strcmp(argv[1], "undo") == 0)
  {
    if (!instance->undo)
    { // If a "move" has not been called since the last undo, invalid command.
      fail("error\n");
    }

    instance->undo = false;
    memmove(instance->grid, instance->prevGrid, sizeof(instance->grid)); // Copy the memory from the previous state to the current state
    printf("success\n");
  }

  else
  {
    fail("error\n");
  }

  return 0;
}
