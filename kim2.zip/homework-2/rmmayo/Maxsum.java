import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {

	private static volatile int numWorkers = 0;//The number of workers
	private static volatile ArrayList<Integer> inputArr;//The array of numbers
	private static volatile int[] sums;//The results of the threads

	private static class Worker extends Thread {
		private int index;//This threads index
		private boolean report;//Should this thread report its findings?

		public Worker(int i, boolean flag) {
			index = i;
			report = flag;
		}

		@Override
		public void run() {//The thread performs the maxsum algorithm
			int max = Integer.MIN_VALUE;
			for (int j = index; j < inputArr.size(); j+=numWorkers) {
				int sum = 0;
				for (int k = j; k < inputArr.size(); k++) {
					sum += inputArr.get(k);

					if (sum > max) {
						max = sum;
					}
				}

			}
			
			if(report) {//Report its findings
				System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + max);
			}
			
			sums[index] = max;//Put its result in the array of sums
		}

	}

	public static void main(String[] args) {
		
			
			numWorkers = Integer.parseInt(args[0]);
			
			sums = new int[numWorkers];
			Scanner stdin = new Scanner(System.in);
			boolean flag = false;
			if (args.length == 2 && "report".equals(args[1])) {
				
				flag = true;
			}

			inputArr = new ArrayList<>();
			ArrayList<Worker> threads = new ArrayList<Maxsum.Worker>();
			while (stdin.hasNext()) {//Read the input file
				inputArr.add(Integer.parseInt(stdin.nextLine()));
			}

			for (int i = 0; i < numWorkers; i++) {//Create the threads, run them, add them to the list of threads
				Maxsum.Worker thred = new Maxsum.Worker(i, flag);
				thred.run();
				threads.add(thred);
			}

			for (int i = 0; i < numWorkers; i++) {//Wait for each thread to finish
				try {
					threads.get(i).join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}


			int maximum = sums[0];//Find the max of the sums the threads found
			for(int i = 0; i < sums.length; i++) {
				if(sums[i] > maximum) {
					maximum = sums[i];
				}
			}

			System.out.println("Maximum Sum: " + maximum);//Print the max


		}

}
