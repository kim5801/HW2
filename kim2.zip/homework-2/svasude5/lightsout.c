#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  Moves the given board at the positions x and y as 
  provided.

  @param x the x position to move at
  @param y the y position to move at
  @param b the board pointer to edit.
*/
void move(int x, int y, board *b) {
  // Reverse the light at the given position
  b->lights[x][y] = !b->lights[x][y];
  // Check position above and update
  if (x+1 < 5) {
    b->lights[x+1][y] = !b->lights[x+1][y];
  }
  // Check position below and update
  if (x-1 >= 0) {
    b->lights[x-1][y] = !b->lights[x-1][y];
  }
  // Check position to the right and update
  if (y+1 < 5) {
    b->lights[x][y+1] = !b->lights[x][y+1];
  }
  // Check position to the left and update
  if (y-1 >= 0) {
    b->lights[x][y-1] = !b->lights[x][y-1];
  }
  // Update last moved row and column
  b->lastRow = x;
  b->lastCol = y;
  // Update whether the user can undo or not
  b->canUndo = true;
}

/**
  Undos the last move of the given board at the 
  positions x and y as provided.

  @param x the x position to move at
  @param y the y position to move at
  @param b the board pointer to edit.
*/
void undo(int x, int y, board *b) {
  // Use the move function to undo the last move
  move(x, y, b);
  // Set canUndo to false
  b->canUndo = false;
}

/**
  Reports the state of the board.

  @param b the board pointer to report.
*/
void report(board *b) {
  // Loop through each row and column
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      // Print the appropriate character for the board
      if (b->lights[i][j] == true) {
        printf("*");
      } else {
        printf(".");
      }
    }
    printf("\n");
  }
}

/**
  The main method to process instructions for the lightsout
  game.
  @param argc number of command line args
  @param argv the command line args
  @return exit status
*/
int main( int argc, char *argv[] ) {
  
  // Create a shmid from the shared memory region opened up in reset.c
  int shmid = shmget(ftok(HOME_DIR, 1), sizeof(board) + (GRID_SIZE * sizeof(bool *)) + (GRID_SIZE * GRID_SIZE * sizeof(bool)), 0 );
  if (shmid == -1)
    fail("Unable to create shared memory.");
  // Attach memory and cast to board pointer
  board *b = (board *) shmat(shmid, 0, 0);
  if ( b == (board *)-1 )
    fail( "Couldn't map shared memory into address space." );

  // Set the pointer fields in the struct to the right memory addresses
  b->lights = (bool **) b + sizeof(board);
  for (int col = 0; col < GRID_SIZE; col++) {
    b->lights[col] = (bool *) (b->lights + (GRID_SIZE * sizeof(bool *)) + ((GRID_SIZE * col) * sizeof(bool)));
  }

  // Parse command-line arguments.
  if ( argc != 2 && argc != 4 ) {
    fail("error");
  }

  // If command number is potentially undo or report
  if (argc == 2) {
    // Check each option and perform action accordingly
    if (strcmp("undo", argv[1]) == 0) {
      if (b->canUndo) {
        // Undo
        undo(b->lastRow, b->lastCol, b);
        printf("success\n");
      } else {
        fail("error");
      }
    } else if (strcmp("report", argv[1]) == 0) {
      // Report
      report(b);
    } else {
      // Not a valid command
      fail("error");
    }
  } else if (argc == 4) {
    // Check for potential move command
    if (strcmp("move", argv[1]) == 0) {
      // Check if the coordinates are valid
      if (argv[2][0] >= '0' && argv[2][0] <= '4' && strlen(argv[2]) == 1
          && argv[3][0] >= '0' && argv[3][0] <= '4' && strlen(argv[3]) == 1) {
        // Move
        move(argv[2][0] - '0', argv[3][0] - '0', b);
        printf("success\n");
      } else {
        // Coords are not valid so error out
        fail("error");
      }
    } else {
      // Coords are not valid, so error out
      fail("error");
    }
  }
  // Detach pointer to shared memory
  shmdt(b);

  return 0;
}
