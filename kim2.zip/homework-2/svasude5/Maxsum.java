import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class which contains code to create a number of workers to
 * find the maximum sum of a contiguous subarray given a list
 * of integers.
 */
public class Maxsum {

	/**
	 * Custom class which extends Thread containing code to check
	 * the assigned indexes and communicate them back to the main
	 * thread (process which created the threads).
	 */
    static class ThreadFunc extends Thread {

		/** List of indexes to check */
		int[] indexes;
		/** List of integers to check */
		List<Integer> list;
		/** Reference to the list of maxes from all worker threads */
		List<Integer> maxes;
		/** Report flag */
		boolean report;

		/**
		 * Constructor which takes in all variables for all the state vars.
		 * @param indexes indexes to set
		 * @param list list to set
		 * @param maxes maxes to set
		 * @param report report to set
		 */
		public ThreadFunc(int[] indexes, List<Integer> list, List<Integer> maxes, boolean report) {
			this.indexes = indexes;
			this.list = list;
			this.maxes = maxes;
			this.report = report;
		}

		/**
		 * Runs the code to check through each index.
		 */
		public void run() {
			int max = 0;
			int sum = 0;
			// Start searching at each index in the list
			for (int i = 0; i < indexes.length; i++) {
				int index = indexes[i];
				for (int j = index; j < list.size(); j++) {
					// Add to sum
					sum += list.get(j);
					// Update max if necessary
					if (sum > max) {
					max = sum;
					}
				}
				// Reset sum
				sum = 0;
			}
			// Add max to main maxes list
			maxes.add(max);
			// Report thread max if report flag is enabled
			if (report) {
				System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + max + ".");
			}
		}
	}

	/**
	 * Method to exit with a usage error.
	 */
	static void usage() {
		// Print usage message
		System.err.println("usage: maxsum <workers>");
		System.err.println("       maxsum <workers> report");
		// Exit with error status
		System.exit(1);
    }

	/**
	 * Reads a list of ints from standard input.
	 * @return a list of integer objects
	 */
    static List<Integer> readList() {
		// Create scanner object to read from standard input
		Scanner scan = new Scanner(System.in);
		// Create list to return
		List<Integer> list = new ArrayList<Integer>();
		// Read all available ints from stdin
		while (scan.hasNextInt()) {
			list.add(scan.nextInt());
		}
		// Close scanner
		scan.close();
		//Return list
		return list;
    }

	/**
	 * Main method which creates all worker threads to compute the 
	 * maxsum.
	 * @param args command-line arguments
	 */
    public static void main(String[] args) {
		/** Variable for the report flag */
		boolean report = false;
		/** Variable for the number of workers */
		int workers = 0;

		// Check usage andd command line arguments to ensure they are valid
		if (args.length < 1 || args.length > 2) {
			usage();
		}
		try {
			workers = Integer.parseInt(args[0]);
			if (workers < 1) {
				usage();
			}

		} catch (NumberFormatException e) {
			usage();
		}
		if (args.length == 2) {
			if (args[1].equals("report")) {
				report = true;
			} else {
				usage();
			}
		}

		// Read the list from stdin
		List<Integer> list = readList();
		// Create the main maxes list
		List<Integer> maxes = new ArrayList<Integer>(workers);
		// array to hold worker threads
		ThreadFunc[] threads = new ThreadFunc[workers];

		// Minimum indexes to check for each worker
		int split = list.size() / workers;
		// The leftover indexes to be assigned 
		int rem = list.size() % workers;
		for (int i = 0; i < workers; i++) {
			// Calculate the indexes needed for each worker to check
			int indexsize = split;
			// If there are leftover indexes, add them until there aren't any
			if (rem > 0) {
				indexsize += rem--;
			}
			// Create indexes array to pass to thread
			int[] indexes = new int[indexsize];
			int loop = 0;
			for (int j = i; j < list.size(); j += workers) {
				indexes[loop] = j;
				loop++;
			}
			// Create and startnew thread
			threads[i] = new ThreadFunc(indexes, list, maxes, report);
			threads[i].start();
		}

		// Join all the threads
		try {
			for (int i = 0; i < threads.length; i++) {
				threads[i].join();
			}
		} catch (InterruptedException e) {
			System.out.println("Unable to join with thread.");
		}
		int max = maxes.get(0);
		// Get the max out of all threads
		for (Integer i : maxes) {
			if (i > max) {
				max = i;
			}
		}
		// Print the result
	    System.out.println("Maximum Sum: " + max);
    }

}
