#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Global board variable
static board *b;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Prints invalid input error message then exits
static void invalid(char const *filename) {
  fprintf( stderr, "Invalid input file: %s\n", filename );
  exit( 1 );
}


/**
  The main method to read in the provided file and create a game
  board from it.
  @param argc number of command line args
  @param argv the command line args
  @return exit status
*/
int main( int argc, char *argv[] ) {

  // Parse command-line arguments.
  if ( argc != 2 )
    usage();

  char *filename = argv[1];
  FILE *fp = NULL;
  if ((fp = fopen(filename, "r")) == NULL) {
    invalid(filename);
  }

  // Create a shared memory region with the proper size
  int shmid = shmget(ftok(HOME_DIR, 1), sizeof(board) + (GRID_SIZE * sizeof(bool *)) + (GRID_SIZE * GRID_SIZE * sizeof(bool)), 
                      0666 | IPC_CREAT);
  if (shmid == -1)
    fail("Unable to create shared memory.");

  // Attach memory and cast to board pointer
  b = (board *) shmat(shmid, 0, 0);
  if ( b == (board *)-1 )
    fail( "Couldn't map shared memory into address space." );

  // Allocate pointers for all necessary board struct fields
  b->lights = (bool **) b + sizeof(board);
  for (int col = 0; col < GRID_SIZE; col++) {
    b->lights[col] = (bool *) (b->lights + (GRID_SIZE * sizeof(bool *)) + ((GRID_SIZE * col) * sizeof(bool)));
  }
  // Set default values for board fields
  b->lastRow = 0;
  b->lastCol = 0;
  b->canUndo = false;
  
  int i = 0;
  int j = 0;
  char c;
  // While there is a valid character in the file
  while(fscanf(fp, "%c", &c) != EOF) {
    // If the light is off
    if (c == '.') {
      // If the file is invalid, terminate
      if (j == GRID_SIZE || i == GRID_SIZE) {
        invalid(filename);
      }
      // Set the appropriate index of the board to false
      b->lights[i][j] = false;
      j++;
    } else if (c == '*') {
      //If the light is on
      //If the file is invalid, terminate
      if (j == GRID_SIZE || i == GRID_SIZE) {
        invalid(filename);
      }
      // Set the appropriate index of the board to true
      b->lights[i][j] = true;
      j++;
    } else if (c == '\n') {
      // Move to next row if char is newline
      i++;
      j = 0;
    } else {
      // Invalid character, terminate
      invalid(filename);
    }
  }
  // Detach shared memory pointer
  shmdt(b);

  return 0;
}
