// Height and width of the playing area.
#define GRID_SIZE 5

// Struct to hold board state
typedef struct board {
  // 2D array to hold state of game board lights
  bool **lights;
  // The row of the last move
  int lastRow;
  // The column of the last move
  int lastCol;
  // Whether the user can undo or not
  bool canUndo;
} board;

// Home directory pathname
#define HOME_DIR "/afs/unity.ncsu.edu/users/s/svasude5"
