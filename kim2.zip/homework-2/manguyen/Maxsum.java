import java.util.*;
 
public class Maxsum extends Thread {
    //list from input
    private static ArrayList<Integer> vList;
    //global var to hold the max sum of each thread
    private static int[] maxThreads = new int[4];
    
    //fail
    public static void fail(String msg) {
        System.out.println(msg);
        System.exit(1);
    }

    // Print out a usage message, then exit.
    public static void usage() {
        System.out.print("usage: java Maxsum <workers>\n" );
        System.out.print("       java Maxsum <workers> report\n" );
        System.exit( 1 );
    }

    //read from input
    public static void readList() {
        //open scanner
        Scanner scnr = new Scanner(System.in);

        // Set up initial list
        vList = new ArrayList<>();
        
        // Keep reading as many values as we can.
        while ( scnr.hasNext() ) {
            // Store the latest value in the next array slot.
            vList.add(scnr.nextInt());
        }
        //make sure to close scanner
        scnr.close();
    }

    public static class GetSum implements Runnable {
        //fields for helping threads computate
        private int max;

        //these 3 more specifically are immutable
        private int idx;
        private boolean report;
        private int workers;

        public GetSum(int idx, boolean report, int workers) {
            this.idx = idx;
            this.report = report;
            this.workers = workers;
        }

        @Override
        public void run() {

            int index = idx;
            //iterate each index for this thread
            while (index < vList.size()) {
                //initialize with first value
                int currentMax = vList.get(index);
                
                //Get the max for that index only
                for (int i = index; i < vList.size(); i++) {
                    int current = 0;
                    for (int j = index; j <= i; j++) {
                        current += vList.get(j);
                    }
                    if (current > currentMax) {
                        currentMax = current;
                    }
                }

                //If that index has a higher max, update
                if (currentMax > max) {
                    max = currentMax;
                }
                
                //increment by # of workers
                index += workers;
            }

            //report if necessary
            if (report) {
                System.out.println("I'm process " + Thread.currentThread().getId() + 
                ". The maximum sum I found is " + max);
            }

            //update to the global var, the immutable idx is same idx for the thread so it works out
            maxThreads[idx] = max;
            //make sure to stop the thread
            Thread.currentThread().interrupt();
        }
    }
 
    public static void main(String[] args) {
        boolean report = false;
        int workers = 4;
        int maxSum = Integer.MIN_VALUE;
        
        //check proper formatting
        if ( args.length < 1 || args.length > 2 ) {
            System.out.println(0);
            usage();
        }

        char w = args[0].charAt(0);
        //check to make sure that it's a positive number
        if ( !Character.isDigit(w) || Character.getNumericValue(w) < 1 ) {
            usage();
        } else {
            workers = Character.getNumericValue(w);
        }

        //if there's another arg
        if ( args.length == 2 ) {
            if ( !"report".equals(args[1]) ) {
              usage();
            }
            report = true;
        }

        //read the input file
        readList();

        //creat arr list of threads
        ArrayList<Thread> threads = new ArrayList<>();
        //create and start threads
        for (int i = 0; i < workers; i++) {
            Thread t = new Thread(new GetSum(i, report, workers));
            threads.add(t);
            t.start();
        }

        //join threads, once joined check to see if that thread has a higher result than the return value (maxSum)
        for (int i = 0; i < workers; i++) {
            try {
                threads.get(i).join();
              } catch ( InterruptedException e ) {
                System.out.println( "Interrupted during join!" );
              }

            if (maxThreads[i] > maxSum) {
                maxSum = maxThreads[i];
            }
        }

        //Print your result king
        System.out.println("Maximum sum: " + maxSum);
    }
}