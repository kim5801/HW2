#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

//global variable for other functions to access
GameState *lightsout;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//helper method for moving current board to previous
void boardtoPrev() {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            lightsout->prev[i * GRID_SIZE + j] = lightsout->board[i * GRID_SIZE + j];
        }
    }
}

//for handling move
void move(int r, int c) {
    //move current to previous before changing anything
    boardtoPrev();

    //calculate 2d indecies to 1d
    int idx = r * GRID_SIZE + c;
    
    //user ternary to change given index
    lightsout->board[idx] = (lightsout->board[idx] == '.') ? '*' : '.';

    //check above
    if (idx - 5 >= 0) {
      lightsout->board[idx - 5] = (lightsout->board[idx - 5] == '.') ? '*' : '.';
    }
    //check below
    if (idx + 5 < 30) {
      lightsout->board[idx + 5] = (lightsout->board[idx + 5] == '.') ? '*' : '.';
    }
    //check left
    if (idx - 1 >= 0) {
      if (idx % 5 != 0) {
        lightsout->board[idx - 1] = (lightsout->board[idx - 1] == '.') ? '*' : '.';
      }
    }

    //check right
    if (idx + 1 < 30) {
      if (idx % 4 != 0) {
        lightsout->board[idx + 1] = (lightsout->board[idx + 1] == '.') ? '*' : '.';
      }
    }

    //now that a move has been made, you can undo it
    lightsout->canUndo = true;
    printf("success\n");
}

void undoMove() {
  //if you can you can...
  if (!lightsout->canUndo) {
    fail("error");
  }

  //move prev board to current
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      lightsout->board[i * GRID_SIZE + j] = lightsout->prev[i * GRID_SIZE + j];
    }
  }

  //make sure you can't undo a move again
  lightsout->canUndo = false;
  printf("success\n");
}

void report() {
  //print out
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
        putchar(lightsout->board[i * GRID_SIZE + j]);
    }
    putchar('\n');
  }
}

int main( int argc, char *argv[] ) {
  //provide usage failure
  if (argc < 2 || argc > 4 || argc == 3) {
    fail("error");
  }

  key_t key;
  key = ftok(PATHNAME, 1738); //the key, shoutout Fetty Wap
  int shmID = shmget(key, 0, 0);
  if (shmID == -1) {
    fail("error");
  }

  //get the shared memory and store in global var
  lightsout = (GameState *) shmat(shmID, 0, 0);
  if (strcmp(argv[1], "move") == 0) {
    int r;
    int c;
    //scan in coordinates and check if properly scanned
    if (sscanf(argv[2], "%d", &r) != 1 || sscanf(argv[3], "%d", &c) != 1 ) {
        fail("error");
    }

    //then check if coordinates fall in between 0 &  4, inclusive
    if (r < 0 || r > 4 || c < 0 || c > 4) {
        fail("error");
    }
    //after checking everything, you can now move
    move(r, c);
  } else if (strcmp(argv[1], "undo") == 0) {
    undoMove();
  } else if(strcmp(argv[1], "report") == 0) {
    report();
  } else {
    fail("error");
  }
  return 0;
}
