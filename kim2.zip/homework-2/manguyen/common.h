// Height and width of the playing area.
#define GRID_SIZE 5

#define PATHNAME "/afs/unity.ncsu.edu/users/m/manguyen"

#define BLOCK_SIZE 1024



typedef struct {
    char board[GRID_SIZE * GRID_SIZE + GRID_SIZE];
    char prev[GRID_SIZE * GRID_SIZE + GRID_SIZE];
    bool canUndo;
} GameState;