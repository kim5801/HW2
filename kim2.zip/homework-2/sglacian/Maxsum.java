/*
 * This program finds the max sum from a given file of values.
 * The program utilizes threads as workers to find multiple max values.
 * @author Sophia Laciano
 * @file Maxsum.java
 */

import java.util.Scanner;
import java.util.Arrays;
import java.lang.*;
 
 /** The class Maxsum containing all the functionality to run Homework 2 part 3 */
public class Maxsum {

    /* Print out a usage message, then exit. */
    static void usage() {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit( 1 );
    }
    
    /** Subclass Thread to tell the thread what to do. */
    static class MyThread extends Thread {
        /** Effectively, a parameter we're passing the thread. */
        /** The next index to start adding at, being passed to the thread. */
        private int nextIndex;
        /* The number of workers being passed to the thread. */
        private int numWorkers;
        /* The amount of values in the file, being passed to the thread. */
        private int valCount;
        /* The array of values from the vile, being passed to the thread. */
        private int valList[];

        /** The return max sum and id from the thread. */
        public int maxSummy;
        public long threadId;
    
        /** Make a new Thread, giving it a parameter value to store. */
        public MyThread( int indexStart, int numWorkers, int valCount, int[] valList ) {
            this.nextIndex = indexStart;
            this.numWorkers = numWorkers;
            this.valCount = valCount;
            this.valList = valList;
        }

        /** When run, I report in and the max sum. */
        public void run() {
            int tempMax = 0;
            int currentSum = 0;
            while ( nextIndex < valCount ) {
                for ( int j = nextIndex; j < valCount; j++ ) {
                    currentSum += valList[j];
                    if ( currentSum > tempMax ) {
                        tempMax = currentSum;
                    }
                }
                nextIndex += numWorkers;
                currentSum = 0;
            }

            // Store the final max sum in our maxsummy field, where the main thread can get it.
            threadId = Thread.currentThread().getId();
            maxSummy = tempMax;
        }
    }
    /** Make a thread and wait for it to do something. */
    public static void main( String[] args ) {
        boolean report = false;

        // Parse command-line arguments.
        if ( args.length < 1 || args.length > 2 ) {
            usage();
        }
        // Check that workers given is an integer.
        Scanner scanner = new Scanner(args[0]);
        if ( scanner.hasNextInt() == false ) {
            usage();
        }
        int workers = scanner.nextInt();
        // Check that workers is a value greater then 0.
        if ( workers < 1 ) {
            usage();
        }

        // If there's a second argument, it better be the word, report.
        if ( args.length == 2 ) {
            if ( args[ 1 ].equals( "report" ) == false ) {
                usage();
            }
            report = true;
        }
        
        // Read all the values in from the file given at standard input.
        Scanner inputScan = new Scanner( System.in );
        int values[] = new int[100];
        int j = 0;
        int count = 0;
        while( inputScan.hasNext() == true ) {
            values[ j ] = inputScan.nextInt();
            count++;
            j++;
            if ( j == values.length ) {
                values = Arrays.copyOf( values, values.length + 100 );
            }
        }
    
        // The ultimate maximum sum to be returned.
        int parentMaxSum = 0;
        
        // Make 10 threads and let them start running.
        MyThread[] thread = new MyThread [ workers ];
        for ( int i = 0; i < workers; i++ ) {
            thread[ i ] = new MyThread( i, workers, count, values );
            thread[ i ].start();
        }

        // Wait for each of the threads to terminate.
        try {
            for ( int i = 0; i < thread.length; i++ ) {
                thread[ i ].join();
                // Report each thread id and sum if report was called.
                if ( report == true ) {
                    System.out.print( "I'm thread " + thread[ i ].threadId );
                    System.out.print( ". The maximum sum I found is " );
                    System.out.println( thread[ i ].maxSummy );
                }
                // Check if this thread has the ultimate max value.
                if ( thread[ i ].maxSummy > parentMaxSum ) {
                    parentMaxSum = thread[ i ].maxSummy;
                }
            }
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
        // Print out maximum sum.
        System.out.println( "Maximum Sum: " + parentMaxSum );        
        
    }
}
