#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/**
 * Program interprets user commands from the command line
 * and makes changes as needed. Uses the shared memory made
 * by reset to store the current board and last move.
 */

// Print out an error message and exit.
static void fail() {
    fprintf(stdout, "error\n");
    exit(EXIT_FAILURE);
}

// change the value, used to adjust board
static void swapChars(char *current) {
  if (*current == '.') {
    *current = '*';
  }
  else {
    *current = '.';
  }
}

static int numeric(char num) {
    if (num < '0' || num > '4') {
        fail("Invalid number");
    }
    int val = num - '0';
    return val;
}

/**
 * update the board, the impacted pieces are centered at 
 * r,c. 
 *
 * Note: pieces directly touching the noted piece are
 * flipped as well.
 */
void move(int r, int c, GameState *state) {
    // check that r and c are valid values
    if (r < 0 || r > MAX_LEN || c < 0 || c > MAX_LEN) {
        fail();
    }

    // store last move into state
    state->lastMove[0] = r;
    state->lastMove[1] = c;

    // update spot selected
    swapChars(&state->board[r][c]);

    // check edge locations before changing
    if (r != 0) { // change row above
        swapChars(&state->board[r - 1][c]);
    }
    if (r != MAX_LEN) { // change row below
        swapChars(&state->board[r + 1][c]);
    }
    if (c != 0) { // change left column
        swapChars(&state->board[r][c - 1]);
    }
    if (c != MAX_LEN) { // change right column
        swapChars(&state->board[r][c + 1]);
    }
    
    state->undoValid = true;
}

/**
 * undo the last move done - last move should have been saved
 * in the shared memory.
 */
void undo(GameState *state) {
    if (state->undoValid) {
        // undo the last move
        move(state->lastMove[0], state->lastMove[1], state);
        state->undoValid = false;  
        printf("success");
    }
    else {
        fail("Undo failed.");
    }    
}

/**
 * Print out the current board from shared memory
 */
void report(GameState *state) {
    for (int r = 0; r < GRID_SIZE; r++) {
        // print out each spot in the board
        for (int c = 0; c < GRID_SIZE; c++) {
            printf("%c", state->board[r][c]);
        }
        // print new line to account for next
        // line in board
        printf("\n");
    }
}

int main( int argc, char *argv[] ) {
    // starting board should have already been created
    // and is stored in shared memory with lightsout
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/k/kepolcho", 5), 0, 0);
    if (shmid == -1) {
        fail("Can't create shared memory");
    }

    // get board from shared memory
    GameState *sbuffer = (GameState *)shmat(shmid, 0, 0);
    if (sbuffer == (GameState *)-1) {
        fail("Can't map shared memory segment into address space");
    }
    

    // read user input on what command to run
    if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail("error");
        }

        // convert arguments into integers, error checking
        // handled in numeric
        int row = numeric(*argv[2]);
        int col = numeric(*argv[3]);
        move(row, col, sbuffer);        
        printf("success\n");
    }
    else if(strcmp(argv[1], "undo") == 0) {
        undo(sbuffer);
    }
    else if(strcmp(argv[1], "report") == 0) {
        report(sbuffer);
    }
    else {
        fail();
    }



  return 0;
}
