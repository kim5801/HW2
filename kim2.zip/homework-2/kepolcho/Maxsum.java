/**
 * General class for converting maxsum.c to a java program
 * with threading, instead of forks and children.
 */

// import general things needed for maxsum assignment
import java.util.*;

public class Maxsum { 
    private volatile static ArrayList<Integer> values = new ArrayList<Integer>();
    
    /**
     * method to hand useage problems. Exits on improper usage
     */
    public static void usage() {
        System.out.println("usage: Maxsum <workers>");
        System.out.println("       Maxsum <workers> report");
        System.exit(0);
    }

    /**
     * Check if the passed string is a numeric value.
     * Returns true if able to successfully parse an integer
     * value.
     */
    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    /**
     * Custom thread class to handle the custom threads
     */
    static class ThreadSum extends Thread {
        private ArrayList<Integer> nums = new ArrayList<Integer>();
        private int workers = 0;
        private int startVal = 0;
        private boolean reportTrue = false;

        public ThreadSum(ArrayList<Integer> nums, int workers, int startVal, boolean reportTrue) {
            this.nums = nums;
            this.workers = workers;
            this.startVal = startVal;
            this.reportTrue = reportTrue;
        }

        public void run() {
            int max = nums.get(0);
            int size = nums.size();

            // start at indicated value, increases with num workers
            for (int i = startVal; i < size; i += workers) {
                int sum = 0;
                for (int j = i; j < size; j++) {
                    sum += nums.get(j);
                    if (sum > max) {
                        max = sum;
                    }
                }
                
            }
            // print out the current thread ID and the max sum found
            if (reportTrue) {
                System.out.printf("I'm thread %d. The maximum sum I found is %d.%n", Thread.currentThread().getId(), max);
            }
            
            // add max to list of values found
            values.add(max);
        }
    }

    /**
     * Main function for the program. Processes user input, 
     * creates the threads, and then reports the max value found
     * @param args user arguments
     */
    public static void main(String[] args) {
        // create vars to hold args if valid
        boolean report = false;
        int numWorkers = 0;

        // array of values from file
        ArrayList<Integer> inputVals = new ArrayList<Integer>();

        // scanner to read user input
        Scanner scan = new Scanner(System.in);

        // ERROR CHECKING

        // can be 1 or two arguments, num workers and report
        if (args.length > 2) {
            usage();
        }

        // check if it's a number and get num workers, should be at 0
        if (isNumeric(args[0]))  {
            if (Integer.parseInt(args[0]) <= 0) {
                // value is invalid number of workers, fail!
                usage();
            }
            else {
                // number is valid, parse it into the number of workers
                numWorkers = Integer.parseInt(args[0]);
            }
        }
        else { // value isn't numeric! Fail
            usage();
        }
    
        // check that if there is another argument, it's report
        if (args.length == 2) {
            if (!("report".equals(args[1]))) {
                // second argument isn't report, fail!
                usage();
            }
            report = true;
        }
        
        // System.out.println("Passed error checking, reading in values.");
        // populate array of values
        while (scan.hasNextInt()) {
            inputVals.add(scan.nextInt());
        }

        // close the scanner
        scan.close();

        // System.out.println("Printing array: ");
        // System.out.println(inputVals.toString());

        // create array to hold threads
        ThreadSum[] threads = new ThreadSum[numWorkers];

        // System.out.println("Creating Threads");
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new ThreadSum(inputVals, numWorkers, i, report);
            threads[i].start();
        }

        // stop each thread
        try {
            for (int i = 0; i < threads.length; i++) {
                threads[i].join();
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        }

        System.out.printf("Maximum sum: %d%n", Collections.max(values));
    }
}