/**
 * ADD DESC
 * @file common.h
 * @author Isaac Dunn (ijdunn)
 */

// Height and width of the playing area.
#define GRID_SIZE 5

// The AFS file home directory used with ftok() to get the key for the shared memory
#define AFS_PATH "/afs/unity.ncsu.edu/users/i/ijdunn/"

// The constant used with the proj_id parameter in the ftok() function to get the shared memory key
#define PROJ_ID_CONST 123

// Struct definition to hold the grid, undo flag, and the last move
typedef struct {
  bool board[GRID_SIZE][GRID_SIZE];
  bool undoFlag;
  int lastRow;
  int lastCol;
} GameState ;
