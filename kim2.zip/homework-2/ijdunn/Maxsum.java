/** Scanner import to read the values from standard input */
import java.util.Scanner;
/** ArrayList import for our data structure to store the values read from standard input */
import java.util.ArrayList;

/**
 * The Maxsum program calculates the maximum sum from the values from standard input.
 * It uses multithreading to calculate the maximum sum using the number of 
 * threads/workers that is specified.
 * @author Isaac Dunn (ijdunn)
 */
public class Maxsum {

  /**
   * The thread subclass will be used to create the threads used to compute
   * the maximum sum.
   * @author Isaac Dunn (ijdunn)
   */
  static class MaxSumThread extends Thread {

    /** The worker number of the thread, used as the starting index to distribute the workload */
    private int workerNum;
    /** The number of workers, used to increment the loop to distribute the workload */
    private int numWorkers;
    /** The return value of the thread, the maximum sum found from the thread */
    private int threadMaxSum;
    /** The field to determine if the thread is to report its maximum sum and thread ID after execution */
    private boolean report;
    /** The instance of the ArrayList of Integers containing the values */
    private ArrayList<Integer> values;

    /**
     * Thread constructor given the worker number, report flag, number of workers, and ArrayList of values.
     * Also initializes the thread's maximum sum to be zero.
     * @param num  The worker number to assign to the thread
     * @param report  The boolean flag to determine if the worker threads should report its maximum sum
     * @param workers  The number of workers
     * @param list  The list of values to compute the maximum sum from
     */
    public MaxSumThread( int num, boolean reportFlag, int workers, ArrayList<Integer> list ) {
      workerNum = num;
      report = reportFlag;
      numWorkers = workers;
      values = list;
      threadMaxSum = 0;
    }

    /**
     * Getter method for the maximum value found from the thread/worker
     * @return threadMaxSum  The maximum sum found from the thread/worker
     */
    public int getThreadMaxSum() {
      return threadMaxSum;
    }

    /**
     * This is the method that runs the thread. It uses loops to divide the work evenly between
     * each worker thread to find the maximum sum from the values. If the report flag is true,
     * the thread will print its thread ID and the maximum sum that it found.
     */
    public void run() {
      // Find the maximum sum, start at workerNum index, increment by number of workers
      for ( int i = workerNum; i < values.size(); i += numWorkers ) {
        int sum = 0;
        for ( int j = i; j < values.size(); j++ ) {
          sum += values.get(j);
          // If the new sum is larger than the thread max, update the thread maximum
          if ( sum > threadMaxSum ) {
            threadMaxSum = sum;
          }
        }
      }
      // Report the thread ID and maximum sum if the flag is true
      if ( report ) {
        System.out.printf("I'm thread %d. The maximum sum I found is %d\n", getId(), threadMaxSum);
      }
    }
  }

  /**
   * The fail method is used to print a message to standard error and exit the program
   * with an error code of 1 for failure.
   * @param message  A String of the message to print to standard error
   */
  public static void fail( String message ) {
    System.err.println(message);
    System.exit(1);
  }

  /** The usage method is used to print a message to standard output if the user tries to
   * run the program with invalid command-line arguments and exits with error code of 1 for failure. 
   */
  public static void usage() {
    System.out.println("usage: java Maxsum <workers>");
    System.out.println("       java Maxsum <workers> report");
    System.exit(1);
  }

  /**
   * The main method parses the command-line arguments to determine the number
   * of workers and whether the threads should report. Then it reads the input
   * file from redirected standard input using the Scanner class to get the list
   * of values to store into an ArrayList. The threads are then created to compute 
   * the maximum sum given the list of values. The maximum sum is then printed to
   * standard output.
   * @param args  The command-line arguments
   */
  public static void main(String[] args) {
    // Initialize variables
    int workers = 0;
    int maxSum = 0;
    boolean report = false;
    ArrayList<Integer> values = new ArrayList<Integer>();

    // Parse command-line arguments, print usage if invalid number of arguments
    if ( args.length < 1 || args.length > 2 ) {
      usage();
    }

    // Parse number of workers
    try {
      workers = Integer.parseInt(args[0]);
      // Print usage message if number of workers is less than one
      if ( workers < 1 ) {
        usage();
      }
    } catch ( NumberFormatException e ) {
      // Print usage message if unsuccessfully parsed to int
      usage();
    }

    // Print usage if second argument is not the report string
    if ( args.length == 2 ) {
      if ( !args[1].equals("report") ) {
        usage();
      }
      // If it is the report string, report flag is set to true
      report = true;
    } 

    // Read numbers from standard input using Scanner and add them to the values ArrayList
    Scanner intScanner = new Scanner(System.in);
    while (intScanner.hasNextInt()) {
      values.add(intScanner.nextInt());
    }

    // Create threads based on number of workers
    MaxSumThread[] threads = new MaxSumThread[workers];
    for ( int i = 0; i < threads.length; i++ ) {
      threads[i] = new MaxSumThread( i, report, workers, values );
      threads[i].start();
    }

    // Join all threads to wait for all of them to terminate
    try {
      for ( MaxSumThread thread : threads ) {
        thread.join();
        // Check the maximum sum from each thread, update to find the largest maximum sum
        if ( thread.getThreadMaxSum() > maxSum ) {
          maxSum = thread.getThreadMaxSum();
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println("Interrupted during join");
    }

    // Print maximum sum of all of the threads and exit
    System.out.printf("Maximum Sum: %d\n", maxSum);
    System.exit(0);
  }
}
