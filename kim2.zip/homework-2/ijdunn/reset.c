/**
 * The reset program reads a file of the Lights Out board and creates a
 * struct in shared memory that stores the state of the game. Each time the
 * reset program is run, the GameState struct in shared memory is updated to
 * reflect the new starting game board.
 * @author Isaac Dunn (ijdunn)
 * @file reset.c
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** ASCII decimal value for the asterisks (star) */
#define ASCII_STAR 42
/** ASCII decimal value for the period */
#define ASCII_PERIOD 46
/** ASCII decimal value for a newline character */
#define ASCII_NEWLINE 10

/**
 * This function prints the specified message to standard error and exits
 * with code 1 for failure.
 * @param message  The string to print to standard error
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * This function prints a usage message to standard error and
 * exits with code 1 for failure.
 */
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * This function is used to print an error message to standard error when a file is invalid.
 * This will print the name of the file and exit with a failure status.
 * @param filename  The name of the file to include in the error message
 */
static void fileFail( char const *filename ) {
  fprintf( stderr, "Invalid input file: %s\n", filename );
  exit( 1 );
}

/**
 * The main function parses the command-line arguments to get the name of the board file and
 * creates the shared memory segment to store the GameState struct. The fields of the struct
 * are then initialized, which is stored in shared memory.
 * @param argc  The number of command-line arguments
 * @param argv  The command-line arguments
 * @return  Exit status, 0 for success, non-zero for failure
 */
int main( int argc, char *argv[] ) {
  // Parse command-line arguments
  // Must be exactly two command-line arguments, print usage message
  if ( argc != 2 ) {
    usage();
  }
  // Attempt to open the input file of the board state
  char *filename = argv[1];
  FILE *fd = fopen( filename, "r" );
  // File failed if unable to open the file
  if ( !fd ) {
    fileFail( filename );
  }

  // Create a unique shared memory ID using ftok()
  int memId = ftok( AFS_PATH, PROJ_ID_CONST );
  // Create the shared memory
  int shmId = shmget( memId, sizeof( GameState), 0666 | IPC_CREAT );
  if ( shmId == -1 ) {
    fail( "Can't create shared memory" );
  }
  // Map the shared memory into my address space
  GameState *state = (GameState *)shmat( shmId, 0, 0 );
  if ( state == (GameState *) - 1 ) {
    fail( "Can't map shared memory segment into address space" );
  }

  // Initialize fields for the undo function
  state->undoFlag = false;
  state->lastRow = -1;
  state->lastCol = -1;

  // Read input for the starting state of the board
  for ( int row = 0; row < GRID_SIZE; row++ ) {
    for ( int col = 0; col < GRID_SIZE; col++ ) {
      char ch = fgetc( fd );
      // Checking for valid characters
      if ( ch == ASCII_PERIOD || ch == ASCII_STAR ) {
        // Store star as true in the board, light is on, false if it is not a star
        ( ch == ASCII_STAR ) ? ( state->board[row][col] = true ) : ( state->board[row][col] = false );
      } else {
        // Invalid character in file, print to stderr and exit
        fileFail( filename );
      }
    }
    // After five columns, next char should be a newline
    char ch = fgetc( fd );
    if ( ch != ASCII_NEWLINE ) {
      // Invalid character in file, print to stderr and exit
      fileFail( filename );
    }
  }
  // Last input read should be EOF
  if ( fgetc( fd ) != EOF ) {
    // Invalid character in file, print to stderr and exit
    fileFail( filename );
  }

  // Exit success, with code 0
  return 0;
}
