#include <stdio.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// Used for some messages 
#define MESSAGE_LIMIT 1024

// This is the GameState Struct
typedef struct {
  char currentBoardState[ GRID_SIZE ][ GRID_SIZE ];
  char previousBoardState[ GRID_SIZE ][ GRID_SIZE ];
  bool undo;
} GameState;
