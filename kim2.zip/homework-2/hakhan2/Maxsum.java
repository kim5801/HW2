import java.util.Scanner; 
import java.util.ArrayList; 
import java.lang.Thread;

public class Maxsum {
    
    // Function to fail if an error occurs 
    public static void fail(String message) {
        System.out.println(message);
        System.exit(1);
    }

    // Create a thread the extends Thread
    static class MyThread extends Thread {
        // All the fields to be used in the thread
        private ArrayList<Integer> array;
        private int start;
        private int end;
        private int max;
        private boolean report = false;

        // contructor for the thread
        public MyThread(ArrayList<Integer> array, int start, int end, boolean report) {
            this.array = array;
            this.start = start;
            this.end = end;
            this.max = Integer.MIN_VALUE;
            this.report = report;
        }

        @Override
        public void run() {
            int sum;

            // Iterate through start to end index
            for( int i = start; i < end; i++ ) {
                sum = 0;
                // Get the max value from the other threads
                for ( int j = i; j < array.size(); j++) {

                    // add the current index to the sum 
                    sum += array.get(j);

                    // compare it to max
                    if( sum > this.max ) {
                        // if sum is greater than max
                        // set max to sum 
                        this.max = sum;
                    }
                }
            }

            if(report){
                System.out.println(String.format("I'm thread %d. The maximum sum I found is %d", Thread.currentThread().getId(), this.max));
            }
        }

        // Return the max value from the sum 
        public int getMax() {
            return this.max;
        }
    } 
    
    public static void main( String args[] ) {
        
        // Boolean for reporting
        boolean report = false; 

        // Ensure only 1 or 2 arguments are passed
        if (args.length != 1 && args.length != 2 ) {
            fail("usage: MaxSum <workers>\n       MaxSum <workers> report");
        }
        
        // If there is a second parameter, ensure it is "report"
        if (args.length == 2 && !args[1].equals("report")) {
            fail("usage: MaxSum <workers>\n       MaxSum <workers> report");
        }
        else if (args.length == 2 && args[1].equals("report")) {
            report = true; 
        }

        // Get input from the user until there's no more input
        Scanner input = new Scanner(System.in);

        // Create a list to store the numbers
        ArrayList<Integer> numbers = new ArrayList<Integer>();

        // Read input until there's no more input 
        while ( input.hasNext() ) {
            numbers.add(input.nextInt());
        }
        
        // Close the input stream
        input.close();     
        
        // Number of workers
        int numWorkers = 1;
        try {
            // try to read the numbers of workers
            numWorkers = Integer.parseInt(args[0]);
        }
        catch (NumberFormatException e) {
            fail("usage: MaxSum <workers>\n       MaxSum <workers> report");
        }

        // Distribute the work 
        int numCount = numbers.size();
        int work = numCount >= numWorkers ? numCount / numWorkers : 1;
        
        // Create an array of threads 
        MyThread[] threads = new MyThread[numWorkers];

        // give each worker work
        int worker = 0;

        // iterate through the numbers count 
        for ( int i = 0; i < numCount; i++) {
            
            // you want the end to either be the current index + work or the numCount variable
            int end = i + work < numCount ? i + work : numCount;
            
            // start the thread
            threads[worker] = new MyThread( numbers, i, end, report );
            threads[worker++].start(); 
            
            // update i
            if(numCount >= numWorkers)
                i = i + work;
        }

        // if all the workers haven't been run, give them a start and end (to ensure there are as many threads as asked)
        while( worker < numWorkers) {
            threads[worker] = new MyThread( numbers, numCount - 1, numCount, report );
            threads[worker++].start(); 
        }

        // Wait for each of the threads to terminate.
        try {
            
            // the place where the final max value will be held
            int finalMaxValue = Integer.MIN_VALUE;
            
            // iterate and join every thread
            for ( int i = 0; i < threads.length; i++ ) {
                threads[ i ].join();
                // update the max value
                if (threads[i].getMax() > finalMaxValue)
                    finalMaxValue = threads[i].getMax(); 
            }

            // print out the max value
            System.out.println("Maximum Sum: " + finalMaxValue);
            
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
    }
}