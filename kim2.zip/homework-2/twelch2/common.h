#ifndef BOARD_H
#define BOARD_H

// Height and width of the playing area.
#define GRID_SIZE 5

//Struct to hold state of board and most recent move
typedef struct {
    //The state of the board
    char grid[GRID_SIZE][GRID_SIZE];
    //Flag for if the undo operation is available
    bool undo;
    //Row index of last move
    int lastRow;
    //Column index of last move
    int lastCol;
} GameState;

#endif

