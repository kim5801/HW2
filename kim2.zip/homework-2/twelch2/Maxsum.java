import java.util.Scanner;

/**
 * Maxsum reads in a list of integers and finds the maximum sum of consecutive integers in the list
 * This is accomplished by creating the number of threads designated by the command line argument
 * @author Thomas Welch
 */
public class Maxsum {
	
	//Array of values
	public static int[] vList;
	//Count of values in list
	public static int vCount;
	//Number of worker threads
	public static int numThreads;
	//Flag representing whether to report max sum found
	public static boolean report;
	//Maximum size of array
	public static int arrayCap;
	
	/** Calculates the maximum value found by this thread */
	public static class ThreadMax extends Thread {
		//Starting point for thread
		public int startVal;
		//Maximum found by this thread thus far
		public int maxSum;
		
		
		/**
		 * Constructor for ThreadMax
		 * @param val to start iterating on
		 */
		public ThreadMax(int val) {
			startVal = val;
		}
	
		/**
		 * Iterate through the list to find the maximum sum
		 */
		public void run() {
			//Iterate through vList starting at i, moving by the number of workers each time
			//Set max sum to the initial value
			maxSum = vList[startVal];
			//Iterate through the rest of the values
			for (int j = startVal; j < vCount; j += numThreads) {
				int currentSum = vList[j];
				//Iterate through remainder of list adding to the sum and checking against the maxSum found
				for (int k = j + 1; k < vCount; ++k) {
					currentSum += vList[k];
					//Change maxSum if currentSum is greater
					if (currentSum > maxSum) {
						maxSum = currentSum;
					}
				}
			}
			if (report == true) {
				System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + maxSum + ".");
			}
		}
	}
	
	/**
	 * main creates worker threads, lets them run, and determines the maximum calculated sum
	 * @param args for workers and report option
	 */
	public static void main(String args[]) {
		//Error, incorrect number of arguments
		if (args.length < 1 || args.length > 2) {
			System.out.println( "usage: maxsum <workers>" );
			System.out.println( "       maxsum <workers> report" );
			System.exit( 1 );
		}
		
		try {
			//Determine number of threads to create
			numThreads = Integer.parseInt(args[0]);
		} catch (Exception e) {
			//Error, no int to parse
			System.out.println( "usage: maxsum <workers>" );
			System.out.println( "       maxsum <workers> report" );
			System.exit( 1 );
		}
		
		//Check if we should report thread results
		if (args.length == 2) {
			if ("report".equals(args[1])) {
				report = true;
			} else {
				//Error
				System.out.println( "usage: maxsum <workers>" );
				System.out.println( "       maxsum <workers> report" );
				System.exit( 1 );
			}
		}
		
		//Read in list of values as an array of ints
		arrayCap = 1000;
		vCount = 0;
		//Initialize empty vList
		vList = new int[arrayCap];
		Scanner scnr = new Scanner(System.in);
		while (scnr.hasNextInt()) {
			//Resize array if needed
			if (vCount == arrayCap) {
				arrayCap = arrayCap * 2;
				int[] temp = new int[arrayCap];
				//Copy over previous entries
				for (int k = 0; k < vCount; ++k) {
					temp[k] = vList[k];
				}
				//Set vList to new larger list
				vList = temp;
			}
			//Add the new value to the list
			vList[vCount] = scnr.nextInt();
			//Increment the count of values in the list
			vCount++;
		}
		//Close scanner; no longer needed
		scnr.close();
		
		//Create and run threads
		ThreadMax[] threads = new ThreadMax[numThreads];
		//Create the requested number of threads and start running
		for (int i = 0; i < numThreads; ++i) {
			threads[i] = new ThreadMax(i);
			threads[i].start();
		}
		
		//Start totalMax at first value of list
		int totalMax = vList[0];
		//Join all threads
		for (int j = 0; j < threads.length; ++j) {
			try {
				//Join the thread
				threads[j].join();
				//Compare maximum values
				if (threads[j].maxSum > totalMax) {
					totalMax = threads[j].maxSum;
				}
				//Catch exception
			} catch (InterruptedException e) {
				System.out.println( "Interrupted during join!" );
			}
		}
		
		//Print final maximum
		System.out.println("Maximum Sum: " + totalMax);
	}
}
