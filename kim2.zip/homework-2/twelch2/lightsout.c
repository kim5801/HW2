/**
    @file lightsout.c
    @author Thomas Welch
    Lightsout is responsible for making a single change to the game board in shared memory and 
    then exiting. Some code has been adapted from my Homework 1 client and server code
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

//Returns the opposite character to the one provided (. or *)
char flip(char current) {
  if (current == '*') {
    return '.';
  } else {
    return '*';
  }
}

int main( int argc, char *argv[] ) {

    // Make a shared memory segment
    int key = ftok("/afs/unity.ncsu.edu/users/t/twelch2", 1);
    int shmid = shmget( key, 0, 0 );
    if ( shmid == -1 ) {
        fail( "Could not create shared memory" );
    }

    //Attach shared memory segment
    GameState *gameBoard = (GameState *)shmat( shmid, NULL, 0 );
    if ( gameBoard == (GameState *)-1 )
        fail( "Could not create shared memory" );

    //Check argument number
    if (argc < 2 ) {
        //Error, not enough arguments
        fail( "error, not enough arguments" );
    }

    //Store command
    char *command = argv[1];

    //Declare variables for moves
    int startCol;
    int endCol;
    int startRow;
    int endRow;
    //Indices for grid move
    int r;
    int c;

    //Execute commmand
    if (strncmp(command, "move", 4) == 0) {

        //Check for necessary arguments (valid r and c values)
        if (argc != 4) {
            printf("error\n");
            exit(1);
        }

        //Convert the strings to integers
        r = atoi(argv[2]);
        c = atoi(argv[3]);

        //Check bounds of indices
        if (r < 0 || c < 0 || r > 4 || c > 4) {
            //Error, out of bounds
            printf("error\n");
            exit(1);
        }

        //Make the move and flip affected character
        startCol = c - 1;
        endCol = c + 1;

        //Flip the char left of chosen
        if (startCol < 0) {
            //Do nothing
        } else {
            gameBoard->grid[r][startCol] = flip(gameBoard->grid[r][startCol]);
        }
        //Flip the char right of chosen
        if (endCol > 4) {
            //Do nothing
        } else {
            gameBoard->grid[r][endCol] = flip(gameBoard->grid[r][endCol]);
        }
        //Flip the chosen char
        gameBoard->grid[r][c] = flip(gameBoard->grid[r][c]);
        startRow = r - 1;
        endRow = r + 1;
        //Flip the char above the chosen
        if (startRow < 0) {
            //Do nothing
        } else {
            gameBoard->grid[startRow][c] = flip(gameBoard->grid[startRow][c]);
        }
        //Flip the char below the chosen
        if (endRow > 4) {
            //Do nothing
        } else {
            gameBoard->grid[endRow][c] = flip(gameBoard->grid[endRow][c]);
        }

        //Set undo to true, indicating that undo command may be made
        gameBoard->undo = true;
        gameBoard->lastRow = r;
        gameBoard->lastCol = c;

    } else if (strncmp(command, "undo", 4) == 0) {
        //Check if undo is available
        if (gameBoard->undo) {
            r = gameBoard->lastRow;
            c = gameBoard->lastCol;

            //Make the move and flip affected character
            startCol = c - 1;
            endCol = c + 1;

            //Flip the char left of chosen
            if (startCol < 0) {
                //Do nothing
            } else {
                gameBoard->grid[r][startCol] = flip(gameBoard->grid[r][startCol]);
            }
            //Flip the char right of chosen
            if (endCol > 4) {
                //Do nothing
            } else {
                gameBoard->grid[r][endCol] = flip(gameBoard->grid[r][endCol]);
            }
            //Flip the chosen char
            gameBoard->grid[r][c] = flip(gameBoard->grid[r][c]);
            startRow = r - 1;
            endRow = r + 1;
            //Flip the char above the chosen
            if (startRow < 0) {
                //Do nothing
            } else {
                gameBoard->grid[startRow][c] = flip(gameBoard->grid[startRow][c]);
            }
            //Flip the char below the chosen
            if (endRow > 4) {
                //Do nothing
            } else {
                gameBoard->grid[endRow][c] = flip(gameBoard->grid[endRow][c]);
            }
            //Set undo to false
            gameBoard->undo = false;
        } else {
            printf("error\n");
            exit(1);
        }
    } else if (strncmp(command, "report", 6) == 0) {
        //Send a report of the current board state
        char buffer[31] = {'\0'};
        int bufferPos = 0;
        //Iterate through board grid and add characters to buffer for printing
        for (int k = 0; k < GRID_SIZE; ++k) {
            for (int j = 0; j < GRID_SIZE; ++j) {
                buffer[bufferPos] = gameBoard->grid[k][j];
                ++bufferPos;
            }
            //Add a newline to facilitate printing
            buffer[bufferPos] = '\n';
            ++bufferPos;
        }
        //Print the final buffer
        printf(buffer);
    } else {
        //Unrecognized command
        printf("error\n");
        exit(1);
    }

    //Release the reference to shared memory
    shmdt(gameBoard);

    //Exit program
    return 0;
}
