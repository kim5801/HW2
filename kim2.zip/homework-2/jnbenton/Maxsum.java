import java.util.Scanner;
import java.util.ArrayList;
import java.lang.Integer.*;
import java.lang.Thread;

/**
  This class calculates the maximum sum of an array of integers.
  @author Jack Benton (jnbenton)
 */
public class Maxsum {

    // MyThread subclass of Thread, this will "tell" what each thread to do based
    // on the parameters the threads are initialized with.
    static class MyThread extends Thread {
        // Parameter for each thread, this will be starting index each thread gets
        // an max sum from
        private int start;

        // Parameter for number of workers
        private int workers;

        // Boolean parameter for if the thread should report
        private boolean report;

        // Return value from the thread
        private int myMaxSum;

        // Constructor for thread, with parameter for starting index
        public MyThread(int start, int workers, boolean report) {
            this.start = start;
            this.workers = workers;
            this.report = report;
        }
        // method that each thread runs
        public void run() {
            myMaxSum = -1;
            for (int i = start; i < vCount; i = i + workers) {
                int sum = 0;
                for (int j = i; j < vCount; j++) {
                    sum = sum + vList.get(j);
                    if (sum >= myMaxSum) {
                        myMaxSum = sum;
                    }
                }
            }
            // If report parameter - the thread will report it's max sum found
            if (report) {
                System.out.printf("I'm thread " + getId() + ". The maximum sum I found is " +  myMaxSum + ".\n");
            }
        }
    }

    // usage method, exits program
    static void usage() {
        System.out.print( "usage: maxsum <workers>\n" );
        System.out.print( "       maxsum <workers> report\n" );
        System.exit( 1 );
    }

    // Variable for return
    private static int maxSum = 0;
    // Input sequence of values
    private static ArrayList<Integer> vList;
    // Number of values on the list
    private static int vCount = 0; 
    // Capacity of list of values
    private static int vCap = 0;

    // Reads in the input into an ArrayList
    static void readList() {
        vCap = 5;
        vList = new ArrayList<>(vCap);

        int v;
        Scanner scan = new Scanner(System.in);
        while (scan.hasNext()) {
            vList.ensureCapacity(vCount);
            v = scan.nextInt();
            vList.add(v);
            vCount++;
            scan.nextLine();
        }
    }

    // main method that calculates max sum
    public static void main( String args[] ) {
        boolean report = false;
        int workers = 4;
        if (args.length != 1 && args.length != 2) {
            usage();
        }
        workers = Integer.parseInt(args[0]);
        if (workers < 1) {
            usage();
        }
        if (args.length == 2) {
            report = true;
        }

        readList();

        // Make workers(param) amount of threads and let them start running
        MyThread[] workerArr = new MyThread[workers];
        int ct = 0;
        for (int i = 0; i < workerArr.length; i++) {
            workerArr[i] = new MyThread(i, workers, report);
            workerArr[i].start();
        }
        // Wait for each thread to terminate
        try {
            for (int i = 0; i < workerArr.length; i++) {
                workerArr[i].join();
                // find max sum
                if (workerArr[i].myMaxSum > maxSum) {
                    maxSum = workerArr[i].myMaxSum;
                }
            }
            System.out.println("Maximum Sum: " + maxSum);
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        }
     }
}