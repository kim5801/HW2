#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message, char const *file ) {
  fprintf( stderr, "%s%s\n", message, file);
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Invalid command-line arguments
  if (argc != 2) {
    usage();
  }
  // Input redirection
  int in = open(argv[1], O_RDONLY);
  if (in < 0) {
    fail("Invalid input file: ", argv[1]);
  }
  dup2(in, STDIN_FILENO);
  close(in);

  
  key_t key = ftok("/afs/unity.ncsu.edu/users/j/jnbenton", 1);
  int schmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
  GameState *gameBuffer = (GameState *)shmat(schmid, 0, 0);

  // Get board information
  char board[GRID_SIZE * GRID_SIZE];
  char piece;
  int ct = 0;
  while (scanf("%c", &piece) == 1) {
    if (piece == '\n') {
      continue;
    }
    if (piece != '.' && piece != '*') {
      fail("Invalid input file: ", argv[1]);
    }
    board[ct++] = piece;
  }
  gameBuffer->board = board;
  int recentMove[2] = {-1, -1};
  gameBuffer->recentMove = recentMove;

  return 0;
}
