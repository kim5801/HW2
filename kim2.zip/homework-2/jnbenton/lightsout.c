#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  char *cmd = argv[1];
  if (strcmp(cmd, "move") != 0 && strcmp(cmd, "undo") != 0 && strcmp(cmd, "report") != 0) {
    fail("Invalid command");
  }
  
  key_t key = ftok("/afs/unity.ncsu.edu/users/j/jnbenton", 28);
  int shmid = shmget(key, 0, 0);
  GameState *gameBuffer = (GameState *)shmat(shmid, 0, 0);

  if (strcmp(cmd, "move") == 0) {
    if (argc != 4) {
      printf("error");
      fail("Invalid move command");
    }
    if (atoi(argv[2]) < 0 || atoi(argv[2]) > 4 || atoi(argv[3]) < 0 || atoi(argv[3]) > 4) {
      printf("error");
      fail("Invalid move command - not in bounds");
    }
    int r = atoi(argv[2]);
    int c = atoi(argv[3]);
    if (gameBuffer->board[(r * GRID_SIZE) + c] == '*') {
      gameBuffer->board[(r * GRID_SIZE) + c] = '.';
    } else if (gameBuffer->board[(r * GRID_SIZE) + c] == '.') {
      gameBuffer->board[(r * GRID_SIZE) + c] = '*';
    }
    gameBuffer->recentMove[0] = r;
    gameBuffer->recentMove[1] = c;
  }

  if (strcmp(cmd, "undo") == 0) {
    if (argc != 2) {
      printf("error");
      fail("Invalid undo command");
    }
    if (gameBuffer->recentMove[0] == -1 || gameBuffer->recentMove[1] == -1) {
      printf("error");
      fail("Invalid undo - there's no move to undo");
    }
    int r = gameBuffer->recentMove[0];
    int c = gameBuffer->recentMove[1];
    gameBuffer->board[(r * GRID_SIZE) + c] = '.';
    gameBuffer->recentMove[0] = -1;
    gameBuffer->recentMove[1] = -1;
  }

  if (strcmp(cmd, "report") == 0) {
    if (argc != 2) {
      printf("error");
      fail("Invalid report command");
    }
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
        printf("%c", gameBuffer->board[(i * GRID_SIZE) + j]);
      }
      printf("/n");
    }
  }
  printf("success");

  return 0;
}
