#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief print a board struct
 * 
 * @param board board to print 
 */
void printBoard(lightBoard * board) {
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      printf("%c", board->board[i][j]);
    }
    printf("\n");
  }
  printf("\n");
}

// flip light
char flipLight(char c) {
  if(c == '.')
    return '*';
  else
    return '.';
}

// flip all relevant lights / play the move
void playMove(lightBoard * board) {

  board->board[board->move[0]][board->move[1]] = flipLight(board->board[board->move[0]][board->move[1]]);
  if(board->move[0] > 0)
    board->board[board->move[0] - 1][board->move[1]] = flipLight(board->board[board->move[0] - 1][board->move[1]]);
  if(board->move[1] > 0)
    board->board[board->move[0]][board->move[1] - 1] = flipLight(board->board[board->move[0]][board->move[1] - 1]);
  if(board->move[0] < 4)
    board->board[board->move[0] + 1][board->move[1]] = flipLight(board->board[board->move[0] + 1][board->move[1]]);
  if(board->move[1] < 4)
    board->board[board->move[0]][board->move[1] + 1] = flipLight(board->board[board->move[0]][board->move[1] + 1]);

}

int main( int argc, char *argv[] ) {

  // checks for invalid input
  if(argc != 2 && argc != 4)
    fail("error");

  if(strcmp(argv[1], "move") != 0 && strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0)
    fail("error");

  if(strcmp(argv[1], "move") == 0 && argc != 4)
    fail("error");

  if(strcmp(argv[1], "report") == 0 && argc != 2)
    fail("error");

  if(strcmp(argv[1], "undo") == 0 && argc != 2)
    fail("error");

  lightBoard * board;
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/t/tnharnat", 't'), sizeof(*board), 0);
  board = (lightBoard *)shmat(shmid, 0 , 0);

  // move command
  if(strcmp(argv[1], "move") == 0) {
    int move[2];
    if(sscanf(argv[2], "%d", move) != 1 || sscanf(argv[3], "%d", move + 1) != 1)
      fail("error");
    if(move[0] < 0 || move[0] > 4 || move[1] < 0 || move[1] > 4)
      fail("error");

    board->move[0] = move[0];
    board->move[1] = move[1];
    playMove(board);
    printf("success\n");
  }

  // report command
  if(strcmp(argv[1], "report") == 0) {
    printBoard(board);
  }

  // undo command (fails if undo already sent after most recent move)
  if(strcmp(argv[1], "undo") == 0) {
    if(board->move[0] == -1)
      fail("error");
    else {
      playMove(board);
      board->move[0] = -1;
      printf("success\n");
    }
    
  }


  return 0;
}
