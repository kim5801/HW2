#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "Invalid input file: %s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * @brief initializes the shared memory and the board
 * 
 * @param argc number of args
 * @param argv board filename
 * @return int 
 */
int main( int argc, char *argv[] ) {

  if(argc != 2)
    usage();

  lightBoard * board;

  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/t/tnharnat", 't'), sizeof(*board), 0666 | IPC_CREAT);
  board = (lightBoard *)shmat(shmid, 0 , 0);

  // initialize move field to be "previously undoed" and read the file
  board->move[0] = -1;
  board->move[1] = -1;
  FILE * input = fopen(argv[1], "r");
  if(!input)
    fail(argv[1]);

  //board population
  for(int i = 0; i < 5; i++) {
      for(int j = 0; j < 5; j++) {
      board->board[i][j] = fgetc(input);
      }
      fgetc(input);
  }

  return 0;
}