import java.util.ArrayList;
import java.util.Scanner;

/**
 * Uses threads to find largest consecutive sum in an array of ints
 */
public class Maxsum {
	
    public static ArrayList<Integer> vList = new ArrayList<Integer>();
    public static ArrayList<Integer> maxList = new ArrayList<Integer>();
    public static int vCount = 0;
    public static boolean report = false;
    public static int workers = 4;

    // Thread Function
	public static class threadFunc implements Runnable {

        private int modVal;

        public threadFunc(int modVal) {
            this.modVal = modVal;
        }
        
        // Thread running function
		public void run() {
			
            int sum = Integer.MIN_VALUE;
            int max = sum;
            for(int i = modVal; i < vCount; i += workers) {
                sum = 0;
                for(int j = i; j < vCount; j++) {
                    sum += vList.get(j);
                    if (sum > max) 
                    max = sum;
                }
            }

            maxList.add(max);

            if(report)
                System.out.println("I'm thread " + modVal + ". The maximum sum I found is " + max + ".");
                    
        }
	}

    // usage function
    static void usage() {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit( 1 );
    }

    /**
     * passed in number of threads to create
     */
	public static void main( String[] args ) {

        int argc = args.length;

        // Parse command-line arguments.
        if (argc < 1 || argc > 2)
            usage();

        if (!args[0].matches("-?\\d+"))
            usage();

        // If there's a second argument, it better be the word, report
        if ( argc == 2 ) {
            if (!args[1].equalsIgnoreCase("report"))
                usage();
            report = true;
        }

        workers = Integer.parseInt(args[0]);

        // Populate vList with scanned input
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNextInt()) {
            vList.add(scanner.nextInt());
            vCount++;
        }
        scanner.close();

	    ArrayList<Thread> threads = new ArrayList<Thread>();

        // initialize all threads
        for(int i = 0; i < workers; i++) {
            threads.add(new Thread(new threadFunc(i)));
            threads.get(i).start();
        }
	  	
        // join with threads
        try {
            for(int i = 0; i < workers; i++)
                threads.get(i).join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // take largest value found
        int totalMax = Integer.MIN_VALUE;
        for(int i = 0; i < workers; i++) {
            if(maxList.get(i) > totalMax)
                totalMax = maxList.get(i);
        }

        System.out.println("Maximum Sum: " + totalMax);
    
	}
}
