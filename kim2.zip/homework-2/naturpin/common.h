#include <stdbool.h>
#include <sys/ipc.h>

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Size of Memory ID block
#define BLOCK_SIZE 1024

// Height and width of the playing area.
#define GRID_SIZE 5

// GameState Struct
typedef struct GameState {
    // Here's our board
    char board[GRID_SIZE][GRID_SIZE];

    // Here's a string which contains our last "move" command. Since each cell of the board is binary
    // (can only be '.' or '*'), undo is the same as replaying your last move. It's negligibly less 
    // expensive than storing the last board state, but it makes me feel a lot cooler
    int lastMove[2];

    // A flag to keep track of whether or not the last command was a "move". If it was, we're able to undo
    bool justMoved;
} GameState;

// Project ID
#define PROJ_ID 0