import java.util.Scanner;
import java.util.ArrayList;

public class Maxsum {

    private static ArrayList<Integer> list = new ArrayList<Integer>();

    static class Worker extends Thread
    {

        // Number assigned to the worker based on the order in which it was created
        public int num;

        // The total number of workers
        public int workers;

        // Whether or not the thread should report when done
        public boolean report;

        // The maximum sum for this thread only
        public int localMax;

        // Constructor for our thread
        public Worker(int num, int workers, boolean report) {
            this.num = num;
            this.workers = workers;
            this.report = report;
        }
    
        // Our run method for each thread
        public void run()
        {
            // Stores our sum of index values, so we can just add the next element instead of 
            // recomputing each time
            int sum = 0;

            localMax = 0;

            // Asign indexes to start on based on worker's assigned number
            for (int i = num; i < list.size(); i = i + workers) {

                // Check the assigned indexes
                for (int j = i; j < list.size(); j++) {
                    sum += list.get(j);

                    // If we have a new max, save it
                    if (sum > localMax)
                        localMax = sum;
                }

                // Reset sum for next round
                sum = 0;

            }

            // If asked to report, report the local sum
            if (report) {
                System.out.println("I’m process " + getId() + ". The maximum sum I found is " + localMax + ".");
            }

        }
    }

    // Print out a usage message, then exit.
    static void usage() {
        System.out.println("usage: maxsum <workers>");
        System.out.println("       maxsum <workers> report");
        System.exit(1);
    }

    // Read the input, number by number
    public static void readList() {
        Scanner sc = new Scanner(System.in);

        while (sc.hasNextInt()) {
            list.add(sc.nextInt());
        }
    }

    public static void main( String[] args ) {

        // Whether or not the user chooses to report for each thread
        boolean report = false;

        // Get the number of workers from the command-line arguments
        int workers = Integer.valueOf(args[0]);

        // Parse command-line arguments.
        if (args.length < 1 || args.length > 2 || workers < 1)
            usage();

        // If there's a second argument, it better be the word, report
        if (args.length == 2) {
            if (!args[1].equals("report"))
                usage();

            report = true;
        }

        // Read in the list of numbers
        readList();

        // Create all of our workers
        Worker[] thread = new Worker[workers];

        // Start all of our workers
        for (int i = 0; i < workers; i++) {
            thread[i] = new Worker(i, workers, report);
            thread[i].start();
        }

        // The max sum to be reported
        int maxSum = 0;

        // Used to check each local sum against the max sum
        int check = 0;

        // Wait for each of the workers to terminate.
        try {
            for (int i = 0; i < workers; i++) {
                thread[i].join();

                // Once they've terminated, read the local sum and compare it
                check = thread[i].localMax;

                if (check > maxSum)
                    maxSum = check;
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        }

        // Report the max sum
        System.out.println("Maximum Sum: " + maxSum);

    }
}