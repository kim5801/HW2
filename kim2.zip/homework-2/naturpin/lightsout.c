#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// A small private method to handle the move command. Changes the state of the command's
// target as well as any existing adjacent cells
static void move(GameState* gs, int row, int column) {

    // Change the target cell
    if (gs->board[row][column] == '.') {
        gs->board[row][column] = '*';
    } else {
        gs->board[row][column] = '.';
    }

    // Change the cell above the target, if it exists
    if (row > 0) {
        if (gs->board[row - 1][column] == '.') {
            gs->board[row - 1][column] = '*';
        } else {
            gs->board[row - 1][column] = '.';
        }
    }

    // Change the cell to the left of the target, if it exists
    if (column > 0) {
        if (gs->board[row][column - 1] == '.') {
            gs->board[row][column - 1] = '*';
        } else {
            gs->board[row][column - 1] = '.';
        }
    }

    // Change the cell to the right of the target, if it exists
    if (column < GRID_SIZE - 1) {
        if (gs->board[row][column + 1] == '.') {
            gs->board[row][column + 1] = '*';
        } else {
            gs->board[row][column + 1] = '.';
        }
    }

    // Change the cell below the target, if it exists
    if (row < GRID_SIZE - 1) {
        if (gs->board[row + 1][column] == '.') {
            gs->board[row + 1][column] = '*';
        } else {
            gs->board[row + 1][column] = '.';
        }
    }

    printf("success\n");
}

int main( int argc, char *argv[] ) {

    // Shared memory key
    key_t token = ftok("/afs/unity.ncsu.edu/users/n/naturpin/CSC246/CSC246_HW2", PROJ_ID);
    if (token < 0) {
        fail("Could not generate token.");
    }

    // Memory ID
    int memId = shmget(token, BLOCK_SIZE, 0666 | IPC_CREAT);
    if (memId < 0) {
        fail("Could not generate memory ID.");
    }

        // Create GameState struct
    GameState* gs = (GameState*)shmat(memId, 0, 0);
    if (gs == (GameState*) - 1) {
        fail("Could not initialize game state.");
    }

    // Check for correct number of arguments. That's 4 for move and 2 for everything else
    if (argc != 2 && (argc != 4 && strcmp(argv[1], "move") != 0))
        fail("error");


    // Handle client commands

    if (strcmp(argv[1], "move") == 0) {
        // UC1: The client asks to perform a move

        // Reuse those row and column variables from earlier to read our move
        gs->lastMove[0] = argv[2][0] - '0';
        gs->lastMove[1] = argv[3][0] - '0';

        // Save this command as our most recent move and set the flag
        gs->justMoved = true;

        // If either row or column is out of bounds, fail
        if ((gs->lastMove[0] < 0 || gs->lastMove[0] > GRID_SIZE - 1) || (gs->lastMove[1] < 0 || gs->lastMove[1] > GRID_SIZE - 1))
            fail("error");

        // Call our move function and consider this command successful
        move(gs, gs->lastMove[0], gs->lastMove[1]);

    } else if (strcmp(argv[1], "undo") == 0) {
        // UC2: The client asks to undo the last move

        // Only perform "undo" if our last command was "move"
        if (gs->justMoved) {

            // Call our move function and consider this command successful
            move(gs, gs->lastMove[0], gs->lastMove[1]);
        } else {
            fail("error");
        }

        // Either way, our most recent command is no longer "move"
        gs->justMoved = false;

    } else if (strcmp(argv[1], "report") == 0) {
        // UC3: The client asks for a report

        // Just print the board
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                printf("%c", gs->board[i][j]);
            }
            printf("\n");
        }
    }

    // shmctl(memId, IPC_RMID, 0);

	return 0;
}
