#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

    // Shared memory key
    key_t token = ftok("/afs/unity.ncsu.edu/users/n/naturpin/CSC246/CSC246_HW2", PROJ_ID);
    if (token < 0) {
        fail("Could not generate token.");
    }

    // Memory ID
    int memId = shmget(token, BLOCK_SIZE, 0666 | IPC_CREAT);
    if (memId < 0) {
        fail("Could not generate memory ID.");
    }

    // Create GameState struct
    GameState* gs = (GameState*)shmat(memId, 0, 0);
    if (gs == (GameState*) - 1) {
        fail("Could not initialize game state.");
    }

    // Initialize fields
    gs->lastMove[0] = 0;
    gs->lastMove[1] = 0;
    gs->justMoved = false;

    // If we have the wrong number of args, fail
    if (argc != 2)
        usage();

    // Read in the file from argv
    FILE * fp = fopen(argv[1], "r");

    // If we couldn't open it, fail
    if (!fp) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
		exit(EXIT_FAILURE);
    }

    // Our current row. We'll use this for a few different things
    int r = 0;

    // Our current column, used for a few different things as well
    int c = 0;

    // Store the board state in a 2D array. Since we have to account for newlines, we'll be reading 30 chars
    for (int charsRead = 0; charsRead < 30; charsRead++) {

        // Read in the next character
        int ch = fgetc(fp);

        // If we're past the last column, we shouldn't see any more GameState cells
        if (c > 4) {
            // If we do, fail
            if (ch == '.' || ch == '*') {
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
				exit(EXIT_FAILURE);
            }
        } else {
            // Read in the cell if it's a valid char
            if (ch == '.' || ch == '*') {
                gs->board[r][c] = ch;
            } else {
                // Otherwise, fail
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
				exit(EXIT_FAILURE);
            }
        }

        // Everytime we read a character, we should move to the next column
        c++;

        // If we've read all 5 columns and the newline, it's time to move on to the next row
        if (c == GRID_SIZE)
            r++;

        // Speaking of that newline, starting on a new row also starts us back on the first column
        if (ch == '\n')
            c = 0;
    }

    // Read one more character to get us past EOF. If we're not there, something's wrong with our file, so we should fail
    fgetc(fp);
    if (!feof(fp)) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(EXIT_FAILURE);
    }

    shmdt(gs);

  return 0;
}
