import java.util.Scanner;

public class Maxsum {

  // Input sequence of values.
  private static int vList[];

  // Number of values on the list.
  private static int vCount = 0;

  // Capacity of the list of values.
  private static int vCap = 0;
  
  // Number of workers to use.
  private static int workers = 4;
  
  // Boolean to determin if workers should report
  private static boolean report = false;
  
  static private int MIN = -1000000000;

  /** Worker thread class. */

  public static class WorkerThread extends Thread {
    
    /** Integer representing which iteration thread this is */
    public int i;
    /** Integer representing the highest value found */
    public int max;
    
    public WorkerThread( int i ) {
      super();
      this.i = i;
    }
    
    // Determines the highest value of the threads section of the work and reports it if needed
    public void run() {
      int highestCurrent = MIN;
      max = MIN;
      for( int j = 0; j < vCount; j++ ) {
        if ( j % workers == i ) {
          highestCurrent = MIN;
          int current = 0;
          for( int k = j; k < vCount; k++ ) {
            current += vList[ k ];
            if ( current > highestCurrent ) {
              highestCurrent = current;
            }
          }
          if ( highestCurrent > max ) {
            max = highestCurrent;
          }
        }
      }
      if ( report ) {
        System.out.print( "I'm thread " + this.getId() + ". The maximum sum I found is " + max + ".\n" );
      }
    }
  }

  public static void main( String[] args ) {
  
    // Parse command-line arguments.
    if ( args.length < 1 || args.length > 2 ) {
      System.out.print( "usage: maxsum <workers>\n" );
      System.out.print( "       maxsum <workers> report\n" );
      return;
    }

    try {
      workers = Integer.parseInt( args[ 0 ] );
    } catch ( Exception e ) {
      System.out.print( "usage: maxsum <workers>\n" );
      System.out.print( "       maxsum <workers> report\n" );
      return;
    }
    if ( workers < 1 ) {
      System.out.print( "usage: maxsum <workers>\n" );
      System.out.print( "       maxsum <workers> report\n" );
      return;
    }

    // If there's a second argument, it better be the word, report
    if ( args.length == 2 ) {
      if ( !args[ 1 ].equals( "report" ) ) {
        System.out.print( "usage: maxsum <workers>\n" );
        System.out.print( "       maxsum <workers> report\n" );
        return;
      }
      report = true;
    }

    vCap = 5;
    vList = new int[ vCap ];

    // Keep reading as many values as we can.
    Scanner reader = new Scanner( System.in );
    int v = 0;
    boolean read = true;
    while ( read ) {
      try {
        v = reader.nextInt();
      } catch ( Exception e ) {
        read = false;
      }
      if ( read ) {
        // Grow the list if needed.
        if ( vCount >= vCap ) {
          int tempList[] = vList;
          vCap *= 2;
          vList = new int[ vCap ];
          for ( int i = 0; i < tempList.length; i++ ) {
            vList[ i ] = tempList[ i ];
          }
        }
  
        // Store the latest value in the next array slot.
        vList[ vCount++ ] = v;
      }
    }
    reader.close();
    // Create a list of the worker threads and start them all
    WorkerThread workerList[] = new WorkerThread[ workers ];
    for ( int i = 0; i < workers; i++ ) {
      workerList[ i ] = new WorkerThread( i );
      workerList[ i ].start();
    }
    // Join with all threads
    for ( int i = 0; i < workers; i++ ) {
      try {
        workerList[ i ].join();
      } catch ( InterruptedException ie ) {
        System.out.print( "Interrupted" );
      }
    }
    // Determine the highest value from all threads
    int highest = MIN;
    for ( int i = 0; i < workers; i++ ) {
      if ( workerList[ i ].max > highest ) {
        highest = workerList[ i ].max;
      }
    }
    
    System.out.print( "Maximum Sum: " + highest + "\n" );
  }
}