#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make or undo a move on the board and set the last move.
void move( GameState *game, int loc[ MOVE_SIZE ], bool undo ) {
  game->board[ loc[ 0 ] ][ loc[ 1 ] ] = game->board[ loc[ 0 ] ][ loc[ 1 ] ] != 1;
  if ( loc[ 0 ] != 0 ) {
    game->board[ loc[ 0 ] - 1 ][ loc[ 1 ] ] = game->board[ loc[ 0 ] - 1 ][ loc[ 1 ] ] != 1;
  }
  if ( loc[ 0 ] != GRID_SIZE - 1 ) {
    game->board[ loc[ 0 ] + 1 ][ loc[ 1 ] ] = game->board[ loc[ 0 ] + 1 ][ loc[ 1 ] ] != 1;
  }
  if ( loc[ 1 ] != 0 ) {
    game->board[ loc[ 0 ] ][ loc[ 1 ] - 1 ] = game->board[ loc[ 0 ] ][ loc[ 1 ] - 1 ] != 1;
  }
  if ( loc[ 1 ] != GRID_SIZE - 1 ) {
    game->board[ loc[ 0 ] ][ loc[ 1 ] + 1 ] = game->board[ loc[ 0 ] ][ loc[ 1 ] + 1 ] != 1;
  }
  if ( undo ) {
    game->last[ 0 ] = -1;
    game->last[ 1 ] = -1;
  } else {
    game->last[ 0 ] = loc[ 0 ];
    game->last[ 1 ] = loc[ 1 ];
  }
}

// Create a string representing the board.
void boardString( GameState *game, char str[ 31 ] ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      if ( game->board[ i ][ j ] ) {
        str[ ( ( GRID_SIZE + 1 ) * i ) + j ] = '*';
      } else {
        str[ ( ( GRID_SIZE + 1 ) * i ) + j ] = '.';
      }
    }
  }
  for( int i = GRID_SIZE; i < GRID_SIZE * ( GRID_SIZE + 1 ); i += ( GRID_SIZE + 1 ) ) {
    str[ i ] = '\n';
  }
  str[ 31 ] = '\0';
}

int main( int argc, char *argv[] ) {
  
  // Access the shared memory containing the game state.
  key_t key = ftok( "/afs/unity.ncsu.edu/users/a/awoverby/", 1 );
  int id = shmget( key, sizeof( GameState ), 0 );
  void *mem = shmat( id, 0, 0 );
  GameState *game = (GameState *) mem;
  
  if( strcmp( argv[ 1 ], "report" ) == 0 ) {
    if( argc != 2 ) {
      fail( "error" );
    }
    // Print out a report of the current game state.
    char report[ 31 ];
    boardString( game, report );
    printf( "%s", report );
  } else if( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if( argc != 2 ) {
      fail( "error" );
    }
    // Undo the last move, if there was one
    if ( game->last[ 0 ] == -1 ) {
      fail( "error" );
    }
    move( game, game->last, true );
    printf( "success\n" );
  } else if( strcmp( argv[ 1 ], "move" ) == 0 ) {
    if( argc != 4 || strlen( argv[ 2 ] ) != 1 || strlen( argv[ 3 ] ) != 1 || argv[ 2 ][ 0 ] < '0' || argv[ 2 ][ 0 ] > '4' || argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) {
      fail( "error" );
    }
    // Make the given move
    int loc[ MOVE_SIZE ] = { ( int )( argv[ 2 ][ 0 ] - '0' ), ( int )( argv[ 3 ][ 0 ] - '0' ) };
    move( game, loc, false );
    printf( "success\n" );
  } else {
    fail( "error" );
  }
  
  return 0;
}
