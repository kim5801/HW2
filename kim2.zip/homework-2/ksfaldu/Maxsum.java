import java.util.*;

import java.io.*;
import java.lang.*;

/**
 * @file Maxsum.java
 * @author Kush Faldu (ksfaldu) 
 * Program finds out the largest sum calculated from the largest contigous 
 * non-empty subsequence within the input sequence.
 */
public class Maxsum {

	/** Number of threads that exist */
	private static int workers;

	/** Whether or not to print out report */
	private static boolean report = false;

	/** a list containg all the integer values */
	private static ArrayList<Integer> list;

	/**
	 * Class for creating and using threads
	 */
	static class MyThread extends Thread {
		/** start value assigned to each thread */
		private int x;

		/** max sum found */
		public long max;

		/**
		 * Creates a thread
		 * 
		 * @param x value
		 */
		public MyThread(int x) {
			this.x = x;
			this.max = 0;

		}

		/**
		 * work for each worker thread
		 */
		public void run() {
			long sum = 0;
			// Loops through the integer list
			for (int i = x; i < list.size(); i += workers) {
        sum = 0;
				for (int j = i; j < list.size(); j++) {
					sum += list.get(j);
					if (sum > max) {
						max = sum;
					}
				}
			}

			if (report) {
				System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + max);
			}
		}

	}

	/**
	 * Reads the file and stores values in the list Person objects
	 * 
	 * @param scanner used to read file
	 */
	public static void readList(Scanner scanner) {
		Scanner line = null;

		// While file has a line in it, read it
		while (scanner.hasNextLine()) {
			line = new Scanner(scanner.nextLine());
			int value = line.nextInt();
			list.add(value);

		}

		line.close();

	}

	/**
	 * main method to start the program
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {

		// get the number of workers requested
		workers = Integer.parseInt(args[0]);

		// make a list to store the int values after reading
		list = new ArrayList<Integer>(5);

		// Checks if report is mentioned in command line arguments
		if (args.length > 1) {
			if (args[1].equals("report")) {
				report = true;
			} else {
				System.out.println("Invalid command line argument: " + args[1]);
			}
		}

		// Makes scanner to read file
		Scanner scanner = new Scanner(System.in);
		readList(scanner);

		// Make threads and let them start running.
		MyThread[] threads = new MyThread[workers];
		for (int i = 0; i < threads.length; i++) {
			threads[i] = new MyThread(i);
			threads[i].start();
		}

		// Wait for each of the threads to terminate.
		long maximumSum = 0;
		try {
			for (int i = 0; i < threads.length; i++) {
				// join the thread
				threads[i].join();

				// update the maximum sum
				long temp = threads[i].max;
				if (maximumSum < temp) {
					maximumSum = temp;
				}
			}
		} catch (InterruptedException e) {
			System.out.println("Interrupted during join");
		}

		// Print out total count of pairs violating distancing
		System.out.println("Maximum Sum: " + maximumSum);
	}

}
