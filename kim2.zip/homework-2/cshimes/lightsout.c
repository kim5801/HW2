/**
 * @file lightsout.c
 * @author Cameron Himes
 * @brief Contains functionality to parse user input then report on the state of the game board as well
 * as playing moves and undoing moves where possible.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message, struct GameState * gameState ) {
  fprintf( stderr, "%s\n", message );
  shmdt(gameState);
  exit( 1 );
}

// Print out an error message and exit.
static void error( struct GameState * gameState ) {
  printf("error\n");
  shmdt(gameState);
  exit( 1 );
}

// Print out a success message and exit.
static void success( struct GameState * gameState ) {
  printf("success\n");
  shmdt(gameState);
  exit( 0 );
}

// Play a move on the board
// Adopted from the playMove method of HW1 Pt4 'server.c' file
void playMove(char * move, struct GameState * game) {
  int row = move[0] - '0';
  int col = move[1] - '0';

  // Play the move by editing values in the game board
  game->board[row][col] = game->board[row][col] == '.'? '*': '.';

  if (row != 0) {
    game->board[row - 1][col] = game->board[row - 1][col] == '.'? '*': '.';
  }

  if (row != GRID_SIZE - 1) {
    game->board[row + 1][col] = game->board[row + 1][col] == '.'? '*': '.';
  }

  if (col != 0) {
    game->board[row][col - 1] = game->board[row][col - 1] == '.'? '*': '.';
  }

  if (col != GRID_SIZE - 1) {
    game->board[row][col + 1] = game->board[row][col + 1] == '.'? '*': '.';
  }

  // Update the Game struct's lastMove and undoAvailable fields
  game->lastMove[0] = move[0];
  game->lastMove[1] = move[1];
  game->lastMove[2] = '\0';
  game->undoAvailable = true;
}

int main( int argc, char *argv[] ) {
  // Attach to memory, make a pointer for the gameState object
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/c/cshimes", 1), sizeof(struct GameState), 0666);
  struct GameState *gameState = (struct GameState *) shmat(shmid, 0, 0);
  if (gameState == (struct GameState *) -1) {
    fail("Couldn't attach to the shared memory space.", gameState);
  }

  // Handle user input
  // Code adopted from input validation in HW2 Pt.4 - client.c
   if (argc == 2) {
    // Undo command
    if (strcmp("undo", argv[1]) == 0) {
      // Undo the most recent move by playing it again
      if (gameState->undoAvailable == false) {
        error(gameState);
      }
      playMove(gameState->lastMove, gameState);
      // Update the undoAvailable field so two undos cannot be performed in a row
      gameState->undoAvailable = false;
      success(gameState);
    } 
    // Report command
    else if (strcmp("report", argv[1]) == 0) 
    {
      // Print out the contents of the board
      for (int i = 0; i < GRID_SIZE; i++) {
        printf("%c", gameState->board[i][0]);
        printf("%c", gameState->board[i][1]);
        printf("%c", gameState->board[i][2]);
        printf("%c", gameState->board[i][3]);
        printf("%c\n", gameState->board[i][4]);
      }
      // Print an additional line for a better looking output then exit
      printf("\n");
      exit(0);
    } else {
        error(gameState);
    }
   } else if (argc == 4) {
        if (strcmp("move", argv[1]) != 0) {
          error(gameState);
        }
        int row;
        int col;
        // Attempt to parse the input into rows and columns, which have to be between 0 and 4 (inclusive)
        if (sscanf(argv[2], "%d", &row) != 1 || row < 0 || row > GRID_SIZE - 1) {
          error(gameState);
        }

        if (sscanf(argv[3], "%d", &col) != 1 || col < 0 || col > GRID_SIZE - 1) {
          error(gameState);
        }

        // Play the move
        char * move = strcat(argv[2], argv[3]);
        playMove(move, gameState);
        success(gameState);
   } else {
      error(gameState);
   }
}
