import java.util.Scanner;
import java.util.ArrayList; 

/**
 * An example of using multi-threading in Java to search a list of integers
 * and find the maximum contiguous sum inside that list by evenly assigning starting indices
 * to worker threads.
 * 
 * Fall 2022 CSC 246 Homework 2 Pt. 2
 * 
 * @author Cameron Himes
 */
public class Maxsum 
{
    /** Boolean indicating whether each worker thread should report the max sum they found */
    private static volatile boolean report = false;
    /** Integer representing the global maximum sum found in the input list of integers */
    private static volatile int maxSum = Integer.MIN_VALUE;
    /** The list of input integers */
    private static volatile ArrayList<Integer> inputNumbers = new ArrayList<Integer>();

    /**
     * Represents a worker thread responsible for searching some subset of the provided list
     * of integers to find the maximum contiguous sum.
     */
    static class WorkerThread extends Thread {
        /** The indices at which the worker should start their search */
        private ArrayList<Integer> startingIndices;

        /**
         * Creates a worker thread and sets its starting indices according to the paraemter
         * @param startingIndices the indices at which the worker thread should start their searches for the max sum
         */
        public WorkerThread (ArrayList<Integer> startingIndices) {
            this.startingIndices = startingIndices;
        }

        /**
         * Finds and potentially reports (based on the value of the boolean field report) the maximum sum
         * in a list of integers.
         * 
         * The algorithm is based on the one I created for Homework 1 Part 3's maxsum.c program.
         */
        public void run() {
            int localMaxSum = Integer.MIN_VALUE;
            // For each starting index, run through the list of values and find the sum
            for (Integer idx: startingIndices) {
                int localSum = 0;
                int currentIndex = idx;
                
                while (currentIndex < inputNumbers.size()) {
                    localSum += inputNumbers.get(currentIndex);

                    // If the locally found sum is greater than the current local max, update the max
                    if (localSum > localMaxSum) {
                        localMaxSum = localSum;
                    }
                    currentIndex++;
                }
            }

            // Print the maximum local sum if the report flag was passed in
            if (report) {
                System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", Thread.currentThread().getId(), localMaxSum);
            }

            // Set the shared variable, maxSum, to be the local max sum if the local max sum is greater
            if (localMaxSum > maxSum) {
                maxSum = localMaxSum;
            }
        }
    } 

    /**
     * Parse user input and file input then make worker threads and wait for them to finish
     */
    public static void main(String args[]) 
    {
        // Parse user input
        if (args.length < 1 || args.length > 2) {
            System.out.println("Usage: java Maxsum {number} {report} < input.txt");
            System.exit(1);
        }

        int workers = Integer.parseInt(args[0]);
        if (args.length == 2 && args[1].equals("report")) {
            report = true;
        }

        // Read in the contents of the input file into an ArrayList
        Scanner inputScn = new Scanner(System.in);
        try {
            while (inputScn.hasNext()) {
                inputNumbers.add(inputScn.nextInt());
            } 
        } catch (Exception e) {
            inputScn.close();
            System.exit(1);
        }
        inputScn.close();

        // Create the worker threads and start them running with their indices
        // NOTE - code inspired by course example ThreadArguments.java
        WorkerThread[] threads = new WorkerThread[workers];
        for (int i = 0; i < threads.length; i++) {

            // Determine the indices for the new worker to search
            ArrayList<Integer> indicesToSearch = new ArrayList<Integer>();
            for (int j = i; j < inputNumbers.size(); j += workers) {
                indicesToSearch.add(j);
            }

            // Create the threads and start their searching
            threads[i] = new WorkerThread(indicesToSearch);
            threads[i].start();
        }

        // Wait for the threads to terminate after logging their results (either in the console or in the maxsum variable)
        try {
            for (int i = 0; i < threads.length; i++) {
                threads[i].join();
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join with worker thread.");
        }

        // Print out the final maximum sum
        System.out.printf("Maximum Sum: %d\n", maxSum);
    }
}