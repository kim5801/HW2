// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * gameState structure
 * row is the row number of the most recent move
 * column is the column number of the most recent move
 * canUndo indicated whether it is valid to use an undo operation (cannot be used twice in a row)
 * board is a 5x5 array meant to hold characters represented the lightsout board
 */
struct gameState {
    int row;
    int column;
    bool canUndo;
    char board[GRID_SIZE][GRID_SIZE];
};