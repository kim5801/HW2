import java.util.ArrayList;
import java.util.Scanner;

/**
 * find the maximum sum from a continuous range within a range of numbers
 * User can specify number of threads, to which the more threads can have an 
 * expectation of a faster runtime. An optional report parametere can be added
 * to get individual results from each thread.
 * The program will output the maximum sum found throughout all threads created
 * @author Nolan Peters
 */
public class Maxsum {
	

	// Input sequence of values.
	static ArrayList<Integer> vList = new ArrayList<Integer>(100);
	
	static ArrayList<Integer> resultList = new ArrayList<Integer>(100);

	// Number of values on the list.
	static int vCount = 0;


	
 /**
  * finds max within continuous range, each thread created
  * will run a unique run function
  *
  */
	static class getMax implements Runnable {
		int startIndex;
		int current;
		int workers;
		public int largest;
		int sum = 0;
		boolean report = false;
		getMax(int a, int workers, boolean report){
			startIndex = a;
			current = startIndex;
			this.workers = workers;
			largest = vList.get(startIndex);
			this.report = report;
		}
		 public void run() {
		   while (current < vCount) {
			   for (int i = current; i < vCount; i++) {
		             sum += vList.get(i);
		             if (sum > largest) {
		                 largest = sum;
		             }
		         }
		         sum = 0;
		         current += workers;
		   }
		   if (report) {
		         System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + largest + ".");
		     }
		   resultList.add(largest);
  	}
	}
	
	// Read the list of values.
	static void readList() {
	  // Keep reading as many values as we can.
	  int v;
	  Scanner scnr = new Scanner(System.in);
	  while ( scnr.hasNextInt() ) {
	    v = scnr.nextInt();

	    // Store the latest value in the next array slot.
	    vList.add(v) ;
	    vCount++;
	  }
	  scnr.close();
	}
	
	

/**
 * creates number of specified threads and runs them to find
 * a max sum in a continuous range, the work is spread out between
 * each worker relatively evenly
 *
 */
	public static void main( String args[] ) {
	  Boolean report = false;
	  int workers = Integer.parseInt(args[0]);

	  if (args.length == 2) {
		  if (args[1].equals("report")) {
			  report = true;
		  }
	  }


	  readList();

	  
	  Thread threads[] = new Thread[workers];
	  for (int i = 0; i < workers; i++) {
		  threads[i] = new Thread( new getMax(i, workers, report) );
          threads[i].start();
	  }
	  
	    
	     
	 
	  for (int i = 0; i < workers; i++) {
	     try {
	      	threads[i].join();
       } catch (InterruptedException e) {
		      e.printStackTrace();
	     }
	  }
	 
	  int largest = resultList.get(0);
	  for (int i = 0; i < resultList.size(); i++ ) {
	     if (resultList.get(i) > largest) {
	    	 largest = resultList.get(i);
	     }
	  }
	  System.out.println("Maximum Sum: " + largest);
	  return;
	}
}
