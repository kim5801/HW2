/**
 * manages operations on a lightsout game board, allowing for user to
 * view the board using report, make a move using move and allowing for
 * the previous move to be reverted
 * @author Nolan Peters
 * @file lightsout.c
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}



/** 
 *prints out the current game board
 *@param gameBoard array
 */
static void printBoard(char gameBoard[GRID_SIZE][GRID_SIZE]) {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
          printf("%c", gameBoard[i][j]);
      }
      printf("\n");
    }
}

/** 
 * performs a move operation on the gameboard indicated by row/column
 * @param gameBoard board to be operated on
 * @param row row of move location
 * @param column column of move location
 */
static void move(char gameBoard[GRID_SIZE][GRID_SIZE], int row, int column) {
    if (gameBoard[row][column] == '.') {
        gameBoard[row][column] = '*';
    } else { gameBoard[row][column] = '.';
    }
    
    if (row - 1 >= 0) {
        if (gameBoard[row - 1][column] == '.') {
            gameBoard[row - 1][column] = '*';
        } else { gameBoard[row - 1][column] = '.';
        }
    }
    
    if (row + 1 < GRID_SIZE) {
        if (gameBoard[row + 1][column] == '.') {
            gameBoard[row + 1][column] = '*';
        } else { gameBoard[row + 1][column] = '.';
        }
    }
    
    if (column - 1 >= 0 ) {
        if (gameBoard[row][column - 1] == '.') {
            gameBoard[row][column - 1] = '*';
        } else { gameBoard[row][column - 1] = '.';
        }
    }
    
    if (column + 1 < GRID_SIZE ) {
        if (gameBoard[row][column + 1] == '.') {
            gameBoard[row][column + 1] = '*';
        } else { gameBoard[row][column + 1] = '.';
        }
    }
}

int main( int argc, char *argv[] ) {

    //create key and access shared memory
    key_t key = ftok("/afs/unity.ncsu.edu/users/n/ntpeter2", 1);
    int shmid = shmget(key, sizeof(struct gameState), 0666);
    struct gameState *game = (struct gameState*) shmat(shmid, 0, 0);
    
    //check if number of arguments is invalid
 if (argc < 2 || argc > 4) {
        fail("error");
    }
    
    
    //process for if report is called
    if (strcmp(argv[1], "report") == 0) {
        printBoard(game->board);
    // check if the process is move
   } else if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail("error");
        }
        int row = argv[2][0] - '0';
        int column = argv[3][0] - '0';
        if ((row > 4 || row < 0) || (column > 4 || column < 0)) {
            fail("error");
        }
        move(game->board, row, column);
        game->row = row;
        game->column = column;
        game->canUndo = true;
        printf("success\n");
    }
    
     else if (strcmp(argv[1], "undo") == 0) {
      if (!(game->canUndo)) {
          fail("error");
      }
      //use gameState memory to repeat previous move (undoing it)
       move(game->board, game->row, game->column);
       game->canUndo = false;
       printf("success\n");
        
    } else { fail("error"); } //incorrect argument
    exit(0);
}
