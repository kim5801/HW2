// Height and width of the playing area.
#define GRID_SIZE 5


// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024



// board struct

struct GameState{
  char board[GRID_SIZE][GRID_SIZE];
  char lastMove[GRID_SIZE][GRID_SIZE];
  bool isLast;
  } typedef GameState;
