#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Maximum message size for communicating over the queue.
#define MAX_SIZE 1024

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

static void printBoard( struct GameState *board) {
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      printf("%c", board->board[i][j]);
    }
    printf("\n");
  }
}

static void makeMove( struct GameState *b, int row, int column ) {
  if(b->board[row][column] == '*') {
    b->board[row][column] = '.';
  }
  else {
    b->board[row][column] = '*';
  }
  
  if( row + 1 < GRID_SIZE ) {
    if(b->board[row + 1][column] == '*' ) {
      b->board[row + 1][column] = '.';
    }
    else {
      b->board[row + 1][column] = '*';
    }
  }
  
  if( row > 0 ) {
    if(b->board[row - 1][column] == '*' ) {
      b->board[row - 1][column] = '.';
    }
    else {
      b->board[row - 1][column] = '*';
    }
  }
  
  if( column + 1 < GRID_SIZE ) {
    if(b->board[row][column + 1] == '*' ) {
      b->board[row][column + 1] = '.';
    }
    else {
      b->board[row][column + 1] = '*';
    }
  }
  
  if( column > 0 ) {
    if(b->board[row][column - 1] == '*' ) {
      b->board[row][column - 1] = '.';
    }
    else {
      b->board[row][column - 1] = '*';
    }
  }
  
}
int main( int argc, char *argv[] ) {
  // Make a shared memory segment 1KB in size --writer
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/n/nykerkad", 1), sizeof( struct GameState ), 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  // Map the shared memory into my address space
  GameState *game = (GameState *)shmat( shmid, 0, 0 );
  if ( !game )
    fail( "Can't map shared memory segment into address space" );
    
  // Read a line of arguments
  char buffer[ MAX_SIZE + 1 ];
  int row;
  int column;
  sscanf( argv[1], "%s", buffer );
  
  if( strcmp( buffer, "move") == 0) {
    sscanf( argv[2], "%d", &row );
    sscanf( argv[3], "%d", &column );
    if( row > 4 || row < 0 ) {
      fail("error");
    } 
    if( column > 4 || column < 0 ) {
      fail("error");
    }
    // Send the move and row and column to server.
    for(int i = 0; i < 5; i++) {
      for(int j = 0; j < 5; j++) {
        game->lastMove[i][j] = game->board[i][j];
      }
    }
    makeMove(game, row, column);
   
      
    
    game->isLast = true;
    printf("success\n");
  }
  
  else if( strcmp( buffer, "undo") == 0 ) {
    //send undo command
    if (game->isLast){
      for(int i = 0; i < 5; i++) {
        for(int j = 0; j < 5; j++) {
          
          game->board[i][j] = game->lastMove[i][j];
        }
      }
    game->isLast = false;
    printf("success\n");
    }
    else 
       printf("error\n");
  }
  
  else if( strcmp( buffer, "report") == 0 ) {
    //send report command
    printBoard(game);
  }
  
  else {
    fail("error");
  }

  shmdt(game);
  return 0;
}
