import java.util.*;
import java.lang.*;

public class Maxsum {

// Input sequence of values.
  public static ArrayList<Integer> vList;

// Number of values on the list.
  public static int vCount = 0;

// Capacity of the list of values.
  public static int vCap = 0;
  
  public static boolean report;
  
  // Print out an error message and exit.
  public static void fail( String message ) {
    System.err.println( message );
    System.exit( 1 );
  }

// Print out a usage message, then exit.
  public static void usage() {
    System.out.println( "usage: maxsum <workers>" );
    System.out.println( "       maxsum <workers> report" );
    System.exit( 1 );
  }
  
  public static void readList() {
  // Set up initial list and capacity.
    vCap = 5;

    // Keep reading as many values as we can.
    int v;
    Scanner input = new Scanner(System.in);
    vList = new ArrayList<Integer>();
    while(input.hasNextInt()) {
      // Store the latest value in the next array slot.
      v = input.nextInt();
      vList.add(vCount, v);
      vCount++;
    }
  }

  public static boolean isInt(String workers) {
    try {
      Integer.parseInt(workers);
      return true;
    } catch (NumberFormatException e) {
        return false;
    }
  }
  
  static class MyThread extends Thread {
  
    public ArrayList<Integer> indices;
    private int maxSum;
    
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( ArrayList<Integer> indicies ) {
      this.indices = indicies;
      this.maxSum = Integer.MIN_VALUE;
    }
    
    public void run() {
      for(int j = 0; j < indices.size(); j++ ){
        int sum = 0;
        int temp = Integer.MIN_VALUE;
        for(int i = indices.get(j); i < vCount; i++ ) {
          sum += vList.get(i);
          if(temp < sum) {
            temp = sum;
          }
        }
        if( temp > maxSum )
          maxSum = temp;
      }
     if(report) {
       System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + this.maxSum);
     } 
    }
  }
  
  public static void main( String[] args ) {
    int argCount = args.length;
    int workers = 4;

    // Parse command-line arguments.
    if ( argCount < 1 || argCount > 2 )
      usage();

    if( isInt(args[ 0 ]) ) {
      workers = Integer.parseInt(args[ 0 ]);
      if(workers < 1 ) {
        usage();
      }
    }
    else {
      usage();
    }
    
    // If there's a second argument, it better be the word, report
    if ( argCount == 2 ) {
      if ( args[ 1 ].equals("report") )
      report = true;
    }

    readList();
  
  //divvi up the work by assigning each worker to an equal amount of loops (indecies to take care of) as the other workers
    int loops = vCount / workers; 
    int currentSum;
  
    ArrayList<MyThread> threads = new ArrayList<MyThread>(workers);
    
    
    //set indices
    //initialize threads
    
    for(int i = 0; i < workers; i++ ) {
     ArrayList<Integer> indecies = new ArrayList<Integer>(loops);
    
     for(int j = i; j < vCount; j += workers ) {
       indecies.add(j);
     } 
     MyThread thread = new MyThread(indecies);
     threads.add(thread);
    }
    //start thread
    for ( int i = 0; i < workers; i++ ) {
      threads.get(i).start();
    }
  
    // Wait for each of the threads to terminate. 
    try {
    
      for ( int i = 0; i < workers; i++ ) {
        threads.get(i).join();
      }
      int maxSum = Integer.MIN_VALUE;
      for( int i = 0; i < workers; i++ ) {
        int temp = threads.get(i).maxSum;
        if( maxSum < temp ) {
          maxSum = temp;
        }
      }
      System.out.println( "Maximum Sum: " + maxSum );
    } catch( InterruptedException e ) {
        System.out.println("Interrupted during join");
    }
  }
}