#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Maximum message size for communicating over the queue.
#define MAX_SIZE 1024

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

//initializes and populates the original board
int initializeBoard(FILE *fp, struct GameState *game) {
  for(int rows = 0; rows < 5; rows++ ) {
    for(int columns = 0; columns < 5; columns++) {
      char character = fgetc(fp);
      game->board[rows][columns] = character;
      if(character != '*' && character != '.' && character != '\n' ) {
        return -1;
      }
    }
    fgetc(fp);
  }
  game->isLast = false;
  return 0;
}

// Size of the shared block of memory.
const int BLOCK_SIZE = 1024;


int main( int argc, char *argv[] ) {
  
  if(argc > 2 || argc < 1) {
    usage();
  }
  if(strcmp(argv[0], "./reset") != 0) {
    usage();
  }
   
  // Make a shared memory segment 1KB in size --writer
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/n/nykerkad", 1), sizeof( struct GameState ), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
  // Map the shared memory into my address space
  struct GameState *game = (struct GameState *)shmat( shmid, 0, 0 );
  if ( game == (struct GameState *) - 1 )
    fail( "Can't map shared memory segment into address space" );
    
    
 
  FILE *fp = fopen(argv[1], "r");
  if(!fp) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
  }
  int rtn = initializeBoard(fp, game);
  if( rtn == -1 ) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
  }
  fclose(fp);

  shmdt(game);
  return 0;
}
