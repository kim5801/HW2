import java.util.Scanner;

public class Maxsum {
    // Stores initial capacity for list of ints
    private static final int INIT_CAP = 5;
    // Will be used to represent integers read in from file
    private static int[] list;
    // Number of values on the list.
    private static int vCount = 0;
    // Capacity of the list of values.
    private static int vCap = 0;
    // Flag for whether we need to report the results
    private static boolean toReport = false;

    // Private inner class to create a custom thread to calculate the maxsum in a range of numbers
    static class Thread1 extends Thread {
        // Stores total sum in range of numbers
        public int sum = 0;
        // Initial index to start from in list
        private int start = 0;
        // Final index to add from list
        private int end = 0;

        // Constructs Thread object with specified start and stop indexes
        public Thread1(int start, int end) {
            this.start = start;
            this.end = end;
        }

        // Method used to calculate sum when thread is started
        public void run() {
            for(int i = start; i < end; i++) {
                if(sum + list[i] > sum) { //if adding the current index with make the sum larger...
                    sum += list[i]; // update sum to include number at current index
                }
            }
            if(toReport) // if report flag is true, report thread information in each iteration
                System.out.println("I'm thread " + this.getId()
                                + ". The maximum sum I found is " + sum + ".");

        }
    }

    // Method doubles size of list if it has reached its capacity
    private static void growArray() {
        vCap = vCap * 2;
        int[] newList = new int[vCap];
        for(int i = 0; i < vCount; i++)
            newList[i] = list[i];
        list = newList.clone();
    }

    // Reads integers from input to list[]
    private static void readList() {
        Scanner input = new Scanner(System.in); // create Scanner to read from stdin
        while(input.hasNextInt()) {
            if(vCount == vCap)
                growArray();
            list[vCount] = input.nextInt();
            vCount++;
        }
    }

    public static void main( String[] args ) {
        if(args.length != 1 && args.length != 2) {
            System.out.println("usage: Maxsum <workers>");
            System.out.println("       Maxsum <workers> report");
            return;
        }
        int workers = Integer.parseInt(args[0]);
        if(args.length == 2 && args[1].equals("report"))
            toReport = true;
        vCap = INIT_CAP;
        list = new int[vCap];
        readList(); // read input to list

        int maxsum = 0;
        int sectionSize = vCount / workers; //establishes how much of the list each worker evaluates
        // System.out.println(sectionSize);
        int end = sectionSize;
        int start = 0;
        Thread1[] threads = new Thread1[workers];
        for(int i = 0; i < workers; i++) { //create provided # workers/threads
            threads[i] = new Thread1(start, end);
            threads[i].start(); //start running the threads

            //update indexes for next thread
            start = end;
            end += sectionSize;
            if(vCount < end)
                end = vCount;
        }

        try {
            for(int i = 0; i < workers; i++) {
                if(threads[i].sum > maxsum) // Update max sum given final sums from workers
                    maxsum = threads[i].sum;
                threads[i].join();  // Attempt to join the threads
            }
        } catch( InterruptedException e ) {
            System.out.println("Interrupted during join!");
        }

        // Output final sum
        System.out.println("Maximum Sum: " + maxsum);
    }
}
