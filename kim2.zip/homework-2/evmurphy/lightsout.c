#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// If the command executes successfully print message and exit.
static int success() {
    printf("success\n");
    return 0;
}

// Checks if provided numbers are out of bounds for the board
static bool outofbound(int num) {
    if(num < 0 || num > 4)
        return true;
    return false;
}

// Prints board to stdout
static void reportGame(struct GameState * g) {
    for(int i = 0; i < GRID_SIZE; i++) {
        for(int j = 0; j < GRID_SIZE; j++)
            printf("%c", g->board[ i ][ j ]);
        putchar('\n');
    }
}

// Checks if provided character is a digit
//   returns true if digit, otherwise false
static bool isDigit(char curr) {
    if(curr >= '0' && curr <= '9')
        return true;
    return false;
}

// Updates provided space turn "lights" on or off
static void updateSpace(char *curr) {
    if(*curr == '*')
        *curr = '.';
    else
        *curr = '*';
}

int main( int argc, char *argv[] ) {
    if(argc != 4 && argc != 2) { //must have 2 or 4 command line arguments
        fail("error");
    }
    char *command = argv[ 1 ];
    if(strcmp(command, "move") != 0 && strcmp(command, "undo") != 0 
        && strcmp(command, "report") != 0) {
        fail("Out of bounds"); //if the second argument is an invalid option
    }
    
    int row = -1, col = -1;
    if(strcmp(command, "move") == 0) {
        if( argc != 4 || !isDigit(*argv[ 2 ]) || !isDigit(*argv[ 3 ]) )
            fail("error"); //if the arguments provided after move keyword are invalid
        //converts char to int
        row = atoi(argv[ 2 ]);
        col = atoi(argv[ 3 ]);
        
        if(outofbound( row ) || outofbound( col ))
            fail("error"); //if the arguments provided after move keyword are invalid
    }

    int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/evmurphy", 0), sizeof( struct GameState ), 0 ); //create segment of memory for GameState
    if ( shmid == -1 )
        fail( "Can't create shared memory" );
    
    struct GameState *game = (struct GameState *) shmat( shmid, 0, 0 ); //cast pointer to GameState struct
    if ( game == (struct GameState *)-1 ) //if memory segment fails to map successfully
        fail( "Can't map shared memory segment into address space" );

    if(strcmp(command, "move") == 0) { // if provided command is to make a move
        game->undoOK = true; // undo is now an option
        update_move:
            updateSpace(&(game->board[row][col]));
            // check if space is a valid space on the board.
            // if it is, update space, otherwise don't
            if(!outofbound(row - 1))
                updateSpace(&(game->board[row - 1][col]));
            if(!outofbound(row + 1))
                updateSpace(&(game->board[row + 1][col]));
            if(!outofbound(col + 1))
                updateSpace(&(game->board[row][col + 1]));
            if(!outofbound(col - 1))
                updateSpace(&(game->board[row][col - 1]));
            // save move to prevMove in game struct
            game->prevMove[0] = row;
            game->prevMove[1] = col;
            shmdt( game ); // release reference to shared memory
            return success();
    }
    if(strcmp(command, "undo") == 0) { // if provided command is to undo the last move
        if(!game->undoOK) // if there isn't a move to undo, exit unsuccessfully
            fail("error");
        row = game->prevMove[0];
        col = game->prevMove[1];
        game->undoOK = false;

        goto update_move;
    }
    if(strcmp(command, "report") == 0)
        reportGame(game);
    // Release our reference to the shared memory segment.
    shmdt( game );
    return 0;
}
