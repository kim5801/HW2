#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

//reads input from file and fills information for initial board
static void readBoard(int fd, struct GameState * g, char * file) {
    char buffer[1]; //stores the output of read -- will be overwritten during each call
    for(int i = 0; i < GRID_SIZE; i++) {
        for(int j = 0; j < GRID_SIZE; j++) {
            if(read(fd, buffer, 1) == 0 || ( *buffer != '.' && *buffer != '*')) {
                if(*buffer != '\n') { //if not a valid character option...
                    fprintf( stderr, "Invalid input file: %s\n", file );
                    exit(1); //exit unsuccessfully
                }
            }
            g->board[i][j] = *buffer; //update board at specified index
        }
        read(fd, buffer, 1); //get rid of newline
    }
} 

int main( int argc, char *argv[] ) {
    if(argc != 2) //if invalid number of command line arguments
        usage();
    int openFile;
    char *filename = argv[ 1 ];
    if( ( openFile = open( argv[ 1 ], O_RDONLY ) ) == -1 ) { //open file to be used for reading board
        fprintf( stderr, "Invalid input file: %s\n", filename );
        exit(1);
    }
    key_t mem_key = ftok("/afs/unity.ncsu.edu/users/e/evmurphy", 0); //create custom key for shmget()
    int shmid = shmget(mem_key, sizeof(struct GameState), 0666 | IPC_CREAT); //create segment of memory for GameState
    if ( shmid == -1 )
        fail( "Can't create shared memory" );
    
    struct GameState *game = (struct GameState *) shmat( shmid, 0, 0 ); //cast pointer to GameState struct
    if ( game == (struct GameState *)-1 ) //if memory segment fails to map successfully
        fail( "Can't map shared memory segment into address space" );
    
    readBoard(openFile, game, filename); //read through file and store contents of board
    game->undoOK = false;
    // Release our reference to the shared memory segment.
    shmdt( game );
    return 0;
}
