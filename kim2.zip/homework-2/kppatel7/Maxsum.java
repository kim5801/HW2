import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * program to use multiple threads to find the largest sum
 * from an input file
 */
public class Maxsum {

  // Print out a usage message, then exit.
  public static void usage() {
    System.out.print("usage: maxsum <workers>\n");
    System.out.print("       maxsum <workers> report\n");
    System.exit(1);
  }

  // Print out an error message and exit.
  public static void fail(String message) {
    System.err.print(message);
    System.exit(1);
  }

  // arraylist of integers in the input file. use arraylist so it does the array capacity changes automatically
  static ArrayList<Integer> vList = new ArrayList<Integer>();

  // Number of values on the list.
  static int vCount = 0;

  // Read the list of values.
  public static void readList(Scanner fileReader) throws FileNotFoundException {
    //next value in the fileReader
    int val;
    while (fileReader.hasNext()) {
      val = fileReader.nextInt();
      // Store the latest value in the next array slot.
      vList.add(vCount, val);
      vCount++;
    }
  }

  static class MyThread extends Thread {

    private int threadNum;

    /**
     * sum to be stored
     */
    private int tempMax;

    /**
     * worker field
     */
    private int workers;

    /**
     * report field
     */
    private boolean report;

    //thread constructor
    public MyThread(int threadNum, boolean report, int workers) {
      //which thread is this
      this.threadNum = threadNum;
      //did they do the report option?
      this.report = report;
      //num of threads
      this.workers = workers;
      //max found by this thread (dosent have to be initialized)
      this.tempMax = 0;
    }

    //same code from C to calc the concurrent maxsum
    public void run() {
      for (int j = threadNum; j < vCount; j += workers) {
        int tempSum = 0;
        for (int k = j; k < vCount; k++) {
          tempSum += vList.get(k);
          if (tempSum > tempMax) {
            tempMax = tempSum;
          }
        }
      }

      //print out process id and tempMax found
      if (report) {
       
        System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + tempMax);
      }
    }
  }

  public static void main(String[] args) throws FileNotFoundException {
    boolean report = false;
    int workers = 4;
    int maxSum = 0;

    // check there is the right amount of command line args
    if (args.length < 1 || args.length > 2) {
      usage();
    }

    // If there's a second argument, it better be the word, report
    if (args.length == 2) {
      if (args[1].compareTo("report") != 0) {
        usage();
      }
      else{
        report = true;
      }
    }

    //change the string command line arg to a int and check if its valid
    workers = Integer.parseInt(args[0]);

    if (workers < 1) {
      usage();
    }

    //scanner for input that well pass to the readList func to populate the vList
    Scanner in = new Scanner(System.in);
    readList(in);

    //create threads
    MyThread[] thread = new MyThread[workers];
    //make and start the threads with the necessary fields
    for (int i = 0; i < workers; i++) {
      thread[i] = new MyThread(i, report, workers);
    }
    for (int i = 0; i < workers; i++) {
      thread[i].start();
    }

    int[] sums = new int[workers];
    // Wait for each of the threads to terminate.
    try {
      for (int i = 0; i < workers; i++) {
        thread[i].join();
      }
      for (int i = 0; i < workers; i++) {
        sums[i] = thread[i].tempMax;
      }
    } catch (InterruptedException e) {
      System.out.println("Error joining with threads");
    }

    //compare sum values to find the max sum
    maxSum = 0;
    for (int i = 0; i < workers; i++) {
      if (sums[i] > maxSum) {
        maxSum = sums[i];
      }
    }
    //max sum is displayed
    System.out.println("Maximum Sum: " + maxSum);
  }
}
