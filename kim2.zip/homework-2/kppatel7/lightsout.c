/**
 * @file lightsout.c
 * @author Kush Patel
 * @brief creates the lights out game using shared memory
 *
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/**
 * change the specified spot on the board from a * to . or vice versa
 *
 * @param game game board
 * @param row row to change
 * @param column col to change
 */
void flipPiece(GameState *game, int row, int column)
{
    // get the exact spot in the single array
    int spot = (row * GRID_SIZE) + column;
    if (game->board[spot] == '.')
    {
        game->board[spot] = '*';
    }

    else if (game->board[spot] == '*')
    {
        game->board[spot] = '.';
    }
}

/**
 * changes the board accordingly when making a move
 * 
 * @param game game board
 * @param row row to change
 * @param col col to change
 */
void makeMove(GameState *game, int row, int col)
{
    if (row == 0 && col == 0)
    { // top left corner
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row, col + 1);
    }
    else if (row == 0 && col == 4)
    { // upper right corner
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row, col - 1);
    }
    else if (row == 4 && col == 0)
    { // bottom left corner
        flipPiece(game, row, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col + 1);
    }
    else if (row == 4 && col == 4)
    { // bottom right corner
        flipPiece(game, row, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
    }
    else if (row == 0 && (col != 0 || col != 4))
    { // upper row not corners
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row, col - 1);
        flipPiece(game, row, col + 1);
        
    }
    else if (row == 4 && (col != 0 || col != 4))
    { // bottom row not corners
        flipPiece(game, row, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
        flipPiece(game, row, col + 1);
        
    }
    else if (col == 0 && (row != 0 || row != 4))
    { // left col but not corners
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col + 1);
    }
    else if (col == 4 && (row != 0 || row != 4))
    { // right-most column not corners
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
    }
    else
    { // everything else
        flipPiece(game, row, col);
        flipPiece(game, row + 1, col);
        flipPiece(game, row - 1, col);
        flipPiece(game, row, col - 1);
        flipPiece(game, row, col + 1);
    }
}

/**
 * check if the passed in number is valid or not
 *
 * @param number number to check
 * @return true if number is between 0-4 inclusive
 * @return false if any other number or negative
 */
bool validNumber(const char number[])
{
    // cant have a num that starts with '-'
    if (number[0] == 45)
    {
        return false;
    }

    for (int i = 0; number[i] != 0; i++)
    {

        if (number[i] >= '0' && number[i] < '5')
        {
            return true;
        }
    }
    return false;
}

int main(int argc, char *argv[])
{
    key_t key;
    key = ftok(PATH_NAME, 7);               // creates unique key
    int sharedMemoryID = shmget(key, 0, 0); // make the shared memory space

    GameState *game = (GameState *)shmat(sharedMemoryID, 0, 0); //attach the memory

    //the three options than can be specified to lightsout
    if (strcmp(argv[1], "report") == 0)
    {
        for (int row = 0; row < GRID_SIZE; row++)
        {
            for (int col = 0; col < GRID_SIZE; col++)
            {
                printf("%c", game->board[(row * 5) + col]);
            }
            printf("\n"); // end of row
        }
        printf("\n");
    }
    //take old move and redo it
    else if (strcmp(argv[1], "undo") == 0)
    {
        if (game->undoPossible)
        {
            int row = game->oldRow;
            int col = game->oldCol;
            //undos last move
            makeMove(game, row, col);
            //cant undo twice in a row
            game->undoPossible = false;
            printf("success\n");
        }
        else if (!game->undoPossible)
        {
            printf("error\n");
        }
    }
    else if (argc == 4 && (strcmp(argv[1], "move") == 0) && (validNumber(argv[2]) && validNumber(argv[3])))
    {
        game->moveRow = atoi(argv[2]); // gets the row as int
        game->moveCol = atoi(argv[3]); // gets the column as int

        int row = game->moveRow;
        int col = game->moveCol;
        // switches the board state
        makeMove(game, row, col);
        //they made a move so undo is possible and stored
        game->undoPossible = true;
        game->lastRow = row;
        game->lastCol = col;
        printf("success\n");
    }
    else
    {
        printf("error\n");
    }

    return 0;
}