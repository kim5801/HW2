#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flips from . or #
static char flip(char element) {
    if(element == '*') {
		    return '.';
		} else if(element == '.') {
		    return '*';
		} else {
		    fail("Invalid board");
		}
	  return 'x';
}
// GameState struct to keep track of the current board, previous board, and undo ability
typedef struct {
    bool canUndo;
    char prevBoard[GRID_SIZE][GRID_SIZE];
    char currentBoard[GRID_SIZE][GRID_SIZE];
    
} GameState;

int main( int argc, char *argv[] ) {

    char buffer[7];
    if(argc == 4) { // Checks number of commands
		    strcpy(buffer, "move");
	      if(*argv[2] - 48 < 0 || *argv[2] - 48 > 4 || *argv[3] - 48 < 0 || *argv[3] - 48 > 4) {
				    fail("Error: Invalid indices"); // Fails if move has invalid indices
				}
	      buffer[4] = *argv[2];
	      buffer[5] = *argv[3];
	     	if(atoi(argv[2]) < 0 || atoi(argv[2]) > 5 || atoi(argv[3]) < 0 || atoi(argv[3]) > 5) {
				    fail("Error: Invalid index"); // Fails if move has invalid indices
		    }
		} else if (argc == 2) {
		    if(strcmp(argv[1], "report") == 0) {
				    strcpy(buffer, "report");
				} else if(strcmp(argv[1], "undo") == 0) {
				    strcpy(buffer, "undo");
				} else {
				    fail("Error: Invalid command"); // Fails if bad command is entered
				}
		} else {
		    fail("Error: Invalid run parameters");
		}
    
    char cmd[4]; // Temporary string to hold first four characters for move
    cmd[0] = buffer[0];
    cmd[1] = buffer[1];
    cmd[2] = buffer[2];
    cmd[3] = buffer[3];
    cmd[4] = '\0';
    
    int shmid = shmget(ftok(MEM_KEY, 0), sizeof(GameState), IPC_CREAT | 0666);
    if(shmid == -1) {
        fail("Couldn't get memory");
	  }
    GameState *sbuffer = (GameState *)shmat(shmid, 0, 0);
    
	  if(strcmp("report", buffer) == 0) { // Prints the current state of the board
        for(int i = 0; i < GRID_SIZE; i++) {
				     for(int k = 0; k < GRID_SIZE; k++) {
						     printf("%c", sbuffer->currentBoard[i][k]);
						 }
	 	 	       printf("\n");
				}
		} else if(strcmp("undo", buffer) == 0) { // Undoes move if possible
        if(sbuffer->canUndo) {
				    for(int i = 0; i < GRID_SIZE; i++) { // Updates currentBoard to prevBoard 
				        for(int k = 0; k < GRID_SIZE; k++) {
							      sbuffer->currentBoard[i][k] = sbuffer->prevBoard[i][k];
						  	} 
				    }
 			      sbuffer->canUndo = false;
	 	        printf("success\n");
				} else {
				    printf("error\n");
				}
		} else if(strcmp("move", cmd) == 0) { // Makes a move if possible
          sbuffer->canUndo = true;
			    int row = buffer[4] - 48;
			    int col = buffer[5] - 48;
			    for(int i = 0; i < GRID_SIZE; i++) { // Firstly updates prevBoard to board before making changes to board
					    for(int k = 0; k < GRID_SIZE; k++) {
							    sbuffer->prevBoard[i][k] = sbuffer->currentBoard[i][k];
							}
					}
		 		  if(row - 1 < 0) { // Deals with all cases when row == 0 i.e. left top row
					    if(col - 1 < 0) {
							    sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
                  sbuffer->currentBoard[row][col + 1] = flip(sbuffer->currentBoard[row][col + 1]);
           				sbuffer->currentBoard[row + 1][col] = flip(sbuffer->currentBoard[row + 1][col]);
							} else if(col + 1 > 4) {
							    sbuffer->currentBoard[row][col - 1] = flip(sbuffer->currentBoard[row][col - 1]);
 				          sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
	 		            sbuffer->currentBoard[row + 1][col] = flip(sbuffer->currentBoard[row + 1][col]);
							} else {
							    sbuffer->currentBoard[row][col - 1] = flip(sbuffer->currentBoard[row][col - 1]);
 				          sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
			            sbuffer->currentBoard[row][col + 1] = flip(sbuffer->currentBoard[row][col + 1]);
			            sbuffer->currentBoard[row + 1][col] = flip(sbuffer->currentBoard[row + 1][col]);
							} 
				  } else if(row + 1 > 4) { // Deals with all cases when row == 4 i.e. bottom row
					    if(col - 1 < 0) {
							    sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
                  sbuffer->currentBoard[row][col + 1] = flip(sbuffer->currentBoard[row][col + 1]);
           				sbuffer->currentBoard[row - 1][col] = flip(sbuffer->currentBoard[row - 1][col]);
							} else if(col + 1 > 4) {
							    sbuffer->currentBoard[row][col - 1] = flip(sbuffer->currentBoard[row][col - 1]);
 				          sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
	 		            sbuffer->currentBoard[row - 1][col] = flip(sbuffer->currentBoard[row - 1][col]);
							} else {
							    sbuffer->currentBoard[row][col - 1] = flip(sbuffer->currentBoard[row][col - 1]);
 				          sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
			            sbuffer->currentBoard[row][col + 1] = flip(sbuffer->currentBoard[row][col + 1]);
			            sbuffer->currentBoard[row - 1][col] = flip(sbuffer->currentBoard[row - 1][col]);
							} 
					} else if(col - 1 < 0) { // Deals with all cases if col == 0 i.e. left column
					    sbuffer->currentBoard[row - 1][col] = flip(sbuffer->currentBoard[row - 1][col]);
 				      sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
			        sbuffer->currentBoard[row][col + 1] = flip(sbuffer->currentBoard[row][col + 1]);
			        sbuffer->currentBoard[row + 1][col] = flip(sbuffer->currentBoard[row + 1][col]);
					} else if(col + 1 > 4) { // Deals with all cases if col == 4 i.e. right column
					    sbuffer->currentBoard[row][col - 1] = flip(sbuffer->currentBoard[row][col - 1]);
 				      sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
			        sbuffer->currentBoard[row + 1][col] = flip(sbuffer->currentBoard[row + 1][col]);
			        sbuffer->currentBoard[row - 1][col] = flip(sbuffer->currentBoard[row - 1][col]);
					} else { // Deals with all remaining middle cases for col and row
					    sbuffer->currentBoard[row][col - 1] = flip(sbuffer->currentBoard[row][col - 1]);
 				      sbuffer->currentBoard[row][col] = flip(sbuffer->currentBoard[row][col]);
			        sbuffer->currentBoard[row][col + 1] = flip(sbuffer->currentBoard[row][col + 1]);
			        sbuffer->currentBoard[row - 1][col] = flip(sbuffer->currentBoard[row - 1][col]);
			        sbuffer->currentBoard[row + 1][col] = flip(sbuffer->currentBoard[row + 1][col]);
					}
			    printf("success\n");
		}

  return 0;
}
