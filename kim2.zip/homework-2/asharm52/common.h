// Height and width of the playing area.
#define GRID_SIZE 5

// the gameboard struct
typedef struct {
  char board[ GRID_SIZE ][ GRID_SIZE ];
  char oldBoard[ GRID_SIZE ][ GRID_SIZE ];
  bool undoAvailable;
} GameState;
