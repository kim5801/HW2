import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Maxsum {

    // Input sequence of values.
    private static volatile List<Integer> vList;

    // Number of values on the list.
    private static volatile int vCount = 0;

    // the numbers of threads requested by the user
    public static int workers = 4;

    // boolean keeping track of whether or not user wants report to be printed
    public static boolean report = false;

    /**
     * usage function that prints when there is an error with user input
     */
    private static void usage() {
        System.out.println("usage: maxsum <workers>");
        System.out.println("maxsum <workers> report");
        System.exit(1);
    }

    /**
     * function prints when there is a technical failure
     * @param message the message to be printed
     */
    private static void fail(String message) {
        System.err.println(message);
        System.exit(1);
    }

    /*
     * reads the list provided by the user and stores the numbers in an arrayList
     */
    private static void readList() {
        vList = new ArrayList<Integer>();
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextInt()) {
            vList.add(sc.nextInt());
            vCount++;
        }
        sc.close();
    }

    /**
     * Thread class, contains the logic for each thread to calculate the largest sum
     * it can, then store
     * it in a global variable for the "parent" thread to look at
     */
    public static class WorkerThread extends Thread {
        // global var for parent thread to look at
        public int max = -100000;

        // private vars needed only by the thread to compute largest
        private int workerIndex;
        private int workerIndex2;
        private int sum = 0;

        // constructor for the thread
        public WorkerThread(int workerIndex) {
            this.workerIndex = workerIndex;
            this.workerIndex2 = workerIndex;
        }

        /**
         * this function runs once for each thread
         */
        public void run() {
            // iterating through the list of numbers trying to find the highest sum
            while (workerIndex < vCount) {
                while (workerIndex2 < vCount) {
                    sum += vList.get(workerIndex2);
                    if (sum > max) {
                        max = sum;
                    }
                    workerIndex2++;
                }
                workerIndex += workers;
                workerIndex2 = workerIndex;
                sum = 0;
            }
            if (max == -100000) {
                max = 0;
            }
            //print out report to user if requested
            if (report) {
                System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + max);
            }
        }
    }

    /**
     * main function looks at user input and creates that many threads
     * calls the function to read in the text file
     * the threads are sent to calculate the max, then this functions finds the largest one and prints it
     * @param args user input
     */
    public static void main(String[] args) {

        // Parse command-line arguments.
        if (args.length < 2 || args.length > 3) {
            usage();
        }

        try {
            workers = Integer.parseInt(args[0]);
        } catch (NumberFormatException nfe) {
            usage();
        }

        if (workers < 1) {
            usage();
        }

        if (args.length == 2) {
            if (!args[1].equals("report")) {
                usage();
            }
            report = true;
        }

        readList();

        WorkerThread threads[] = new WorkerThread[workers];
        for (int i = 0; i < workers; i++) {
            threads[i] = new WorkerThread(i);
            threads[i].start();
        }

        // Wait for each of the threads to terminate.
        int totalSum = 0;
        int finalMax = -100000;
        try {
            for (int i = 0; i < workers; i++) {
                totalSum = threads[i].max;
                if (totalSum > finalMax) {
                    finalMax = totalSum;
                }
                threads[i].join();
            }
        } catch (InterruptedException e) {
            fail("Interrupted during join!");
        }
        System.out.println("Maximum Sum: " + finalMax);
    }

}
