#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

#include <sys/ipc.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}





int main( int argc, char *argv[] ) {
  //setting up the board - incorrect arg
  if ( argc != 2 ) {
    usage();
  }
  //incorrect file
  int readFile = open( argv[1], O_RDONLY );
  if ( readFile < 0 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( 1 );
  }

  char readInput[31];
  //read from file
  int readLength = read( readFile, readInput, sizeof(readInput) );
  //check
  if (readLength != 30) { //30 is EOF / null? 31 is for us
    fail("Invalid input file: filename");
  }
  
  //GameState gs = {readInput, 5};
  //creating a shared memory w/ permissions - w special key
  char name[50] = "/afs/unity.ncsu.edu/users/g/gawatts2";
  key_t key = ftok( name, 'e');
  int shmid = shmget( key, sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    printf("%d", errno);
    fail( "Can't create shared memory" );
  }
  

  
  //into adress space
  GameState *structbuffer = (GameState *)shmat( shmid, 0, 0 );
  if ( structbuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
    
    
  //access the contents of the shared memory via this pointer, as if the shared memory was just an instance of GameState
  strcpy(structbuffer->board , readInput);
  structbuffer->state = 0;

  //structbuffer = &gs;
  //printf("%d",structbuffer->state);
  
  // Release our reference to the shared memory segment.
  shmdt( structbuffer );
  
  return 0;
}