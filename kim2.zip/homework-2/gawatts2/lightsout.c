#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// move operation based on position given, assumed position is correct; take advantage
//of referene semantics 
//THIS FUNCTION IS FROM PREVIOUS ASSIGNMENT (FROM ME)
void moveF(int rowIdx, int colIdx, char* lineRepofGrid  ) {
  //game matrix is in grid
  int tick = 0;
  char grid[5][6];
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      grid[row][col] = lineRepofGrid[tick];
      //putchar(grid[row][col]); //to test in printing
      tick++;
    }
  }
  // putchar('\n'); //to test in printing
  //!!grid[][] mirrors like how it is in game here !!
  bool top = false;
  bool bottom = false;
  bool left = false;
  bool right = false;
  //top row
  if (rowIdx == 0) {
    //top left corner
    if (colIdx == 0 ) {
      bottom = true;
      right = true;
    }
    //top right corner
    else if (colIdx == 4) {
      bottom = true;
      left = true;
    }
    //top internal
    else {
      bottom = true;
      left = true;
      right = true;
    } 
  } //top row close
  //bottom row
  else if ( rowIdx == 4) { 
    //bottom left corner
    if ( colIdx == 0 ) {
      top = true;
      right = true;
    }
    //bottom right corner
    else if (colIdx == 4) {
      left = true;
      top = true;
    } 
    //bottom internal
    else {
      left = true;
      top = true;
      right = true;
    }
  } //bottom row close
  //in middle
  else {
  //middle left side
    if ( colIdx == 0 ) {
      bottom = true;
      top = true;
      right = true;
    }
    //middle right side
    else if ( colIdx == 4 ) {
      bottom = true;
      top = true;
      left = true;
    }
    //internal middle - all change
    else {
      bottom = true;
      top = true;
      left = true;
      right = true;
    }
  }
  //!up to here determined the valid changeable positions
  if (top) {
    if (grid[rowIdx - 1][colIdx] == '.') {
      grid[rowIdx - 1][colIdx] = '*';
    } else {
      grid[rowIdx - 1][colIdx] = '.';
    }
  }
  if (bottom) {
    if (grid[rowIdx + 1][colIdx] == '.') {
      grid[rowIdx + 1][colIdx] = '*';
    } else {
      grid[rowIdx + 1][colIdx] = '.';
    }
  }
  if (left) {
    if (grid[rowIdx][colIdx - 1] == '.') {
      grid[rowIdx][colIdx - 1] = '*';
    } else {
      grid[rowIdx][colIdx - 1] = '.';
    }
  }
  if (right) {
    if (grid[rowIdx][colIdx + 1] == '.') {
      grid[rowIdx][colIdx + 1] = '*';
    } else {
      grid[rowIdx][colIdx + 1] = '.';
    }
  }
  //now change the position itself given
  if (grid[rowIdx][colIdx] == '.') {
    grid[rowIdx][colIdx] = '*';
  } else {
    grid[rowIdx][colIdx] = '.';
  }
  //!! AT THIS POINT ALL MOVES PUT IN GRID[][]
  tick = 0;
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      lineRepofGrid[tick] = grid[row][col];
      //putchar(lineRepofGrid[tick]); //to test in printing
      tick++;
    }
  }
  
}





int main( int argc, char *argv[] ) {
  //creating a shared memory w/ permissions - w special key
  char name[50] = "/afs/unity.ncsu.edu/users/g/gawatts2";
  key_t key = ftok( name, 'e');
  int shmid = shmget( key, 0, 0 );
  if ( shmid == -1 ) {
    printf("%d", errno);
    fail( "Can't create shared memory" );
  }
  
  //into adress space
  GameState *structbuffer = (GameState *)shmat( shmid, 0, 0 );
  if ( structbuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
 
  //printf("%s",structbuffer->board);
  

  
  //check params
  bool move = false;
  bool undo = false;
  bool report = false;

  int row;
  int col;
  //check if argument is ./client move r c
  if ( argc == 4) {
    //now check the position
    row = atoi(argv[2]);
    col = atoi(argv[3]);
    if ( row < 0 || row > 4) {
        printf("error\n");
        exit(1);
      }
      //col
      if ( col < 0 || col > 4) {
        printf("error\n");
        exit(1);
      }
    move = true;
  }//END OF 4 ARG  CHECK  
  else if ( argc == 2) { //either undo or report
    //check if move is correct
    if ( strcmp(argv[1], "undo") == 0 ) {
      undo = true;
    }
    else {
      report = true; 
    } 
  } 
  
  
    //    OPTION REPORT   ///
  if ( report ) {
    printf("%s",structbuffer->board);
  }
  
  //    OPTION UNDO   ///
  else if (undo) {
     if ( structbuffer->state == 0 ) { //fail
          printf("error\n");
     } else { //success
       printf("success\n");
       int tick = 0;
       for (int row = 0; row < 5; row++) {
         for (int col = 0; col < 6; col++) {
            structbuffer->board[tick] = structbuffer->prev[tick];
            //putchar(readInput[tick]); //to test in printing
            tick++;
          }
        }
       structbuffer->state = 0;
    }
  } 
  
  //    OPTION MOVE   ///
  else if (move) {
     //back up readInput
    int tick = 0;
    for (int row = 0; row < 5; row++) {
      for (int col = 0; col < 6; col++) {
        structbuffer->prev[tick] = structbuffer->board[tick];
        //putchar(lineRepofGrid[tick]); //to test in printing
        tick++;
      }
    }
    structbuffer->state = 1; //indicates moved
    moveF( row, col, structbuffer->board);
    printf("sucess\n");
  }
  else {
    printf("error\n");
  }
  
  
  //no longer need
  shmdt( structbuffer );
  //shmctl( shmid, IPC_RMID, 0 );
  
  return 0;
}