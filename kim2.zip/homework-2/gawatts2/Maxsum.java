import java.util.Scanner;
import java.util.*;

/** A simple class to demonstrate threads in Java. */
public class Maxsum {

  public static ArrayList<Integer> items;

  private static volatile int workers;


  /** Instead of making a Runnable, you can just subclass
      Thread to tell the thread what to do. */
  static class MyThread extends Thread {

    private int startIndex;

    private int greatest;
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( int startIndex ) {
      this.startIndex = startIndex;
    }

    /** When run, I report in and compute a fibonacci number. */
    public void run() {
      int sum = 0;
      greatest = 0;
      int n = items.size();
      for (int c = startIndex; c < n ; c += workers) {
        sum = 0;
        for ( int i = c; i < n; i++) {
          sum = items.get(i) + sum;
          if (sum > greatest) {
            greatest = sum;
          }
        }
      }

    }


  }


  public static void main( String[] args ) {
    int argcLength = args.length;
    workers = Integer.parseInt( args[0]);

    boolean report = false;
    if ( argcLength == 2 ) {
      report = true;
    }
    items = new ArrayList<>();
    Scanner myObj = new Scanner(System.in);
    while ( myObj.hasNext() ) {
      int num = myObj.nextInt();

      items.add(num);
    }
    myObj.close();

    // Make threads and let them start running.

    MyThread[] thread = new MyThread [ workers ];
    for ( int i = 0; i < thread.length; i++ ) {
      thread[ i ] = new MyThread( i );

      thread[ i ].start();

    }

    // Wait for each of the threads to terminate.
    int largest = 0;
    try {
      for ( int i = 0; i < thread.length; i++ ) {
        thread[ i ].join();
        if (thread[ i ].greatest > largest) {
          largest = thread[ i ].greatest;
        }
        if (report) {
          System.out.println( "Im thread " + thread[ i ].getId() + ". The maximum sum I found is " +
                          + thread[ i ].greatest + ".");
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    System.out.println( "Maximum Sum: " + largest );

  }

}
