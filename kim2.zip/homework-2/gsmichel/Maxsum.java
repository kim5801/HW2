import java.io.*; 
import java.util.*; 
/**
  This program finds the max sum from a list of integers by using threads.
  @author Gabriella Micheli
*/
public class Maxsum {
  
  /** This is the list of integers */
  public static ArrayList<Integer>vList;
  /** This is the number of integers in the list above */
  public static int vCount;
  /** This is a boolean value if the threads should report their findings*/
  public static boolean report;
  
  /** Thread to search through list and find sum */
  static class MyThread extends Thread {
	/** This is the list of indices that the thread searches through */
    private ArrayList<Integer> indices;
    /** This is the maximum sum that the thread finds*/
    private int maxSum;

    
    /** 
    Make a new Thread, giving it a parameter value to store. 
    @param indices the list of indices to look through
    */
    public  MyThread( ArrayList<Integer> indices) {
      this.indices = indices;
      this.maxSum =  Integer.MIN_VALUE;
    }

   /** 
   This runs the threads 
   */
    public void run() {   
      for ( int index = 0; index < indices.size(); index ++ ){
     	int sum = 0;
      	int tempSum = Integer.MIN_VALUE;
      	for (int i = indices.get(index); i < vCount; i++){
         	sum += vList.get(i);
         	if(tempSum < sum){
           		tempSum = sum;
         	}  
      	}
      	if (tempSum > maxSum)
      		maxSum = tempSum;
      }
      if (report)
      	System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + this.maxSum);
    }
    
  }
  /**
  Reads input from user and puts into vList
  */
  public static void readList(){
     Scanner scan = new Scanner(System.in); 
     vCount = 0;
     vList = new ArrayList<Integer>();  
     while ( scan.hasNextInt() ){
       vList.add(vCount, scan.nextInt());
       vCount++;
     }
  }
  /** Print out a usage message and exit. */
static void usage() {
  System.err.println( "usage: Maxsum <number of workers> <optional report> \n" );
  System.exit( 1 );
}

/**
  This is the main function of the program
  @param args the arguments from the command line
*/
  public static void main( String[] args ) {
  
    //read in input from user
    if (args.length < 1 || args.length > 2)
    	usage();
  
    int numThreads = Integer.parseInt(args[0]);
    if ( args.length > 1 && "report".equals(args[1]) )
    	report = true;
    ArrayList<MyThread> threads = new ArrayList<MyThread>(numThreads);
    //make all threads
    readList();
    for ( int i = 0; i < numThreads; i++){
      ArrayList<Integer> indices = new ArrayList<Integer>(vCount % numThreads);
      for (int j = i; j < vCount; j += numThreads){
        indices.add(j);
      }
      MyThread thread = new MyThread( indices );
      threads.add( thread );
    }
    //start all threads
    for ( int i = 0; i < numThreads; i++){
      threads.get(i).start();
    }
    
    try {
        //join all threads
     
      for ( int i = 0; i < numThreads; i++){
      	threads.get(i).join();
      }
      int tempSum = Integer.MIN_VALUE;
      for ( int i = 0; i < numThreads; i++){
        int sum = threads.get(i).maxSum;
      	if(tempSum < sum){
        	tempSum = sum;
        }
      	
      }
      System.out.println("Maximum Sum: " + tempSum);
      
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }

	  
      
  }
}