/**
  This file is takes in arguments and modifies the board accordingly
  It attaches to the memory segment that reset created
  @file lightsout.c
  @author gsmichel
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/* Print out an error message and exit.
  @param message the error message
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
/**
  This is a helper function that prints out the board
  @param board this is the board struct
*/
static void printBoard(struct GameState *board){
  for ( int i = 0; i < GRID_SIZE; i++ ){
    for ( int j = 0; j < GRID_SIZE; j++ ){
      printf("%c",board->board[i][j]);
    }
    printf("\n");
  }
}

/**
  This is a helper function that performs the move on the board. 
  @param board this is the board struct
  @param row this is the row that is being played
  @param column this is the column that is being played
*/
static void makeMove(struct GameState *b, int row, int column)
{

  if (b->board[row][column] == '.')
  	b->board[row][column] = '*';
  else
    b->board[row][column] = '.';
    
  if(row + 1 < GRID_SIZE){
    if (b->board[row+1][column] == '.')
  	  b->board[row+1][column] = '*';
    else
      b->board[row+1][column] = '.';
  }
  if(column + 1 < GRID_SIZE){
    if (b->board[row][column + 1] == '.')
  	  b->board[row][column + 1] = '*';
    else
      b->board[row][column + 1] = '.';
  }
  if(row - 1 > -1){
    if (b->board[row-1][column] == '.')
  	  b->board[row-1][column] = '*';
    else
      b->board[row-1][column] = '.';
  }
  if(column - 1 > -1){
    if (b->board[row][column - 1] == '.')
  	  b->board[row][column - 1] = '*';
    else
      b->board[row][column - 1] = '.';
  }
}
/**
  This is the main function, it attaches to the shared memory segement and parses the command and excutes the commands.
  @param argc number of arguments
  @param argv the actual arguments
  @return the success of the program
*/
int main( int argc, char *argv[] ) {

  //ACCESS MEMORY
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/g/gsmichel", 1), sizeof(GameState), 0);
  if (shmid == -1) 
    fail("Unable to get memory");
  struct GameState *board = (struct GameState *) shmat(shmid, 0, 0);
  if (!board) 
    fail("Unable to attach memory");
  // Read a line of text from the use
  if (strcmp(argv[1], "move") == 0){
    char command[ 5 ];
  	if (sscanf(argv[1], "%s", command) != 1)
      fail("error");
    command[5] = '\0';
    if (argc != 4 ){
      fail("error");
    }
    int row;
    int column;
    if (sscanf(argv[2], "%d", &row) != 1)
      fail("error");
    if (sscanf(argv[3], "%d", &column) != 1)
      fail("error");
    if (row < 0 || row > 4|| column < 0 || column > 4)
        fail("error");
    //Make Move  
    makeMove(board, row, column);
    board->rowMove = row;
    board->columnMove = column;
    printf("success\n");

  	
  } else if (strcmp(argv[1], "undo") == 0){
  	if (argc != 2 ){
      fail("error");
    }
    char command[ 5 ];
  	if (sscanf(argv[1], "%s", command) != 1)
      fail("error");
    command[5] = '\0';
    if(board->rowMove == -1 ||board->columnMove == -1){
      fail("error");
    }
    //do undo
    makeMove(board, board->rowMove, board->columnMove);
    printf("success\n");
    board->rowMove = -1;
    board->columnMove = -1;
  	
  } else if (strcmp(argv[1], "report") == 0){
    if (argc != 2){
      fail("error");
    }
    char command[ 7];
  	if (sscanf(argv[1], "%s", command) != 1)
      fail("error");
    command[7] = '\0';
    
    
  	//print board
    printBoard(board);
  	
  	
  } else {
    
  	fail("error");
  }
  //UNATTACH MEMORY
  shmdt( board );
  return 0;
}
