#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
/**
  This file is incharge of creating the shared memory segment and creating the board in the segment
  @file reset.c
  @author gsmichel
*/


/* Print out an error message and exit.
  @param message the error message
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Print out a usage message and exit. */
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
  This is a helper function that populates the board from the file inputted
  @param fp this is the file pointer
  @param b this is the board that is populated
*/
static int populateBoard(FILE *fp, struct GameState *b )
{
  
  for ( int i = 0; i < GRID_SIZE; i++ ){
    for ( int j = 0; j < GRID_SIZE; j++ ){
      char val;
      fscanf(fp, "%c", &val);
      if (val == '*' || val == '.')
      	b->board[i][j] = val;
      else if (val != ' ' || val != '\n')
        return(-1);
      
    }
    fgetc(fp);
  }
  return 0;
  
}
/**
  This is the main function, it creates the shared memory segement, attaches it, and populates the board
  @param argc number of arguments
  @param argv the actual arguments
  @return the success of the program
*/
int main( int argc, char *argv[] ) {
  if ( argc != 2 )
  	usage();
  FILE *fp = fopen(argv[1], "r");
  if (!fp ){
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( 1 );
  }
  //CREATE MEMORY 
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/g/gsmichel", 1), sizeof( struct GameState), 0666 | IPC_CREAT);
  if (shmid == -1) 
    fail("Unable to create memory");
  struct GameState *board = (struct GameState *) shmat(shmid, 0, 0);
  if (!board) 
    fail("Unable to attach memory");
  //populate board
  int check = populateBoard(fp, board);
  if (check == -1)
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
  fclose(fp);
  shmdt( board );
  exit( EXIT_SUCCESS );
}
