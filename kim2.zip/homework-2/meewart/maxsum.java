import java.util.Arrays;
import java.util.Scanner;

public class maxsum {

    // Input sequence of values.
    private static int vList[];

    // Number of values on the list.
    private static int vCount = 0;

    // Capacity of the list of values.
    private static int vCap = 0;

    // Largest sum found
    private static int globalMaxSum;

    // Number of workers
    private static int workers = 0;

    // True if report option is true;
    private static boolean report = false;

    private static class WorkerThread extends Thread {
        // The array index where the thread will start working
        private int startingIndex;

        // The return value of the thread
        public int localMaxSum;

        /**
         * Constructor for thread
         * @param index index where the thread starts counting
         */
        public WorkerThread(int index) {
            this.startingIndex = index;
        }

        /**
         * Code for the thread to run
         * Calculates the max sum for the list indexes handled by the thread
         */
        public void run() {
            int listIndex = startingIndex;
            // Set localMaxSum to the first value the thread is looking at
            localMaxSum = vList[listIndex];
            
            // While listIndex is within the bounds
            // Outer loop: calculates starting index of inner loop
            while (listIndex < vCount) {
                int sum = 0;
                // Inner loop: loops from listIndex to the end of the list
                // Keeps track of loop sum
                // If loop sum is greater than the local max, updates localMaxSum
                for (int i = listIndex; i < vCount; i++) {
                    sum += vList[i];

                    if (sum > localMaxSum) {
                        localMaxSum = sum;
                    }
                }
                // Increment the listIndex by the number of workers
                listIndex += workers;
            }

            if (report) {
                System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", getId(), localMaxSum);
            }

            if (localMaxSum > globalMaxSum) {
                globalMaxSum = localMaxSum;
            }
        }
    }

    // Read the list of values.
    private static void readList() {
        // Set up initial list and capacity.
        vCap = 5;
        vList = new int[vCap];

        Scanner scnr = new Scanner(System.in);

        // Keep reading as many values as we can.
        int v = 0;
        while (scnr.hasNextInt()) {
            // Save value in the array
            v = scnr.nextInt();

            // Grow the array if needed.
            if ( vCount >= vCap ) {
                vCap *= 2;
                vList = Arrays.copyOf(vList, vCap);
            }

            // Store the latest value in the next array slot.
            vList[ vCount++ ] = v;
        }

        scnr.close();
    }

    private static void usage() {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit(1);
    }

    public static void main(String[] args) {
        // Parse command-line arguments
        // Check args length
        if (args.length < 1 || args.length > 2) {
            usage();
        }

        // Check if workers can be parsed correctly
        try {
            workers = Integer.parseInt(args[0]);
        }
        catch (NumberFormatException e) {
            usage();
        }

        // Check for the report argument
        if (args.length == 2) {
            if (!args[1].equals("report")) {
                usage();
            }
            else {
                report = true;
            }
        }

        // Read in the list of values
        readList();

        // Make thread array
        WorkerThread[] threads = new WorkerThread[workers];

        // For each worker thread
        for (int i = 0; i < workers; i++) {
            // Each thread should start counting at its index
            threads[i] = new WorkerThread(i);
            threads[i].start();
        }

        try {
            for (int i = 0; i < workers; i++) {
                threads[i].join();
            }
        } catch (InterruptedException e) {
            System.out.println("Could not join thread");
        }

        System.out.printf("Maximum Sum: %d\n", globalMaxSum);
    }
}
