#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Compile with
// gcc -Wall -g -std=c99 -D_XOPEN_SOURCE=500 -o lightsout lightsout.c

// Toggles a given row or col of the game board
// Handles error checking if row or col is invalid
// 0 1 2 3 4 5
// 6 7 8 9 10 11
// 12 13 14 15 16 17
// 18 19 20 21 22 23
// 24 25 26 27 28 29
static void toggle(GameState *board, int row, int col) {
  if (row >= 0 && row < 5 && col >= 0 && col < 5) {
    int rowStartingIndex = 6 * row;
    int stateIndex = rowStartingIndex + col;

    if (board->state[stateIndex] == '*') {
      board->state[stateIndex] = '.';
    }
    else {
      board->state[stateIndex] = '*';
    }
  }
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Create shared memory
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/m/meewart", 100), sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }
    
  // Map the shared memory into address space
  GameState *gameBoard = (GameState *) shmat( shmid, 0, 0 );

  // Move command
    if (argc == 4 && strcmp(argv[1], "move") == 0
      && strlen(argv[2]) == 1 && argv[2][0] >= '0' && argv[2][0] <= '4'
      && strlen(argv[3]) == 1 && argv[3][0] >= '0' && argv[3][0] <= '4') {

      // Set to 5 to make sure that they are reset correctly by sscanf
      int row = 5;
      int col = 5;

      // Read in rows and cols
      sscanf(argv[2], "%d", &row);
      sscanf(argv[3], "%d", &col);

      // If rows and cols are valid
      if (row >= 0 && row < 5 && col >= 0 && col < 5) {
        // Save move
        gameBoard->prevRow = row;
        gameBoard->prevCol = col;

        // If row or col is out of bounds due to math, toggle doesn't do anything
        toggle(gameBoard, row, col);
        toggle(gameBoard, row - 1, col);
        toggle(gameBoard, row + 1, col);
        toggle(gameBoard, row, col - 1);
        toggle(gameBoard, row, col + 1);

        // Since a move has been made, set undo value to true
        gameBoard->undoAllowed = 1;
        printf("success\n");
      }
      else {
        printf("error\n");
      }
    }
    // Undo command
    else if (argc == 2 && strcmp(argv[1], "undo") == 0 ) {
      if (gameBoard->undoAllowed) {
        int row = gameBoard->prevRow;
        int col = gameBoard->prevCol;

        toggle(gameBoard, row, col);
        toggle(gameBoard, row - 1, col);
        toggle(gameBoard, row + 1, col);
        toggle(gameBoard, row, col - 1);
        toggle(gameBoard, row, col + 1);
        gameBoard->undoAllowed = 0;

        printf("success\n");
      }
      else {
        printf("error\n");
      }
    }
    // Report command
    else if (argc == 2 && strcmp(argv[1], "report") == 0) {
      printf("%s", gameBoard->state);
    }
    // Unrecognized command
    else {
        printf("error\n");
    }

  return 0;
}
