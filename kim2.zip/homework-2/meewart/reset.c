#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Compile with
// gcc -Wall -g -std=c99 -D_XOPEN_SOURCE=500 -o reset reset.c

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Creates shared memory and fills game board based on input file
int main( int argc, char *argv[] ) {
  // Check args
  if (argc != 2) {
    fail("usage: server <board-file>");
  }

  // Open input file
  FILE *inputFile = fopen(argv[1], "r");
  if (inputFile == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit( 1 );
  }

  // Create shared memory
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/m/meewart", 100), sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }
    
  // Map the shared memory into address space
  GameState *gameBoard = (GameState *) shmat( shmid, 0, 0 );

  // Populate struct with file contents
  char charRead = fgetc(inputFile);
  int boardStrIndex = 0;
  while (charRead != EOF) {
    if (charRead != '*' && charRead != '.' && charRead != '\n') {
      fprintf(stderr, "Invalid input file: %s\n", argv[1]);
      exit( 1 );
    }
    else {
      gameBoard->state[boardStrIndex] = charRead;
    }
    boardStrIndex++;
    charRead = fgetc(inputFile);
  }
  // Add null terminator
  gameBoard->state[30] = '\0';

  // Release reference to the shared memory segment.
  //shmdt( gameBoard );

  // Tell the OS we no longer need the segment.
  //shmctl( shmid, IPC_RMID, 0 );


  return 0;
}
