// Height and width of the playing area.
#define GRID_SIZE 5

typedef struct GameStateStruct GameState;

struct GameStateStruct {
  // String containing board state
  char state[31];
  // Previous move row and columns
  int prevRow;
  int prevCol;
  // True if an undo operation has not been done for the given move
  // False otherwise
  bool undoAllowed;
};
