/**
 * @file reset.c
 * @author Alex Sawdy (adsawdy)
 * Reads a file and initiates shared memory to its lightsout board representation
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * Main method
 * @param number of arguments
 * @param string list of arguments
 * @return exit status
 */
int main( int argc, char *argv[] ) {
  // check number of arguments
  if (argc != 2) {
    usage();
  }
  
  // open file
  FILE *board = fopen( argv[1], "r" );
  if (board == NULL) {
    fprintf(stderr, "invalid input file: %s\n", argv[1]);
    exit(1);
  }
  
  // read + check file
  int buffer[GRID_SIZE][GRID_SIZE];
  // grab a character GRID_SIZE * GRID_SIZE times and check it > (should be 5x '*' OR '.' then a newline) * 5 times
  for (int i = 0; i < GRID_SIZE; i++) {
    int ch = fgetc(board);
    for (int j = 0; j < GRID_SIZE; j++) {
      if (ch == '*' || ch == '.') {
        buffer[i][j] = ch;
      } else {
        fprintf(stderr, "invalid input file: %s (some character was not a '*' or '.')\n", argv[1]);
        exit(1);
      }
      ch = fgetc(board);
    }
    if (ch != '\n') {
      fprintf(stderr, "invalid input file: %s (expected newline)\n", argv[1]);
      exit(1);
    }
  }
  
  // set the shared memory key
  int memKey = ftok("/afs/unity.ncsu.edu/users/a/adsawdy/", 1);
  
  // shared memory
  // name of shared mem: ftok(AFS home directory path name)
  // running reset *should* overwrite old shared memory with a new one
  
  // create shared memory and set id
  int shmid = shmget(memKey, sizeof(GameState), 0666 | IPC_CREAT);
  if (shmid < 0) {
    fail("failed to initialize shared memory with shmget()");
  }
  
  // create pointer to an Instance of GameState to more easily manipulate shared memory
  GameState *game = (GameState *)shmat(shmid, 0, 0);
  if ( *((int *)game) == -1) {
    fail("failed to operate on shared memory with shmat()");
  }
  
  // make the empty GameState reflect the the lightsout board provided
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      game->gameBoard[i][j] = buffer[i][j];
    }
  }
  game->canUndo = false;
  
  // IF NEEDED: resetting shared memory
  // ipcs shell command lists all shared mem ids, delete with ipcrm -m id
  
  // disconnect
  shmdt(game);

  return 0;
}