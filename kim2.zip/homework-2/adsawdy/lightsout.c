/**
 * @file lightsout.c
 * @author Alex Sawdy (adsawdy)
 * manipulates shared memory to play a game of "lights out"
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * returns the opposite light
 * @param light current light condition
 * @return new light condition
 */
char toggle(char light) {
  if (light == '*') {
    return '.';
  } else {
    return '*';
  }
}

/**
 * Main method
 * @param number of arguments
 * @param string list of arguments
 * @return exit status
 */
int main( int argc, char *argv[] ) {
  char todo = NULL;
  int r = -1;
  int c = -1;
  if (argc == 4 && (sscanf( argv[ 2 ], "%d", &r ) == 1) && r >= 0 && r < GRID_SIZE &&
      (sscanf( argv[ 3 ], "%d", &c ) == 1) && c >= 0 && c < GRID_SIZE && (strcmp(argv[1], "move") == 0)) {
    //move
    todo = 'm';
  } else if (argc == 2 && (strcmp(argv[1], "undo") == 0)) {
    // undo
    todo = 'u';
  } else if (argc == 2 && (strcmp(argv[1], "report") == 0)) {
    // report
    todo = 'r';
  } else {
    // no need to connect/disconnect from shared memory
    fail("error");
  }
  
  
  // set the shared memory key
  int memKey = ftok("/afs/unity.ncsu.edu/users/a/adsawdy/", 1);
  
  // get handle to shared memory
  int shmid = shmget(memKey, sizeof(GameState), 0);
  if (shmid < 0) {
    fail("failed to attach to shared memory with shmget()");
  }
  
  // create pointer to an Instance of GameState to more easily manipulate shared memory
  GameState *game = (GameState *)shmat(shmid, 0, 0);
  if ( *((int *)game) == -1) {
    fail("failed to operate on shared memory with shmat()");
  }

  switch (todo) {
    case 'u':
      if (game->canUndo == false) {
        printf("error\n");
        // exit switch case
        break;
      } else {
        // do undo
        // no break, set r and c to previous r and c and "move" there again to undo
        r = game->lastRow;
        c = game->lastCol;
        // can't undo twice in a row
        game->canUndo = false;
      }
    case 'm':
      // "move" at row r, column c -> toggle light at that row and surrounding rows (if within board)
      
      //         (r-1)(c)
      //(r)(c-1)  (r)(c)  (r)(c+1)
      //         (r+1)(c)

      // toggle the middle
      game->gameBoard[r][c] = toggle(game->gameBoard[r][c]);
      
      // check, if valid toggle sides
      // row change:
      if ( (r - 1) >= 0 && (r - 1) < GRID_SIZE )
        game->gameBoard[r - 1][c] = toggle(game->gameBoard[r - 1][c]);
      if ( (r + 1) >= 0 && (r + 1) < GRID_SIZE )
        game->gameBoard[r + 1][c] = toggle(game->gameBoard[r + 1][c]);
      
      // col change:
      if ( (c - 1) >= 0 && (c - 1) < GRID_SIZE )
        game->gameBoard[r][c - 1] = toggle(game->gameBoard[r][c - 1]);
      if ( (c + 1) >= 0 && (c + 1) < GRID_SIZE )
        game->gameBoard[r][c + 1] = toggle(game->gameBoard[r][c + 1]);
      
      // can undo if got here from a move
      if (todo == 'm') {
        game->canUndo = true;
        game->lastRow = r;
        game->lastCol = c;
      }
      printf("success\n");
      break;
    case 'r':
      // report the current state of the game board
      for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
          printf("%c", game->gameBoard[i][j]);
        }
        printf("\n");
      }
      break;
  }
  
  // disconnect
  shmdt(game);

  return 0;
}
