import java.util.Arrays;
import java.util.Scanner;

/**
 * uses threads to calculate maximum sum in a file
 */
public class Maxsum {
  /** list of integers from input file */
	private static int[] list;
	/** length of integer list */
	private static int listLen;
	/** number of threads to create */
	private static int numThreads;
	/** whether threads should report their relative max sum */
	private static Boolean report;
	
	/**
	 * subclass of thread with custom fields for sums
	 */
	static class MyThread extends Thread {
		/** worker number */
		private int num;

		/** maximum sum found by thread */
		public int value;
		
		/** Make a new Thread, giving it a parameter value to store. */
		public MyThread( int x ) {
			this.num = x;
		}
   
    /**
     * method for threads to run
     */
	  public void run() {
		  int max = 0;
      // O(n) for every [numThreads] in list, check all sums of indices from i + c[numThreads] to listLen, where c is some #
      for (int z = this.num; z < listLen; z += numThreads) {
        // check i + c[workers] (=z)
        // check max for z, z + 1, ... , z +...+ (listLen - 2), z +...+ (listLen - 1)
        int temp = 0;
        for (int j = z; j < listLen; j++) {
          temp = temp + list[j];
          if (temp > max) {
            max = temp;
          }
        }
      }
      this.value = max;
      
      // if report is true, print a short report on what each child did
      if (report) {
        System.out.println("I'm thread " + this.getId() + ". The maximum sum I found is " + value);
      }
    }
	}

  /**
   * main method
   */
	public static void main( String[] args ) {
		// boolean on whether threads report their largest sum
		report = false;
		// main arguments
		if (args.length > 2) {
			throw new IllegalArgumentException("too many args");
		} else if (args.length == 2 ) {
			if (args[1].equals("report")) {
				report = true;
			} else {
				throw new IllegalArgumentException("arg 2 is not report");
			}
		} else if (args.length < 1) {
			throw new IllegalArgumentException("too few args");
		}
		numThreads = Integer.parseInt(args[0]);
		
		// store file output in array...
		list = new int[1];
		Scanner scan = new Scanner(System.in);
		scan.useDelimiter("\n");
		listLen = 0;
		while (scan.hasNextInt()) {
			if (listLen >= list.length) {
				list = Arrays.copyOf(list, list.length * 2 + 1);
			}
			list[listLen] = scan.nextInt();
			listLen++;
		}
		scan.close();
		
		// tests list
    /**
		for (int i = 0; i < listLen; i++) {
			System.out.println(i + ": " + list[i] + "\n");
		}
    System.out.println("length: " + listLen + "\n");
    */
		
		// make list of threads (to help join with them later)
		MyThread[] threads = new MyThread[numThreads];
		for (int i = 0; i < numThreads; i++) {
			MyThread thread = new MyThread(i);
			threads[i] = thread;
			thread.start();
		}
		
		// join with threads, get their sums
		int totalMax = 0;
		for (int i = 0; i < numThreads; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				System.out.println("failed to join with #" + i + " thread");
			}
			if (threads[i].value > totalMax) {
				totalMax = threads[i].value;
			}
		}
   
    System.out.println("Maximum sum: " + totalMax);
		
		return;
	}
}