/**
 * @file reset.c
 * @author Grant Arne gtarne
 * A program which sets up the game board for lights out to 
 * match the given file
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
 * Creates shared memory and sets it to contain a new game board 
 * for lights out
 * 
 * @param argc the number of arguments
 * @param argv the arguments
 * @return int 
 */
int main( int argc, char *argv[] ) {

  int mem_key = ftok( HOME_DIRECTORY, 1 );

  // Check argument number
  if ( argc != 2 ) {
    usage();
  }

  // Create shared memory
  int shmid = shmget( mem_key, sizeof( GameStatus ), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Open file and check it exists
  FILE *boardFile = fopen( argv[ 1 ], "r" );
  if ( boardFile == NULL ) {
    char *message = "Invalid input file";
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( EXIT_FAILURE );
    fail( message );
  }

  // Attach shared board memory
  GameStatus *game = ( GameStatus * ) shmat( shmid, 0, 0 );
  game->canUndo = false;
  char cur;
  // Loop through each row and column of input file
  for ( int r = 0; r < GRID_SIZE; r++ ) {
    for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
      // Get next character
      cur = fgetc( boardFile );
      if ( ( c < GRID_SIZE ) && ( cur == '*' || cur == '.' ) ) { // If character is in grid and valid light
        // Add to board
        game->board[ r ][ c ] = cur;
      } else if ( !( c == GRID_SIZE && cur == '\n' ) ) { // If character is not a newline on the last column
        // Invalid file
        printf( "Invalid input file: %s\n", argv[ 1 ] );
        shmdt( game );
        fclose( boardFile );
        exit( EXIT_FAILURE );
      }
    }
  }
  // Close file
  fclose( boardFile );
  shmdt( game );
  return 0;
}
