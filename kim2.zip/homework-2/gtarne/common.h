/**
 * @file common.h
 * @author Grant Arne gtarne
 * Contains the lightout game struct, the grid size, and the home directory for generating shared memory key
 * 
 */

// Height and width of the playing area.
#define GRID_SIZE 5

#define HOME_DIRECTORY "/afs/unity.ncsu.edu/users/g/gtarne"

/**
 * Represents the status of the game.
 * Holds the board, the last move, and whether there is a last move that can be undone
 * 
 */
typedef struct {
  char board[ GRID_SIZE ][ GRID_SIZE ];
  int lastMove[ 2 ];
  bool canUndo;
} GameStatus;
