/**
 * @file lightsout.c
 * @author Grant Arne gtarne
 * A program which can execute a single command to play lights out
 * 
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** The maximum number of arguments to be valid */
#define MAX_ARGS 4
/** The minimum number of valid args */
#define MIN_ARGS 2

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}


/**
 * Completes one move on the given game at the given row and column, toggling 
 * surrounding lights if they are in the board
 * 
 * @param r the row to move at
 * @param c the column to move at
 * @param game the game to move in
 */
void move( int r, int c, GameStatus *game ) {
  // Center piece
  if ( game->board[ r ][ c ] == '.' ) {
    game->board[ r ][ c ] = '*';
  } else {
    game->board[ r ][ c ] = '.';
  }
  // Above
  if ( r - 1 >= 0 ) {
    if( game->board[ r - 1][ c ] == '.' ) {
      game->board[ r - 1 ][ c ] = '*';
    } else {
      game->board[ r - 1 ][ c ] = '.';
    }
  }
  // Below
  if ( r + 1 < GRID_SIZE ) {
    if( game->board[ r + 1][ c ] == '.' ) {
      game->board[ r + 1 ][ c ] = '*';
    } else {
      game->board[ r + 1 ][ c ] = '.';
    }
  }
  // Left
  if ( c - 1 >= 0 ) {
    if( game->board[ r ][ c - 1 ] == '.' ) {
      game->board[ r ][ c - 1] = '*';
    } else {
      game->board[ r ][ c - 1] = '.';
    }
  }
  // Right
  if ( c + 1 < GRID_SIZE ) {
    if( game->board[ r ][ c + 1 ] == '.' ) {
      game->board[ r ][ c + 1] = '*';
    } else {
      game->board[ r ][ c + 1] = '.';
    }
  }
}

/**
 * Undoes the last move and returns true, or false if it could not be undone
 * 
 * @param game the game to undo the last move in
 * @return true if the move was undone, false otherwise
 */
bool undoMove( GameStatus *game ) {
  if ( game->canUndo ) {
    move( game->lastMove[ 0 ], game->lastMove[ 1 ], game );
    game->canUndo = false;
    return true;
  } else {
    return false;
  }
}

/**
 * Executes a single instruction for playing lights out.
 * Can either move at a given row and column, undo the last move,
 * or print the status of the board.
 * 
 * @param argc the number of arguments
 * @param argv the arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
  int mem_key = ftok( HOME_DIRECTORY, 1 );

  // Check valid number of args
  if ( argc > MAX_ARGS || argc < MIN_ARGS ) {
    fail( "error" );
  }

  // Get shared memory
  int shmid = shmget( mem_key, 0, 0 );
  if ( shmid == -1 ) {
    fail( "Can't create gameboard" );
  }
  GameStatus *game = shmat( shmid, 0, 0 );


  // Check first arg
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // Check for too few args
    if ( argc != MAX_ARGS ) {
      shmdt( game );
      fail( "error");
    }
    // Check that row and column entries are a single character
    if ( strlen( argv[ 2 ] ) != 1  || strlen( argv[ 3 ] ) != 1 ) {

      shmdt( game );
      fail( "error");
      // Check if row and column are invalid characters
    } else if ( ( argv[ 2 ][ 0 ] < '0' || argv[ 2 ][ 0 ] > '4' ) || ( argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) ) {

      shmdt( game );
      fail( "error" );
    } else {
      // Set row and column chars
      int row = argv[ 2 ][ 0 ] - '0';
      int col = argv[ 3 ][ 0 ] - '0';

      // Execute move-----------------------------
      move( row, col, game );
      game->canUndo = true;
      game->lastMove[ 0 ] = row;
      game->lastMove[ 1 ] = col;

      // Indicate success and exit
      printf( "success\n" );
      shmdt( game );
      exit( EXIT_SUCCESS );
    }

  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    // Check for too many args
    if ( argc > MIN_ARGS ) {
      shmdt( game );
      fail( "error" );
    } else {
      // Execute undo-----------------------------
      if ( undoMove( game ) ) {
        printf( "success\n" );
      } else {
        fail( "error" );
      }

    }

  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // Check for too many args
    if ( argc > MIN_ARGS ) {
      shmdt( game );
      fail( "error" );
    } else {
      // Print out board report--------------------------
      char board[ GRID_SIZE * ( GRID_SIZE + 1 ) + 1];
      int index = 0;
      // Go through rows and columns, adding each character
      for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
          if ( c == GRID_SIZE ) {
            board[ index ] = '\n';
          } else {
            board[ index ] = game->board[ r ][ c ];
          }
          index++;
        }
      }
      board[ GRID_SIZE * ( GRID_SIZE + 1 ) ] = '\0';
      printf( board );

      exit( EXIT_SUCCESS );
    }
    
  } else {
    // Invalid input
    shmdt( game );
    fail( "error");
  }

  shmdt( game );
  return 0;
}
