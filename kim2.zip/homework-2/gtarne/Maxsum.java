/**
 * @file maxsum.java
 * @author Grant Arne gtarne
 * Takes an input and finds the subsequence of numbers with the largest sum using the given number of threads
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Finds the maxsum of any number of continguous integers from an input 
 * list using the given number of thread divide the work
 */
public class Maxsum {

    /** The list of values to check */
    static ArrayList<Integer> values;
    /** The number of values in the list */
    static int vCount;
    /** The number of workers to use */
    static int workers;
    /** Whether to report the findings of each worker */
    static Boolean report;

    /**
     * Reads a list of integers from standard input and finds the highest sum of contiguous numbers
     * using the given number of threads and outputs it
     * @param args the arguments for running
     */
    public static void main(String[] args) {
        // Initialize values
        values = new ArrayList<Integer>();
        int max = Integer.MIN_VALUE;
        report = false;
        workers = 4;
        readList();
        vCount = values.size();

        // Check num args
        if ( args.length < 1 || args.length > 2 ) {
            usage();
        }

        // Get number of workers
        if ( Integer.parseInt( args[ 0 ] ) < 1 ) {
            usage();
        } else {
            workers = Integer.parseInt( args[ 0 ] );
        }

        // Check if report
        if ( args.length == 2 && args[ 1 ].equals( "report" ) ) {
            report = true;
        }

        // Make list of threads
        List<Worker> threads = new ArrayList<Worker>();
        // Create threads and run them
        for ( int i = 0; i < workers; i++ ) {
            Worker cur = new Worker( i );
            threads.add( cur );
            cur.start();
        }
        // Join with threads and get results
        try {
            for ( int i = 0; i < workers; i++ ) {
                Worker current = threads.get( i );
                current.join();
                // Check if thread's max is the new max
                if ( current.maxFound > max ) {
                 max = current.maxFound;
                }
            
            }
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
        // Print out the final max sum
        System.out.println( "Maximum Sum: " + max );

    }

    /**
     * Prints a usage message and exits the program
     */
    public static void usage() {
        System.out.println( "usage: maxsum <workers>\n" );
        System.out.println( "       maxsum <workers> report\n" );
        System.exit( 1 );
    }

    /**
     * Reads integers from standard input and adds them to a list of values until 
     * it hits the end of the file
     */
    static void readList() {
        Scanner scan = new Scanner(System.in);
        int val;

        while ( scan.hasNextInt() ) {
            val = scan.nextInt();
            values.add( val );
        }
        scan.close();
    }

    /**
     * A thread that represents a worker which searches through a portion of a
     * list of values and finds a max sum of numbers
     */
    public static class Worker extends Thread {
        /** The max sum found */
        public int maxFound;

        /** The id of the worker */
        public int workerId;

        /**
         * Creates a new worker with the given workerId
         * @param workerId the worker's id
         */
        public Worker( int workerId ) {
            super();
            this.workerId = workerId;
            this.maxFound = Integer.MIN_VALUE;
        }

        /**
         * Searches through a portion of the list of values and finds a max sum
         */
        @Override
        public void run() {
            int sum;
            // Start at their workID, check starting locations evenly spread apart
            for ( int i = workerId; i < vCount; i+= workers ) {
                sum = 0;
                // Iterate through list starting at i
                for ( int j = i; j < vCount; j++ ) {
                    // Add value to sum
                    sum += values.get( j );
                    // Check if the sum is larger
                    if ( sum > maxFound ) {
                        maxFound = sum;
                    }
                }
            }
            // Give report if needed
            if ( report ) {
                System.out.println( "I'm thread " + getId() + ". The maximum sum I found is " + maxFound + "." );
            }
        }
    }
}
