#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Expected number of args
#define EXPECTED_ARGS 2

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  if(argc != EXPECTED_ARGS) {
    usage();
  }

  // Sourced from my hw1 with some modifications
  // Open file, check if file can be opened
  FILE *file = fopen(argv[1], "r");
  if(file == NULL) {
    fprintf(stderr, "Invalid input file: %s", argv[1]);
    exit(EXIT_FAILURE);
  }

  // Create shared memory 
  key_t key = ftok(HOME_DIR, PROJ_ID);
  int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
  if(shmid == -1) {
    fail("Problem creating shared memory");
  }
  GameState *game = (GameState *)shmat(shmid, 0, 0);

  // Sourced from my hw1 with some modifications
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j <= GRID_SIZE; j++) {
      char ch = (char) fgetc(file);
      if(j < GRID_SIZE && ch != '.' && ch != '*') {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        fclose(file);
        exit( EXIT_FAILURE );
      }
      if(j == GRID_SIZE && ch != '\n') {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        fclose(file);
        exit( EXIT_FAILURE );
      }
      if(j < GRID_SIZE) {
        game->currentBoard[i][j] = ch;
      }
    }
  }

  // Makes it a little easier to report
  for(int i = 0; i < GRID_SIZE; i++) {
    game->currentBoard[i][GRID_SIZE] = '\0';
  }

  // undo starts as false
  game->canUndo = false;

  fclose(file);
  return 0;
}
