import java.util.ArrayList;
import java.util.Scanner;

/**
 * Calculates the maximum sum from an array. Maximum sum is defined as
 * a group of consecutive numbers which adds up to the largest amount
 * compared to all other groups of consecutive numbers in the array
 *
 * @author Zachary Mallol
 */
public class Maxsum {
	/** If each thread should report its local max */
	public static boolean report = false;
	
	/** list of numbers */
	public static ArrayList<Integer> list;
	
	/** How many threads will work on the problem */
	public static int workers;
	/**
	 * Thread to calculate the maximum sum from a range of numbers
	 * @author Zachary Mallol
	 */
	private static class LocalMaxCalculator extends Thread {
		
		/** Which number the thread is - determines which part of the problem the
		 * thread works on
		 */
		public int threadNum;
		
		/** Return value, local max that thread calculates */
		public int localMax;
		
		/**
		 * Constructs the new thread
		 * @param threadNum Which thread this is
		 */
		public LocalMaxCalculator(int threadNum) {
			this.threadNum = threadNum;
			// It doesn't get smaller than this
			localMax = Integer.MIN_VALUE;
		}
		
        @Override
        public void run() {
            for(int i = threadNum; i < list.size(); i += workers) {
            	int currentSum = 0;
            	for(int j = i; j < list.size(); j++) {
            		currentSum += list.get(j);
            		if(currentSum > localMax) {
            			localMax = currentSum;
            		}
            	}
            }
            
            if(report) {
            	System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", this.getId(), localMax);
            }
        }
    }
	
	/**
	 * Populates the list field with the numbers from stdin
	 */
	public static void getNumbers() {
		Scanner scnr = new Scanner(System.in);
		while(scnr.hasNextInt()) {
			list.add(scnr.nextInt());
		}
		scnr.close();
	}
	
	/**
	 * Main method
	 * @param args First arg is number of workers, second arg is if the program should report
	 */
	public static void main(String[] args) {
		// Initializes list and workers to correct values
		workers = Integer.parseInt(args[0]);
		list = new ArrayList<Integer>();
		
		// Populates the array list with integers from stdin
		getNumbers();
		
		// Sets report to appropriate value
		if(args.length > 1 && args[1].equals("report")) {
			report = true;
		}
		
		// Below code is loosely based on ThreadArguments.java example file
		LocalMaxCalculator[] threads = new LocalMaxCalculator[workers];
		for(int i = 0; i < threads.length; i++) {
			threads[i] = new LocalMaxCalculator(i);
			threads[i].start();
		}
		
		int max = Integer.MIN_VALUE;
		try {
			for(int i = 0; i < threads.length; i++) {
				threads[i].join();
				if(max < threads[i].localMax) {
					max = threads[i].localMax;
				}
			}
		}
		catch(InterruptedException e) {
			System.out.println("Interrupted during join");
		}
		
		System.out.printf("Maximum Sum: %d\n", max);
	}

}
