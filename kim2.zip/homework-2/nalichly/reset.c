/**
 * Component of the lightsout game responsible for loading/ 
 * resetting game board and storing it in a shared memory
 * segment. Will create the segment if it doesn't already exist.
 * 
 * @file reset.c
 * @author Noah Lichlyter nalichly
 * @date 09-30-22
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/**
 * Print out an error message and exit.
 * @param message the message to be printed
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
} 

/**
 * Print out a usage message and exit.
 */
static void usage() {
  fprintf(stderr, "usage: reset <board-file>\n");
  exit(1);
}

/**
 * Print out an error message and exit.
 * @param message the message to be printed
 */
static void badFile(char const *filename) {
  fprintf( stderr, "Invalid input file: %s\n", filename);
  exit(1);
} 

/**
 * Makes a board from the given file pointer
 * @param fp file pointer to the file containing the board
 * @return char** -- the board created from the file
 */
int makeBoard(FILE *fp, GameState *gs) {

    if (gs == NULL || fp == NULL)
        return 1;

    //make vars for parsing
    char ch;
    int r = 0;
    int c = 0;

    //import board
    while ((ch = fgetc(fp)) != EOF) {
        if ((r >= GRID_SIZE || c >= GRID_SIZE) && ch != '\n') {
            return 1;
        } else if (ch == '\n') {
            r++;
            c = 0;
        } else if (ch == '.' || ch == '*') {
            gs->board[r][c] = ch;
            c++;
        } else { //not one of the approved chars
            return 1;
        }
    }
    return 0; //exit success
}

/**
 * Prints the current state of the game board to the terminal
 * @param board the board to be printed
 */
int printBoard(GameState *gs) {
    if (gs == NULL || gs->board == NULL)
        return 1;

    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            printf("%c", gs->board[i][j]);
        }
        printf("\n");
    }
    return 0;
}

/**
 * Resets the lightsout GameState stored in shared memory. If a gameboard is not
 * currently in memory, it will make a new shared memory segment to hold the 
 * 
 * @param argc number of command-line args recieved
 * @param argv list of Strings containing command-line args given
 * @return 0 if exits successfully
 */
int main( int argc, char *argv[] ) {
    if (argc != 2)
        usage();
  
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        badFile(argv[1]);
    }

    // Make / obtain memaddr of the GameState
    //update shmget with id from ftok() (AFS ONLY)
    key_t key = ftok("/afs/unity.ncsu.edu/users/n/nalichly", 42);

    int shmid = shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
    if (shmid == -1)
        fail( "Can't create shared memory" );

    //Try to attach to shared memory
    GameState *gs = (GameState *)shmat(shmid, 0, 0);
    if (gs == (GameState *)-1) //unsuccessful
        fail( "Can't attach GameState" );

    //read in the gameboard
    int status = makeBoard(fp, gs);
    if (status != 0) {
        badFile(argv[1]);
    }

    //make var to hold last game state w/ extra char for null terminator
    for (int i = 0; i < 3; i++) {
        gs->last[i] = '\0';
    }

    // Release our reference to the shared memory segment.
    shmdt(gs);

    fclose(fp);
    return EXIT_SUCCESS;
}
