import java.util.Scanner;
import java.util.ArrayList;

/**
 * Finds the largest contiguous sum in a given list of ints using a 
 * user-defined number of ints. List of ints is taken in from stdin.
 * Program can also report the thread ids and max sum found by each thread.
 * 
 * @author Noah Lichlyter nalichly
 */
public class Maxsum {

    /** Minimum number of args allowed */
    private static int MIN_ARGS = 1;
    /** Maximum number of args allowed */
    private static int MAX_ARGS = 2;
    /** Index of the worker arg */
    private static int WORKER_ARG = 0;
    /** String printed when invalid args are given */
    private static String USAGE = "\nusage: maxsum <workers>\n" +
                                  "       maxsum <workers> report\n";

    /** Global array list used to hold the list of ints */
    private static ArrayList<Integer> vList;

    /**
     * Subclass of Thread for parsing the global vList 
     * alongside a given number of other threads. 
     */
    private static class WorkerThread extends Thread {

        /** max value that was found by this worker */
        public int max;
        /** first idx to process */
        private int start;
        /** number of workers to  */
        private int workers;

        /**
         * COnstructor for the WorkerThread class. Is given an idx to start at,
         * and the number of workers being used to parse the list. Also 
         * initializes max to the min possible value for an integer
         * @param start idx in vList to start at
         * @param workers number of workers being used
         */
        private WorkerThread(int start, int workers) {
            this.start = start;
            this.workers= workers;
            this.max = Integer.MIN_VALUE;
        }

        /**
         * Runtime logic for worker threads. Each thread starts at its given start
         * index and checks the sums for every number between this index and
         * the end of the list, updating its max when it finds a new
         * one. It then repeats this for every nth term until end of vList is reached. 
         */
        public void run() {
            //checks sums for every nth term to end, where n = num workers
            for (int i = this.start; i < vList.size(); i += workers) {
                int sum = 0;
                //checking sums from nth term to end of list
                for (int j = i; j < vList.size(); j++) {
                    sum += vList.get(j); //add next term to sum
                    if (i == start || sum > this.max) //update max if found
                        this.max = sum;
                }
            }
        }

    }
    
    /**
     * Read in a list of integers from stdin and store them in vList
     * @return 0 if it exited successfully
     */
    private static int readList() {
        //open scanner
        Scanner scan = new Scanner(System.in);

        //read in values
        while (scan.hasNextInt()) {
            vList.add(scan.nextInt());
        }

        //finished
        scan.close(); //close scanner
        return 0; //exit success
    }

    /**
     * Reads in list of integers from stdin
     * @param args the command-line arguments given by user
     */
    public static void main (String[] args) {

        //boolean flag for reporting threads
        boolean report = false;
        int workers = 0;

        //check number of args
        int numArgs = args.length;
        if (numArgs < MIN_ARGS || numArgs > MAX_ARGS) {
            throw new IllegalArgumentException(USAGE);
        }

        //check worker arg / get num workers
        workers = Integer.parseInt(args[WORKER_ARG]);
        if (workers < 1)
            throw new IllegalArgumentException();

        //check if report arg is present
        if (numArgs == MAX_ARGS) {
            String s1 = args[1];
            if (!s1.equals("report")) {
                throw new IllegalArgumentException(USAGE);
            }
            else {
                report = true;
            }
        }

        // Make the arraylist and read in values from stdin
        vList = new ArrayList<Integer>();
        int status = readList();
        if (status != 0) //moreso here just in case
            throw new IllegalArgumentException("error reading list");

        //int to track result - initially set to lowest int value 
        int result = Integer.MIN_VALUE; 

        // array to hold the worker threads
        WorkerThread[] thread = new WorkerThread[workers];

        // make the workers and start them
        for (int i = 0; i < workers; i ++) {
            thread[i] = new WorkerThread(i, workers);
            thread[i].start();
        }

        // Get results from threads
        try { // Report any interruptions during join
            for (int i = 0; i < workers; i++) {
                thread[i].join(); //join the thread
                if (i == 0)
                    result = thread[i].max;
                else if (thread[i].max > result)
                    result = thread[i].max;
                
                if (report)
                System.out.printf("I'm thread %d. The maximum sum I found was %d.\n", 
                                    thread[i].getId(), thread[i].max);
            }
        } catch (InterruptedException e) {
            System.out.println( "Interrupted during join!" );
        }

        //report results
        System.out.printf("Maximum Sum: %d\n", result);

    }
}