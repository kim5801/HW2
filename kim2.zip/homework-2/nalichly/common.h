/**
 * Component of the lightsout game containing constants
 * and the GameState struct used by other components of
 * the program.
 * 
 * @file common.h
 * @author Noah Lichlyter nalichly
 * @date 09-30-22
 */

// Height and width of the playing area.
#define GRID_SIZE 5

//GameState struct: holds gameboard and last move
typedef struct GameStateStruct { 
    //2d char array to hold board
    char board[5][5]; 

    //last move
    char last[3];
} GameState;
