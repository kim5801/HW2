/**
 * Component of the lightsout game responsible for executing 
 * moves dictated by the players. It can also undo the
 * previous move, report the status of the game board, and
 * validate commands given via the command line.
 * 
 * @file lightsout.c
 * @author Noah Lichlyter nalichly
 * @date 09-30-22
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

#define ARG_MIN 2
#define ARG_MAX 4

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

//executes a valid move given by the client
int executeMove(GameState *gs, int r, int c) {
    for (int i = r - 1; i <= r + 1; i++) {
        for (int j = c - 1; j <= c + 1; j++) {
            //bool to track if its okay to flip this char
            bool ok = false;
            //set okay to true if this char is adj. to (r, c)
            if ((i == r - 1 || i == r + 1) && j == c)
                ok = true;
            if ((j == c - 1 || j == c + 1) && i == r)
                ok = true;
            if (i == r && j == c)
                ok = true;
            //flip char if ok
            if (i >= 0 && i < GRID_SIZE && j >= 0 && j < GRID_SIZE && ok) {
                if (gs->board[i][j] == '*')
                    gs->board[i][j] = '.';
                else //period - change to star
                    gs->board[i][j] = '*';
            }
        }
    }
    return 0;
}

/**
 * Prints the current state of the board to the terminal
 * @param gs pointer to GameState holding the board
 */
int printBoard(GameState *gs) {
    if (gs == NULL || gs->board == NULL)
        return 1;

    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            printf("%c", gs->board[i][j]);
        }
        printf("\n");
    }
    return 0;
}

/**
 * Attempts to execute a user-given command for the lightsout
 * game. If it is valid, and execution was successful, it will
 * print "success" and return 0; otherwise it will print an
 * error message (most likely "error") and return 1
 * 
 * @param argc the number of args given by the user
 * @param argv arr of strings holding the args given
 * @return 0 if execures successfully, or 1 otherwise
 */
int main(int argc, char *argv[]) {

    //vars for holding args 
    char cmd;
    int r, c;

    //invalid number of args 
    if (argc != ARG_MIN && argc != ARG_MAX) {
        fail("error"); //temp usage error
    }

    //checks for when 1 arg given
    if (argc == ARG_MIN) { 
        if (strcmp(argv[1], "undo") == 0)
            cmd = 'u';
        else if (strcmp(argv[1], "report") == 0)
            cmd = 'r';
        else if (strcmp(argv[1], "move") == 0)
            fail("error");
        else
            fail("error");
    } 
    // check for when 3 args 
    if (argc == ARG_MAX) {
        if (strcmp(argv[1], "move") == 0) { 
            if (sscanf(argv[2], "%d", &r) != 1 || r < 0 || r > GRID_SIZE - 1)
                fail("error");
            if (sscanf(argv[3], "%d", &c) != 1 || c < 0 || c > GRID_SIZE - 1)
                fail("error");
            cmd = 'm';
        } else { 
            fail("error");
        }
    }

    //get unique key based off of eos home dir
    key_t key = ftok("/afs/unity.ncsu.edu/users/n/nalichly", 42);
    
    // get shmid of the gamestate
    int shmid = shmget(key, 0, 0);
    if (shmid == -1)
        fail( "Can't create shared memory" );

    GameState *gs = (GameState *)shmat(shmid, 0, 0);
    if (gs == (GameState *)-1) //unsuccessful
        fail( "Can't attach GameState" );

    if (cmd == 'm') { //move
        //execute the move
        executeMove(gs, r, c);

        //update last move to this one
        gs->last[0] = r + '0';
        gs->last[1] = c + '0';

        //done
        printf("success\n");
    }

    if (cmd == 'u') { //undo
        //check to make sure undo command is valid
        if (gs->last[0] == '\0') 
            fail("error");

        r = gs->last[0] - '0';
        c = gs->last[1] - '0';

        //execute undo and update last
        executeMove(gs, r, c);
        for (int i = 0; i < 3; i++)
            gs->last[i] = '\0';
        
        //done
        printf("success\n");
    } 

    //report command
    if (cmd == 'r')
        printBoard(gs);

    // Release our reference to shared memory segment
    shmdt(gs);

    return EXIT_SUCCESS;
}
