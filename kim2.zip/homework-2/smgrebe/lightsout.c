#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


// Takes in a character, either '.' or '*' and returns the opposite.
// Equal to turning a light off or turning a light on.
char opposite( char const state ) {
  if (state == '.') {
    return '*';
  }
  return '.';
}

int main( int argc, char *argv[] ) {

  // Gets the id of the shared memory based on a key from the common.h header.
  int shmid = shmget (GET_KEY, sizeof(GameState), 0);
  // Gets the GameState struct from the shared memory.
  GameState *state = (GameState *) shmat( shmid, 0, 0);
  
  // Invalid number of command line arguments.
  if (argc == 1) {
    printf("error\n");
    exit( EXIT_FAILURE );
  }
  
  // Move command
  if (strcmp(argv[1], "move") == 0) {
    if (argc != 4) {  // Invalid number of arguments
      printf("error\n");
      exit ( EXIT_FAILURE );
    }
    
    // Checks that the row and column values are in range
    char *rowChar = argv[2];
    char *colChar = argv[3];
    if (rowChar[0] < '0' || rowChar[0] > '4' || colChar[0] < '0' || colChar[0] > '4') { //arguments not valid
      printf("error\n");
      exit( EXIT_FAILURE );
    }
    
    // Converts the row and column values from the command line to integers
    int row = atoi(rowChar);
    int col = atoi(colChar);
    
    // Switches the given row and column value to its opposite on/off value and
    // attempts to switch each adjacent light, given it is in range.
    state->contents[row][col] = opposite(state->contents[row][col]);
    if (row - 1 > -1) { // trying to invert the square above
      state->contents[row - 1][col] = opposite(state->contents[row - 1][col]);
    }
    if (row + 1 < 5) {  // trying to invert the square below
      state->contents[row + 1][col] = opposite(state->contents[row + 1][col]);
        }
    if (col - 1 > -1) { // trying to invert the left square
      state->contents[row][col - 1] = opposite(state->contents[row][col - 1]);
    }
    if (col + 1 < 5) {  // trying to invert the right square
      state->contents[row][col + 1] = opposite(state->contents[row][col + 1]);
    }
    // Updates the state of the GameState to make an undo operation possible
    state->rowUndo = row;
    state->colUndo = col;
    state->canUndo = true;
    printf("success\n");
  }
  // Undo command
  else if (strcmp(argv[1], "undo") == 0) {
    if (argc != 2) {  // Checking that the number of command line arguments is valid for undo
      printf("error\n");
      exit( EXIT_FAILURE );
    }
    if (state->canUndo) { //makes sure we can undo, otherwise return error message to client
      // Resets the state of GameState so that another undo cannot be performed immediately after
      state->canUndo = false;
      // Gets the last column and row that were acted upon and will invert this spot and 
      // adjacent lights.
      int rowUndo = state->rowUndo;
      int colUndo = state->colUndo;
      //inverting the row and column
      state->contents[rowUndo][colUndo] = opposite(state->contents[rowUndo][colUndo]);
      if (rowUndo - 1 > -1) { //trying to invert the square above
        state->contents[rowUndo - 1][colUndo] = opposite(state->contents[rowUndo - 1][colUndo]);
      }
      if (rowUndo + 1 < 5) {  //trying to invert the square below
        state->contents[rowUndo + 1][colUndo] = opposite(state->contents[rowUndo + 1][colUndo]);
      }
      if (colUndo - 1 > -1) { //trying to invert the left square
        state->contents[rowUndo][colUndo - 1] = opposite(state->contents[rowUndo][colUndo - 1]);
      }
      if (colUndo + 1 < 5) {  //trying to invert the right square
        state->contents[rowUndo][colUndo + 1] = opposite(state->contents[rowUndo][colUndo + 1]);
      }
      printf("success\n");
    }
    else {  // Can't undo - no move has been made or there has already been an undo immediately before
      printf("error\n");
      exit( EXIT_FAILURE );
    }
  }
  // Report command
  else if (strcmp(argv[1], "report") == 0) {
    if (argc != 2) {  // Checking the number of command line arguments for report
      printf("error\n");
      exit( EXIT_FAILURE );
    }
    //copying the board contents into a string
    char board[37];
    board[37] = '\0';
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        board[(i * 6) + j] = state->contents[i][j];
      }
      board[(i * 6) + 5] = '\n';
    }
    // Printing the board to the user
    printf("%s\n", board);
  }
  else {  //invalid command
    printf("error\n");
    exit( EXIT_FAILURE );
  }

  // Exits successfully. No errors were run into along the way.
  exit ( EXIT_SUCCESS );
}
