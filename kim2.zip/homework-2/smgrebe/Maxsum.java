import java.util.ArrayList;
import java.util.Scanner;

// Class to calculate the maximum sum of contiguous non-empty
// subsequences in a list. Runs from the main method.
public class Maxsum {

    // List of numbers from standard input to find the max of
    private static ArrayList<Integer> list;

    // Worker threads for this program.
    private static class WorkerThread extends Thread {
        // Each thread has a list of indexes to start their sequential
        // maximum search from.
        private final ArrayList<Integer> indexes;

        // Maximum sum the thread has found from all
        // of their indexes
        public int maxSum;

        // Initializes the worker thread's index list
        public WorkerThread ( final ArrayList<Integer> indexes ) {
            this.indexes = indexes;
        }

        // Runs the thread
        @Override
        public void run () {
            // Start the max at the lowest value possible
            int methodMax = Integer.MIN_VALUE;

            // Look through each index in the index list
            for ( final int i : indexes ) {
                // The local max is the maximum sum for the current index
                int localMax = methodMax;
                // Calculate the current sum after adding one more index from
                // the initial index.
                // Compares to local sum each time and updates when necessary.
                int sum = 0;
                for ( int j = i; j < list.size(); j++ ) {
                    sum += list.get( j );
                    if ( sum > localMax ) {
                        localMax = sum;
                    }
                }
                // Updates to method max if the local max is greater
                if ( localMax > methodMax ) {
                    methodMax = localMax;
                }
            }

            // Updates the maxSum field to the method max the thread has
            // calculated. This will be used from the main thread to calculate
            // the final Maximum Sum
            maxSum = methodMax;
        }
    }

    // Print out a usage message, then exit.
    private static void usage () {
        System.out.println( "usage: maxsum <workers>\n       maxsum <workers> report\n" );
        System.exit( 1 );
    }

    // Main method, the args array starts after Java {ProgramName}
    // So the first argument should be the number of worker threads
    // and the second optional argument is the word "report".
    public static void main ( final String[] args ) {
        boolean report = false;
        final int workers = Integer.parseInt( args[0] );
        // Making sure there is the appropriate amount of command line args
        if ( args.length < 1 || args.length > 2 ) {
            usage();
        }

        // Number of workers is parsed and is positive
        if ( workers < 1 ) {
            usage();
        }

        // If there's a second argument, it should be the word "report"
        if ( args.length == 2 ) {
            if ( !args[1].equals( "report" ) ) {
                usage();
            }
            report = true;
        }

        // Reading the list from input through a Scanner
        list = new ArrayList<Integer>();
        final Scanner s = new Scanner( System.in );
        while ( s.hasNextInt() ) {
            list.add( s.nextInt() );
        }
        s.close(); // avoids any file leaks

        // Creating list of Threads based on the number of workers
        final WorkerThread[] threads = new WorkerThread[workers];

        // Initializing each thread in the list to have an empty list
        // of indexes. This will be updated next.
        for ( int i = 0; i < workers; i++ ) {
            threads[i] = new WorkerThread( new ArrayList<Integer>() );
        }

        // Initializing each thread with their list of indexes to check
        for ( int i = 0; i < list.size(); i++ ) {
            threads[i % workers].indexes.add( i );
        }

        // Running each thread.
        for ( int i = 0; i < workers; i++ ) {
            threads[i].run();
        }

        // Joining all threads into the main thread.
        // After each joins, the main thread compares its calculated
        // max sum to the current max sum and updates it as necessary.
        // If the report field is true, the thread's details are printed.
        int max = Integer.MIN_VALUE;
        for ( final WorkerThread thread : threads ) {
            try {
                thread.join();
                if ( max < thread.maxSum ) {
                    max = thread.maxSum;
                }
                if ( report ) {
                    System.out.println(
                            "I'm thread " + thread.getId() + ". The maximum sum I found is " + thread.maxSum + "." );
                }
            }
            catch ( final InterruptedException e ) { // Error occurs when
                                                     // joining threads
                System.out.println( "Interrupted during join!" );
            }

        }

        // Prints the final maximum sum.
        System.out.println( "Maximum sum: " + max );

    }

}
