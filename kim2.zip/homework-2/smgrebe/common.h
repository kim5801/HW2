#include <sys/shm.h>
#include <sys/ipc.h>

// Height and width of the playing area.
#define GRID_SIZE 5

// Defines the method call to get a key for a shared memory block.
#define GET_KEY ftok("/afs/unity.ncsu.edu/users/s/smgrebe/", 1)

// Creating a Game State struct
// This includes each light in the board,
// whether or not the board can undo, and
// the row and columns to find the spot to
// undo if it is valid.
typedef struct {
  char contents[5][5];
  int rowUndo;
  int colUndo;
  bool canUndo;
} GameState;

