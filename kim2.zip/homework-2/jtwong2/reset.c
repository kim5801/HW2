#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

#define NUM_CHARS_IN_BOARD 25

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Reads the file and creates a game struct with the contents of the file
static void createGame(Game *g, char *filename) {
  // Open the file
  FILE *gameFile = fopen(filename, "r");
  if (!gameFile) {
    fprintf(stderr, "Invalid input file: %s\n", filename);
    exit(1);
  }

  // Initialize the state of the game. We can't undo a move immediately after
  // starting the game
  g->undoOK = false;
  g->lastMoveRow = -1;
  g->lastMoveCol = -1;

  // Fill in the game board, reading from the file
  int row = 0;
  int col = 0;
  char currentChar = 0;
  int numGameChars = 0;
  while (fscanf(gameFile, "%c", &currentChar) == 1) { // Loop until there are no more characters to read
    // Check for invalid input characters in the file (anything that isn't a newline, ., or *)
    if (currentChar != '\n' && currentChar != '.' && currentChar != '*') {
      fprintf(stderr, "Invalid input file: %s\n", filename);
      exit(1);
    }

    // Newline means to start filling in the next row
    if (currentChar == '\n') {
      // If we hit a newline before fully filling in the column, we know the file is invalid
      if (col != 5) {
        fprintf(stderr, "Invalid input file: %s\n", filename);
        exit(1);
      } else {
        // Else, start filling in the next row
        row++;
        col = 0;
        continue;
      }
    }

    // Check for too many characters in the board
    if (numGameChars > NUM_CHARS_IN_BOARD) {
      fprintf(stderr, "Invalid input file: %s\n", filename);
      exit(1);
    }

    // Fill in the board square with the character in the file
    g->board[row][col] = currentChar;
    numGameChars++;
    col++;
  }

  // Close file since we're done reading from it
  fclose(gameFile);
}

// Starting point for the reset program
int main( int argc, char *argv[] ) {
  // Check the validity of command-line arguments
  if (argc != 2) {
    usage();
  }

  // Create the shared memory segment
  int memId = shmget(ftok("/afs/unity.ncsu.edu/users/j/jtwong2/", 0), sizeof(Game), 0666 | IPC_CREAT | IPC_EXCL);
  if (memId == -1) { // If the create failed, then try to delete the segment and retry creating one
    // Attempt to delete the segment
    memId = shmget(ftok("/afs/unity.ncsu.edu/users/j/jtwong2/", 0), sizeof(Game), 0666 | IPC_CREAT); // Get the old shared memory block
    int status = shmctl(memId, IPC_RMID, 0); // Delete the old shared memory block

    // Retry creating the memory
    memId = shmget(ftok("/afs/unity.ncsu.edu/users/j/jtwong2/", 0), sizeof(Game), 0666 | IPC_CREAT | IPC_EXCL);
    if (memId == -1) { // If it still failed, fail the program
      printf("Errno: %d\n", errno);
      printf("Detach status: %d\n", status);
      fail("Could not create memory segment");
    }
  }

  // Treat the shared memory segment like a game struct
  Game *sharedGame = (Game*)shmat(memId, 0, 0);

  // Read in the data from the file and place it into the struct
  createGame(sharedGame, argv[1]);

  shmdt(sharedGame); // The reset program no longer needs the memory, so detach it (but don't delete it)

  // Exit, since this program has now set up the environment for the client program (lightsout.c)
  return 0;
}
