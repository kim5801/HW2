#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out the command error message and exit
static void error() {
  printf("error\n");
  exit(1);
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Prints the board.
static void printGame(Game *g) {
  // Prints one cell at a time, starting from 0,0 (top left)
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      printf("%c", g->board[i][j]);
    }

    printf("\n");
  }
}

// This method assumes that the move is valid
static int makeMove(Game *g, int row, int col) {

  // Flip the light at the move's coordinates
  if (g->board[row][col] == '.') {
    g->board[row][col] = '*';
  } else { // Must be set to '*' currently
    g->board[row][col] = '.';
  }


  // Flip the light above the move's coordinates
  if (row + 1 <= 4) { // If there's another cell on the board above the move's coordinate
    if (g->board[row + 1][col] == '.') {
      g->board[row + 1][col] = '*';
    } else { // Must be set to '*' currently
      g->board[row + 1][col] = '.';
    }
  }

  // Flip the light below the move's coordinates
  if (row - 1 >= 0) { // If there's another cell on the board below the move's coordinate
    if (g->board[row - 1][col] == '.') {
      g->board[row - 1][col] = '*';
    } else { // Must be set to '*' currently
      g->board[row - 1][col] = '.';
    }
  }

  // Flip the light to the right of the move's coordinates
  if (col + 1 <= 4) { // If there's another cell on the board to the right of the move's coordinate
    if (g->board[row][col + 1] == '.') {
      g->board[row][col + 1] = '*';
    } else { // Must be set to '*' currently
      g->board[row][col + 1] = '.';
    }
  }

  // Flip the light to the left of the move's coordinates
  if (col - 1 >= 0) { // If there's another cell on the board to the left of the move's coordinate
    if (g->board[row][col - 1] == '.') {
      g->board[row][col - 1] = '*';
    } else { // Must be set to '*' currently
      g->board[row][col - 1] = '.';
    }
  }

  // Set the game's last move
  g->lastMoveRow = row;
  g->lastMoveCol = col;
  g->undoOK = true;

  // Return success or failure (0 or 1, respectively)
  return 0;
}

int main( int argc, char *argv[] ) {
  // Attach to the shared memory segment to access the game
  int memId = shmget(ftok("/afs/unity.ncsu.edu/users/j/jtwong2/", 0), 0, 0);

  if (memId == -1) {
    fail("Could not attach shared memory");
  }

  Game *sharedGame = (Game*)shmat(memId, 0, 0);

  // Validate number of arguments
  if (argc < 2 || argc > 4) {
    error();
  }

  // Parse the command
  if (strcmp("move", argv[1]) == 0) {
    // Validate arguments for the move command
    if (argc != 4) {
      error();
    }

    // Make sure the arguments are integers between 0 and 4, inclusive
    if (argv[2][0] < '0' || argv[2][0] > '4' || argv[2][1] != '\0' || argv[3][0] < '0' || argv[3][0] > '4' || argv[3][1] != '\0') {
      error();
    }

    // Make the move on the shared board
    int col = argv[2][0] - '0';
    int row = argv[3][0] - '0';
    makeMove(sharedGame, col, row);

    // Print exit status of command
    printf("success\n");
  } else if (strcmp("report", argv[1]) == 0) { // Handles the report command
    // Validate arguments for the report command
    if (argc != 2) {
      error();
    }

    // No need to print out any success/error message; just print out the board
    printGame(sharedGame);
  } else if (strcmp("undo", argv[1]) == 0) {
    // Validate arguments for the undo command
    if (argc != 2) {
      error();
    }

    // Undo the move
    if (sharedGame->undoOK) { // If an undo is allowed
      makeMove(sharedGame, sharedGame->lastMoveRow, sharedGame->lastMoveCol); // An undo is just the same as redoing the last move
      sharedGame->undoOK = false; // Two undos in a row is not allowed
    } else {
      error(); // Not allowed to undo twice in a row
    }

    // Print the success message
    printf("success\n");
  } else {
    error(); // Must not have been a valid command, so error
  }

  shmdt(sharedGame); // This program no longer needs the shared memory (since it's about to terminate) so detach it
  return 0;
}
