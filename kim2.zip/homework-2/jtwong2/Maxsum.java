import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class Maxsum {
  // Variables to hold data used in all threads
  static ArrayList<Integer> values;
  static int valCount;
  static int numWorkers;
  static boolean report;

  public static void main(String args[]) {
    // Initialize the variables
    report = false;
    values = new ArrayList<Integer>();
    valCount = 0;

    // Check to make sure there are the right number of command-line arguments
    if (args.length < 1 || args.length > 2) {
      System.out.println("Invalid arguments");
      System.exit(1);
    }

    // Argument validation - if the first argument is not an int, exit
    try {
      numWorkers = Integer.parseInt(args[0]);
    } catch (NumberFormatException e) {
      System.out.println("Invalid arguments");
      System.exit(1);
    }

    // Check if the report argument is present
    if (args.length == 2 && args[1].equals("report")) {
      report = true;
    } else if (args.length == 2 && !args[1].equals("report")) { // If there are two arguments but the second is not "report"
      System.out.println("Invalid arguments");
      System.exit(1);
    }

    // Read in values from standard input
    Scanner in = new Scanner(System.in);
    while (in.hasNext()) { // While the scanner has tokens
      try {
        values.add(in.nextInt());
        valCount++;
      } catch (InputMismatchException e) { // If there is a non-integer value, we should exit
        System.out.println("File contains invalid characters");
        System.exit(1);
      }
    }

    // If the user wants more workers than values in the list, we get no performance increases. Therefore, let's clamp the max number of workers to the
    // number of values.
    if (numWorkers > valCount) {
      numWorkers = valCount;
    }

    // Create the threads in a for loop, passing in their index (to give then their starting index to inspect) and starting them
    SumWorker[] workers = new SumWorker[Integer.parseInt(args[0])];
    for (int i = 0; i < numWorkers; i++) {
      workers[i] = new SumWorker(i);
      workers[i].start();
    }

    // Join with the threads
    int[] vals = new int[numWorkers];
    for (int i = 0; i < numWorkers; i++) {
      try {
        // Join with the thread and retrieve its max value and store it
        workers[i].join();
        vals[i] = workers[i].max;
      } catch (InterruptedException e) { // This shouldn't happen, but catch it just in case
        System.out.println("Interrupted during thread join");
        System.exit(1);
      }
    }

    // Calculate the max from the workers' results and print it
    int max = vals[0];
    for (int i = 1; i < numWorkers; i++) { // Just iterate through and record current max
      if (vals[i] > max) {
        max = vals[i];
      }
    }

    // Print out the max for the entire program
    System.out.println("Maximum sum: " + max);
  }

  // Class for the worker threads
  static class SumWorker extends Thread {
    private int startIdx;

    public int max;

    // Workers need to know what index they start summing from, therefore we pass it in as a parameter
    public SumWorker(int startIdx) {
      this.startIdx = startIdx;
    }

    // This method sums starting from every n elements, where n is the number of other workers also doing the sum operation
    public void run() {
      // By default, largest sum so far is the first value being searched
      int largestSum = values.get(startIdx);

      // Compute sums starting at every n index
      for (int i = startIdx; i < valCount; i += numWorkers) {
        int sum = 0; // Reset before each iteration of the inner loop, since it is doing the summing
        for (int j = i; j < valCount; j++) { // Starting at the current index, sum until the end of the list
          sum += values.get(j);
          if (sum > largestSum) { // If the new value makes the sum the largest found so far
            largestSum = sum; // Record the new max
          }
        }
      }

      this.max = largestSum; // Set the max sum found for this thread so that the main thread can access it

      // Optionally report the sum from this worker
      if (report) {
        System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + largestSum + ".");
      }
    }
  }
}
