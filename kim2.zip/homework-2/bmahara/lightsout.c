#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//main method accesses shared memory and perform soperations as specified by the user
int main( int argc, char *argv[] ) {

  if(argc < 2 || argc > 4) {
    fail("error");
  }

  int k = ftok("/afs/unity.ncsu.edu/users/b/bmahara", KEY_CONSTANT);

  int shmid = shmget( k, 0, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  //attaching to shared memory
  GameState *gstate = (GameState *) shmat( shmid, 0, 0 );
  if ( gstate == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if(argc == 2) {
    if(strcmp(argv[1], "report") == 0) {

      for(int i = 0; i < GRID_SIZE; i++) {

        for(int j = 0; j < GRID_SIZE; j++) {
          if(gstate->lights[i][j]) {
            printf("*");
          }
          else {
            printf(".");
          }
        }
        printf("\n");

      }
    }

    else if(strcmp(argv[1], "undo") == 0) {
      int r = gstate->pvs_choice_row;
      int c = gstate->pvs_choice_col;
      //r = -1 only when 
      if(r != -1) { 

        //move command
        //row and col obtained
        gstate->lights[r][c] = !gstate->lights[r][c];
        //above
        if((r + 1) <= 4) {
          gstate->lights[r + 1][c] = !gstate->lights[r + 1][c];
        }
        //below
        if((r - 1) >= 0) {
          gstate->lights[r - 1][c] = !gstate->lights[r - 1][c];
        }
        //left
        if((c - 1) >= 0) {
          gstate->lights[r][c - 1] = !gstate->lights[r][c - 1];
        }
        //left
        if((c + 1) <= 4) {
          gstate->lights[r][c + 1] = !gstate->lights[r][c + 1];
        }     

        gstate->pvs_choice_row = -1;
        gstate->pvs_choice_col = -1;

        printf("success\n");
        
      }
      else {
        fail("error");
      }
    }

  }

  else if(strcmp(argv[1], "move") == 0) {
    if(argc != 4) {
      fail("error l64");
    }

    else {
      if(*argv[2] < '0' || *argv[2] > '4' || *argv[3] > '4' || *argv[3] < '0') {
          fail("error");
      }

      char rc[2];
      rc[0] = *argv[2];
      rc[1] = '\0';
      int r = atoi(rc);

      char cc[2];
      cc[0] = *argv[3];
      cc[1] = '\0';
      int c = atoi(cc);

      //move command
      //row and col obtained
      gstate->lights[r][c] = !gstate->lights[r][c];
      //above
      if((r + 1) <= 4) {
        gstate->lights[r + 1][c] = !gstate->lights[r + 1][c];
      }
      //below
      if((r - 1) >= 0) {
        gstate->lights[r - 1][c] = !gstate->lights[r - 1][c];
      }
      //left
      if((c - 1) >= 0) {
        gstate->lights[r][c - 1] = !gstate->lights[r][c - 1];
      }
      //left
      if((c + 1) <= 4) {
        gstate->lights[r][c + 1] = !gstate->lights[r][c + 1];
      }     

      gstate->pvs_choice_row = r;
      gstate->pvs_choice_col = c;

      printf("success\n");

    }
  }

  else {
    //command is neither move undo or report
    fail("error");
  }

  shmdt( gstate );

  return 0;
}
