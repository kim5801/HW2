#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  if(argc != 2) usage();

  FILE *inp = fopen(argv[1], "r");
  if(inp == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  int k = ftok("/afs/unity.ncsu.edu/users/b/bmahara", KEY_CONSTANT);
  int shmid = shmget( k, sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  GameState *gstate = (GameState *) shmat( shmid, 0, 0 );
  if ( gstate == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" ); 

  //reading file
  int row = 0;
  int col = 0;

  char ch;

  //resetting values that may have carried over from previous executions
  gstate->pvs_choice_row = -1;
  gstate->pvs_choice_col = -1;

  while( (ch = fgetc(inp)) != EOF) {
    if(ch != '.' && ch != '*' && ch != '\n') {
      fprintf(stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }

    if(ch == '.') {
      gstate->lights[row][col++] = false;
    }
    else if(ch == '*') {
      gstate->lights[row][col++] = true;
    }

    if(col == 5) {
      row++;
      col = 0;
    }

  } //light board ready

  // Release our reference to the shared memory segment.
  shmdt( gstate );

  return 0;
}
