import java.util.*;

/**
 * Finds maximum subset sum from a list of numbers using n workers
 * @author Bagya Maharajan
 */
public class Maxsum {

    /** number of workers specified by user */
    private static volatile int workers;
    /** list size */
    private static volatile int total_vals;
    /** stores each workers share */
    private static volatile int my_share;
    /** stores excess shares of work that are remaining */
    private static volatile int excess_share;
    /** list of all values read at input */
    private static volatile ArrayList<Integer> list;
    /** does user want to report? */
    private static volatile boolean report;

    /** Class for worker threads */
    static class Worker extends Thread {

        //stores sindex to start looking from
        private int wrkr_id;
        
        //storing max value each worker finds - for main to access
        public int maxIFound;

        /** Constructor for the thread worker */
        public Worker(int i) {
            this.wrkr_id = i;
        }
        
        public void run() {
            int max = Integer.MIN_VALUE;
            
            for(int a = 0; a < my_share; a++) {                
                int subset_sum = 0;

                for(int b = (wrkr_id + (a * workers)); b < total_vals; b++) {
                    subset_sum += list.get(b);

                    if(subset_sum > max) {
                        max = subset_sum;
                    }
                }
            } //calculated max for my share

            //any excess shares I(thread) needs to calculate?
            if(excess_share != 0) {
                int excess_share_idx = total_vals - excess_share;
                int excess_share_ss = 0;
                for(int d = excess_share_idx; d < total_vals; d++) {
                    excess_share_ss += list.get(d);
                    if(excess_share_ss > max) {
                        max = excess_share_ss;
                    }
                }
                excess_share--;
            }

            maxIFound = max;

            if(report) {
                System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + maxIFound);
            }
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        report = false;        
        if(args.length == 2) {
            report = true;
        }

        list = new ArrayList<>();
        //reading list of ints to add
        while(in.hasNextInt()) {
             int x = in.nextInt();
             list.add(x);            
        }

        workers = Integer.parseInt(args[0]);
        total_vals = list.size();
        //share for each worker
        my_share = total_vals / workers;
        excess_share = total_vals % workers;

        Worker[] threads = new Worker[workers];

        //running worker number of threads
        for(int i = 0; i < workers; i++) {
            threads[i] =  new Worker(i);
            threads[i].start();
        }

        //waiting for all threads to finish
        try {
            int maximum_max = Integer.MIN_VALUE;
            for(int w = 0; w < workers; w++) {
                threads[w].join();
                if(threads[w].maxIFound > maximum_max)
                    maximum_max = threads[w].maxIFound;
            }

            System.out.println("Maximum sum: " + maximum_max);
        }
        catch(Exception e) {
            System.out.println("Interrupted during join!");
        }

        

    }
}