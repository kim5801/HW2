import java.util.*;

/**
 * @file Maxsum.java
 * @author tjoshi Tej Joshi
 * @brief this file finds the max subarray from a list of integers in a file using threads in java
 * 
 * Sources: 
 * Used the following example files from moodle as inspiration in creating this file:
 * ThreadArguments.java
 * HelloThreads.java
 */
public class Maxsum {
    volatile static ArrayList<Integer> vList = new ArrayList<Integer>();
    volatile static ArrayList<Integer> workerOutput = new ArrayList<Integer>();
    volatile static boolean report = false;
    volatile static int workers;
    
    public static void readList() {
        Scanner scan = new Scanner(System.in);
        while (scan.hasNextInt()) {
            vList.add((Integer) scan.nextInt());
        }
        scan.close();
    }

    /** Thread to print ab. */
    static class threadCode implements Runnable {
        public int start;
        public threadCode(int startArg) {
            start = startArg;
        }
        
        public int maxSubarray(int start) {
            int currSum = 0;
            int maxSum = vList.get(start);
            for (int i = start; i < vList.size(); i++) {
                currSum += vList.get(i);
                if (currSum > maxSum) {
                    maxSum = currSum;
                }
            }
            return maxSum;
        }
        public void run() {
            int currMax = 0;
            int actMax = 0;
            // this loop defines the start indexes for the subarrays this child process has 
            // find the maximum subarray of
            for (int j = start; j < vList.size(); j += workers) {
                currMax = maxSubarray(j);
                // if the current max subarray found is bigger than the old max subarray,
                // store the current max subarray as the maximum subarray found
                if (currMax > actMax) {
                    actMax = currMax;
                }
            }
            workerOutput.set(start, (Integer) actMax);
            // if user says to report the processes, then the following will be printed
        }
     }

     public static void usage() {
        System.out.print( "usage: maxsum <workers>\n" );
        System.out.print( "       maxsum <workers> report\n" );
        System.exit( 1 );
    }
    public static void main( String[] args ) {
        if (args.length > 2  || args.length < 1) {
            usage();
        }
        try {
            workers = Integer.parseInt(args[0]);
        }
        catch (Exception e) {
            usage();
        }
        if (workers < 1) {
            usage();
        }
        if (args.length == 2) {
            if (args[1].compareTo("report") != 0) {
                usage();
            }
            report = true;
        }
        readList();
        Thread[] workerThreads = new Thread[workers];

        for (int i = 0; i < workers; i++) {
            workerOutput.add(0);
            workerThreads[i] = new Thread(new threadCode(i));
            workerThreads[i].start();
        }
        for (int i = 0; i < workers; i++) {
            try {
                workerThreads[i].join();
              }
              catch (InterruptedException e) {
                System.out.println("Couldn't Join");
              }
        }
        if (report) {
            for (int i  = 0; i < workers; i++) {
                System.out.println("I’m thread "+ workerThreads[i].getId() +". The maximum sum I found is "+ workerOutput.get(i) +".");
            }
        }
        int currMax = 0;
        int actMax = 0;
        for (int i = 0; i < workers; i++) {
            currMax = workerOutput.get(i);
            if (currMax > actMax) {
                actMax = currMax;
            }
        }
        System.out.println("Maximum Sum: " + actMax);
    }
}