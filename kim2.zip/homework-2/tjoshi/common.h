// Height and width of the playing area.
#define GRID_SIZE 5

typedef struct GameState {
    bool prevUndo;
    char currArray[GRID_SIZE][GRID_SIZE];
    char prevArray[GRID_SIZE][GRID_SIZE];
} GameState;