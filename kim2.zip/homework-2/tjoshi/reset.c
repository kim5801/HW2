#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}



int main( int argc, char *argv[] ) {
  if ( argc != 2 ) {
    usage();
  }
  FILE *fp = fopen(argv[1], "r");
  // checks the command line argument had a valid file input
  if (!fp) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( 1 );
  }
  // makes a unique key 
  key_t key = ftok("/afs/unity.ncsu.edu/users/t/tjoshi/", 911);
  // gets the block of memory
  int shmid =  shmget(key, sizeof(GameState), 0666 | IPC_CREAT);
   if ( shmid == -1 )
    fail( "Can't create shared memory" );
  GameState *gameState = (GameState *)shmat( shmid, 0, 0 );
  if ( gameState == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );
  //Reads the file character by character to check if it meets 
  //the given board requirements and unsuccessfully exits if not.
  //Additionally it reads in the characters into the current character
  //array.
  char ch = fgetc(fp);
  int colCount = 0;
  int rowCount = 0;
  while (ch != EOF) {
    if (ch == '\n') {
      rowCount++;
      if (colCount != 5 || rowCount > 5) {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
      }
      colCount = 0;
    }
    else if (ch == '.' || ch == '*') {
      gameState->currArray[rowCount][colCount++] = ch;
    }
    else {
      fprintf( stderr, "Invalid input file: %s\n", argv[1] );
      exit( 1 );
    }
    ch = fgetc(fp);
  }
  gameState->prevUndo = false;
  shmdt( gameState );

  return 0;
}
