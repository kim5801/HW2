// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * board structure, has an array to store the old and new grid.
*/
typedef struct {

    /** Copy of the last move made by the user */
    char oldGame[25];
    
    /** Copy of the newest move made by the user */
    char newGame[25];
    
    /** Lets lights out know if undo is valid or not */
    int flag;
} GameState;