#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Size of the shared memory block
#define BLOCK_SIZE sizeof(GameState)

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// // Print out a usage message and exit.
// static void usage() {
//   fprintf( stderr, "usage: reset <board-file>\n" );
//   exit( 1 );
// }

//free the board struct and its fields
static void freeBoard(GameState *game, int shmid) {
  shmdt(game);
  shmctl( shmid, IPC_RMID, 0 );
}

int main( int argc, char *argv[] ) {

  // Make a shared memory segment one GameState in size
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/t/ttheis2", 1), BLOCK_SIZE, 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
    
  // Map the shared memory into my address space
  GameState* game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );


  if(argc != 2) {
    fail("usage: server<board-file>");
  }
  
  FILE* read = fopen(argv[1], "r");
  if(read == NULL) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }
  
  //GameState* game = malloc(sizeof(board));
  //game->oldGame = malloc(25 * sizeof(char));
  //game->newGame = malloc(25 * sizeof(char));
  game->flag = 0;
  
  int cnt = 0;
  char ch = fgetc(read);
  bool newLine = true;
  
  while(ch != EOF) {
    if(cnt > 25) { //more than 25 chars
      freeBoard(game, shmid);
      fprintf( stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }
    
    if(ch != '.' && ch != '*' && ch != '\n') { //invalid character
      freeBoard(game, shmid);
      fprintf( stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }
    
    //if the count is at a "newLine" marker, but the new line has already passed
    //else if there is no newLine yet and it does not equal '\n' fail
    if(cnt % 5 == 0 && (ch == '*' || ch == '.') && newLine) {
      game->newGame[cnt] = ch;
      //printf("Count: %d, and ch: %c\n", cnt, ch);
      cnt++;
      ch = fgetc(read);
      newLine = false;
      continue;
    } else if ((cnt % 5 == 0 && ch != '\n') || ((cnt % 5 != 0) && ch == '\n')) {
      //printf("Count: %d, and ch: %c\n", cnt, ch);
      freeBoard(game, shmid);
      fprintf( stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }
    

    //don't increment cnt and don't add to array make newLine true
    if(ch == '\n') {
      ch  = fgetc(read);
      newLine = true;
      continue;
    }

    //add to array and increment count
    game->newGame[cnt] = ch;
    //printf("Count: %d, and ch: %c\n", cnt, ch);
    cnt++;
    ch = fgetc(read);
  }
  
  
  
  //add the game struct to shared memory
  
//   // Make a shared memory segment 1KB in size
//   int shmid = shmget( 9876, BLOCK_SIZE, 0666 | IPC_CREAT );
//   if ( shmid == -1 )
//     fail( "Can't create shared memory" );
// 
//   // Map the shared memory into my address space
//   GameState* shGame = (GameState *)shmat( shmid, 0, 0 );
//   shGame = game;
//   if ( sbuffer == (GameState *)-1 )
//     fail( "Can't map shared memory segment into address space" );

//   int linecnt = 0;
//   for (int i = 0; i <= 24; i++) {
//     if (linecnt == 5) {
//       printf("\n");
//       linecnt = 0;
//       i--;
//       continue;
//     }
//     printf("%c", game->newGame[i]);
//     linecnt++;
//   }
//   printf("\n");
// 
//     for (int i = 0; i <= 24; i++) {
//       printf("%d %c", i, game->newGame[i]);
//       printf("\n");
//     }

//   game->flag = 1;
  shmdt(game);

  return 0;
}
