#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

#define BLOCK_SIZE sizeof(GameState)

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//Changes a . to a * or vice versa on the game board
static void makeMove(GameState *game, int idx) {
  if(game->newGame[idx] == '*') {
    game->newGame[idx] = '.';
  } else if (game->newGame[idx] == '.') {
    game->newGame[idx] = '*';
  }
}

//Makes newGame equal to oldGame
static void undoMove(GameState *game) {
  for(int i = 0; i < 25; i++) {
    game->newGame[i] = game->oldGame[i];
  }
}

//Makes oldGame equal to newGame
static void newBoard(GameState *game) {
  for(int i = 0; i < 25; i++) {
    game->oldGame[i] = game->newGame[i];
  }
}

//Starting point of the program receives information from the user and 
//outputs accordingly.
int main( int argc, char *argv[] ) {
  // Make a shared memory segment one GameState in size
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/t/ttheis2", 1), BLOCK_SIZE, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );
    
  // Map the shared memory into my address space
  GameState* game = (GameState *)shmat( shmid, 0, 0 );
  if ( game == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if (argc == 4) {
    if (strcmp("move", argv[1])) {
//      mq_close( clientQueue );
//      mq_close( serverQueue );
      printf("error\n");
      exit(1);
    }

    //checks if the given row and col are valid
    char row;
    char col;
    if (argv[2][0] < '0' || argv[2][0] > '4') {
      shmdt(game);
      printf("Invalid row\n");
      exit(1);
    }
    if (argv[3][0] < '0' || argv[3][0] > '4') {
      shmdt(game);
      printf("Invalid col\n");
      exit(1);
    }
    if (strlen(argv[2]) != 1 || strlen(argv[3]) != 1) {
      shmdt(game);
      printf("Invalid args\n");
      exit(1);
    }

    row = argv[2][0] - '0';
    col = argv[3][0] - '0';
//     char buff[ 3 ];
//     buff[0] = row;
//     buff[1] = col;
//     buff[2] = '\0';

    newBoard(game);

      //makes the move using the makeMove helper method
      int idx = (row * 5) + col;
      if (col > 0 && col < 4) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx - 1 >= 0) {
          makeMove(game, idx - 1);
        }
        
        if (idx + 1 <= 24) {
          makeMove(game, idx + 1);
        }

      }
      else if (col == 0) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx + 1 >= 0) {
          makeMove(game, idx + 1);
        }
      }
      else if (col == 4) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx - 1 >= 0) {
          makeMove(game, idx - 1);
        }
      }
      game->flag = 1;
      printf("success\n");
      shmdt(game);
      exit(0);
    /**
     * 
     *
     *
     * Change this so that it uses memory instead of a send queue
     *
     *
     *
     */
   //  mq_send( serverQueue, buff, strlen(buff), 0);
//     
//     char buffer[ MESSAGE_LIMIT ];
// 
//     int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
//     
//     if (len >= 0) {
//       for (int i = 0; i < len; i++) {
//         printf("%c", buffer[i]);
//       }
//       printf("\n");
//     } else {
//       mq_close( clientQueue );
//       mq_close( serverQueue );
//       printf("Error receiving\n");
//     }
//     
//     if (buffer[0] == 'e') {
//       exit(1);
//     } else {
//       exit(0);
//     } 
  }
  
  if (argc == 2) {
  
    if(strcmp("undo", argv[1]) && strcmp("report", argv[1])) {
//       mq_close( clientQueue );
//       mq_close( serverQueue );
      printf("error\n");
      exit(1);
    }
    
    if (!strcmp("undo", argv[1])) {
     //  printf("got to undo\n");
      //char *u = "undo";
      if(game->flag) {
        undoMove(game);
        game->flag = 0;
        printf("success\n");
        shmdt(game);
        exit(0);
      } else {
        printf("error\n");
        shmdt(game);
        exit(1);
      }
      /**
       *
       *
       *
       * Change this so it uses memory instead of queues
       *
       *
       *
       */
//       mq_send(serverQueue, u, strlen(u), 0);  
//       
//       char buffer[ MESSAGE_LIMIT ];
// 
//       int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
// 
//       if (len >= 0) {
//         for (int i = 0; i < len; i++) {
//           printf("%c", buffer[i]);
//         }
//         printf("\n");
//       
//       }else {
//         mq_close( clientQueue );
//         mq_close( serverQueue );
//         printf("Error receiving\n");
//       }
//       
//       if (buffer[0] == 'e') {
//         exit(1);
//       } else {
//         exit(0);
//       }
    }
    
    if (!strcmp("report", argv[1])) {
      //printf("got to report\n");
      //char *r = "report";
      
      int linecnt = 0;
      for (int i = 0; i <= 24; i++) {
        if (linecnt == 5) {
          printf("\n");
          linecnt = 0;
          i--;
          continue;
        }
        printf("%c", game->newGame[i]);
        linecnt++;
      }
      printf("\n");
      shmdt(game);
      exit(0);
      

//     for (int i = 0; i <= 24; i++) {
//       printf("%d %c", i, game->newGame[i]);
//       printf("\n");
//     }

      
      /**
      *
      *
      *
      * Change this so it uses shared memory instead of message queues
      *
      *
      *
      */
//       mq_send(serverQueue,r, strlen(r), 0);
//     
//       char buff[ MESSAGE_LIMIT ];
//       //char *buffer = malloc(sizeof(char) * MESSAGE_LIMIT);
//       
//       int len = mq_receive(clientQueue, buff, sizeof(buff), NULL);
//      //  printf("%d\n", len);
//       if (len >= 0) {
//         int linecnt = 0;
//         //printf("1\n");
//         for (int i = 0; i <= 24; i++) {
//           if (linecnt == 5) {
//             printf("\n");
//             linecnt = 0;
//             i--;
//             //printf("2\n");
//             continue;
//           }
//           printf("%c", buff[i]);
//           //printf("3\n");
//           linecnt++;
//         }
//         printf("\n");
//         //free(buffer);
//         exit(0); 
//       } else {
//         mq_close( clientQueue );
//         mq_close( serverQueue );
//         printf("Error receiving\n");
//         //free(buffer);
//         exit(1);
//       }
    }
  } else {
//     mq_close( clientQueue );
//     mq_close( serverQueue );
    printf("error\n");
    shmdt(game);
    exit(1);
  }
  return 0;
}