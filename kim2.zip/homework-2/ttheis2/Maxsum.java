import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

/**
 * This class reads from the given input and gives back the maximum sum from the given
 * input using a provided number of threads to speed up the process. 
 * @author tadeotheis
 *
 */
public class Maxsum {

  /** Number of values on the list. */
  private static int vCount = 0;

  /** Input sequence of values. */
  private static ArrayList<Integer> vList;
  
  /** Number of workers */
  private static int workers = 0;
  
  /** Says if to report the local max or not for threads */
  private static boolean report = false;
  
  /** Shared variable all threads can see. */
  private static volatile int globalMax;
  
  /** Says if it is the first max or not used to initialize the max value */
  private static volatile Boolean firstThread = true;
  
  /** Array of threads to hold the multiple thread processes */
  private static MyThread[] thread;
  
  /** Stops a thread from accessing the global max when it is being initialized */
  private static Semaphore s = new Semaphore(1);
  
  /** Stops a thread from changing globalMax if another thread is changing it */
  private static Semaphore x = new Semaphore(1);
  
  /**
   * MyThread object that extends Thread. Changes Thread so that MyThread can have 
   * an int value associated to it. 
   */
  static class MyThread extends Thread {
  
    /** The place of this thread in the thread array */
    private int idx;

    
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( int idx ) {
      this.idx = idx;
    }

    /**
     * What this thread runs when it starts.
     */
    public void run() {
      int localMax = 0;
      //Iterates through different starting points for each child based on what worker
      //(i) it is and increments by the number of workers, as described in the write up.
      for(int j = this.idx; j < vCount; j += workers) {
        //the current max for this particular value of j has to be reset before each nested 
        //loop
        int currentMax = 0;
        //Starts at the value of j (index we want to count from) and ends at the end of 
        //the list adding at each index so that each individual 'max' calculation is linear
        for(int k = j; k < vCount; k++) {
          if(k >= vCount) {
            //prevents overflow
            break;
          }
          //increment the current max
          currentMax += vList.get(k);
          
          //update the global max if necessary
          if(currentMax > localMax) {
            localMax = currentMax;
          }
        }
        
        //initialize globalMax (only happens once)
        try {
		  s.acquire();
		} catch (InterruptedException e) {
		  e.printStackTrace();
		}
        if(firstThread) {
          //System.out.println("I entered the first thread section");
          globalMax = localMax;
          firstThread = false;
        }
        s.release();
        
        //changed globalMax if localMax is larger
        if(localMax > globalMax) {
          try {
			x.acquire();
		  } catch (InterruptedException e) {
			e.printStackTrace();
		  }
		  //System.out.println("I entered the change max section I am thread: " + thread[index].getId());
          globalMax = localMax;
          x.release();
        }
      }
      
      
      //report the threads local max if asked for
      if(report) {
        System.out.println("I'm thread " + thread[this.idx].getId() + ". The maximum sum I found is " + localMax + ".");
      }
    }
  }
  
  /**
   * Read the list of values.
   */
  private static void readList() {
    vList = new ArrayList<Integer>();
    try (Scanner scnr = new Scanner(System.in)) {
	  int v;
	  while(true) {
	    if(!(scnr.hasNextInt())) {
		  break;
		}
		v = scnr.nextInt();
		vList.add(vCount++, v);
	  }
	} catch(Exception e) {
	  fail("Failed to read in values");
	}
  }
  
  /**
   * Print out a usage message, then exit.
   */
  private static void usage() {
    System.out.println( "usage: maxsum <workers>" );
    System.out.println( "       maxsum <workers> report\n" );
    System.exit( 1 );
  }
  
  /**
   * Print out an error message and exit.
   */
  private static void fail( String message) {
    System.out.println(message);
    System.exit( 1 );
  }
  
  /**
   * Starting point of the program. Reads in args from the user and handles errors for 
   * incorrect output. Calculates the max of the given list using the specified number
   * of threads.
   *
   * @param args a String array of arguments provided by the user.
   */
  public static void main( String[] args ) {
  
    //System.out.println( "args length: " + args.length);
    if(args.length < 1 || args.length > 2) {
      //System.out.println( "got here 1" );
      usage();
    }

    try {
      //System.out.println( "got here 2" );
      workers = Integer.parseInt(args[0]);
      //System.out.println( "got here 3" );
    } catch(NumberFormatException e) {
      usage();
    }
  
    if(args.length == 2 && "report".equals(args[1])) {
      report  = true;
    }
  
    readList();
    
    //first loop that loops through the workers (only the parent goes through this)
    thread = new MyThread [ workers ];
    for(int i = 0; i < workers; i++) {
      thread[i] = new MyThread(i);
      thread[i].start();
    }
    
    // Wait for the new thread to exit.
    try {
      for(int i = 0; i < workers; i++) {
        thread[i].join(); //wait until all the child processes are done running
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    
    System.out.println("Maximum Sum: " + globalMax);
  }
}