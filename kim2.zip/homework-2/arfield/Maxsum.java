

import java.util.ArrayList;
import java.util.Scanner;
public class Maxsum {
  
  private static ArrayList<Integer> vList = new ArrayList<Integer>();
  private static int vCount = 0;

  static class sumThread extends Thread {
    
    private int start;
    private int offset;
    
    public int localMaxSum = Integer.MIN_VALUE;

    public sumThread( int start, int offset ) {
      this.start = start;
      this.offset = offset;
    }
  
    public void run() {
      int sum = 0;
      for ( int i = start; i < vCount; i += offset ) {
        for ( int j = i; j < vCount; j++ ) {
          sum += vList.get( j );
          if ( sum > localMaxSum ) {
            localMaxSum = sum;
          }
        }
        sum = 0;
      }
    }
  }

  public static void main( String[] args ) {
    boolean report = false;
    int workers = 4;

    if ( args.length < 1 || args.length > 2 || (args.length == 2 && args[ 1 ].compareTo( "report" ) != 0) ) {
      System.out.println( "usage: maxsum <workers>" );
      System.out.println( "       maxsum <workers> report" );
      System.exit( 1 );
    } else {
      try {
        workers = Integer.parseInt( args[0] );
      } catch ( NumberFormatException e ) {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit( 1 );
      }
    }

    if ( args.length == 2 ) {
      report = true;
    }

    Scanner scan = new Scanner( System.in );
    while ( scan.hasNext() ) {
      try {
        vList.add( Integer.parseInt( scan.nextLine() ) );
        vCount++;
      } catch( NumberFormatException e ) {
        System.out.println( "Invalid input file." );
        System.exit( 1 );
      }
    }

    sumThread[] thread = new sumThread [ workers ];
    for( int i = 0; i < workers; i++ ) {
      thread[ i ] = new sumThread( i, workers );
      thread[ i ].start();
    }
  
    int maxSum = Integer.MIN_VALUE; 
  
    try {
      for ( int i = 0; i < thread.length; i++ ) {
        thread[ i ].join();
        
        if ( report ) {
          System.out.println( "I’m thread " + thread[ i ].getId() + ". The maximum sum I found is " + thread[ i ].localMaxSum + "." );
        }

        if ( thread[ i ].localMaxSum > maxSum ) {
          maxSum = thread[ i ].localMaxSum;
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    
    System.out.println( "Maximum Sum: " + maxSum );

  }
}
