#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//game state pointer that will grab shared mem
static State *game;

/**
 * Updates position at board( r, c ) and the surrounding cells to the opposite of their current values 
 */
static void makeMove( int r, int c) {
  //Loop through cells surrounding the move position and update the character of the cardinal cells
  //if the row or col is out of bounds skip that column and row combination
  for (int row = r - 1; row <= r + 1; row ++) {
    for (int col = c - 1; col <= c + 1; col++ ) {
      //check that we are in a valid row and col
      if ( row >= 0 && row < GRID_SIZE && col >= 0 && col < GRID_SIZE ) {
        //exclude noncardinal cells
        if( row == r || col == c ) {
          //perform swap operation
          if ( game->board[ row ][ col ] == '*' ) {
            game->board[ row ][ col ] = '.';
          } else {
            game->board[ row ][ col ] = '*';
          }
        }
      }
    }
  }
}

/**
 *  Prints Board state to terminal
 */
static void printBoard() {
  for( int r = 0; r < GRID_SIZE; r++ ) {
    for( int c = 0; c < GRID_SIZE; c++ ) {
      printf( "%c", game->board[r][c] );
    }
    printf("\n");
  }
}

/**
 * Checks if char array is made solely of digits
 */
static bool isNumber( char *num ) {
  for(int i = 0; num[i] != '\0'; i++ ) {
    if(!isdigit(num[i]))
      return false;
  }
  return true;
}

int main( int argc, char *argv[] ) {
  // Checks that argnumber and command are a valid combination
  if ( argc < 2 || argc > 4 || ( strcmp( argv[1], "move" ) == 0 && argc != 4) ||
      ((strcmp( argv[1], "undo" ) == 0 || strcmp( argv[1], "report" ) == 0) && argc != 2)) {
    fail("error");
  }
  
  //get shared memory
  int shmid = shmget( ftok( "/afs/unity.ncsu.edu/users/a/arfield", 5 ), 0, 0 );
  if ( shmid == -1 )
    fail( "shmget failed" );

  game = (State *)shmat( shmid, 0, 0 );
  if ( game == (State *)-1 )
    fail( "failed to attach game" );

  if ( strcmp( argv[1], "move" ) == 0 ) {
    //Call move command, takes 2 additional arguments for row and col of move
    //error if row and col args are out of range (< 0 or >= GRID_SIZE ) or not numeric
    if ( !isNumber(argv[2]) || !isNumber(argv[3]) || atoi(argv[2]) >= GRID_SIZE || atoi(argv[2]) < 0 || atoi(argv[3]) >= GRID_SIZE || atoi(argv[3]) < 0 ) {
      fail("error");
    }
    
    int row = atoi( argv[2] );
    int col = atoi( argv[3] );
    makeMove( row, col );
    game->lastMove[0] = row;
    game->lastMove[1] = col;
    printf("success\n");
  } else if ( strcmp( argv[1], "undo" ) == 0 ) {
    //Run undo command by doing last move and reset lmove to fail state, if no last move exists (fail state)
    //send back fail message
    if ( game->lastMove[0] == GRID_SIZE || game->lastMove[1] == GRID_SIZE ) {
      fail("error");
    } else {
      makeMove( game->lastMove[0], game->lastMove[1] );
      game->lastMove[0] = GRID_SIZE;
      game->lastMove[1] = GRID_SIZE;
      printf("success\n");
    }
  } else if ( strcmp( argv[1], "report" ) == 0 ) {
    printBoard();
  }

  shmdt( game );

  return 0;
}
