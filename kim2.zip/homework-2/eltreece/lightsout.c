/**
 * @file lightsout.c
 * @author Ethan Treece (eltreece)
 * 
 * Retrieves the board information from shared memory and processes board operations.
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "error\n" );
  exit( EXIT_FAILURE );
}

// Stores the game state information in GameState struct
static GameState *sbuffer;

// Flips the 'light' by switching * and . characters
void flip(char *c) {
  if (*c == '*') {
    *c = '.';
  } else {
    *c = '*';
  }
}

// Processes the move operation
void move(char *x, char *y) {
  int r = *x - 48;
  int c = *y - 48;

  sbuffer->undo = 0;
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      sbuffer->temp[i][j] = sbuffer->arr[i][j];
    }
  }
  
  if (r == 0 && c == 0) { // top left
    flip(&sbuffer->arr[0][0]);
    flip(&sbuffer->arr[0][1]);
    flip(&sbuffer->arr[1][0]);
  } else if (r == 0 && c == 4) { // top right
    flip(&sbuffer->arr[0][4]);
    flip(&sbuffer->arr[0][3]);
    flip(&sbuffer->arr[1][4]);
  } else if (r == 4 && c == 4) { // bottom right
    flip(&sbuffer->arr[0][0]);
    flip(&sbuffer->arr[0][1]);
    flip(&sbuffer->arr[1][0]);
  } else if (r == 4 && c == 0) { // botttom left
    flip(&sbuffer->arr[4][0]);
    flip(&sbuffer->arr[3][0]);
    flip(&sbuffer->arr[4][1]);
  } else if (r == 0) { // top edge
    flip(&sbuffer->arr[0][c]);
    flip(&sbuffer->arr[0][c + 1]);
    flip(&sbuffer->arr[0][c - 1]);
    flip(&sbuffer->arr[1][c]);
  } else if (r == 4) { // bottom edge
    flip(&sbuffer->arr[4][c]);
    flip(&sbuffer->arr[4][c + 1]);
    flip(&sbuffer->arr[4][c - 1]);
    flip(&sbuffer->arr[3][c]);
  } else if (c == 0) { // left edge
    flip(&sbuffer->arr[r][0]);
    flip(&sbuffer->arr[r + 1][0]);
    flip(&sbuffer->arr[r - 1][0]);
    flip(&sbuffer->arr[r][1]);
  } else if (c == 4) { // right edge
    flip(&sbuffer->arr[r][4]);
    flip(&sbuffer->arr[r + 1][4]);
    flip(&sbuffer->arr[r - 1][4]);
    flip(&sbuffer->arr[r][3]);
  } else { // middle area
    flip(&sbuffer->arr[r][c]);
    flip(&sbuffer->arr[r + 1][c]);
    flip(&sbuffer->arr[r - 1][c]);
    flip(&sbuffer->arr[r][c + 1]);
    flip(&sbuffer->arr[r][c - 1]);
  }
}

// Processes the undo operation
void undo() {
  if (sbuffer->undo == 0) {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        sbuffer->arr[i][j] = sbuffer->temp[i][j];
      }
    }
    sbuffer->undo = 1; 
    printf("success\n");
  } else {
    fail("error");
  }
}

int main( int argc, char *argv[] ) {

  // Make a shared memory segment 1KB in size
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/eltreece/", 0), sizeof(GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  sbuffer = (GameState *)shmat( shmid, 0, 0 );
  if ( sbuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  if ( argc == 2 ) {
    if (strcmp( argv[ 1 ], "report" ) == 0) {
      for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
          printf("%c", sbuffer->arr[i][j]);
        }
        printf("\n");
      }
    } else if (strcmp( argv[ 1 ], "undo" ) == 0) {
      undo();
    } else {
      usage();
    }
  } else if (argc == 4) {
    if ( strcmp( argv[ 1 ], "move" ) != 0 ) {
      usage();
    } else {
      if (strlen(argv[2]) > 1 || strlen(argv[3]) > 1)
        usage();
      if (argv[2][0] < 48 || argv[2][0] > 52 || argv[3][0] < 48 || argv[3][0] > 52)
        usage();
      move(&argv[2][0], &argv[3][0]);
      printf("success\n");
    }
  } else {
    usage();
  }

  // Release our reference to the shared memory segment.
  shmdt( sbuffer );

  return 0;
}
