// Height and width of the playing area.
#define GRID_SIZE 5

// Size of the space of shared memory
#define BLOCK_SIZE 1024

/**
 * The GameState struct keep track of the current and previous board if an
 * undo is to take place
 * 
 */
typedef struct {
  char arr[GRID_SIZE][GRID_SIZE];
  char temp[GRID_SIZE][GRID_SIZE];
  int undo;
} GameState;
