import java.util.ArrayList;
import java.util.Scanner;

/**
 * @file Maxsum.java
 * @author Ethan Treece (eltreece)
 * 
 * The maxsum program's job is to use multiple processes and multiple CPU cores to solve
 * a computationally expensive problem more quickly. The task is to find a contiguous non-empty
 * subsequence within a sequence of positive and negative integer values that has the largest
 * sum. 
 * 
 */
public class Maxsum {

    // List that keeps all the values of the given text file
    public static ArrayList<Integer> list = new ArrayList<Integer>();

    // Number of workers
    public static int workers = 4;

    static class FindMax extends Thread {
        // The starting value to find the max
        public int start;
        // The max value for this thread
        public int max;
        // Constructor initializes the start value
        public FindMax(int start) {
            this.start = start;
        }

        public void run() {
            max = 0;
            for (int i = start; i < list.size(); i += workers) {
                int total = 0;
                for (int j = i; j < list.size(); j++) {
                    total += list.get(j);
                    if (total > max) {
                        max = total;
                    }
                }
            }
        }
    }

    // Print usage error message and then exit
    public static void usage() {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit( 1 );
    }

    public static void main( String[] args ) {
        if (args.length < 1 || args.length > 2) {
            usage();
        }
        try {  
            workers = Integer.parseInt(args[0]);
            if (workers < 1) {
                usage();
            }
        } catch(NumberFormatException e){
            usage(); 
        }
        if (args.length == 2 && !"report".equals(args[1])) { 
            usage(); 
        }

        // ArrayList of integers of given input
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            list.add(Integer.parseInt(scanner.nextLine()));
        }
        scanner.close();

        // Make a workers number of threads and let them start running
        FindMax[] threads = new FindMax[workers];
        for (int i = 0; i < workers; i++) {
            threads[i] = new FindMax(i);
            threads[i].start();
        }

        // Wait for each of the threads to terminate.
        try {
            for ( int i = 0; i < threads.length; i++ ) {
                threads[ i ].join();
            }
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }

        int max = 0;
        for (FindMax thread : threads) {
            if (args.length == 2)
                System.out.println("I'm thread " + thread.getId() + ". " + "The max sum I found is " + thread.max + ".");
            if (thread.max > max) {
                max = thread.max;
            }
        }
        System.out.println( "Maximum Sum: " + max );

    }
}
