/**
 * This program checks for the greatest sum using thread instead of pipe.
 * used the example files for reference
 * @author Arnav Sharma
 * @file maxsum.java
 *
 */
import java.util.*;
public class Maxsum {
    //number of values in the list
    private static int vCount;
    //number of workers
    private static int workers;
    private static int[] vList = new int[5];
    //report if true or false
    private static boolean report;
  static class MyThread extends Thread {
    private int oldSum;
    private int newSum;
    /** A parameter we're passing the thread, which
    number it's supposed to compute.*/
    private int x;
    
    /** Make a new Thread, giving it a parameter value to store.*/
    public MyThread( int x ) {
      this.x = x;
    }

    /** When run, I report in and compute number. */
    public void run() {
      for (int j = x; j < vCount; j = j + workers) {
                // make 0 every time to reset
                oldSum = 0;
                for (int l = j; l < vCount; l++) {

                    // adds them
                    oldSum = oldSum + vList[l];
                    if (newSum < oldSum) {
                        newSum = oldSum;
                    }
                }
            }
            if (report == true) {
                System.out.println("I’m thread " + getId() + ". The maximum sum I found is "
                       + newSum + ".");
            }
    }
  }

/**
 * Read the list of values.
 *
 */
  private static void readList() {
    Scanner in = new Scanner(System.in);
    int counter = 0;
    while(in.hasNextInt()) {
      if (counter == vList.length) {
      int[] listData = Arrays.copyOf(vList, vList.length * 2);
      vList = listData;
      }
      vList[counter] = Integer.parseInt(in.next());
      counter++;
    }
  }

/**
 * The main method puts everything together and checks for errors in arg length.
 * args.
 *
 */
  public static void main( String[] args ) {
    workers = Integer.parseInt(args[0]);
    //declare workers
    MyThread[] thread = new MyThread [workers];
    //check correct input length
    if (args.length != 2) {
      System.out.println("usage: maxsum <workers>");
      System.out.println("       maxsum <workers> report");
      System.exit(0);
    }

    //check correct input length
    if (!args[1].equals("report")) {
        System.out.println("usage: maxsum <workers>");
        System.out.println("       maxsum <workers> report");
        System.exit(0);
    }
    //set report
    report = true;

    //call read list to read numbers
    readList();
    vCount = vList.length;
    for ( int i = 0; i < thread.length; i++ ) {
      thread[i] = new MyThread( i + 1 );
      thread[i].start();
    }

    // Wait for each of the threads to terminate.
    try {
      int b = 0;
      int max = 0;
      for ( int i = 0; i < thread.length; i++ ) {
        thread[i].join();
        b = thread[i].newSum;
        if (max < b) {
            max = b;
      }
      }
      //printing sum
    System.out.println("Maximum Sum: " + max);
    } catch ( InterruptedException e ) {
      System.out.println("Interrupted during join");
    }
  }
}