import java.util.*;
import java.io.*;

public class Maxsum {
    
    private static ArrayList<Integer> vals;
    
    private static int workers;
    
    private static int size;

    static class MyThread extends Thread {
        private int start;
    
        public long finalMax;
    
        public MyThread( int start ) {
            this.start = start;
        }
    
        public void run() {
            int curMax = 0;
            for ( int p = start; p < size; p += workers ) {
                curMax = 0;
                for ( int j = p; j < size; j++ ) {
                    curMax += vals.get( j );
                    if ( curMax > finalMax ) {
                        finalMax = curMax;
                    }
                }
            }
        }
    }
    
    public static void main( String[] args ) {

        boolean report = false;;
        if ( args.length > 1 ) {
            report = ( args[ 1 ] ).equals( "report" );
        }
        workers = Integer.valueOf( args[ 0 ] );
        Scanner scan = new Scanner( System.in );
        vals = new ArrayList<Integer>();
        
        while ( scan.hasNextInt() ) {
            vals.add( ( Integer )scan.nextInt() );
        }
        size = vals.size();
        
        MyThread[] threads = new MyThread[ workers ];
        for ( int i = 0; i < threads.length; i++ ) {
            threads[ i ] = new MyThread( i );
            threads[ i ].start();
        }
        
        try {
            for ( int i = 0; i < threads.length; i++ ) {
                threads[ i ].join();
                if ( report == true ) {
                    System.out.println( "I'm thread " + threads[ i ].getId() 
                        + ". The maximum sum I found is " + threads[ i ].finalMax + "." );
                }
            }
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
        
        long maxSum = -90000;
        for ( int i = 0; i < workers; i++ ) {
            if ( threads[ i ].finalMax > maxSum ) {
                maxSum = threads[ i ].finalMax;
            }
        }
        System.out.println( "Maximum Sum: " + maxSum );
      
    }

}