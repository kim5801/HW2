// Height and width of the playing area.
#define GRID_SIZE 5

//path to home directory
char *path = "/afs/unity.ncsu.edu/users/a/ashill5";

//ftok constant
#define FTOK_ID 1

/**
 * Struct to represent the board
 */
typedef struct Board {
  int lx, ly;
  char board[GRID_SIZE][GRID_SIZE];
} Board;
