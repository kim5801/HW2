#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

int dl[] = {-1, 0, 1, 0}, cl[] = {0, 1, 0, -1};

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Method to check for valid int input
 * @param str string to parse
 * @return int converted int from string
 */
int checkInt(char const *str) {
  if (strcmp("0", str) == 0) {
    return 0;
  }
  int val = atoi(str);
  if (val == 0) {
    return -1;
  }
  if (val < 0 || val >= GRID_SIZE) {
    return -1;
  }
  return val;
}

/**
 * Method to check bounds in grid
 * @param x coordinate
 * @param y coordinate
 * @return true if in bounds
 */
bool inBounds(int x, int y) {
  return (x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE);
}

/**
 * Method to help swap characters
 * @param ch the initial char
 * @return the swapped char
 */
char swapChar(char ch) {
  return (ch == '*') ? '.' : '*';
}

/**
 * Method to apply operation on board
 * @param board the board state
 * @param x coordinate to move
 * @param y coordinate to move
 */
void applyOperation(Board *state, int x, int y) {
  state->board[x][y] = swapChar(state->board[x][y]);
  for (int i = 0; i < 4; i++) {
    int nx = x + dl[i], ny = y + cl[i];
    if (!inBounds(nx, ny))
      continue;
    state->board[nx][ny] = swapChar(state->board[nx][ny]);
  }
}

int main(int argc, char *argv[]) {

  //get board state
  Board *state;
  key_t id = ftok(path, FTOK_ID);

  //Make a shared memory segment of struct size
  int shmid = shmget(id, 0, 0);
  if (shmid == -1)
    fail("Can't create shared memory");

  Board *sbuffer = (Board *)shmat(shmid, 0, 0);
  if (sbuffer == (Board *)-1)
    fail( "Can't map shared memory segment into address space"  );
  
  state = sbuffer;

  //error check arguments
  int operation = 0, x = 0, y = 0;
  if (argc < 2 || argc > 4) {
    fail("error");
  }
  if (strcmp("move", argv[1]) == 0) {
    operation = 1;
    if (argc != 4) {
      fail("error");
    }
    x = checkInt(argv[2]);
    y = checkInt(argv[3]);
    if (!inBounds(x, y) || x == -1 || y == -1) {
      fail("error");
    }
  } else if (strcmp("undo", argv[1]) == 0) {
    operation = 2;
    if (argc != 2 || state->lx == -1) {
      fail("error");
    }
  } else if (strcmp("report", argv[1]) == 0) {
    operation = 3;
    if (argc != 2) {
      fail("error");
    }
  } else {
    fail("error");
  }
  
  //apply operations
  if (operation == 1) {
    applyOperation(state, x, y);
    state->lx = x;
    state->ly = y;
  } else if (operation == 2) {
    applyOperation(state, state->lx, state->ly);
    state->lx = -1;
    state->ly = -1;
  } else {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
        printf("%c", state->board[i][j]);
      }
      printf("\n");
    }
    return 0;
  }
  
  //save state to shared memory
  sbuffer = state; 
  
  //release reference
  shmdt(sbuffer);

  printf("success\n");

  return 0;
}
