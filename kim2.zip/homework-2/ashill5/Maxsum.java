import java.util.ArrayList;
import java.util.*;
import java.io.*;
import java.lang.Thread;

/**
 * Class to calculate the maxsum for HW2
 *
 */
public class Maxsum {
  
  /** field to hold shared array of elements */
  private static volatile ArrayList<Integer> list;

  /** field to count workers */
  private static volatile int work_num = 0;

  public static void usage() {
    System.out.println("usage: Maxsum <workers>");
    System.out.println("       Maxsum <workers>");
    System.exit(1);
  }

  /**
   * Method to be run by a single thread
   */
  static class Worker extends Thread {
  
    /** index to start calculation from */
    private int index;

    /** answer from computation */
    private int answer;
  
    /**
     * constructor for worker thread 
     * @param index the index to start from
     * */
    public Worker(int index) {
      this.index = index;
      this.answer = 0;
    }
    
    /**
     * Method to get the max
     */
    public int getMax() {
      return answer;
    }

    /**
     * Method to run with thread
     */
    public void run() {
      answer = calculate(index);
      for (int i = index + work_num; i < list.size(); i += work_num) {
        int val = calculate(i);
        if (val > answer) {
          answer = val;
        }
      }
    }

    /**
     * Method to calculate max from one index only
     * @param index place to start
     */
    private int calculate(int index) {
      int maxsum = list.get(index);
      int sum = maxsum;
      for (int i = index + 1; i < list.size(); i++) {
        sum += list.get(i);
        if (sum > maxsum) {
          maxsum = sum;
        }
      }
      return maxsum;
    }

    /**
     * Method to print thread message
     */
    void printWorker() {
      System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + this.answer + ".");
    }
  }

  public static void main(String[] args) {
  
    //arguments validation
    int argc = args.length;
    if (argc < 1 || argc > 2) {
      usage();
    }
    try {
      work_num = Integer.parseInt(args[0]);
    } catch (Exception e) {
      usage();
    }
    if (work_num <= 0) {
      usage();
    }
    if (argc == 2 && !args[1].equals("report")) {
      usage();
    }
    
    //scanner for input
    Scanner scanner = new Scanner(System.in);

    list = new ArrayList<Integer>();
    while (scanner.hasNextInt()) {
      list.add(scanner.nextInt());
    }
    
    //make threads
    Worker[] workers = new Worker[work_num];
    for (int i = 0; i < work_num; i++) {
      workers[i] = new Worker(i); 
      workers[i].start();
    }
    
    //calculate max
    int answer = list.get(0);
    try {
      for (int i = 0; i < work_num; i++) {
        workers[i].join();
        workers[i].printWorker();

        if (workers[i].getMax() > answer) {
          answer = workers[i].getMax();
        }
      }
    } catch (InterruptedException e) {
      System.out.println("Interrupted during join!");
    }

    System.out.println("Maximum Sum: " + answer);
  }
}
