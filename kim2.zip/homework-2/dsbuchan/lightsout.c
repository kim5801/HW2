/**
 * @file lightsout.c
 * @author Daniel Buchanan (dsbuchan)
 * Will access a GameState in shared memory. User can make move on the 
 * 5x5 board, undo a move, and report what the board looks like.
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** The third argument in command line*/
static int THIRD_ARG = 2;
/** The fourth argument in the command line*/
static int FOURTH_ARG = 3;
/** The number of arguments for move command*/
static int NUM_MOVE = 4;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// carries out a move
void move(GameState * game, char r, char c){

  // converting the row and column input characters to integers
  int row = r - '0';
  int col = c - '0';
  // set pointer to the grid
  char * grid = game->grid;
  if(row > (GRID_SIZE - 1) || col > (GRID_SIZE - 1)){
    fail("error");
  } else {
    // at cell
    if(grid[(row * (GRID_SIZE + 1)) + col] == '.'){
      grid[(row * (GRID_SIZE + 1)) + col] = '*';
    } else {
      grid[(row * (GRID_SIZE + 1)) + col] = '.';
    }
        
    // above cell
    if(row > 0){
      if(grid[(row - 1) * (GRID_SIZE + 1) + col] == '.'){
        grid[(row - 1) * (GRID_SIZE + 1) + col] = '*';
      } else {
        grid[(row - 1) * (GRID_SIZE + 1) + col] = '.';
      }
    }
    // below cell
    if(row < GRID_SIZE - 1){
      if(grid[(row + 1) * (GRID_SIZE + 1) + col] == '.'){
        grid[(row + 1) * (GRID_SIZE + 1) + col] = '*';
      } else {
        grid[(row + 1) * (GRID_SIZE + 1) + col] = '.';
      }
    }
    // left of cell
    if(col > 0){
      if(grid[(row * (GRID_SIZE + 1)) + col - 1] == '.'){
        grid[(row * (GRID_SIZE + 1)) + col - 1] = '*';
      } else {
        grid[(row * (GRID_SIZE + 1)) + col - 1] = '.';
      }
    }
    // right of cell
    if(col < GRID_SIZE - 1){
      if(grid[(row) * (GRID_SIZE + 1) + col + 1] == '.'){
        grid[(row) * (GRID_SIZE + 1) + col + 1] = '*';
      } else {
        grid[(row) * (GRID_SIZE + 1) + col + 1] = '.';
      }
    }
    // move is successful
    printf("success\n");
  }
  
}

// will take command line arguments for moves. 
// will save game state to the shared memory
int main( int argc, char *argv[] ) {
  int id = shmget( ftok("/afs/unity.ncsu.edu/users/d/dsbuchan", 1), 0, 0);
  if(id == -1){
    fail("error");
  }

  GameState * buffer = (GameState *)shmat(id, 0, 0);
  if(buffer == (GameState *) - 1){
    fail("error");
  }

  // read in command line argument
  if(0 == strcmp("move" , argv[1]) && argc == NUM_MOVE){
    // invalid arguments for move
    if(strlen(argv[THIRD_ARG]) > 1 || strlen(argv[FOURTH_ARG]) > 1){
      fail("error");

    }
    // charcter not valid for the coordinates
    if(argv[THIRD_ARG][0] < '0' || argv[THIRD_ARG][0] > '9'){
      fail("error");
    }
    if(argv[FOURTH_ARG ][0] < '0' || argv[FOURTH_ARG ][0] > '9'){
      fail("error");
    }

    // call move to enter a move
    move(buffer, argv[THIRD_ARG][0] , argv[FOURTH_ARG ][0]);
    // update undo and the previous move
    buffer->undo = true;
    buffer->prevMove[0] = argv[THIRD_ARG][0];
    buffer->prevMove[1] = argv[FOURTH_ARG ][0];
  } else if(0 == strcmp("undo" , argv[1])){
    // if undo is false, send error
    if(!(buffer->undo)){
      fail("error");
    } else {
      buffer->undo = false;
      // enter the privous move
      move(buffer, buffer->prevMove[0], buffer->prevMove[1]);
    }
  } else if(0 == strcmp("report" , argv[1])){
    // null terminated? if not then use this
    for(int i = 0; i < (GRID_SIZE + 1) * GRID_SIZE; i++){
      printf("%c", buffer->grid[i]);
    }
    
    //printf("%s", buffer->grid);
  } else {
    fail("error");
  }

  // detach from shared memory when program exits
  shmdt(buffer);
  return 0;
}
