import java.util.Scanner;
import java.lang.Thread;
import java.util.ArrayList;

/**
  * Creates threads to calculate the max sum within a list of integers.
  * @author Daniel Buchanan (dsbuchan)
 */
public class Maxsum{

    static class SumThread extends Thread{
        /** Stores the return value from the thread */
        public int sum;
        /** Stores the number of workers the system has */
        private int numWorkers;
        /** Which numbered worker is this thread */
        private int worker;
        /** the array of integers to work with */
        private ArrayList<Integer> data;

        /** 
         * Makes a new thread
         * @param numWorkers the number of different threads
         * @param worker which numbered thread is this
         * @param data list of integers
         */
        public SumThread(int numWorkers, int worker, ArrayList<Integer> data){
            this.sum = 0;
            this.numWorkers = numWorkers;
            this.worker = worker;
            this.data = data;
        }

        /** 
         * Calculate the sum for this thread 
         */
        public void run(){
            // outer loop to jump the length of workers
            for(int k = this.worker; k < this.data.size(); k += this.numWorkers){
                int currSum = 0;
                for(int i = k; i < this.data.size(); i++){
                    currSum += this.data.get(i);
                    if(currSum > this.sum){
                        this.sum = currSum;
                    }
                }   
            }   
        }
    }

    /** 
     * Reads in the input into an array 
     */
    public static ArrayList<Integer> read(){
        // creating array of integers
        ArrayList<Integer> arr = new ArrayList<Integer>();
        Scanner scan = new Scanner(System.in);
        while(scan.hasNextInt()){
            arr.add(scan.nextInt());
        }
        return arr;
    }

    public static void main(String[] args){
        // error handle for invalid arguments

        int numWorkers = 1;
        boolean report = false;
        // take in commands 
        // credit: Oracle java documentation
        if(args.length > 0){
            try{
                numWorkers = Integer.parseInt(args[0]);
            } catch(NumberFormatException e){
                System.err.println("Invalid format");
                System.exit(1);
            }
        }
        // if report is entered in the command line
        if(args.length > 1){
            if(args[1].equals("report")){
                report = true;
            } else {
                System.err.println("Invalid format");
                System.exit(1);
            }

        }
        


        // read in all the integers 
        ArrayList<Integer> arr = read();
        int max = 0;
        // create threads to be workers
        SumThread[] thread = new SumThread[numWorkers];
        for(int i = 0; i < numWorkers; i++){
            thread[i] = new SumThread(numWorkers, i, arr);
            thread[i].start();
        }

        // join back with each thread after each thread calculates its sum
        try{
            for(int i = 0; i < numWorkers; i++){
                thread[i].join();
                if(report){
                    System.out.println("I'm process " + thread[i].getId() + ". The maximum sum I found is " + thread[i].sum + ".");
                }
                if(thread[i].sum > max){
                    max = thread[i].sum;
                }
            }
        } catch(InterruptedException e){
            System.out.println("Threads failed");
        }
        // prints the max sum
        System.out.println("Maximum Sum: " + max);

    }
}