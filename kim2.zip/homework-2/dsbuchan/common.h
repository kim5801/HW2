// Height and width of the playing area.
#define GRID_SIZE 5

typedef struct GameState{
    /** Stores the grid for the game*/
    char grid[(GRID_SIZE + 1) * GRID_SIZE];
    /** Stores the coordinates of the previous move*/
    char prevMove[2];
    /** If an undo is a valid command*/
    _Bool undo;
} GameState;


