// Import the Scanner class to read text files
import java.util.*; 

/**
* @file Maxsum.java
* @author dsmathur
* This file includes functions to obtain the maximum sum
* out of the different sequences possible. This is 
* completed by using different threads to computationally
* derive the maximum sum in each scenario, and then combine
* all the output sums together to find the maxSum.
*/
public class Maxsum {
    private static final int INITIAL_CAPACITY = 5;
    
    //Input sequence of values 
    private static int [] vList = new int [INITIAL_CAPACITY];
    
    //Number of values on the list
    private static int vCount  = 0;
    
    //Capacity of the list of values
    private static int vCap = INITIAL_CAPACITY;
    
    // The number of threads to run within the same process
    private static int threads  = 0;
    
    /**
    * Prints the usage statement if the number 
    * of arguments
    *
    */
    private static void usage() {
        System.out.println( "usage: maxsum <workers>\n" );
        System.out.println( "       maxsum <workers> report\n" );
        System.exit(1);
    }
    
    /** 
    * The maxthread class that performs the computations,
    * of calculating the maximum sum given the range start 
    * index.
    */
    static class MaxThread extends Thread {    
        
        /** A variable that holds the start index of each range the worker focuses on */
        private int rangeStartIndex;
        
        /** The return value from the thread */
        public int  maxValue;
        
        //A variable to hold the maximum sum from the workers
        int maxSum;
        
        /** Make a new thread  giving it a parameter value to store */
        public MaxThread(int index){
            this.rangeStartIndex = index;
        }
        
        /**
        * Runs the thread given the range start index and 
        * calculates the maximum sum
        */
        public void run(){
            /** When i run , i perform certain operations */
            for(int i  = rangeStartIndex;i < vCount;){
                int sum = 0;
                for(int j = i ; j < vCount; j++){
                    sum = sum + vList[j];
                    if(sum > maxSum){
                        maxSum = sum;
                    }
                }
                //Go to next range start index
                i = i + threads;
            }
            maxValue = maxSum;
        }
    }
    
    /**
    * The main class that creates all of the threads
    * and prints out the report if asked along with 
    * the maximum sum found for each thread.
    * @param args arguments in the main
    */
	public static void main(String[] args) {
        boolean report = false;
        
        //Initializing the number of workers to be 4 , default, if not specified
        threads = 4;
        
        //Need a scanner to obtain input from the file 
        Scanner scnr  = new Scanner(System.in);
        
        //Parse the command line arguments
        if(args.length < 1 || args.length > 2) {
            usage();
        }
        //If the command line arguments cannot be read as an int,
        // for the number of workers , then the program should fail 
        try{
            threads = Integer.parseInt(args[0]);
        }catch(NumberFormatException e ) {
            System.out.println(args[0]);
            usage();
        }
        
        //The program should also fail , as the number of workers 
        // cannot be less than 1
        if(threads < 1) { 
            usage();
        }
        
        if(args.length == 2) {
            //If there are two arguments, but the second argument 
            // is not a "report" then the program should exit. 
            if(!args[1].equals("report")) {
                usage();	
            }
            //Otherwise mark report as true
            report = true;
        }
        int value = 0;
        
        //Keep reading until input is available in the file 
        while(scnr.hasNextLine()){
            //Need to create a bigger array in case the count of elements
            // is greater than the capacity . 
            if(vCount >= vCap){
                vCap*=2;
                int [] newvList = new int [vCap];
                for(int i = 0 ; i < vList.length;i++){
                    newvList[i] = vList[i];
                }
                vList = newvList;
            }
            //Taking each character from the file and parse
            // it has an integer in order to obtain the sequence
            // of integers to work on 
            value = Integer.parseInt(scnr.nextLine());
            vList[vCount++] = value;
        }
        
        //A start range index that each thread will have in order to 
        // keep track of which ranges to work on 
        int rangeStartIndex = 0 ;
        
        //Make number of worker  threads
        MaxThread[] thread = new MaxThread[threads];
        for(int i  = 0 ; i < thread.length;i++){
            thread[i] = new MaxThread(rangeStartIndex);
            thread[i].start();
            rangeStartIndex++;
        }
        
        //An array to keep record of the maximum sums in each thread
        int [] maxArray = new int[threads];
        //Wait for all the threads to terminate
        try{
            for(int i = 0 ; i < thread.length;i++){
                thread[i].join();
                //Before they exit , take the maximum value from each thread and store it
                maxArray[i] = thread[i].maxValue;
                
                //If the threads were required to report their pid and their individual 
                // max sum then they should print the following 
                if(report){
                    System.out.println("I'm thread " + thread[i].getId() + " The maximum sum I found is " + thread[i].maxValue);
                }
            }
        }catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
        
        //Go through all of the values in the max array
        int max = maxArray[0];
        for(int i = 1 ; i < threads; i ++){
            if( maxArray[i] > max){
                max  = maxArray[i];
            }
        }
        
        //Print the maximum sum
        System.out.println("Maximum sum: " + max);
        
        //Closing the scanner
        scnr.close();
        
    }
}
