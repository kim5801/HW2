// Height and width of the playing area.
#define GRID_SIZE 5

/** A struct defined for storing the states of the board */
typedef struct{
    /** A character array for the current state of the board*/
    char currentboard[GRID_SIZE][GRID_SIZE];
    /** A character array for the previous state of the board*/
    char previousboard[GRID_SIZE][GRID_SIZE];
    /** A boolean representing the undo operation*/
    bool undo;
}GameState;