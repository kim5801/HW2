/**
* @file reset.c
* @author dsmathur
* This class focuses on creating a shared memory 
* segment representing the board struct.
* It also reads the board file and performs invalid checks.
* It asks for a board file as an input and creates a struct
* which is according to the board proposed. This struct 
* is saved a shared memory segment.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

/**
* The main class of the file . It creates the shared memory segment
* and reads in the board file and performs checks while creating
* the struct and setting up the fields.
* @param argc the number of arguments
* @param argv the arguments entered
* @return an int of  whether the program successfully exited or not
*/
int main( int argc, char *argv[] ) {
    if ( argc !=2){
        usage();
        //Free the struct created
        exit( 1 );
    }
    //Open the file for read only purposes
    int fd = open(argv[1],O_RDONLY);
    
    //If the given board file is invalid (if the file does not exist)
    if(fd < 0){
        printf("Invalid input file: %s\n",argv[1]);
        exit(1);
    }
    
    /** Making a shared memory, this only creates a shared memory segment, it is not assigned yet*/
    int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/d/dsmathur",0), sizeof(GameState), 0666 | IPC_CREAT );
    //If shared memory cant be made , then fail 
    if ( shmid == -1 ){
        fail( "Can't create shared memory" );
    }
    
    //Similar to creating a new instance of GameState
    GameState *board = (GameState * )shmat(shmid,0,0);
    
    //Initializing the undo operation to be false
    board -> undo = 0;  
    
    //Initializing an array that will hold the contents of the board
    // file, that is the state of the lights in the board game
    char readArray[GRID_SIZE + 1];
    //A variable representing if a file is invalid 
    bool invalidfile = 0;
    
    //To count the number of rows in the board file and perform invalid checks
    int countrows = 0;
    
    //The number of bytes read in to the array, is represented by len 
    int len =  read(fd,readArray,sizeof(readArray));    
    
    //While there is something left to read off from the file
    while(len > 0){
        //if 6 columns are not read then that indicates this is an invalid file
        if(len != GRID_SIZE + 1){
            invalidfile = 1;
            break;
        }
        //Go through all the characters and check if they match the requirements
        // for the board file
        //Performing invalid checks
        for(int i = 0 ; i < len;i++){
            if(readArray[i] != '\n'){
                board->currentboard[countrows][i] = readArray[i];
            }
            if(readArray[i] != '*' && readArray[i] != '\n' && readArray[i] != '.'){
                invalidfile = 1;
                break;
            }
        }
        if(invalidfile){
            break;
        }
        countrows++;
        
        //Continue reading from the file
        len =  read(fd,readArray,sizeof(readArray));
    }
    
    //If the number of rows is not five, the program should fail
    if(countrows != GRID_SIZE){
        invalidfile = 1;
    }
    
    //If the file is invalid, exit 
    if(invalidfile){
        printf("Invalid input file: %s\n",argv[1]);
        shmdt( board );
        exit(1);
    }
    
    return 0;
}

