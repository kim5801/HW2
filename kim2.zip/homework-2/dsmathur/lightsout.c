/**
* @file lightsout.c
* @author dsmathur
* This file includes all the operations of the 
* board game ranging from move to report.
* It takes in the commands from the user and uses
* a shared memory segment created from reset.c 
* in order to make the corresponding updates 
* to the board.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** String used for printing success to the terminal */
#define SUCCESS "success\n"

/** String  used for representing the move command in the server message queue*/
#define MOVE "move"

/** String used for representing the undo command in the server message queue*/
#define UNDO "undo"

/** String used for representing the report command in the server message queue*/
#define REPORT "report"

/** A constant used for the error message */
#define ERROR_MESSAGE "error"

/** Used for recording the values from the board file */
#define MESSAGE_LIMIT 37

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/**
* The main program in lightsout.c that takes in arguments
* and accesses the shared memory created by reset.c 
* in order to update the boards according to the commands
* entered by the user.
* @param argc  the number of arguments
* @param argv the arguments in a char pointer array
* @return an int of  whether the program successfully exited or not
*/
int main( int argc, char *argv[] ) {
    
    //Access the shared created memory segment
    int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/d/dsmathur",0),0,0);
    if ( shmid == -1 )
        fail( "Can't create shared memory" );
    
    //Similar to creating a new instance of GameState
    GameState *board = (GameState * )shmat(shmid,0,0);
    // To represent whether a given command entered is valid or not
    bool invalidCommand = 0;
    
    if(argc  == 1){
        fail(ERROR_MESSAGE);
    }
    //if the operation performed was move , then 
    //follow the given approach 
    if(strcmp(argv[1],MOVE) == 0){
        if(argc != 4){
            fail(ERROR_MESSAGE);
        }
        
        //Read the arguments related to the rows and columns
        // in integer terms
        int row = atoi(argv[2]);
        int column = atoi(argv[3]);
        
        //Performing some invalid checks
        //If the row was not zero and the return value of 
        // atoi() function is 0 , this indicates that 
        // an error occurred with regards to processing the 
        // row value as an integer.
        if(strcmp(argv[2], "0") != 0){
            if(row <= 0  || row >= GRID_SIZE){
                invalidCommand = 1;
            }
        }
        
        //If the column was not zero and the return value of 
        // atoi() function is 0 , this indicates that 
        // an error occurred with regards to processing the 
        // column value as an integer.
        if(strcmp(argv[3], "0") != 0){
            if(column<=0  || column >= GRID_SIZE){
                invalidCommand = 1;
            }
        }
        
        //If it was an invalid move command, 
        // the program should fail
        if(invalidCommand){
            fail(ERROR_MESSAGE);
        }
        
        //Save the previous state of the board before making any changes
        for(int i = 0 ; i < GRID_SIZE;i++){
            for(int j=0; j < GRID_SIZE;j++){
                board-> previousboard[i][j] = board ->currentboard[i][j];
            }
        }
            
        //Perform the move operations required for the
        // current place in the board
        if(board -> currentboard[row][column] == '.'){
            board->currentboard[row][column] = '*'; 
        }
        else if(board->currentboard[row][column] == '*'){
            board->currentboard[row][column] = '.';
        }    
        //Check the place above, the current row,column index
        //Perform this only if there is an available row above
        if(row -1 >= 0 ){
            if(board->currentboard[row -1][column] == '.'){
                board->currentboard[row-1][column] = '*';
            }
            else if(board->currentboard[row - 1][column] == '*'){
                board->currentboard[row-1][column] = '.';
            }    
        }    
        //Check the place below
        //Perform this only when a row is available below
        if(row + 1 <= GRID_SIZE -1  ){
            if(board->currentboard[row + 1][column] == '.'){
                board->currentboard[row+1][column] = '*';
            }
            else if(board->currentboard[row + 1][column] == '*'){
                board->currentboard[row+1][column] = '.';
            } 
        }    
        //Check the place to the right
        //Perform this only when a column is available to the right
        if(column + 1 <= GRID_SIZE -1){
            if(board->currentboard[row][column + 1] == '.'){
                board->currentboard[row][column + 1] = '*';
            }
            else if(board->currentboard[row][column + 1] == '*'){
                board->currentboard[row][column + 1] = '.';
            }
        }
            
        //Check the place to the left
        //Perform this only when a column is available to the left 
        if(column - 1 >= 0 ){
            if(board->currentboard[row][column - 1] == '.'){
                board->currentboard[row][column - 1] = '*';
            }
            else if(board->currentboard[row][column -1] == '*'){
                board->currentboard[row][column - 1] = '.';
            }
        }
            
        //Since a move operation has been performed 
        // we can set undo to true indicating that an undo  
        // operation can be performed after this
        board->undo = 1;
        
        //Print success if the move operation was successful
        printf("success\n");
            
    }
    
    //If the command to be performed is undo
    else if(strcmp(argv[1],UNDO) == 0){
        //Performing invalid checks on the undo operation command
        if(argc != 2){
            fail(ERROR_MESSAGE);
        }
        if(board->undo == 0){
            fail(ERROR_MESSAGE);
        }
        
        //Copying the items in the previous state of the gameboard
        // to the current state in order for the undo operation 
        // to be carried out successfully.
        for(int i = 0  ; i < GRID_SIZE;i++){
            for(int j = 0; j < GRID_SIZE;j++){
                board->currentboard[i][j] = board->previousboard[i][j];
            }
        } 
        //Set undo back to false as undo has been performed now
        board->undo = 0;
        //Print success if the undo operation was successful
        printf("success\n");
    }
    
    //If the command issued was report instead , then the program   
    //should print  the current state of the board.
    else if(strcmp(argv[1],REPORT) == 0){
        if(argc != 2){
            fail(ERROR_MESSAGE);
        }
        
        //Initializing a char array to hold the current state of the board
        char sendReport[MESSAGE_LIMIT];
        int charcount = 0;
        for(int i = 0 ; i < GRID_SIZE;i++){
            for(int j = 0 ; j < GRID_SIZE;j++){
                sendReport[charcount++] = board -> currentboard[i][j];
            }
            sendReport[charcount++] = '\n';
        }
        //Putting a null terminator at the end of this character array
        sendReport[charcount] = '\0';
        printf("%s",sendReport);
    }
    else{ 
        fail(ERROR_MESSAGE);
    }
    
    return 0;
}
