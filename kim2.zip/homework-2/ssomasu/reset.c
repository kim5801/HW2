/**
 * @file reset.c
 * @author Sarvesh Somsaundaram ssomasu
 * Program to load in the board and load the GameState
 * 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // check to make sure the correct number of arguments is passed in
  if ( argc != 2 ) {
    usage();
  }

  // check to make sure the file is valid
  FILE *fp = fopen( argv[ 1 ], "r" );
  if ( fp == NULL) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( 1 );
  }

  // get a unique key using ftok()
  key_t uniqID = ftok( "/afs/unity.ncsu.edu/users/s/ssomasu", 1 );

  //create the shared memory using the size of GameState and shmget
  int shmid = shmget( uniqID, sizeof(GameState), 0666 | IPC_CREAT );

  // check to make sure the shared memory segment was created
  if (shmid == -1 )
    fail("Can't create shared memory");
  
  // create the game board and initialize all values from the input file
  GameState *board = (GameState *)shmat(shmid, NULL, 0);

  // load the values into the Board struct
  for ( int i = 0; i < 5; i++ ) {
    fgets( board->boardState[i], 6, fp );
    // check that the characters are valid in the board
    for ( int j = 0; j < 5; j++ ) {
      // update the previous board as well
      board->prevBoard[i][j] = board->boardState[i][j];
      // if a charater is invaid exit
      if (board->boardState[i][j] != '.' && board->boardState[i][j] != '*') {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
      }
    }
    // skip the new line character at the end
    fgetc( fp );
  }

  // set the undo state to false, a move must be made first
  board->canUndo = false;

  // close open files
  fclose( fp );
  
  return 0;
}

