#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// initialize the board
GameState *board;

// function to return a string value of the board to send to the client and to print
char *printBoard(GameState *board) {
  char *boardString = (char *) malloc( 30 * sizeof(char));
  int k = 0;
  for ( int i = 0; i < 5; i++ ) {
    for ( int j = 0; j < 5; j++ ) {
      boardString[k] = board->boardState[i][j];
      k++;
    }
    boardString[k] = '\n';
    k++;
  }
  return boardString;
}


// a function to update the previous board after each move so that an undo move can restore the old board
void *updatePrevBoard() {
  for ( int i = 0; i < 5; i++ ) {
    for ( int j = 0; j < 5; j++ ) {
      board->prevBoard[i][j] = board->boardState[i][j];
    }
  }

  return NULL;
}

// a function to change the value from an asterisk to a period for any given index
void *changeValue(int i, int j) {
  if ( i >= 0 && i <= 4 && j >= 0 && j <= 4 ) {
    if(board->boardState[i][j] == '*') {
      board->boardState[i][j] = '.';
    }
    else {
      board->boardState[i][j] = '*';
    }
  }

  return NULL;
}

int main( int argc, char *argv[] ) {
  
  // check if the number of arguments is correct, either one argument or 3 arguments
  if (argc != 2 && argc != 4) {
    fail("Invalid number of arguments given");
  }

  // use the same key used in the reset program to get the shared memory
  key_t uniqID = ftok("/afs/unity.ncsu.edu/users/s/ssomasu", 1);
  int shmid = shmget(uniqID, 0, 0);

  // get board from memory
  board = (GameState *)shmat(shmid, NULL, 0);


  // check if the first argument matches report
  if ( strcmp( argv[ 1 ], "report" ) == 0) {
    // check to make sure correct number of args are present
    if (argc != 2) {
      fail( "Invalid number of arguments" );
    }
    printf("%s", printBoard(board));
        
  } 
  
  // check if the argument is undo
  else if ( strcmp( argv[ 1 ], "undo") == 0) {
    // check to make sure correct number of args are present
    if (argc != 2) {
      fail( "Invalid number of arguments" );
    }
    // if an undo operation is allowed then reset the current state to the previous state
    if (board->canUndo) {
      for ( int i = 0; i < 5; i++ ) {
        for ( int j = 0; j < 5; j++ ) {
          board->boardState[i][j] = board->prevBoard[i][j];
        }
      }
      printf("success\n");
    } 
    // if an undo is not allowed send an error message
    else {
      fail("error");
    }
    // undo only has a one step use so another move must be made before undo can be called again
    board->canUndo = false;

  }


  // check to see if the argument was move
  else if ( strcmp( argv[1], "move") == 0) {
    // check to make sure the index values are present as well
    if (argc != 4) {
      fail( "Invalid number of arguments" );
    }

    // check to make sure no nonsense values get through as index values
    if (atoi(argv[2]) == 0 && strcmp(argv[2], "0") != 0) {
      fail("error");
    }
    else if (atoi(argv[3]) == 0 && strcmp(argv[3], "0") != 0) {
      fail("error");
    }
    
    // indexes for values
    int index1 = atoi(argv[2]);
    int index2 = atoi(argv[3]);

    // check the index values to make sure they are valid
    if (index1 < 0 || index1 > 4 || index2 < 0 || index2 > 4) {
      fail("error");
    }

    // update the previous board first to save vals, then change the current values based on which index is chosen
    else {
      updatePrevBoard();
      changeValue(index1, index2);
      changeValue(index1 - 1, index2);
      changeValue(index1 + 1, index2);
      changeValue(index1, index2 - 1);
      changeValue(index1, index2 + 1);

      // set undo to true since a move has been made
      board->canUndo = true;
      // send a success message to the client
      printf("success\n");
    }
  }
  // if an invalid command is entered, fail
  else {
    fail("error");
    exit( 1 );
  }
  return 0;
}

