import java.util.ArrayList;
import java.util.Scanner;

/**
 * A java class to test multithreads in the maxsum program
 */
public class Maxsum {
    // Input sequence of value
    static ArrayList<Integer> vList;

    // Number of values on the list
    static int vCount = 0;

    // report flag
    static boolean report = false;

    // Usage error
    public static void usage() {
        System.out.println("usage: maxsum <workers>\n       maxsum <workers> report");
        System.exit(1);
    }

    //read input
    public static void readList() {
        // a scanner to read in values
        Scanner scnr = new Scanner(System.in);
        // an arraylist to read vales to
        vList = new ArrayList<>();

        // read values from stdin
        while (scnr.hasNextInt()) {
            vList.add(scnr.nextInt());
            vCount++;
        }
        // close the scanner
        scnr.close();
    }

    // a class to create the thread
    static class MyThread extends Thread {
        // the start index to find max sum
        private int startIndex;
        // the end index to find max sum
        private int endIndex;
        // keep track of the sum
        private int sum;
        // report the max
        public int max;
        
        // The constructor for the thread
        public MyThread( int startIndex, int endIndex) {
          this.startIndex = startIndex;
          this.endIndex = endIndex;
          this.max = Integer.MIN_VALUE;
          this.sum = 0;
        }
        
        // function to run to find max sum
        public void run() {
            for ( int i = startIndex; i < endIndex; i ++ ) {
                sum = 0;
                for ( int j = i; j < vCount; j++ ) {
                    sum += vList.get(j);
                    if ( sum > max ) {
                        max = sum;
                    }
                }
            }
            // check if the report flag is on
            if (report) {
                System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + max + ".");
            }
        }
      }

    public static void main(String[] args) {
        // initialize workers
        int workers = 4;

        // check conditions
        if ( args.length < 1 || args.length > 2) {
            usage();
        }
        
        try {
            workers = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            usage();
        }
        // activate report if flag is present
        if (args.length == 2) {
            if( args[1].compareTo("report") != 0) {
                usage();
            }
            report = true;
        }

        // read the lsit in
        readList();
        // calculate the number of splits to do
        int numSplits = vCount / workers;

        // initialize the threads
        MyThread[] threads = new MyThread[workers];

        // create all threads and enter the start and end index
        for (int i = 0; i < threads.length; i++ ) {
            // determine the start index for the worker
            int startIndex = 0 + ( i * numSplits );
            // determine the index to go to for each worker
            int endIndex = numSplits + startIndex;
            threads[i] = new MyThread(startIndex, endIndex);
            threads[i].start();
        }

        
        int max = Integer.MIN_VALUE;
        // wait for threads to close and check if the final max value from each thread is the max
        try {
            for (int i = 0; i < threads.length; i++) {
                threads[ i ].join();
                if (threads[i].max > max) {
                    max = threads[i].max;
                }
            }
        } catch (InterruptedException e) {
            System.out.println( "Interrupted during join!" );
        }

        // report final max
        System.out.println("Maximum Sum: " + max);

    }
    
}
