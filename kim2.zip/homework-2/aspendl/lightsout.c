#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>

#include "common.h"

// If COND evaluates true on argc and the ARGVth argument matches CMD, return the return value of ACT
// The calling parentheses of ACT are written outside of the macro
#define cmdeval(COND, ARGV, CMD, ACT) if (argc COND && strcmp(argv[ARGV], CMD) == 0) return ACT

// Macro for toggling a space on a board
#define tglbrd(IDX) gs->spaces[IDX] = gs->spaces[IDX] == '.' ? '*' : '.'

// Print out an error message and exit.
static void fail(char const* message) {
	fprintf(stderr, "%s\n", message);
	exit(1);
}

// Validate move arguments
int doMove(char* rstr, char* cstr) {
	GameState gs = getGameState();
	int idx, r, c;

	// Setup
	if (rstr != NULL && cstr != NULL) { // Normal mode
		// Validate arguments
		if (sscanf(rstr, "%d", &r) != 1 || sscanf(cstr, "%d", &c) != 1 ||
			r < 0 || GRID_SIZE <= r || c < 0 || GRID_SIZE <= c)
			fail("error");
		// Get move parameters
		gs->undo = idx = r * ROW_SIZE + c;
	} else { // Undo mode
		// Get move parameters
		idx = gs->undo;
		r = idx / ROW_SIZE;
		c = idx % ROW_SIZE;
		gs->undo = -1;
	}

	// Perform move
	tglbrd(idx);
	if (c > 0) tglbrd(idx - 1);
	if (r > 0) tglbrd(idx - ROW_SIZE);
	if (c < GRID_SIZE - 1) tglbrd(idx + 1);
	if (r < GRID_SIZE - 1) tglbrd(idx + ROW_SIZE);
	printf("success\n");
	shmdt(gs);
	return 0;
}

// Report board state
int doReport() {
	GameState gs = getGameState();
	printf(gs->spaces);
	shmdt(gs);
	return 0;
}

int main(int argc, char* argv[]) {
	// Try to match each command
	// cmdeval(argc condition, which argv, compare to string, which function to call)
	cmdeval(== 4, 1, "move", doMove)(argv[2], argv[3]);
	cmdeval(== 2, 1, "report", doReport)();
	cmdeval(== 2, 1, "undo", doMove)(NULL, NULL); // Sentinel values for undo
	// Failed to match to any command
	fail("usage: lightsout [report|undo]\n       lightsout move [r] [c]");
	return 1;
}
