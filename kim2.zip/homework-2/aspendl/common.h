// Height and width of the playing area.
#define GRID_SIZE 5
// Width of each row (my implementation includes '\n' to make printing simpler)
#define ROW_SIZE (GRID_SIZE + 1)

// Board state and info (game state)
struct GS {
	char spaces[GRID_SIZE * ROW_SIZE + 1]; // One extra column to contain the newlines and one extra char for null terminator
	int undo; // Index of most recent move
};
typedef struct GS* GameState; // So I don't have to type * every time

// Print out the errno code, its description, and an error message, then exit.
// Return value is present so it can be used in the condition clause of the macro 'msgqr'
static int fail_errno(char const* message) {
	fprintf(stderr, "Error %d: %s\n%s\n", errno, strerror(errno), message);
	exit(1);
	return 1;
}

// Load GameState struct from shared memory
GameState getGameState() {
	key_t shmemkey = ftok("/afs/unity.ncsu.edu/users/a/aspendl", 'a');
	if (shmemkey == -1) fail_errno("Couldn't generate shared memory key!");
	int seg_id = shmget(shmemkey, sizeof(struct GS), IPC_CREAT | 0666);
	if (seg_id == -1) fail_errno("Couldn't create shared memory block!");
	GameState gs = (GameState)shmat(seg_id, NULL, 0);
	if (gs == ((GameState)-1)) fail_errno("Couldn't attach to shared memory block!");
	return gs;
}
