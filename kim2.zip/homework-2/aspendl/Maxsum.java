import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Maxsum {
    static class MaxSumR extends Thread {
        private int maxSum;
        private int startIndex;

        public MaxSumR(int start) {
            startIndex = start;
        }

        public int getMaxSum() {
            return maxSum;
        }

        @Override
        public void run() {
            int idx, sum;
            // The way this works is that each index 'i' basically gets threads[i % workers]
            // Set starting point of sum range (in increments of #workers)
            for (maxSum = vList.get(startIndex); startIndex < vList.size() - 1; startIndex += workers)
                // Check all ranges from the starting point
                for (idx = startIndex + 1, sum = vList.get(startIndex); idx < vList.size(); idx++)
                    // If the running total is larger than the max sum...
                    if (maxSum < (sum += vList.get(idx)))
                        // ...set maxSum to the new value.
                        maxSum = sum;
            // Report
            if (report)
                System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", currentThread().getId(), maxSum);
        }
    }

    static List<Integer> vList = new ArrayList<>();

    static int workers = 4;
    static boolean report = false;

    public static void main(String[] args) {
        // Validate cmd line arguments
        if (args.length > 2) return; // Too many arguments
        if (args.length >= 1) // Has #workers argument
            try {
                workers = Integer.parseInt(args[0]);
                if (workers < 1) return;
            } catch (NumberFormatException nfe) {
                return;
            }
        if (args.length == 2) { // Has report? argument
            if (args[1].equalsIgnoreCase("report")) report = true;
            else return;
        }

        // Read in list of integers
        Scanner in = new Scanner(System.in);
        while (true)
            try {
                vList.add(in.nextInt());
            } catch (NoSuchElementException nsee) {
                break;
            }

        // Make threads
        MaxSumR[] msrs = new MaxSumR[workers];
        for (int i = 0; i < workers; i++)
            msrs[i] = new MaxSumR(i);
        // Start threads
        for (MaxSumR msr : msrs) msr.start();
        // Join with threads
        for (MaxSumR msr : msrs)
            try {
                msr.join();
            } catch (InterruptedException e) {
                return;
            }
        // Tally results
        int maxSum = msrs[0].getMaxSum();
        for (MaxSumR msr : msrs)
            if (maxSum < msr.getMaxSum())
                maxSum = msr.getMaxSum();
        System.out.printf("Maximum Sum: %d\n", maxSum);
    }
}
