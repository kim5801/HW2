import java.util.*;
/** 
* @file Maxsum.Java
* @author Annie Lowman aklowman
*
* Program is the Java implementation to take in a list of numbers,
* and then use a given number of threads from the command line argument
* to generate threads and calculate the maximum sum of a sequence 
* of numbers from the given list.
*/
public class Maxsum {

    /** List to keep track of the numbers from the input file*/
    public static ArrayList<Integer> list;
    /** number to keep track of the number of threads to create*/
    public static int numWorkers;
    /** boolean to keep track of whether of not user wants a report for each thread*/
    public static boolean report = false;

    /**
    * Class extends the Thread class in order to 
    * specialize our implementation of threads to keep track of
    * the indexs of the array to be checking, and the current
    * max that that thread has found.
    */
    static class MyThread extends Thread {

        /** Number to keep track of the index's of the array to be checking*/
        private int skip;
        /** Max sum found from this thread*/
        public int max;
    
        /**
        * Constructor for the thread
        * @param skip Index's for the array to check
        */
        public MyThread( int skip ) {
            this.skip = skip;
        }

        /**
        * Function takes the index's to check, and then calculates different sums
        * from the list of numbers and then keeps track of the maximum sum found
        * from the list of numbers
        */
        public void run() {
            int currentSum = 0;
            int localMax = 0;
            // outer loop to start counting at certain index's
            for (int i = skip; i < list.size(); i = i + numWorkers) {
                currentSum = 0;
                // inner loop to calculate the actual sum starting from that index
                for (int j = i; j < list.size(); j++ ) {
                    currentSum += list.get(j);
                    if (skip == i) {
                        localMax = currentSum;
                    }
                    if (currentSum > localMax) {
                        localMax = currentSum;
                    }
                }
            }

            max = localMax;
            // output the max sum found if the report option is given
            if (report) {
                System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", getId(), max);
            }
        }
    }

    /**
    * Main method to do error checking on the command line arguments given,
    * then call the function to read in the list of numbers from the given file,
    * and then generate the threads to calculate the maximum sum
    *
    * @param args command line argument
    */
    public static void main (String[] args) {
        // check command line arguments
        if (args.length != 1 && args.length != 2) {
            System.exit(1);
        }
        try {
            numWorkers = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.exit(1);
        }
        if (numWorkers < 0) {
            System.exit(1);
        }

        if (args.length == 2) {
            if (!args[1].equals("report")) {
                System.exit(1);
            }
            else {
                report = true;
            }
        }

        readList();
    
        MyThread[] threads = new MyThread[numWorkers];
        // create the threads and start each one
        for ( int i = 0; i < numWorkers; i++ ) {
            threads[i] = new MyThread(i);
            threads[i].start();
        }


        int overallMax = 0;
        // get the report from each of the threads for the maximum sun
        try {
            for ( int i = 0; i < numWorkers; i++ ) {
                threads[i].join();
                if (i == 0) {
                    overallMax = threads[i].max;
                }
                if (threads[i].max > overallMax) {
                    overallMax = threads[i].max;
                }

            }
        } catch ( InterruptedException e ) {
            System.out.println("Interrupted during join.");
        }

        System.out.println("Maximum sum: " + overallMax);
        



    }
    
    /** Method reads in the numbers from the given input file*/
    public static void readList() {
        list = new ArrayList<Integer>();
        Scanner in = new Scanner(System.in);
        while (in.hasNextInt()) {
            list.add(in.nextInt());
        }
        
        in.close();
    }

    
}