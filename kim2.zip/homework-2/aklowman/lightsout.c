/**
* @file lightsout.c
* @author Annie Lowman
*
* File contains the functionality to access the shared memeory, and then
* execute either a more, report, or undo command, as well as perform
* error checking on these commands
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Minumum number of command line arguments*/
#define ARGS_MIN 2
/** Maximum number of command line arguments*/
#define ARGS_MAX 4
/** Upper bound of the array index's*/
#define UPPER_BOUND 4

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
/**
* Main function loads in struct from the section of shared memory, and then
* performs error checking the make sure that the given command line arguments
* are valid. The function then executres the given command for either executing
* a move command, printing out a the current game board, or undoing the previous command.
* The program exits after executing one command.
*
* @param argc number of command line arguments
* @param argv command line arguments
* @return program exit status
*/
int main( int argc, char *argv[] ) {
    
    // check number of arguments user supplied
    if ( argc != ARGS_MIN && argc != ARGS_MAX ) {
        fail("Incorrect number of arguments");
    } 
    // attempt to access the region of shared memory
    int shmid = shmget( ftok( AFS_NAME, PROJ_ID ), 0, 0 );
    if ( shmid == -1 ) {
        fail( "Can't create shared memory" );
    }
    // cast the region of memeory to be a GameState struct
    GameState *game = ( GameState * )shmat( shmid, 0, 0 );
    if ( game == (GameState * ) -1 ) {
        fail ("Can't map shared memory segment into address space" );
    }
    
    // handle the functionality for the undo command
    if ( strcmp ( "undo", argv[ 1 ] ) == 0 )  {
        // check to ensure args are correct
        if ( argc != ARGS_MIN ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        // check to see if undo is allowed currently
        if (!game->undo ) {
            shmdt( game );
            fail("Illegal action");
        }
        // if undo is allowed, undo!
        int row = game->row;
        int col = game->col;
        
        if (game->gameBoard[row][col] == '.' ) {
            game->gameBoard[row][col] = '*';
        } else {
            game->gameBoard[row][col] = '.';
        }
        
        int oneBack = row - 1;
        if ( oneBack >= 0 ) {
            if (game->gameBoard[oneBack][col] == '.' ) {
                game->gameBoard[oneBack][col] = '*';
            } else {
                game->gameBoard[oneBack][col] = '.';
            }
        }
        
        int oneFor = row + 1;
        if ( oneFor < GRID_SIZE ) {
            if (game->gameBoard[oneFor][col] == '.' ) {
                game->gameBoard[oneFor][col] = '*';
            } else {
                game->gameBoard[oneFor][col] = '.';
            }
        }
        
        int oneUp = col - 1;
        if ( oneUp >= 0 ) {
            if (game->gameBoard[row][oneUp] == '.' ) {
                game->gameBoard[row][oneUp] = '*';
            } else {
                game->gameBoard[row][oneUp] = '.';
            }
        }
        
        int oneDown = col + 1;
        if ( oneDown < GRID_SIZE ) {
            if (game->gameBoard[row][oneDown] == '.' ) {
                game->gameBoard[row][oneDown] = '*';
            } else {
                game->gameBoard[row][oneDown] = '.';
            }
        }
        
        game->undo = false;
        printf("success\n");
        
    } // handle the functionality for the report command
    else if (strcmp( "report", argv[1] ) == 0 ) {
        // check for valid number of arguments
        if (argc != ARGS_MIN ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        // print out the game board
        for ( int i = 0; i < GRID_SIZE; i++ ) {
            for (int j = 0; j < GRID_SIZE; j++ ) {
                printf("%c", game->gameBoard[i][j]);
            }
            printf("\n");
        }
        
        
    } // handle the functionality for the move command
    else if ( strcmp("move", argv[1] ) == 0 ) {
        if ( argc != ARGS_MAX ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        
        int row;
        int result = sscanf( argv[ 2 ], "%d", &row );
        if (result != 1) {
            shmdt( game );
            fail("Invalid arguments");
        }
        int col;
        result = sscanf( argv[ 3 ], "%d", &col );
        if (result != 1) {
            shmdt( game );
            fail("Invalid arguments");
        }
        // checking if numbers provided are within the correct bounds
        if (row < 0 || row > UPPER_BOUND ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        
        if (col < 0 || col > UPPER_BOUND ) {
            shmdt( game );
            fail("Invalid arguments");
        }
        // assign the GameState row and column to the row and column being moved
        game->row = row;
        game->col = col;
        
        if (game->gameBoard[row][col] == '.' ) {
            game->gameBoard[row][col] = '*';
        } else {
            game->gameBoard[row][col] = '.';
        }
        
        int oneBack = row - 1;
        if ( oneBack >= 0 ) {
            if (game->gameBoard[oneBack][col] == '.' ) {
                game->gameBoard[oneBack][col] = '*';
            } else {
                game->gameBoard[oneBack][col] = '.';
            }
        }
        
        int oneFor = row + 1;
        if ( oneFor < GRID_SIZE ) {
            if (game->gameBoard[oneFor][col] == '.' ) {
                game->gameBoard[oneFor][col] = '*';
            } else {
                game->gameBoard[oneFor][col] = '.';
            }
        }
        
        int oneUp = col - 1;
        if ( oneUp >= 0 ) {
            if (game->gameBoard[row][oneUp] == '.' ) {
                game->gameBoard[row][oneUp] = '*';
            } else {
                game->gameBoard[row][oneUp] = '.';
            }
        }
        
        int oneDown = col + 1;
        if ( oneDown < GRID_SIZE ) {
            if (game->gameBoard[row][oneDown] == '.' ) {
                game->gameBoard[row][oneDown] = '*';
            } else {
                game->gameBoard[row][oneDown] = '.';
            }
        }
        
        game->undo = true;
        printf("success\n");
    } // handle if the given command line argument is not one of the 3 valid commands
    else {
        shmdt( game );
        fail("Invalid arguments");
    }
    
    

    return 0;
}
