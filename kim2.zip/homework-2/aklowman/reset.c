/**
* @file reset.c
* @author Annie Lowman aklowman
*
* File opens the given board, validates the file, and then opens a region
* of shared memory for communication between different processes, and loads the
* game board from the given file into the region of shared memory
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
* Function does error checking on the command line arguments, and then
* loads the game board into the region of shared memory and sets the
* undo status of the GameState struct to false.
*
* @param argc number of command line arguments
* @param argv command line arguments
* @return program exit status
*/
int main( int argc, char *argv[] ) {
    // checking number of command line arguments
    if (argc != 2 ) {
        usage();
    }
    // opening given input file
    FILE *fp = fopen ( argv[ 1 ], "r");
    if ( fp == NULL ) {
        printf("Invalid input file: " );
        fail( argv[1] );
    }
    // siting source of shmReader.c for how to open a region of shared memory
    int shmid = shmget( ftok( AFS_NAME, PROJ_ID ), sizeof( GameState ), 0666 | IPC_CREAT );
    if ( shmid == -1 ) {
        fail( "Can't create shared memory" );
    }
    // cast the region of shared memory to be a struct
    GameState *game = ( GameState * )shmat( shmid, 0 , 0);
    if ( game == (GameState *)-1 ) {
        fail( "Can't map shared memory segment into address space" );
    }
    
    // validate the contents of the input file and add it's contents to the struct
    char ch; 
    for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
            ch = fgetc( fp );
            if ( ch == EOF )  {
                if (i != GRID_SIZE - 1 && j != GRID_SIZE) {
                     fprintf( stderr, "Invalid input file: " );
                     fail(argv[1]);
                }
            }
            else if ( j == GRID_SIZE && ch >= ' ' ) {
                 fprintf( stderr, "Invalid input file: " );
                 fail(argv[1]);
            }
            else if (ch < ' ' && j != GRID_SIZE ) {
                 fprintf( stderr, "Invalid input file: " );
                 fail(argv[1]);
            }
            else if (ch != '.' && ch != '*' && ch >= ' ') {
                 fprintf( stderr, "Invalid input file: " );
                 fail(argv[1]);
            }
            if ( j != GRID_SIZE ) {
                game->gameBoard[i][j] = ch;
            }
        }
    }
    
    if (ch != EOF) {
        ch = fgetc( fp );
        if (ch != EOF ) {
            fail("Invalid input file");
        }
    }
    
    fclose ( fp ); 
    // set GameState undo status to false
    game->undo = false;
    


    return 0;
}
