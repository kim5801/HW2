import java.util.ArrayList;
import java.util.Scanner;

/**
 * Finds the maximum sum in a list read into the program.
 * @file Maxsum.java
 * @author Zach Taylor(zstaylor)
 */
public class Maxsum {
			
	/**
	 * Worker thread, searches the source list based on the given parameters
	 * @author Zach Taylor (zstaylor)
	 */
	class WorkerThread extends Thread {
		
		private ArrayList<Integer> sourcelist;
		private int startidx;
		private int workers;
		private int runsperworker;
		private boolean report;
		public  int returnmax;
		
		/**
		 * Creates new worker thread with the given search parameters and source list
		 * @param start Start index
		 * @param numworkers Number of worker threads
		 * @param runs Number of runs per worker thread
		 * @param report Flag if threads should report indepentent results or not
		 * @param sourcelist list to search
		 */
		public WorkerThread(int start, int numworkers, int runs, boolean report, ArrayList<Integer> sourcelist) {
			startidx = start;
			workers = numworkers;
			runsperworker = runs;
			this.report = report;
			this.sourcelist = sourcelist;
		}
		
		/**
		 * Thread entry point
		 */
		public void run() {
			
			int localmax = 0;
					
			for(int i = 0; i < runsperworker; i++) {
				
				int sum = 0;
				
				for(int j = i + (workers*i) + startidx; j < sourcelist.size(); j++) {
					
					//add and see if sum is greater
					sum += sourcelist.get(j);
					
					if(sum > localmax) {
						localmax = sum; 
					}
					
				}
			}
			
			//report if desired
			if(report) {
				System.out.println("Im process " + this.getId() + ". The maximum sum I found is " + localmax + ".");
			}

			//set return value field
			returnmax = localmax;
		}
	}
	
	/**
	 * Reads input into an arraylist of integers
	 */
	public ArrayList<Integer> readList() {
		
		ArrayList<Integer> inList = new ArrayList<Integer>();
		
		int current;
		Scanner in = new Scanner(System.in);
		
		while(in.hasNextInt()) {
			
			inList.add(in.nextInt());
		}
		
		return inList;
	}
	
	/**
	 * Non Static Entry Point
	 * @param args Command Line Arguments
	 */
	public void findSum(String[] args) {
		boolean report = false;
		int workers = 4;
		
		//print usage message if needed
		if(args.length < 1 || args.length > 2) {
			System.out.println("usage: maxsum <workers>");
			System.out.println("        maxsum <workers> report");
			System.exit(1);
		}
		
		//take in number of workers
		int paramworkers = Integer.parseInt(args[0]);
		
		if(paramworkers < 1) {
			System.out.println("usage: maxsum <workers>");
			System.out.println("        maxsum <workers> report");
			System.exit(1);
		}
		else {
			workers = paramworkers;
		}
		
		//check for and mark report flag if desired
		if(args.length == 2) {
			if(!("report".equals(args[1]))) {
				System.out.println("usage: maxsum <workers>");
				System.out.println("        maxsum <workers> report");
				System.exit(1);
			}
			
			report = true;
		}
		
				
		//read in values
		ArrayList<Integer> list = readList(); 
		
		
		//create worker buff and initialize run info
		WorkerThread[] children = new WorkerThread[workers];
		
		int runsPerWorker = list.size() / workers;
		if(list.size() % workers != 0) {
			runsPerWorker += 1;
		}
			
		//start workers
		for(int i = 0; i < workers; i++) {
			
			WorkerThread newWorker = new WorkerThread(i, workers, runsPerWorker, report, list);
			children[i] = newWorker;
			
			newWorker.start();
		}
				
		int maxFound = 0;
		
		//rejoin all threads after
		for(int i = 0; i < workers; i++) {
			try {
				children[i].join();
		
				//get the max value
				if(children[i].returnmax > maxFound) {
					maxFound = children[i].returnmax;
				}
			}
			catch(InterruptedException e) {
				System.out.println("Joining child " + i + " interrupted.");
			}
		}
		
		
		System.out.println("Maximum Sum: " + maxFound);
	}
	
	
	/**
	 * Program entry point
	 * @param args Command Line Arguments
	 */
	public static void main(String[] args) {
		
		Maxsum sum = new Maxsum();
		sum.findSum(args);
		
	}
	
}