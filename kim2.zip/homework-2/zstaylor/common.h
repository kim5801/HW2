
#define SHMKeySeed "/afs/unity.ncsu.edu/users/z/zstaylor"
#define BOARDSIZE 5

/**
 * Game State struct, holds current and prevous boards, undo flag.
 */
struct gameState {
    char currentBoard[BOARDSIZE * BOARDSIZE];
    char previousBoard[BOARDSIZE * BOARDSIZE];
    int undoPossible;
}typedef GameState;
