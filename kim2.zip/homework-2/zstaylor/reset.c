/**
 * @file reset.c
 * @author Zach Taylor (zstaylor)
 *
 * resets the game board located in shared memory segment to that specified in
 * a board file, resets game state.
 */
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#include "common.h"

/**
 * Program entry point
 * @param argc Argument Count
 * @param argv Arguments
 * @return Exit status
 */
int main(int argc, char* argv[]) {

    //enforce cmd line args
    if(argc != 2) {
        fprintf(stderr, "usage: reset <game-state-file>\n");
        exit(1);
    }

    //open boardfile
    int boardfd = open(argv[1], O_RDONLY, 0600);
    if(boardfd < 0) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }

    //create shared memory segment and attach
    key_t shmkey = ftok(SHMKeySeed, 1);
    int segment = shmget(shmkey, sizeof(struct gameState), 0666 | IPC_CREAT);
    if(segment < 0) {
        fprintf(stderr, "Failed to get to shared memory\n");
        exit(1);
    }

    GameState* board = (GameState*)shmat(segment, 0, 0);
    if(board == (GameState*)-1) {
        fprintf(stderr, "Failed to attach to shared memory\n");
        perror("Failed to attach");
        exit(1);
    }

    //initialize undo field
    board->undoPossible = 0;


    //create buffer for holding input from file
    char rawInput[50] = {};
    int bytesRead = read(boardfd, rawInput, sizeof(char) * 50);

    //read input from file, checking to ensure it only contains */.
    //if other characters are found, exit unsuccessfully
    for(int i = 0, placed = 0; i < bytesRead; i++) {
        if(rawInput[i] == '.' || rawInput[i] == '*') {
            board->currentBoard[placed] = rawInput[i];
            placed += 1;
        }
        else {
            if(rawInput[i] != '\n') {
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
                exit(1);
            }
        }
    }

    //close board file
    close(boardfd);

    return 0;
}
