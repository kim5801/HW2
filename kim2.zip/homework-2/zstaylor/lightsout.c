/**
 * @file lightsout.c
 * @author Zach Taylor (zstaylor)
 */
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "common.h"

/**
 * Program entry point
 * @param argc Argument Count
 * @param argv Arguments
 * @return Exit status
 */
int main(int argc, char* argv[]) {

    //check for invalid cli arguments
    if(argc < 2 || argc > 4) {
        printf( "error\n" );
        exit( 1 );
    }

    //get and attach shared memory segment
    key_t shmkey = ftok(SHMKeySeed, 1);
    int segment = shmget(shmkey, sizeof(struct gameState), 0666 | IPC_CREAT);
    if(segment < 0) {
        fprintf(stderr, "Failed to get to shared memory\n");
        exit(1);
    }

    GameState* board = (GameState*)shmat(segment, 0, 0);
    if(board == (GameState*)-1) {
        printf("Could not attach shared memory segment\n");
        exit(1);
    }

    //move cmd
    if(strcmp(argv[1], "move") == 0) {

        int row = atoi(argv[2]);
        int col = atoi(argv[3]);

        //ensure that the row and column given are valid
        if(row < 0 || row >= 5 || col < 0 || col >= 5) {
            printf("error\n");
            exit(1);
        }

        //set the lastboard to the current contents, enable an undo
        memcpy(board->previousBoard, board->currentBoard, sizeof(board->currentBoard));
        board->undoPossible = 1;

        //retrieve idx from row/col info
        int idx = row * BOARDSIZE + col;

        //process north cell, if possible
        if(idx - 5 >= 0) {

            if(board->currentBoard[idx-5] == '.') {
                board->currentBoard[idx-5] = '*';
            }
            else {
                board->currentBoard[idx-5] = '.';
            }
        }

        //south cell, if possible
        if(idx + 5 < 25) {

            if(board->currentBoard[idx+5] == '.') {
                board->currentBoard[idx+5] = '*';
            }
            else {
                board->currentBoard[idx+5] = '.';
            }
        }

        //west cell, if possible
        if(idx - 1 >= 0 && col - 1 >= 0) {

            if(board->currentBoard[idx-1] == '.') {
                board->currentBoard[idx-1] = '*';
            }
            else {
                board->currentBoard[idx-1] = '.';
            }
        }

        //east cell
        if(idx + 1 < 25 && col + 1 <= 4) {

            if(board->currentBoard[idx+1] == '.') {
                board->currentBoard[idx+1] = '*';
            }
            else {
                board->currentBoard[idx+1] = '.';
            }
        }

        //cell itself
        if(idx >= 0 && idx < 25) {

            if(board->currentBoard[idx] == '.') {
                board->currentBoard[idx] = '*';
            }
            else {
                board->currentBoard[idx] = '.';
            }
        }

        printf("success\n");
    }
    else if (strcmp(argv[1], "undo") == 0) {

        //check if undo is possible
        if(board->undoPossible == 0) {
            printf("error\n");
            exit(1);
        }

        //roll back current board with last board contents
        memcpy(board->currentBoard, board->previousBoard, sizeof(board->previousBoard));
        board->undoPossible = 0;

        printf("success\n");

    }
    else if (strcmp(argv[1], "report") == 0) {

        //loop with a second counter to determine when to indent
        for(int i = 0, counter = 0; i < (BOARDSIZE * BOARDSIZE); i++, counter++) {

            if (counter == BOARDSIZE) {
                printf("\n");
                counter = 0;
            }

            printf("%c", board->currentBoard[i]);
        }

        printf("\n");

    }
    else {
        //print usage if bad commands
        printf("error\n");
        exit(1);
    }

    //detach shared memory
    shmdt(&segment);

    return 0;
}
