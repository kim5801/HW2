/**
 * @file lightsout.c
 * @author Jonathan Kolesar (jkolesa)
 * This component contains the main function.
 * It reads in a game board from the shared memory segment and 
 * performs actions for the lights out game using command line arguements.
 * The actions modify the game board stored in the shared memory segment.
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Conversition multiplier for the string to integer converter function */
#define CONVERT_MULTIPLIER 10

/**
 * A helper function that prints out the given error message
 * and terminates the program with a exit status of 1
 * 
 * @param message the given error message to print to standard error
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * A helper function to convert the given string to an integer.
 * 
 * @param statusStr number string to be validated as an integer
 * @return whether the given string was a valid integer
 */
int validateInt( char statusStr[] ) {
    // Length of the given string.
    int stringLen = strlen(statusStr);

    if (stringLen > 1 ) {
      return -1;
    }

    if ( statusStr[ 0 ] < '0' || statusStr[ 0 ] > '9' ) {
      return -1;
    } else {
      return 0;
    }
}


// Size of the shared block of memory is the size of the GameBoard struct
//const int GAME_SIZE = sizeof( GameBoard );

/**
 * Start of program.
 * 
 * @param argc number of command line arguments.
 * @param argv list of pointers to the command line arguments.
 * @return int exit success if the user provides valid command line arguments. 
 *              Otherwise, exit failure.
 */
int main( int argc, char *argv[] ) {

  // Gets the key for the shared memory segment
  key_t key = ftok( "/afs/unity.ncsu.edu/users/j/jkolesa", 1 );

  // Make a shared memory segment 1KB in size
  int shmid = shmget( key, GAME_SIZE, 0 );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );



  // Map the shared memory into my address space
  GameBoard *gameBoard = shmat( shmid, 0, 0 );
  if ( gameBoard == (GameBoard *)-1 )
    fail( "Can't map shared memory segment into address space" );

  /*
  // Prints the initial state of the game board after adding it to shared memory.
  for ( int i = 0; i < 5; i++ ) {
    for ( int j = 0; j < 5; j++ ) {
      printf( "%c", gameBoard->board[ i ][ j ] );
      if ( j == 4 )
        printf( "\n" );
    }
  }

  // Prints the initial undo state
  if ( gameBoard->undo == false ) {
    printf("Undo = FALSE\n");
  } else {
    printf("Undo = TRUE\n");
  }
  */








  // Checks that the correct number of command line arguments are given by the user
  if ( argc < 2 || argc > 4 ) {
    fail( "error" );
  }


  // Checks if 2nd command line argument is "move"
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // Checks that there are 4 command line arugments
    if ( argc != 4 ) {
      fail( "error" );
    }

    // Checks that the 3rd argument is only one character long
    if ( strlen( argv[ 2 ] ) != 1 ) {
      fail( "error" );
    }
    // Checks that the given character is a digit
    if ( validateInt( argv[ 2 ] ) == -1 ) {
      fail( "error" );
    }

    if ( validateInt( argv[ 3 ] ) == -1 ) {
      fail( "error" );
    }

    char *one = argv[ 2 ];
    char *two = argv[ 3 ];

    if ( one[ 0 ] >= '0' && one[ 0 ] <= '4' && two[ 0 ] >= '0' && two[ 0 ] <= '4' ) {
      int row = one[ 0 ] - '0';
      int col = two[ 0 ] - '0';

      //printf("Given: %d %d\n", row, col );
      if ( gameBoard->board[ row ][ col ] == '*' ) {
        gameBoard->board[ row ][ col ] = '.';
      } else {
        gameBoard->board[ row ][ col ] = '*';
      }

      int aboveRow = row - 1;
      int aboveCol = col;
      //printf("Above: %d %d\n", aboveRow, aboveCol );
      if ( aboveRow >= 0 ) {
        if ( gameBoard->board[ aboveRow ][ aboveCol ] == '*' ) {
          gameBoard->board[ aboveRow ][ aboveCol ] = '.';
        } else {
          gameBoard->board[ aboveRow ][ aboveCol ] = '*';
        }
      }

      int leftRow = row;
      int leftCol = col - 1;
      //printf("Left: %d %d\n", leftRow, leftCol );
      if ( leftCol >= 0 ) {
        if ( gameBoard->board[ leftRow ][ leftCol ] == '*' ) {
          gameBoard->board[ leftRow ][ leftCol ] = '.';
        } else {
          gameBoard->board[ leftRow ][ leftCol ] = '*';
        }
      }

      int rightRow = row;
      int rightCol = col + 1;
      //printf("Right: %d %d\n", rightRow, rightCol );
      if ( rightCol < GRID_SIZE ) {
        if ( gameBoard->board[ rightRow ][ rightCol ] == '*' ) {
          gameBoard->board[ rightRow ][ rightCol ] = '.';
        } else {
          gameBoard->board[ rightRow ][ rightCol ] = '*';
        }
      }

      int bellowRow = row + 1;
      int bellowCol = col;
      //printf("Bellow: %d %d\n", bellowRow, bellowCol );
      if ( bellowRow < GRID_SIZE ) {
        if ( gameBoard->board[ bellowRow ][ bellowCol ] == '*' ) {
          gameBoard->board[ bellowRow ][ bellowCol ] = '.';
        } else {
          gameBoard->board[ bellowRow ][ bellowCol ] = '*';
        }
      }

      printf("success\n");

      // Remember to set undo to true in here
      gameBoard->undo = true;

      // Saves the previous move command
      gameBoard->prevMov[ 0 ] = one[ 0 ];
      gameBoard->prevMov[ 1 ] = two[ 0 ];

    } else {
      fail( "error" );
    }

  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if ( argc != 2 ) {
      fail( "error" );
    }

    /*
    if ( gameBoard->undo == false ) {
      printf("Undo = FALSE\n");
    } else {
      printf("Undo = TRUE\n");
    }
    */

    if ( gameBoard->undo == true ) {
      // Run the undo command

      // Sets the board back to the previous board state
      char one = gameBoard->prevMov[ 0 ];
      char two = gameBoard->prevMov[ 1 ];

      //printf( "%c %c\n", one, two );

      if ( one >= '0' && one <= '4' && two >= '0' && two <= '4' ) {
        int row = one - '0';
        int col = two - '0';

        //printf("Given: %d %d\n", row, col );
        if ( gameBoard->board[ row ][ col ] == '*' ) {
          gameBoard->board[ row ][ col ] = '.';
        } else {
          gameBoard->board[ row ][ col ] = '*';
        }

        int aboveRow = row - 1;
        int aboveCol = col;
        //printf("Above: %d %d\n", aboveRow, aboveCol );
        if ( aboveRow >= 0 ) {
          if ( gameBoard->board[ aboveRow ][ aboveCol ] == '*' ) {
            gameBoard->board[ aboveRow ][ aboveCol ] = '.';
          } else {
            gameBoard->board[ aboveRow ][ aboveCol ] = '*';
          }
        }

        int leftRow = row;
        int leftCol = col - 1;
        //printf("Left: %d %d\n", leftRow, leftCol );
        if ( leftCol >= 0 ) {
          if ( gameBoard->board[ leftRow ][ leftCol ] == '*' ) {
            gameBoard->board[ leftRow ][ leftCol ] = '.';
          } else {
            gameBoard->board[ leftRow ][ leftCol ] = '*';
          }
        }

        int rightRow = row;
        int rightCol = col + 1;
        //printf("Right: %d %d\n", rightRow, rightCol );
        if ( rightCol < GRID_SIZE ) {
          if ( gameBoard->board[ rightRow ][ rightCol ] == '*' ) {
            gameBoard->board[ rightRow ][ rightCol ] = '.';
          } else {
            gameBoard->board[ rightRow ][ rightCol ] = '*';
          }
        }

        int bellowRow = row + 1;
        int bellowCol = col;
        //printf("Bellow: %d %d\n", bellowRow, bellowCol );
        if ( bellowRow < GRID_SIZE ) {
          if ( gameBoard->board[ bellowRow ][ bellowCol ] == '*' ) {
            gameBoard->board[ bellowRow ][ bellowCol ] = '.';
          } else {
            gameBoard->board[ bellowRow ][ bellowCol ] = '*';
          }
        }

        gameBoard->undo = false;

        printf("success\n");

      }
    } else {
      fail( "error" );
    }

  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    if ( argc != 2 ) {
      fail( "error" );
    }

    // Prints the current state of the game board.
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        printf( "%c", gameBoard->board[ i ][ j ] );
        if ( j == 4 )
          printf( "\n" );
      }
    }

    

  } else {
    fail( "error" );
  }


  // Release our reference to the shared memory segment.
  shmdt( gameBoard );

  // Tell the OS we no longer need the segment. (DON'T DELETE SHARED MEMORY SEGMENT IN HERE)
  //shmctl( shmid, IPC_RMID, 0 );
  
  return 0;
}
