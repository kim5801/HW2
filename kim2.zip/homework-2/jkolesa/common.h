// Height and width of the playing area.
#define GRID_SIZE 5
// Size of the shared block of memory is the size of the GameBoard struct
#define GAME_SIZE sizeof( GameBoard )

typedef struct
{
  int board[GRID_SIZE][GRID_SIZE];
  bool undo;
  char prevMov[2];
} GameBoard;
