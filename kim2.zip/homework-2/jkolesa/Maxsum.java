import java.util.Scanner;

/**
 * The Maxsum class the number of threads asked for from the command line argument to 
 * compute max contiguous sums within each workers given range. Then the maximum found
 * sum is printed.
 * 
 * @author Jonathan Kolesar
 * 
 */
public class Maxsum {

    /**
     * The subclass WorkerThread tells a worker thread what to do.
     * 
     * @author Jonathan Kolesar
     * 
     */
    static class WorkerThread extends Thread {
        /** Integer of starting index for the worker */
        private int startIndex;

        /** Integer array of the list of numbers to compute from */
        private int list[];

        /** Integer of the list size */
        private int size;

        /** Next starting index for the worker to compute a max contiguous sum from */
        private int startShift;

        /** Worker's max sum in it's given range */
        public int maxLocalSum;

        /**
         * Constructs a worker thread and sets the starting index to the given.
         * @param startIndex starting index of the range to compute the contiguous sum
         */
        public WorkerThread( int startIndex, int list[], int size, int startShift ) {
            this.startIndex = startIndex;
            this.list = list;
            this.size = size;
            this.startShift = startShift;
        }

        /**
         * This method runs the worker thread to compute the local contiguous sum.
         */
        public void run() {
            int maxSum = 0;
            for ( int i = startIndex; i < size; i += startShift ) {
                int currSum = 0;
                for ( int j = i; j < size; j++ ) {
                    currSum += list[ j ];
                    if ( currSum > maxSum ) {
                        maxSum = currSum;
                    }
                }
            }

            // Store the final value in the maxLocalSum field, where the main thread can get it.
            this.maxLocalSum = maxSum;
        }
    }

    /** Make a thread and wait for it to do something. */
    public static void main( String[] args ) {

        // Prints the given command line arguements
        /*
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
        */


        if (args.length < 1 || args.length > 2) {
            System.err.println("Args Len: " + args.length);
            System.err.println("usage: maxsum <workers>");
            System.err.println("       maxsum <workers> report");
            System.exit(1);
        }

        // Tries to read in the number of given workers from the command line
        int numWorkers = 4;
        try {
            numWorkers = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.err.println("Arg[0]: " + args[0]);
            System.err.println("usage: maxsum <workers>");
            System.err.println("       maxsum <workers> report");
            System.exit(1);
        }

        // Checks that the second command arguement is "report" if one is given
        boolean report = false;
        if (args.length == 2) {
            if (args[1].equals("report")) {
                report = true;
            } else {
                System.err.println("Arg[1]: " + args[1]);
                System.err.println("usage: maxsum <workers>");
                System.err.println("       maxsum <workers> report");
                System.exit(1);
            }
        }

        // Creates the input file scanner
        Scanner fileScnr = new Scanner(System.in);

        int list[] = new int[6];
        int listCopy[];
        int size = 0;
        while (fileScnr.hasNext()) {
            // Doubles the capacity of the array if it is full
            if (size == list.length - 1) {
                listCopy = new int[list.length * 2];
                System.arraycopy(list, 0, listCopy, 0, size);
                list = listCopy;
            }
            // Reads in the next integer
            list[size] = fileScnr.nextInt();
            // Increments the size of the array to account for integer that was just read in
            size++;
        }

        // Closes the input file scanner
        fileScnr.close();

        // Prints the contents of the array of read in integers from the input file
        /*
        for (int i = 0; i < size; i++) {
            System.out.println(list[i]);
        }
        */


        int numCreatedWorkers = 0;

        // Make the given number of worker threads and let them start running.
        WorkerThread[] workerThreads = new WorkerThread [ numWorkers ];
        for (int i = 0; i < workerThreads.length; i++) {
            workerThreads[i] = new WorkerThread(numCreatedWorkers, list, size, numWorkers);
            workerThreads[i].start();
            numCreatedWorkers++;
        }

        int absoluteMax = 0;

        // Wait for each of the worker threads to terminate.
        try {
            for (int i = 0; i < workerThreads.length; i++) {
                workerThreads[i].join();
                if (report) {
                    System.out.println("I'm thread " + workerThreads[i].getId() + ". The maximum sum I found is " + workerThreads[i].maxLocalSum + ".");
                }
                if (absoluteMax < workerThreads[i].maxLocalSum) {
                    absoluteMax = workerThreads[i].maxLocalSum;
                }
            }
        } catch ( InterruptedException e ) {
            System.out.println("Interrupted during join!");
        }

        System.out.println("Maximum Sum: " + absoluteMax);

    }
    
}
