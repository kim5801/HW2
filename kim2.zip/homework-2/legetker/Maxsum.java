import java.util.*;

public class Maxsum {

    static int[] values;

    static int capacity;

    static int size;

    static boolean report = false;

    static int currentIndex = 0;

    public static void readValues() {
        capacity = 5;
        values = new int[capacity];

        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            if (size >= capacity) {
                capacity *= 2;
                int[] newValues = new int[capacity]; //make a new array
                for (int i = 0; i < values.length; i++) { //copy over the values
                    newValues[i] = values[i];
                }
                values = newValues;
            }
            values[size] = Integer.parseInt(scanner.next()); //read in the value
            size++;
        }
        scanner.close();
    }

    static class MyThread extends Thread {
        private int maxsum;
        private int threadID;
        private int threadMax;
        public MyThread(int threadID ) {
            maxsum = 0;
            threadMax = 0;
            this.threadID = threadID;
        }

        public void run() {
            maxsum = values[0];
            int sum = 0;
            for (int i = currentIndex; i < values.length; i++) {
                sum = 0;
                for (int j = currentIndex; j <= i; j++) {
                    sum = sum + values[j];
                }
                if (sum > maxsum) {
                    maxsum = sum;
                }
            }
            if (maxsum > threadMax) {
                threadMax = maxsum;
            }
        }
    }


    public static void main(String[] args) {
        //Parse command line arguments
        if (!(args.length == 1 || args.length == 2)) {
            System.out.println( "usage: maxsum <workers> report" );
            System.exit(1);
        }
        

        int workers = Integer.parseInt(args[0]);
        if (args.length == 2) {
            if (args[1].equals("report")) {
                report = true;
            } else {
                System.out.println( "usage: maxsum <workers> report" );
            }
        }

        //Read in the values
        readValues();
        
        //Create each thread and start it
        MyThread[] thread = new MyThread [workers];
        int[] maxes = new int[values.length];
        for ( int i = 0; i < thread.length; i++ ) {
            thread[ i ] = new MyThread(i + 1 );
            thread[ i ].start();
        }

        for ( int i = 0; i < values.length; i++ ) {
            currentIndex = i;
            thread[i % workers].run();  
            maxes[i] = thread[i % workers].maxsum;
            //System.out.println(thread[i % workers].maxsum);
        }
        if (report) {
            for ( int i = 0; i < thread.length; i++ ) {
                System.out.println("I’m thread " + thread[i].threadID + ". The maximum sum I found is " + thread[i].threadMax + ".");
            }
        }
            
        int max = 0;
        for (int i = 0; i < maxes.length; i++) {
            if (max < maxes[i]) {
                max = maxes[i];
            }
        }
        System.out.println( "Maximum Sum: " + max);
    }

}

