#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <signal.h>
#include <sys/stat.h>

//Game board
char board[GRID_SIZE][GRID_SIZE];

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
    key_t key = ftok("/afs/unity.ncsu.edu/users/l/legetker", 'l');
    int shmid = shmget( key, 0, 0);
    if ( shmid == -1 )
        perror("Shmget error: ");
        

    char *sbuffer = (char *)shmat(shmid, 0, 0);
    if (sbuffer == (char *)-1)
        fail( "Problem mapping to shared memory" );

    int boardIdx = 0;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            //printf("%c", sbuffer[boardIdx]);
            board[i][j] = sbuffer[boardIdx];
            boardIdx++;
        }
    }
    

    //now, implement game logic. 
  int xPos = 0;
  int yPos = 0;
    char buffer[500];
    for (int i = 0; i < argc; i++) {
        strcat(buffer, argv[i]);
        strcat(buffer, " ");
    }
    //break up each arg
    char *words[4];
    int wordCount = 0;
    char *word;
    word = strtok(buffer, " ");
    while (word != NULL) {
        words[wordCount] = word;
        word = strtok(NULL, " ");
        wordCount++;
    }
    bool move = false;
    
    bool undo = false;
    bool report = false;
    if (strcmp(words[1], "undo") == 0) {
        undo = true;
    } else if (strcmp(words[1], "report") == 0) {
        report = true;
    } else if (strcmp(words[1], "move") == 0) {
        move = true;
        if (words[2][0] < '0' || words[2][0] > '9' || words[3][0] < '0' || words[3][0] > '9') {
            xPos = -1;
            yPos = -1;
        } else {
            xPos = atoi(words[2]);
            yPos = atoi(words[3]);
        }
    } else {
        fail("Invalid command");
    }

    if (move) {
        if ((xPos < GRID_SIZE && xPos >= 0) && (yPos < GRID_SIZE && yPos >= 0)) {
            board[xPos][yPos] = '*';
            printf("sucess\n");
        } else {
            printf("error\n");
        }
    }
    if (undo) {
        board[xPos][yPos] = '.';
        printf("sucess\n");
    }
    if (report) {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                printf("%c", board[i][j]);
            }
            printf("\n");
        }
    }
    boardIdx = 0;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            sbuffer[boardIdx] = board[i][j];
            boardIdx++;
        }
    }
    return 0;
}
