import java.util.*;
import java.lang.*;

/** Java program for finding max sum */
public class Maxsum {
    /** List for the worker to access */
    private static ArrayList<Integer> list = new ArrayList<Integer>();

    static class Worker extends Thread {

        // Offset for worker to divide work evenly and number of current workers
        int offset, numWorkers;
        int maxFound, currSum; // Values for current final max and current while searching

        // Initialize worker with list it needs to access, as well as which numbers to compute
        // and number of workers currently operating
        public Worker( int offset, int numWorkers ) {
            this.offset = offset;
            this.numWorkers = numWorkers;
            maxFound = list.get( 0 ) + list.get( 1 );
            currSum = maxFound;
        }

        // Returns max sum found in the list
        public int getMax() {
            return maxFound;
        }

        // Worker prints max sum found
        public void report() {
            System.out.println( "I'm thread " + getId() + ". The maximum sum I found is " + getMax() );
        }
        
        // Iterate through list to find maximum sum
        public void run() {
            for ( int i = offset; i < list.size(); i = i + numWorkers ) {
                currSum = list.get( i );

                // Find max sum in range
                for ( int j = i + 1; j < list.size(); j++ ) {
                    currSum = currSum + list.get( j );

                    // Set to new max if curr sum is great than curr max
                    if ( currSum > maxFound ) {
                        maxFound = currSum;
                    }
                }
            }
        }
    }
    
    public static void main( String args[] ) {
        // Check for correct usage
        if ( args.length < 1 || args.length > 2 ) {
            System.out.println(args.length);
            System.out.println( "usage: maxsum <workers>" );
            System.out.println( "       maxsum <workers> report" );
            System.exit( 1 );
        }

        // Assign number of workers
        int numWorkers = Integer.valueOf( args[ 0 ] );

        // Scanner to read numbers for list
        Scanner scnr = new Scanner( System.in );

        // Read from input
        while ( scnr.hasNextInt() ) {
            list.add( scnr.nextInt() );
        }

        // Create each thread and begin calculating sums
        Worker[] workers = new Worker[ numWorkers ];
        for ( int i = 0; i < workers.length; i++ ) {
            workers[ i ] = new Worker( i, numWorkers );
            workers[ i ].start();
        }

        // Wait for each thread to finish
        for ( int i = 0; i < workers.length; i++ ) {
            try {
                workers[ i ].join();
            }
            catch ( InterruptedException e ) {
                System.out.println( "Interrupted during join" );
            }
        }

        // See if sums need to be reported
        if ( args.length > 1 && args[ 1 ].equals( "report" ) ) {
            for ( int i = 0; i < workers.length; i++ ) {
                workers[ i ].report();
            }
        }

        int finalMax = workers[ 0 ].getMax();
        // Compare each value to find max sum
        for ( int i = 0; i < workers.length; i++ ) {
            if ( workers[ i ].getMax() > finalMax ) {
                finalMax = workers[ i ].getMax();
            }
        }

        // Print out max sum
        System.out.println( "Maximum sum: " + finalMax );

        // Close scanner
        scnr.close();

    }
}
