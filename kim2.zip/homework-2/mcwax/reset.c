#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Error case: invalid usage.
  if ( argc != 2 ) {
    usage();
  }

  // Attempt to read input file.
  int fd = open( argv[ 1 ], O_RDONLY );

  // Error message for invalid file
  char errFile[ MESSAGE_LIMIT ] = "";

  // File not found, exit
  if ( fd == -1 ) {
    // Technique for avoiding segmentation fault found on stack overflow
    strcat( errFile, INVALID_FILE );
    strcat( errFile, argv[ 1 ] );
    // End of stack overflow code
    fail( errFile );
  }

  // Read file contents, store in buffer
  char board[ MESSAGE_LIMIT ];
  int len = read( fd, board, MESSAGE_LIMIT );

  for ( int i = 0; i < len; i++ ) {
    if ( board[ i ] != '*' && board[ i ] != '.' && board[ i ] != '\n' ) {
      // Invalid character
      // Technique for avoiding segmentation fault found on stack overflow
      strcat( errFile, INVALID_FILE );
      strcat( errFile, argv[ 1 ] );
      // End of stack overflow code
      fail( errFile );
    }
  }
  
  // Create shared memory
  int shmid = shmget( ftok( PATHNAME, 1 ), sizeof( struct GameState * ), 0666 | IPC_CREAT );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Assign GameState struct to shared memory
  struct GameState *currGame = ( struct GameState * ) shmat( shmid, 0, 0 );
  if ( currGame == (struct GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  // Copy read board into GameState fields
  // Copy input board to 2D grid
  int j = 0, k = 0;
  for ( int i = 0; i < len; i++ ) {
    if ( ( i + 1 ) % ( GRID_SIZE + 1 ) == 0 ) { // New row
      j++;
      k = 0;
    }
    else {
      currGame->board[ j ][ k ] = board[ i ];
      k++;
    }
  }

  // Make copy of board for undo
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      currGame->copy[ i ][ j ] = currGame->board[ i ][ j ];
    }
  }

  // Board is now in shared memory, go ahead and exit
  return 0;
}
