#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Parse string as int
int stringToInt( char string[] ) {
  // Iterate through string to take each digit and add it to value
  int value = 0, currDigit = 0, i = 0;
  while ( string[i] != '\0' ) {
    // Not a numerical digit (0-9)
    if ( string[i] < ASCII_LOW || string[i] > ASCII_UP ) {
        return -1;
    }

    currDigit = string[i] - ASCII_LOW;
    value = currDigit + ( value * 10 );

    i++;
  }

  return value;
}

int main( int argc, char *argv[] ) {

  // Create access to shared memory
  int shmid = shmget( ftok( PATHNAME, 1 ), sizeof( struct GameState * ), 0 );
  if ( shmid == -1 ) {
    fail( "Can't create shared memory" );
  }

  // Shared memory access
  struct GameState *currGame = ( struct GameState * ) shmat( shmid, 0, 0 );

  // Player wants to do a move
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {

    // Parse first integer from string
    int r = stringToInt( argv[ 2 ] );

    // Parse second integer from string
    int c = stringToInt( argv[ 3 ] );

    // Invalid integer move input
    if ( ( r == -1 || c == -1 ) || ( r < 0 || r >= GRID_SIZE ) || ( c < 0 || c >= GRID_SIZE ) ) {
      fail( ERROR );
    }
    else {
      // Save state of current grid in case of undo
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          currGame->copy[ i ][ j ] = currGame->board[ i ][ j ];
        }
      }

      // Carry out initial move
      if ( currGame->board[ r ][ c ] == '.' ) {
        currGame->board[ r ][ c ] = '*';
      }
      else {
        currGame->board[ r ][ c ] = '.';
      }

      // Now cascading moves
      // Up
      if ( ( ( r - 1 ) >= 0 ) && ( ( r - 1 ) < GRID_SIZE ) ) {
        if ( currGame->board[ r - 1 ][ c ] == '.' ) {
          currGame->board[ r - 1 ][ c ] = '*';
        }
        else {
          currGame->board[ r - 1 ][ c ] = '.';
        }
      }
      // Down
      if ( ( ( r + 1 ) >= 0 ) && ( ( r + 1 ) < GRID_SIZE ) ) {
        if ( currGame->board[ r + 1 ][ c ] == '.' ) {
          currGame->board[ r + 1 ][ c ] = '*';
        }
        else {
          currGame->board[ r + 1 ][ c ] = '.';
        }
      }
      // Right
      if ( ( ( c + 1 ) >= 0 ) && ( ( c + 1 ) < GRID_SIZE ) ) {
        if ( currGame->board[ r ][ c + 1 ] == '.' ) {
          currGame->board[ r ][ c + 1 ] = '*';
        }
        else {
          currGame->board[ r ][ c + 1 ] = '.';
        }
      }
      // Left
      if ( ( ( c - 1 ) >= 0 ) && ( ( c - 1 ) < GRID_SIZE ) ) {
        if ( currGame->board[ r ][ c - 1 ] == '.' ) {
          currGame->board[ r ][ c - 1 ] = '*';
        }
        else {
          currGame->board[ r ][ c - 1 ] = '.';
        }
      }
      // Done, display message
      printf( "%s\n", SUCCESS );

    }
  }
  else if ( strcmp( argv[ 1 ], "undo") == 0 ) {
    // Check similarity to previous grid. If the same, can't undo
    int validUndo = 0;
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        if ( currGame->copy[ i ][ j ] != currGame->board[ i ][ j ] ) {
          // There is a difference, good to go
          validUndo = 1;
        }
      }
    }
    // Copy over old grid, or exit with error
    if ( validUndo ) {
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          currGame->board[ i ][ j ] = currGame->copy[ i ][ j ];
        }
      }

      // Return success message
      printf( "%s\n", SUCCESS );
    }
    // Error
    else {
      printf( "%s\n", ERROR );
    }
  }
  // Printf out current board report
  else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // Print out shared memory struct
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        printf( "%c", currGame->board[ i ][ j ] );
      }
      printf("\n");
    }
  }
  // Command not recognized
  else {
    printf( "%s\n", ERROR );
  }

  // All commands read, good to exit
  return 0;
}
