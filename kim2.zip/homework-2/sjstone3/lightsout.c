/**
 * @file lightsout.c
 * @author Sam Stone (sjstone3)
 * @brief 
 * It will interpret a user command given in the command-
 * line arguments and make requested changes to the game board stored in shared memory. You can also
 * use a header file named common.h that can be included by both of your programs.
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//evaluates if the string is made up only of digits
bool isNumber( char *input ) {  
  int i = 0;
  while( input[ i ] ) {
    if( input[ i ] < '0' || input[ i ] > '9' ) {
      return false;
    }
    i++;
  }
  return true;
}

/**
  Switches the lights on/off at the given coordinate, left, right, above and below
  @param r rows
  @param c columns
  @param board the board being modified
*/
void move( int r, int c, char board[ GRID_SIZE ][ GRID_SIZE ] ) {
 
  char change = ( board[ r ][ c ] == '*' ? '.' : '*' ); //given coord
  board[ r ][ c ] = change;

  if( r + 1 < GRID_SIZE && r + 1 >= 0 ) { //top of coords
    change = ( board[ r + 1 ][ c ] == '*' ? '.' : '*' );
    board[ r + 1 ][ c ] = change;
  }

  if( r - 1 < GRID_SIZE && r - 1 >= 0 ) { //bottom of coords
    change = ( board[ r - 1][ c ] == '*' ? '.' : '*' );
    board[ r - 1 ][ c ] = change;
  }

  if( c + 1 < GRID_SIZE && c + 1 >= 0 ) { //right of coords
    change = ( board[ r ][ c + 1 ] == '*' ? '.' : '*' );
    board[ r ][ c + 1 ] = change;
  }

  if( c - 1 < GRID_SIZE && c - 1 >= 0 ) { //left of coords
    change = ( board[ r ][ c - 1 ] == '*' ? '.' : '*' );
    board[ r ][ c - 1 ] = change;
  }
}

//Prints out the given board double array into a grid format
void reportBoard( char board[ GRID_SIZE ][ GRID_SIZE ] ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      printf("%c", board[ i ][ j ] );
    }
    printf( "\n" );
  }
}

/**
 * Handles user commands and changes the board
 */
int main( int argc, char *argv[] ) { 
  if( argc <= 1 ) {
    fail( "error" );
  }

  char *cmd = argv[ 1 ];

  //create shared memory
  key_t key = ftok( "/afs/unity.ncsu.edu/users/s/sjstone3", 5 );
  int shmid = shmget( key, 0, 0 );
  if( shmid == -1 ) {
    fprintf( stderr, "%s\n", strerror( errno ) );
  }
  GameState *board = ( GameState * )shmat( shmid, 0, 0 );
  
  /////  MOVE  /////
  if( strcmp( cmd, "move" ) == 0 ) { //move r c
    if( argc != 4 ) {
      fail( "error" );
    }
    //check if valid row and column inputs
    if( !isNumber( argv[ 2 ] ) || !isNumber( argv[ 3 ] ) ) {      
      fail( "error" );
    }
    
    int r = atoi( argv[ 2 ] );
    int c =  atoi( argv[ 3 ] );  
    //columns and rows have to be inputs 0-3  
    if( r < 0 || r > 4 || c < 0 || c > 4 ) {
      fail( "error" );
    }
    
    //copy the current board into the old board state before making the move
    memcpy( board->old, board->recent, sizeof( char ) * GRID_SIZE * GRID_SIZE );
    move( r, c, board->recent );
    //since a move has been made, user can now undo it
    board->undoValid = true;
    
    printf( "success\n" );

  /////  UNDO  /////
  } else if( strcmp( "undo", cmd ) == 0 ) {
    if( !board->undoValid ) {
      fail( "error" );
    }
    memcpy( board->recent, board->old, sizeof( char ) * GRID_SIZE * GRID_SIZE );
    board->undoValid = false;
    printf( "success\n" );

  /////  REPORT  /////
  } else if( strcmp( "report", cmd ) == 0 ) {    
    reportBoard( board->recent );     
  } else {
    fail( "error" );
  }

  //detach shared memory
  shmdt( board );

  return 0;
}
