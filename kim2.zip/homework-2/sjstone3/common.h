// Height and width of the playing area.
#define GRID_SIZE 5

/**
 * Representation of the board and most recent move
 * 
 */
typedef struct {
  char recent[ GRID_SIZE ][ GRID_SIZE ];  
  char old[ GRID_SIZE ][ GRID_SIZE ];
  //used for error checking to make sure user doesn't use undo twice
  //in a row or before a move has been mades
  bool undoValid;
} GameState;
