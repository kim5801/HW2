import java.util.Scanner;
import java.util.ArrayList;

/**
 * Takes a command line argument giving the number of workers to use to find the
 * contiguous non-empty subsequence within the sequence of integers that has the
 * largest sum
 * 
 * Takes the optional argument report, tells it to report the largest sum each
 * worker finds from its own part of the work.
 * 
 * @author Sam Stone
 *
 */

public class Maxsum {

	/** Represents each worker Thread */
	static class Worker extends Thread {
		private int workerNum; // what number worker is this thread
		private int numWorkers; // how many total workers are being used
		private int partitionNum; // how many partitions this worker is expected to evaluate
		public int topSum;

		public Worker(int workerNum, int numWorkers, int partitionNum) {
			this.workerNum = workerNum;
			this.numWorkers = numWorkers;
			this.partitionNum = partitionNum;
			topSum = 0;
		}

		public void run() {
			int j = workerNum;
			int localSum = 0;
			int partCount = 1; // keeps track of current partition number
			while (j < vList.size()) {
				localSum += vList.get(j);

				if (localSum > topSum) {
					topSum = localSum;
				}
				// once the end of the array is reached and the worker still has more partitions
				// to count,
				// start at the next partition and count up again
				if (j == vList.size() - 1 && partitionNum != 0) {
					partitionNum--;
					j = workerNum + numWorkers * partCount;
					localSum = 0; // reset sum for new partition
					partCount++;
					continue;
				} else {
					j++;
				}
			}
		}
	}

	private static ArrayList<Integer> vList; //contains each int value from stdin

	public static void main(String[] args) {
		if (args.length < 1 || args.length > 2) { // invalid number of commands
			usage();
		}

		int numWorkers = 0;
		boolean report = false; //flag used if user wants each Worker to print out the sum they calculated
		try {
			numWorkers = Integer.parseInt(args[0]);
		} catch (NumberFormatException e) {
			usage();
		}

		if (numWorkers < 1) { // invalid number of workers
			usage();
		}

		// If there's a second argument, it better be the word, report
		if (args.length == 2) {
			if (args[1].equals("report")) {
				report = true;
			} else {
				usage();
			}
		}

		vList = new ArrayList<Integer>();
		readInput(); // read in input sequence

		// how many parts of the list each worker should evaluate
		int numPartitions = vList.size() / numWorkers;

		int maxSum = 0;

		// create requested number of worker threads that work in parallel to find
		// largest sum
		Worker[] thread = new Worker[numWorkers];
		for (int i = 0; i < thread.length; i++) {
			thread[i] = new Worker(i, numWorkers, numPartitions);
			thread[i].start();
		}

		// wait for each of the threads to terminate
		try {
			for (int i = 0; i < thread.length; i++) {
				thread[i].join();
				int workerSum = thread[i].topSum;
				
				//find the maximum sum out of all of the workers
				if (workerSum > maxSum) {
					maxSum = workerSum;
				}
				if (report) {
					// print out local sum
					System.out.println(
							"I'm thread " + thread[i].getId() + ". The maximum sum I found is " + workerSum + ".");
				}
			}
		} catch (InterruptedException e) {
			fail("Interrupted during join.");
		}

		// report max sum
		System.out.println("Maximum Sum: " + maxSum);

	}

	// Print out an error message and exit.
	static void fail(String message) {
		System.out.println(message + "\n");
		System.exit(1);
	}

	// Print out a usage message, then exit.
	static void usage() {
		System.out.println("usage: maxsum <workers>\n");
		System.out.println("       maxsum <workers> report\n");
		System.exit(1);
	}

	/**
	 * Reads the input from stdin and stores it into the ArrayList of integers
	 */
	private static void readInput() {
		Scanner scanner = new Scanner(System.in);
		
		while (scanner.hasNext()) {
			if (scanner.hasNextInt()) {
				vList.add(scanner.nextInt());
			} else {
				fail("Invalid input");
			}
		}
		scanner.close();
	}
}
