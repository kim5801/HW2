/**
 * @file reset.c
 * @author Sam Stone (sjstone3)
 * Its job will be to read the initial game board state just like
 * the server did in the previous assignment and create a shared memory segment containing any needed
 * information about the game. The reset.c program will just exit after creating the shared memory
 * segment and initializing it based on the board description file.
 * 
 */

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <errno.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/**
  Takes in a file and stores each of the characters into the gameboard array
  Detects if there's any errors in the file format
  @param file the file being read
  @param filename the name of the input file
  @param board the board where the * and . chars are stored for the game
*/
void readBoard( FILE *file, char *filename, GameState *board ) {
  char currCh = '0';
  int rows = 0;
  int columns = 0;

  //read in board from file
  while( currCh != EOF ) { 
    currCh = fgetc( file );    
    if( currCh == '*' || currCh == '.' ) {
      
      board->recent[ rows ][ columns ] = currCh;
      board->old[ rows ][ columns ] = currCh;
      columns++;      
    } else if( currCh == '\n' ) { 
      //too many or too few columns     
      if( columns != GRID_SIZE ) {
        fprintf( stderr, "columns Invalid input file: %s\n", filename );
        exit( 1 );
      }
      rows++;
      columns = 0;
    } else if( currCh == EOF ) {
      continue;
    } else { //invalid character
      fprintf( stderr, "Invalid input file: %s\n", filename );
      exit( 1 );
    }
  }
  //too many or too few rows
  if( rows != GRID_SIZE ) {
    fprintf( stderr, "%d", rows );      
    fprintf( stderr, "rows Invalid input file: %s\n", filename );
    exit( 1 );
  }
  
}

//Loads in the given file to populate the GameState
//This shared memory will be used by lightsout.c 
int main( int argc, char *argv[] ) {
  //only expects 1 cmd line argument
  if( argc != 2 ) {
    fail( "usage: reset <board-file>" );
  }

  //open board file
  FILE *file = fopen( argv[ 1 ], "r" );
  if( file == 0 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }
  
  //create shared memory
  key_t key = ftok( "/afs/unity.ncsu.edu/users/s/sjstone3", 5 );
  int shmid = shmget( key, sizeof( GameState ), IPC_CREAT | 0666 );
  if( shmid == -1 ) {
    fprintf(stderr, "%s\n", strerror( errno));
    usage();
    
  }

  //attatch the GameState struct to the shared memorys
  GameState *board = ( GameState * )shmat( shmid, 0, 0 );
  readBoard( file, argv[ 1 ], board );
  board->undoValid = false;

  return 0;
}
