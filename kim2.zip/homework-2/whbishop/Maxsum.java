import java.util.*;

/**
 * Q2 for HW 2 CSC 246
 * Class that computes the maximum sum of a given file using workers (threads)
 * @author William Bishop 
 * 9/29/22 Original Version
 */
public class Maxsum {	
	
  /**
   * Prints out an error message and exits the program
   * @param msg the string to print out
   */
	private static void fail(String msg) {
		System.out.println(msg);
		System.exit(1);
	}

  /**
   * Prints out the usage for the program, and then exists the program
   */
	private static void usage() {
		System.out.println("usage: maxsum <workers>");
		System.out.println("       maxsum <workers> report");
		System.exit(1);
	}

	/** Input sequence of values. */
	private static ArrayList<Integer> vList;

	/** Number of values on the list */
	private static int vCount = 0;

	/** Capacity of the list of values. */
	private int vCap = 0;
  
  /** Bool flag to tell if it is the first thread */
	private static volatile Boolean first = true;

  /** Global maximum that the program has found */
	private static volatile int globalMaximum;

  /** Bool flag to tell if the user would like to report each thread or not */
	private static volatile Boolean report;

  /** Array to hold all the different threads */
	private static MyThread[] thread;

  /** Number of workers the user wants */
	private static int workers;
  
  /** 
   * Function to read in the integers from the given input file
   * Creates a new scanner and scans them into the list.
   */
	private static void readList() {
		vList = new ArrayList<Integer>();
		Scanner scnr = new Scanner(System.in);
		int v;
		while (scnr.hasNextInt()) {
			v = scnr.nextInt();
			
			vList.add(vCount, v);
			vCount++;
		}
	}
  
  /**
   * Main starting point of the program
   * Creates all the workers and prints out 
   * the maximum sum
   * @param args[] the string array of the 
   * command line arguments
   */
	public static void main(String args[]) {
    
    report = false;
		workers = 0;
    
    //Parse Command Line Args
		if (args.length < 1 || args.length > 2) usage();

		try {
			workers = Integer.parseInt(args[0]);
		}
		catch (Exception e) {
			usage();
		}

		//If there is a second argument, it better be "report"
		if (args.length == 2) {
			if ("report".equals(args[1])) report = true;
			else usage();
		}

		//Read in the list of integers
		readList();

    //Taken from ThreadArguments.java
    //Create a new thread array and create each new thread, and start it
		thread = new MyThread[workers];
		for (int i = 0; i < workers; i++) {
			thread[i] = new MyThread(i);
			thread[i].start();
		}
    
    //Also taken from ThreadArguments
    //Try to join each worker, catch any exceptions.
		try {
			for (int i = 0; i < workers; i++) thread[i].join();
		} catch ( InterruptedException e ) {
			 System.out.println( "Interrupted during join!" );
		}
    
    //Print out the global maximum sum
		System.out.println("Maximum Sum: " + globalMaximum);
  }

  /**
   * Class taken from ThreadArguments.java
   * A subclass that tells the thread what to do
   */
	static class MyThread extends Thread {

		/** The thread's place in the array */
		private int x;
    
    /** Constructor for the thread
     * @param x the thread's place in the array */
		public MyThread(int x) {
			this.x = x;
		}

    /** 
     * Runs the thread, calculating it's local sum
     */
		public void run() {
			int maxSum = 0;
      
      //Top level of the loop iterates through the indicies, 
      //incrementing by the workers amount
			for (int i = x; i < vCount; i += workers) {
				int currentSumMax = 0;

        //Second level of the loop indexes into each int, and adds 
        //it to the current sum of the thread
				for (int j = i; j < vCount; j++) {
					if (j >= vCount) break;
					currentSumMax += vList.get(j);

          //If the current sum max is greater than the max, we change the max.
					if (currentSumMax > maxSum) maxSum = currentSumMax;
				}
        
        //If this is the first thread, set the max to be the max of the thread
        //Ihope this doesn't break
        //I know I can use semaphores to fix this
				if (first) {
					globalMaximum = maxSum;
					first = false;
				}
        
        //Set the global max
				if (maxSum > globalMaximum) globalMaximum = maxSum;
			}
      
      //Report the individual thread if the user wants
			if (report) System.out.println("I'm thread " + thread[x].getId() + ". The maximum sum I found is " + maxSum + ".");
		}
	}
}
