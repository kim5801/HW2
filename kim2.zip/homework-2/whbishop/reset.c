#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Function that frees the board struct we have, freeing the shared mem
static void freeBoard( GameState *currentGame, int memID) {
	shmdt(currentGame);
	shmctl(memID, IPC_RMID, 0);
}


//Main method for the program, resets the board for main memory for use in lightsout
int main( int argc, char *argv[] ) {

	//Need correct command line args
	if (argc != 2) usage();

	//Open our file for reading, if invalid, let the user know and exit
	FILE* fp = fopen(argv[1], "r");
	if (fp == NULL) {
		fprintf( stderr, "Invalid input file: %s\n", argv[1]);
		exit(1);
	}

	
		
	//Create the shared memory segment
	int shmid = shmget(ftok(unityID, 1), sizeof(GameState), 0666 | IPC_CREAT);
	if (shmid == -1) fail("Cannot create shared mem");

	//Map the shared memory
	GameState* currentGame = (GameState *)shmat(shmid, 0 ,0);
	if (currentGame == (GameState *)-1) fail("Can't map the shared memory into the address space");

	//Set the undo flag to 1
	currentGame->undo = 1;

	//Set vars, got this from my last homework
	int count = 0;
	char ch;
	int line = 1;

	//Gets the input file chars, and attempt to add them
	while ((ch = fgetc(fp)) != EOF) {

		//If there are > 25 chars, its an invalid input file, free the board
		if (count > 25) {
			fprintf( stderr, "Invalid input file: %s\n", argv[1]);
			freeBoard(currentGame, shmid);
			exit(1);
		}

		//If the character is anything other than a ". * \n" let the user know and exit
		if (ch != '.' && ch != '*' && ch != '\n') {
			fprintf( stderr, "Invalid input file: %s\n", argv[1]);
			freeBoard(currentGame, shmid);
			exit(1);
		}

		//Got this part from my last homework, checks that every 6th char is a newline,
		//If it isnt let the user know, free the board, and exit
		if ((count % 5 == 0 && (ch == '.' || ch == '*') && line)) {
			currentGame->newBoard[count++] = ch;
			line = 0;
			continue;
		} else if ((count % 5 == 0 && ch != '\n') || ((count % 5 != 0) && ch == '\n')) {
			fprintf( stderr, "Invalid input file: %s\n", argv[1]);
			freeBoard(currentGame, shmid);
			exit(1);
		}

		//Set our newline flag
		if (ch == '\n') {
			line = 1; 
			continue;
		}
		
		//Put the char into our struct
		currentGame->newBoard[count++] = ch;
	}

	//put the game in shared mem
	shmdt(currentGame);

	//exit successfully
  return 0;
}



