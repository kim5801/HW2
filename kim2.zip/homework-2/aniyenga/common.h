// Height and width of the playing area.
#define GRID_SIZE 5

typedef struct {
	
	char grid[GRID_SIZE][GRID_SIZE + 1];
	
	
	char prevGrid[GRID_SIZE][GRID_SIZE + 1];
	int undo;
} board;
