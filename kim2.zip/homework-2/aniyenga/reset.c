#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// gcc -Wall -g -std=c99 -D_XOPEN_SOURCE=500 -o reset reset.c
//gcc -Wall -g -std=c99 -D_XOPEN_SOURCE=500 -o lightsout lightsout.c


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  if(argc < 2 || argc > 2) {
    
    fail("usage: reset <board-file>\n");
    exit(1);
  }
  FILE *fp = fopen(argv[1], "r");
  //board *b =(board *)malloc(sizeof(board));
  if(fp == NULL) {
  	printf("Invalid input file: %s\n", argv[1]);
  	exit(1);
  }
  char c;
  
  char *buff = (char *)malloc((GRID_SIZE * GRID_SIZE) * sizeof(char));
  char buffed[GRID_SIZE][GRID_SIZE + 1];
  //int newLineCount = 0;
  int ind = 0;
  while(1) {
  	c = fgetc(fp);
  	if(c == EOF) {
  		break;
  	}
  	if(c != '*') {
  		if(c != '.') {
  			if(c != '\n') {
  				//printf("Invalid input file: %s\n", argv[1]);
  				usage();
  			}
  		}
  	} 
	buff[ind] = c;
	ind++;
  			  		
  	
  }
  ind = 0;
  for(int i = 0; i < 5; i++) {
  	for(int j = 0; j < 6; j++) {
		buffed[i][j] = buff[ind];
  		ind++;
  		
  	}
  }

  int shmid;
  key_t key = ftok("/afs/unity.ncsu.edu/users/a/aniyenga", 1);

  //Additional flags if code doesnt work
  // S_IWUSR and S_IRUSR
  
  // (board *)malloc(sizeof(board));
  //printf("asdf\n%s", buffed);
  shmid = shmget(key, sizeof(board), S_IWUSR | IPC_CREAT | 0666);
  board *b = shmat(shmid, NULL, 0);
  b->undo = 1;
  for(int i = 0; i < 5; i++) {
  	strcpy(b->grid[i], buffed[i]);
  	//strcpy(b->prevGrid[i], buffed[i]);
  }
  
//   for(int j = 0; j < 5; j++) {
//   	strcpy(b->prevGrid[j], buffed[j]);
//   }

  
 	
  //sbuffer = (char *)shmat(shmid, NULL, 0);
  


  //free(b);
  //free(buff);
 // shmdt(b);

  return 0;
}
