import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.util.ArrayList;

import java.util.Scanner;





public class Maxsum {
    
  private static ArrayList<Integer> list = new ArrayList<Integer>();
  private static volatile int thread = 0;
  
  private static volatile int max = 0;
  
  static class Threads extends Thread {
  
  	private int x;
  	
  	public Threads(int x){
  		this.x = x;
  	}
  
  
  	
    public void run() {
    //Initial Implementation
    	// max = 0;
//     	for(int i = thread; i < list.size(); i++) {
//     		max += list.get(i);
//     	}
//     	thread++;
//     	System.out.println("Im thread " + thread + ". The maximum sum I found is " + max);
//     	
//Implementation
//		int maxSum = 0;
//     	
//     	for(int i = 0; i < thread; i++) {
//     		for(int j = i + 1; j < list.size(); j++) {
//     			maxSum += list.get(j);
//     			if(maxSum > max) {
//     				max = maxSum;
//     			}
//     		}
//     		
//     	}

		//CLOSEST Implementation
		int maxSum = 0;
		for(int i = x; i < list.size(); i += thread) {
			maxSum = list.get(i);
			for(int j = i + 1; j < list.size(); j++) {
				maxSum += list.get(j);
				if(maxSum > max) {
					max = maxSum;
				}
			}
			 
		
		}
		//Most interesting implementation
		// int  = 0;
// 		int maxSum = list.get(x);
// 		for(int i = x + 1; i < list.size(); i += thread) {
// 			for(int j = i; j < list.size(); j++) {
// 				maxSum += list.get(j);
// 				
// 			}
// 			if(maxSum > max) {
// 				max = maxSum;
// 			}
// 		}
    	
    }
    //How the thread and sum should be formatted
    //I’m thread 10. The maximum sum I found is 145.
    
    
  }
    
    
    
    
    
    
    
    
  public static void main( String[] args ) {
    Scanner scan = null;
    
    try {
    	scan = new Scanner(System.in);
    } catch(Exception e) {
    	System.out.println("File does not exit");
    	System.exit(1);
    }
    
    while(scan.hasNextInt()) {
    	list.add(scan.nextInt());
    	
    }
    int max_val = 0;
    int num_threads = Integer.parseInt(args[0]);
    thread = num_threads;
    //System.out.println(num_threads);
    for(int i = 0; i < num_threads; i++) {
    	//Old implementation when using runnable
    	//Thread newThread = new Thread( new Threads() );
    	Thread newThread = new Threads(i + 1);
    	newThread.start();
    	try {
    		newThread.join();
    	} catch (InterruptedException e) {
    	
    	}
    	System.out.println("I'm thread " + newThread.getId() + ". The maximum sum I found is " + max);
    	if(max > max_val) {
    		max_val = max;
    	}
    	max -= i;
    }
    System.out.println("Maximum Sum: " + max_val);
	// 
// 	int maxSum = 0;
// 	for(int j = 0; j < list.size(); j++) {
// 		maxSum += list.get(j);
// 	}
// 	System.out.println("Sum " + maxSum);
//     
    
    
    
    
    
    
    
    
    
    
  }
    
}




