#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
	// = (board *)malloc(sizeof(board));
	key_t key = ftok("/afs/unity.ncsu.edu/users/a/aniyenga", 1);
	int shmid = shmget( key, sizeof(board), 0666 | IPC_CREAT );
	board *b = (board *)shmat(shmid, NULL, 0);
	int x = -1;
	int y = -1;

	//char buff[GRID_SIZE][GRID_SIZE + 1];
// 	for(int j = 0; j < GRID_SIZE; j++) {
// 		strcpy(b->prevGrid[j], b->grid[j]);
// 		
// 	}
	//b->undo = 1;

	if(strcmp(argv[1], "move") == 0) {
	
		//need to save grid to prevGrid before changing grid
		int arg2 = atoi(argv[2]);
		int arg3 = atoi(argv[3]);
		int num1 = 0;
		char *arr1 = argv[2];
		for(int i = 0; arr1[i]; i++) {
			num1 = (num1 * 10) + (arr1[i] - 48);
		}
		int num2 = 0;
		char *arr2 = argv[3];
		for(int i = 0; arr2[i]; i++) {
			num2 = (num2 * 10) + (arr2[i] - 48);
		}
		if(arg2 != num1) {
			fail("error");
		}
		if(arg3 != num2) {
			fail("error");
		}
		if(num1 >= 5 || num1 < 0) {
			fail("error");
		}
		
		if(num2 >= 5 || num2 < 0) {
			fail("error");
		}
		x = num1;
		y = num2;
		for(int j = 0; j < GRID_SIZE; j++) {
			strcpy(b->prevGrid[j], b->grid[j]);
		}
		if(b->grid[x][y] == '.') {
			b->grid[x][y] = '*';
		} else {
			b->grid[x][y] = '.';
		}
		//above
		if(x != 0) {
			if(b->grid[x - 1][y] == '.') {
				b->grid[x - 1][y] = '*';
			} else {
				b->grid[x - 1][y] = '.';
			}
		}
		
		//below
		if(x != 4) {
			if(b->grid[x + 1][y] == '.') {
				b->grid[x + 1][y] = '*';
			} else {
				b->grid[x + 1][y] = '.';
			}
		}
		
		//left
		if(y != 0) {
			if(b->grid[x][y - 1] == '.') {
				b->grid[x][y - 1] = '*';
			} else {
				b->grid[x][y - 1] = '.';
			}
		}
		
		
		//right
		if(y != 4) {
			if(b->grid[x][y + 1] == '.') {
				b->grid[x][y + 1] = '*';
			} else {
				b->grid[x][y + 1] = '.';
			}
		}
		printf("success\n");
		b->undo = 0;
		
		
		
		
	} else if(strcmp(argv[1], "undo") == 0) {
// 		if(x < 0 || y < 0) {
// 			fail("error");
// 		}
// 		int check = 0;
// 		for(int i = 0; i < GRID_SIZE; i++) {
// 			for(int j = 0; j < 6; j++) {
// 				if(b->prevGrid[i][j] == b->grid[i][j]) {
// 					check++;
// 				}
// 			}
// 		}
// 		//check if each char is the same if it is then no move has occurred
// 		//printf("%d", check);
// 		if(check == (6 * GRID_SIZE)) {
// 			fail("error");
// 		}
		if(b->undo == 1) {
			fail("error");
		}
		for(int j = 0; j < GRID_SIZE; j++) {
			strcpy(b->grid[j], b->prevGrid[j]);
		}
		printf("success\n");
		
		
		
		
		
	} else if(strcmp(argv[1], "report") == 0) {
		for(int i = 0; i < 5; i++) {
  			for(int j = 0; j < 6; j++) {
  				printf("%c", b->grid[i][j]);
  			}
 		}
	} else {
		fail("error");
	}


  return 0;
}
