#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

// Reads in the file and fills the 2D array with 0's and 1's
void initializeBoard(int board[GRID_SIZE][GRID_SIZE], int argc, char *argv[]) {
  //should only have 2 command line args
  if (argc != 2) {
    usage();
  }
  
  //open the file from the second command line argument
  FILE *fp = fopen(argv[1], "r");
  if (!fp) {
    char message[] = "Invalid input file: ";
    strcat(message, argv[1]);
    fail(message);
  }

  //the character being read
  int ch;
  //outer index of the 2D array
  int outerIndex = 0;
  //inner index of the 2D array
  int innerIndex = 0;
  //read in each character until end of file
  while ((ch = fgetc(fp)) != EOF) {
    // * -> 1
    if (ch == '*') {
      board[outerIndex][innerIndex] = 1;
    // . -> 1
    } else if (ch == '.') {
      board[outerIndex][innerIndex] = 0;
    //if we hit new line, move down array and start from left
    } else if (ch == '\n') {
      //not in correct dimmensions
      if (innerIndex != GRID_SIZE) {
        char message[] = "Invalid input file: ";
        strcat(message, argv[1]);
        fail(message);
      }
      //reset for next row of 2D array
      outerIndex++;
      innerIndex = -1;
    //bad character
    } else {
      char message[] = "Invalid input file: ";
      strcat(message, argv[1]);
      fail(message);
    }
    //go from left to right within the row
    innerIndex++;
  }
}

// Sets up the shared memory to be used with lightsout.c and returns
//pointer to it
GameState *initializeMemory(int size) {
  //get unique key based off home directory for cdseitz 
  key_t key = ftok(HOME_DIR, 1);
  if (key == -1)
    fail("ftok unsucessful with the directory");

  //get a GameState pointer to the shared memory
  int shmid = shmget(key, size, 0666 | IPC_CREAT);
  if (shmid == -1)
    fail("shmget operation unsucessful with the given key and size");
  GameState *statePtr = (GameState*) shmat(shmid, 0,0);

  //initialize fields of the struct
  statePtr->lastMove[0] = 5;
  statePtr->lastMove[1] = 5;
  statePtr->canUndo = 0;

  return statePtr;
}

int main( int argc, char *argv[] ) {

  //initialize struct for sizeof only
  GameState state;

  //get a GameState ptr back from the shared memory
  GameState *stateMem = initializeMemory(sizeof(state));

  //set up the game board with the filename
  initializeBoard(stateMem->board, argc, argv);

  return 0;
}
