#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// If it detects one of the error conditions, print error and
//exit unsuccessfully 
static void error() {
  printf("error\n");
  exit(EXIT_FAILURE);
}

// Request successfull so print and exit.
static void success() {
  printf("success\n");
  exit(EXIT_SUCCESS);
}

// Sets up the shared memory that reset.c created and returns
//pointer to it
GameState *initializeMemory(int size) {
  //get unique key based off home directory for cdseitz 
  key_t key = ftok(HOME_DIR, 1);
  if (key == -1)
    fail("ftok unsucessful with the directory");
  
  //get a GameState pointer to the shared memory
  int shmid = shmget(key, size, 0);
  if (shmid == -1)
    fail("shmget operation unsucessful with the given key and size");
  GameState *statePtr = (GameState*) shmat(shmid, 0,0);

  return statePtr;
}

// Prints out the game board stored in the struct row by row
static void report(GameState *stateMem) {
  //start with empty string that we are going to add to
  char message[GRID_SIZE * GRID_SIZE] = "";
  
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      int cell = stateMem->board[i][j];
      //translate 0 to .
      if (cell == 0) {
        strncat(message, ".", 1);
      // 1 goes to *
      } else {
        strncat(message, "*", 1);
      }
    }
    strncat(message, "\n", 1);
  }
  printf("%s", message);
}

// Move operation using the game board and a row, column pair
static void move(GameState *stateMem, int r, int c) {
  //change exact spot
  stateMem->board[r][c] = (stateMem->board[r][c] == 0) ? 1 : 0;

  //get spot above if it is within bounds
  if (r > 0) {
    stateMem->board[r - 1][c] = (stateMem->board[r - 1][c] == 0) ? 1 : 0;
  }
  //get spot below if it is within bounds
  if (r < GRID_SIZE - 1) {
    stateMem->board[r + 1][c] = (stateMem->board[r + 1][c] == 0) ? 1 : 0;
  }
  //get spot to left if it is within bounds
  if (c > 0) {
    stateMem->board[r][c - 1] = (stateMem->board[r][c - 1] == 0) ? 1 : 0;
  }
  //get spot to right if it is within bounds
  if (c < GRID_SIZE - 1) {
    stateMem->board[r][c + 1] = (stateMem->board[r][c + 1] == 0) ? 1 : 0;
  }

  //fill in the last move spaces for undo operation
  stateMem->lastMove[0] = r;
  stateMem->lastMove[1] = c;
  success();
}


int main( int argc, char *argv[] ) {

  //Gamestate object just used for sizeof
  GameState state;

  //get GameState pointer to the shared memory
  GameState *stateMem = initializeMemory(sizeof(state));

  //user wants a report
  if (argc == 2 && (strcmp( argv[ 1 ], "report" ) == 0 )) {
    report(stateMem);
  }

  //user wants a move
  else if (argc == 4 && (strcmp( argv[ 1 ], "move" ) == 0 )) {
    int r, c;
    int status1 = sscanf(argv[2], "%d", &r);
    int status2 = sscanf(argv[3], "%d", &c);
    if (status1 != -1 && status2 != -1 && r >= 0 && r < GRID_SIZE && c >= 0 && c < GRID_SIZE ) {
      stateMem->canUndo = 1;
      move(stateMem, r, c);
    
    //bad arguments passed in
    } else {
      error();
    }
  
  //user wants an undo
  } else if (argc == 2 && (strcmp( argv[ 1 ], "undo" ) == 0 )) {
    //if the struct field says it's not time for an undo, don't do it
    if (stateMem->canUndo != 1) {
      error();
    } else {

      //cause the undo flag to be false so you can't go back to back
      stateMem->canUndo = 0;

      //all an undo is is doing another move with the last location
      move(stateMem, stateMem->lastMove[0], stateMem->lastMove[1]);
    }
  }

  //not one of the allowed messages, so error it
  else {
    error();
  }

  return 0;
}
