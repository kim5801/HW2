import java.util.*;

/** Class used to find the max sum inside a list */
public class Maxsum {

  static class MyThread extends Thread {
    /** param list passed in */
    ArrayList<Integer> list;

    /** param index of the thread passed in */
    int threadIndex;

    /** param number of workers passed in */
    int workers;

    /** param boolean for reporting or not */
    boolean report;

    /** return value for the sum that this thread found*/
    public int sumFound;
    
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( ArrayList<Integer> list, int threadIndex, int workers, boolean report ) {
      this.list = list;
      this.threadIndex = threadIndex;
      this.workers = workers;
      this.report = report;
    }

    /** Goes through the list of starting indexes to traverse the list at different
     *  points and return the max sum found within that range.
     */
    private static int findMaxSumForRange(ArrayList<Integer> list, int count, int[] startingIndexes, int listSize) {
      //keeps track of the largest sum from all traversals of this chunk
      int maxSum = 0;
      //iterate through the array of indexes to start search from
      for (int i = 0; i < count; i++) {
        //keep track of sum starting at one of the indexes
        int currentSum = 0;
        //go from starting index to end of list
        for (int j = startingIndexes[i]; j < listSize; j++) {
          //update current sum and max sum if appropriate
          currentSum += list.get(j);
          if (currentSum > maxSum) {
            maxSum = currentSum;
          }
        }
      }
      return maxSum;
    }

    /** When run, I report in and store the largest sum into sumFound */
    public void run() {
      //size of below list. Some won't fill all buckets if evenly divisible
      int sizeArray = list.size() / workers + 1;
      //array of indexes to traverse list with
      int[] startingIndexes = new int[sizeArray];
      //above array's index
      int index = 0;

      //Go through list and add indexes evenly spaced
      for (int j = threadIndex; j < list.size(); j+= workers){
        startingIndexes[index] = j;
        index++;
      }

      //max is the maximum sum found in the thread's subrange
      this.sumFound = findMaxSumForRange(list, index, startingIndexes, list.size());

      //thread prints its max found if report flag is on
      if (report)
        System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + this.sumFound + ".");
    }
  }

  /** Use a scanner to get user input and put integers into the arraylist */
  private static void getInput(ArrayList<Integer> list) {
    Scanner scnr = new Scanner(System.in);
    while (scnr.hasNextInt()) {
      int next = scnr.nextInt();
      list.add(next);
    }
    scnr.close();
  }

  /** Print usage statement and exit if user doesn't do params correctly */
  private static void usage() {
    System.out.println( "usage: maxsum <workers>" );
    System.out.println( "       maxsum <workers> report" );
    System.exit( 1 );
  }

  /** Main does error checking for user's arguments and starts all the
   *  threads to find the max sum.
   */
  public static void main( String[] args ) {
    boolean report = false;
    int workers = 4;

    //incorrect number of arguments
    if(args.length < 1 || args.length > 2) {
      usage();
    }

    //get the number of workers from command line args
    try {
      workers = Integer.parseInt(args[0]);
    } catch (NumberFormatException e) {
      usage();
    }

    //set the report flag if given in command line args
    if (args.length == 2) {
      if (!args[1].equals("report")) {
        usage();
      }
      else {
        report = true;
      }
    }

    //initialize the overall max sum to the smallest value
    int maxSumForAll = Integer.MIN_VALUE;

    //array list of integers passed in
    ArrayList<Integer> list = new ArrayList<>();

    //fill list with user input
    getInput(list);

    // Make threads and let them start running.
    MyThread[] thread = new MyThread [ workers ];
    for ( int i = 0; i < thread.length; i++ ) {
      thread[ i ] = new MyThread( list, i, workers, report );
      thread[ i ].start();
    }

    // Wait for each of the threads to terminate.
    try {
      for ( int i = 0; i < thread.length; i++ ) {
        thread[ i ].join();
        //update maxSumForAll if appropriate
        if (thread[ i ].sumFound > maxSumForAll) {
          maxSumForAll = thread[ i ].sumFound;
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    
    //print out the largest sum all the threads found
    System.out.println("Maximum Sum: " + maxSumForAll);
  }
}