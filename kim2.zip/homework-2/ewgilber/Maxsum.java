/**
* This program takes a user-inputted file and uses threads to go through the numbers in
* the file and report the maximum sum found at any point during that process
* @author Ethan Gilbert
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {

    // List to store integers from file in
    static ArrayList<Integer> list;
    // True or false does user want a report
    static boolean report = false;

    //Gives worker the range of values to collect sums from
    static class MyThread extends Thread {
        private int start;
        private int sum = 0;
        private int num;
        private int remainder;
        public int localMax = 0;

        public MyThread (int start, int num, int remainder) {
            this.start = start;
            this.num = num;
            this.remainder = remainder;
        }

        //Goes through all indexes with appropriate workers and collects a local sum to 
        //later be compared in main to determine max sum
        public void run() {

            // Assigning workers to indexes to find sums of
            for(int i = start; i < start + num; i++) {
                for(int j = i; j < list.size(); j++) {
                    sum += list.get(j);
                    if(sum > localMax) {
                        localMax = sum;
                    }
                }
                sum = 0;
            }

            //Assigning remaining indexes to workers
            if(start == list.size() - remainder) {
                for(int i = start; i < start + num; i++) {
                    for(int j = i; j < list.size(); j++) {
                        sum += list.get(j);
                        if(sum > localMax) {
                            localMax = sum;
                        }
                    }
                }
                sum = 0;
            }

            //Print report
            if(report) {
                System.out.println("I'm thread " + getId() + ". The maximum sum I found is " + localMax + ".");
            }
        }
    }
    
    public static void main(String [] args) {
        int numWorkers = 0;

        if(args.length < 1 || args.length > 2) {
            usage();
        }

        if(args.length == 1) {
            numWorkers = Integer.parseInt(args[0]);
        }

        if(args.length == 2) {
            numWorkers = Integer.parseInt(args[0]);
            report = true;     
        }
        
        readList();
        
        //Number of numbers per workers
        int num = list.size() / numWorkers;
        //Remaining numbers
        int remainder = list.size() % numWorkers;

        MyThread[] threads = new MyThread[numWorkers];

        //Creating threads
        for(int i = 0; i < threads.length; i++) {
            threads[i] = new MyThread(i*num, num, remainder);
            threads[i].start();
        }

        int totalMax = 0;

        //Joining threads to compare their local maxes with the total max
        try {
            for(int i = 0; i < threads.length; i++) {
                threads[i].join();
                if(threads[i].localMax > totalMax) {
                    totalMax = threads[i].localMax;
                }
            }
        } catch(InterruptedException e) {
            fail("Error joining threads");
        }
        System.out.println("Maximum Sum: " + totalMax);
          
    }

    public static void readList() {
        list = new ArrayList<Integer>();
        int currentNum;

        Scanner scan = new Scanner(System.in);

        while(scan.hasNextInt()) {
            currentNum = scan.nextInt();
            list.add(currentNum);
        }
        scan.close();
    }

    public static void usage() {
        System.out.println( "usage: Maxsum <workers> < <filename>" );
        System.out.println( "usage: Maxsum <workers> report < <filename>" );
        System.exit(1);
    }

    public static void fail(String message) {
        System.out.println(message);
        System.exit(1);
    }
}