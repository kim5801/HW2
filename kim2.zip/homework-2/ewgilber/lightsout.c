#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

if ( argc < 2 || argc > 4 ) {
        fail( "usage: server <board-file>" );
    }
  
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/ewgilber", 1), sizeof(struct GameState), 0666 | IPC_CREAT );
  
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  struct GameState *gameState = (struct GameState *) shmat(shmid, 0, 0);
  
  if(gameState == ((struct GameState *)-1)) {
    fail("Can't map shared memory segment into address space");
  }
  
   // If move command is called
    if ( strcmp( argv[ 1 ] , "move" ) == 0 ) {
        if(argv[2] == NULL || argv[3] == NULL) {
            fail( "error" );
        }

        if(atoi(argv[2]) < 0 || atoi(argv[2]) > 4 || atoi(argv[3]) < 0 || atoi(argv[3]) > 4) {
            fail( "error" );
        }
       
        char temp[GRID_SIZE][GRID_SIZE];
        
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            temp[i][j] = gameState->board[i][j];
          }
        }

        int row = atoi(argv[1]);
        int col = atoi(argv[2]);
        
        //Left Side
        if(col == 0) {
          
          //Special Case 0 0
          if(row == 0) {
            if(temp[0][0] == '.') {
              temp[0][0] = '*';
            } else {
              temp[0][0] = '.';
            }
            if(temp[0][1] == '.') {
              temp[0][1] = '*';
            } else {
              temp[0][1] = '.';
            }
            if(temp[1][0] == '.') {
              temp[1][0] = '*';
            } else {
              temp[1][0] = '.';
            }
          }
          //Special Case 4 0
          else if(row == 4) {
            if(temp[4][0] == '.') {
              temp[4][0] = '*';
            } else {
              temp[4][0] = '.';
            }
            if(temp[4][1] == '.') {
              temp[4][1] = '*';
            } else {
              temp[4][1] = '.';
            }
            if(temp[3][0] == '.') {
              temp[3][0] = '*';
            } else {
              temp[3][0] = '.';
            }
          } else {
            //Special Case 1,2,3 0
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
          }
        }
          //Right side
          else if(col == 4) {
          //Special Case 0 4
          if(row == 0) {
            if(temp[0][4] == '.') {
              temp[0][4] = '*';
            } else {
              temp[0][4] = '.';
            }
            if(temp[0][3] == '.') {
              temp[0][3] = '*';
            } else {
              temp[0][3] = '.';
            }
            if(temp[4][1] == '.') {
              temp[4][1] = '*';
            } else {
              temp[4][1] = '.';
            }
          }
          //Special Case 4 4
          else if(row == 4) {
            if(temp[4][4] == '.') {
              temp[4][4] = '*';
            } else {
              temp[4][4] = '.';
            }
            if(temp[4][3] == '.') {
              temp[4][3] = '*';
            } else {
              temp[4][3] = '.';
            }
            if(temp[3][4] == '.') {
              temp[3][4] = '*';
            } else {
              temp[3][4] = '.';
            }
          } else {
            //Special Case 1,2,3 4
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
          }
        }
        //Top
        else if(row == 0 && (col != 0 || col != 4)) {
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row][col-1] == '.') {
              temp[row][col-1] = '*';
            } else {
              temp[row][col-1] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
        }

        //Bottom
        else if(row == 4 && (col != 0 || col != 4)) {
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col-1] == '.') {
              temp[row][col-1] = '*';
            } else {
              temp[row][col-1] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
        }
        else {
          if(temp[row][col] == '.') {
          temp[row][col] = '*';
          } else {
            temp[row][col] = '.';
          }
          if(temp[row-1][col] == '.') {
            temp[row-1][col] = '*';
          } else {
            temp[row-1][col] = '.';
          }
          if(temp[row+1][col] == '.') {
            temp[row+1][col] = '*';
          } else {
            temp[row+1][col] = '.';
          }
          if(temp[row][col-1] == '.') {
            temp[row][col-1] = '*';
          } else {
            temp[row][col-1] = '.';
          }
          if(temp[row][col+1] == '.') {
            temp[row][col+1] = '*';
          } else {
            temp[row][col+1] = '.';
          }
        }

        //printf("%s", *temp[0][0]);

        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            gameState->board[i][j] = temp[i][j];
          }
        }
        printf("Success\n");
        
    }

    //If undo command is called
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
        //Check too many arguments
        if ( argc != 2 ) {
            fail( "error" );
        }
    }

    //If report command is called
    else if ( strcmp( argv[ 1 ], "report" ) == 0) {
        //Check too many arguments
        if ( argc != 2 ) {
            fail( "error" );
        }
        
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            printf("%c", gameState->board[i][j]);
          }
        }
    } else {
        fail( "usage: server <board-file>" );
    }

  shmdt(gameState);
  return 0;
}
