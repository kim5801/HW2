#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
if(argc != 2) {
  usage();
}
int fd;
if((fd = open(argv[1], O_RDONLY)) < 0) {
  printf("Invalid input file: %s", argv[1]);
  fail("");
}

// Make a shared memory segment
  int shmid = shmget( ftok("/afs/unity.ncsu.edu/users/e/ewgilber", 1), sizeof(struct GameState), 0666 | IPC_CREAT );
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  struct GameState *gameState = (struct GameState *) shmat( shmid, 0, 0 );

  if ( gameState == (struct GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  char buffer[GRID_SIZE * (GRID_SIZE+1)];
  read(fd, buffer, sizeof(buffer));
        
        
          for(int j = 0; j < 30; j++) {
            printf("%c", buffer[j]);
          }
        
  int index = 0;
  for(int i = 0 ; i < GRID_SIZE; i++) {
    for(int j = 0 ; j < GRID_SIZE; j++) {
    gameState->board[i][j] = buffer[index];
    index++;
    }
  }


  // Release our reference to the shared memory segment.
  shmdt( gameState );

  return 0;
}
