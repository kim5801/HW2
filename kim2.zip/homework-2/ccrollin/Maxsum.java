import java.util.Arrays;
import java.util.Scanner;

/**
    @file Maxsum.java
    @author Caleb Rollins (ccrollin)
    This program uses multiple threads we will call workers to more quickly parse
    a list of positive and negative integers to figure out the maximum sum of values in any
    range throughout the list.
*/
public class Maxsum {

	// This is a helper function provided that will print out a usage message then exit.
	private static void usage()
	{
		System.out.println("usage: maxsum <workers>");
		System.out.println("       maxsum <workers> report");
		System.exit(1);
	}

	// Input sequence of values.
	private static int vList[];

	// Number of values on the list.
	private static int vCount = 0;

	// Capacity of the list of values.
	private static int vCap = 0;

	// Variable to store the number of workers the user would like to assign
	private static int workers;

	// Read the list of values.
	private static void readList()
	{
		// Set up initial list and capacity.
		vCap = 5;
		vList = new int[vCap];

		// Keep reading as many values as we can.
		int v;
		Scanner in = new Scanner(System.in);
		while ( in.hasNextInt() ) {
			v = in.nextInt();
			// Grow the list if needed.
			if ( vCount >= vCap ) {
				vCap *= 2;
				vList = Arrays.copyOf(vList, vCap);
			}

			// Store the latest value in the next array slot.
			vList[vCount++] = v;
		}
		in.close();
	}

	// This function will iterate through the vList starting at the index passed with the goal of calculating the maximum sum in this segment
	private static int runSummationSegment( int startingSegmentIndex )
	{
		int segmentMax = 0;
		int runningSum = 0;
		for ( int j = startingSegmentIndex; j < vCount; j++ ) {
			runningSum += vList[j];
			if ( runningSum > segmentMax ) {
				segmentMax = runningSum;
			}
		}
		return segmentMax;
	}

    // This is an extended version of a standard Java thread
    // that maintains additional state that we want to store in the Thread object
	static class ThreadSum extends Thread {
	    // this threads effective order of creation
        private int myEffectivePID;
	    // variables to maintain the TreadSum state such as whether the user opted for report mode
		private boolean report;
		// a variable to store the final thread maximum sum calculated
		public int mySum;

        // use a explict constructor that takes in a boolean stating whether reporting is necessary
		public ThreadSum(int myEffectivePID, boolean report) {
		    this.myEffectivePID = myEffectivePID;
			this.report = report;
		}

		// an overridden run() method that was inherited from the standard Java thread
		public void run() {
			// Workers are split up evenly
			for (int i = 0; i < vCount; i++) {
			    if ( i % workers == myEffectivePID ) {
					int segmentMaxSum = runSummationSegment( i );
                	if ( segmentMaxSum > mySum ) {
                		mySum = segmentMaxSum;
                	}
				}
			}
			// If the user wants to report the local child max then we can do that here
			if ( report ) {
				System.out.printf( "I'm thread %d. The maximum sum I found is %d.\n", getId(), mySum );
			}
		}
	}

	// Create the workers and wait for all of them to return their local max sum to then find/report the global max
	public static void main(String[] args)
	{
		// Unless the user specifies that we should report child/worker local max sums then we do assume not
		boolean report = false;

		// Parse command-line arguments.
		if ( args.length < 1 || args.length > 2 )
			usage();

		try {
			workers = Integer.parseInt(args[0]);
		}
		catch (NumberFormatException e) {
			usage();
		}

		if ( workers < 1 )
			usage();

		// If there's a second argument, it better be the word, report
		if ( args.length == 2 ) {
			if ( "report".compareTo( args[1] ) != 0 )
				usage();
			report = true;
		}

		// Call helper method that will read the input file and add the contents into vList
		readList();

		// Iterate repeatedly creating children/workers of the original parent thread
		// Let all the workers know that they can start concurrently
		ThreadSum[] workerArr = new ThreadSum[workers];
		for (int i = 0; i < workers; i++ ) {
			workerArr[i] = new ThreadSum( i, report );
			workerArr[i].start();
		}

		// Wait for all workers to finish before doing anything
		// Record the overall/global max when inspecting all workers
		int overallMax = 0;
		try {
			for (int i = 0; i < workers; i++) {
				workerArr[i].join();
				int currentWorkerSum = workerArr[i].mySum;
				if ( currentWorkerSum > overallMax ) {
					overallMax = currentWorkerSum;
				}
			}
		}
		catch ( InterruptedException e ) {
			System.out.println( "Interrupted during join!" );
		}

		// Print global max sum now that it is found
		System.out.printf( "Maximum Sum: %d\n", overallMax );
	}
}
