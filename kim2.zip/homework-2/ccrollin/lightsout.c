/**
    @file lightsout.c
    @author Caleb Rollins (ccrollin)
    This is the lightsout.c program for the Lights Out board game that will respond
    to user commands and issue them appropriately by changing the fields within the
    shared reference to the GameState struct. The same helper functions that I developed
    in the previous homework have been repurposed to accommodate for the new functionality
    and mode of inter-process communication.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// This is a helper method that makes a new move on the game board using the row and column passed
// The makeMove function is also called when the user wants to undo the last move so a parameter exists to differentiate who is calling makeMove
// We return 0 on a successful move operations, otherwise we return 1 on an unsuccessful move operation
static int makeMove( GameState *state, int row, int column, bool undoTriggered )
{
    // Ensure that the row and column sent by client are valid for the grid size
    if ( row >= 0 && row < GRID_SIZE && column >= 0 && column < GRID_SIZE ) {
        // If so just negate the current status of the cell at row and column
        state->boardStatus[row][column] = !( state->boardStatus[row][column] );
    }
    else {
        // Otherwise let the client know that they did not provide proper row and column
        return 1;
    }

    // Set the top cell above the cell at row and column while accounting for edge case
    if ( row != 0 ) {
        state->boardStatus[row - 1][column] = !( state->boardStatus[row - 1][column] );
    }
    // Set the bottom cell below the cell at row and column while accounting for edge case
    if ( row != GRID_SIZE - 1 ) {
        state->boardStatus[row + 1][column] = !( state->boardStatus[row + 1][column] );
    }
    // Set the cell to the left of the cell at row and column while accounting for edge case
    if ( column != 0 ) {
        state->boardStatus[row][column - 1] = !( state->boardStatus[row][column - 1] );
    }
    // Set the cell to the right of the cell at row and column while accounting for edge case
    if ( column != GRID_SIZE - 1 ) {
        state->boardStatus[row][column + 1] = !( state->boardStatus[row][column + 1] );
    }

    // Set the value of undoCompleted in the state struct whether an undo operation was calling makeMove
    state->undoCompleted = undoTriggered;

    // Store the most recent cell that makeMove worked on so that it can be potentially undone
    state->mostRecentMoveR = row;
    state->mostRecentMoveC = column;

    return 0;
}

// This is a helper method the delegates to makeMove to undo the last move on the game board
// A player can only undo the most recent play, so we also ensure that they cannot undo multiple times
// We return 0 on a successful move operations, otherwise we return 1 on an unsuccessful move operation
static int undoMove( GameState *state )
{
    if ( state->undoCompleted ) {
        return 1;
    }
    else {
        makeMove( state, state->mostRecentMoveR, state->mostRecentMoveC, true );
        return 0;
    }
}

// This is a helper method that goes through our the game grid/board stored in the state struct
// and prints out a one dimensional string representation that includes newline characters
static void reportState( GameState *state )
{
    int i = 0;
    for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE; c++ ) {
            if ( state->boardStatus[r][c] ) {
                putchar( '*' );
            }
            else {
                putchar( '.' );
            }
            i++;
        }
        putchar( '\n' );
        i++;
    }
}

// This is the home of all code in this program
// Here we read command line arguments that dictate how we play and then appropriately respond
int main( int argc, char *argv[] )
{
    // We need to have at least one command line argument to tell it what to do
    if ( argc < 2 ) {
        printf( "error\n" );
        exit( 1 );
    }

    // Here we are accessing the already created shared memory, stating the size of a GameState struct for this
    // shared memory sector. Note: the  ftok() call ensures that the id of the shared memory is unique to myself
    // by using my home directory path in AFS
    int shmID = shmget( ftok( "/afs/unity.ncsu.edu/users/c/ccrollin", 0 ), sizeof( GameState ), 0 );
    // Handle the case where we have an issue accessing shared memory
    if ( shmID == -1 ) {
        fail( "Can't access shared memory" );
    }

    // Now we can attach to the shared memory segment and get a reference (pointer) back
    // that we can now use as we see fit later on in the program
    char *sharedBuff = ( char * ) shmat( shmID, NULL, 0 );
    // Handle the case where we have an issue mapping the shared memory segment into address space
    if ( sharedBuff == ( char * ) -1 ) {
        fail( "Can't map shared memory segment into address space" );
    }

    // At first, we have access to only this shared buffer as a sequence of bytes
    // Since we know that only a GameState struct will be passed and the memory is the
    // correct size of a GameState struct, we can cast sharedBuff to a GameState ptr
    GameState *state = ( GameState * ) ( sharedBuff );

    // If the first command line argument is move then handle a move operation
    if ( strcmp( argv[1], "move" ) == 0 ) {
        // Ensure that there is a row and column command line argument specified
        if ( argc != 4 ) {
            printf( "error\n" );
            exit( 1 );
        }

        // Ensure that the length of each row and column argument is 1 (this means numbers 0-9 are still possible, but the later logic will check that
        // the row and column ranges are valid for the designated board size)
        if ( strlen( argv[2] ) != 1 || strlen( argv[3] ) != 1 ) {
            printf( "error\n" );
            exit( 1 );
        }

        // Convert the ASCII version of the row and column to integer versions
        int row = *argv[2] - '0';
        int col = *argv[3] - '0';

        int returnMoveStatus = makeMove( state, row, col, false );
        if ( returnMoveStatus == 0 ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            exit( 1 );
        }
    }
    else if ( strcmp( argv[1], "undo" ) == 0 ) {
        // If the first command line argument is to undo the previous move
        // Check that the only command line argument is the undo
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }

        int undoMoveStatus = undoMove( state );
        if ( undoMoveStatus == 0 ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            exit( 1 );
        }
    }
    else if ( strcmp( argv[1], "report" ) == 0 ) {
        // If the first command line argument is to report the current state of the board
        // Check that the only command line argument is the report
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }
        reportState( state );
    }
    else {
        // if we got a command that was not one of the valid commands then let the user know, and then quit
        printf( "error\n" );
        exit( 1 );
    }

    // Release our reference to the shared memory segment
    shmdt( sharedBuff );

    // If we made it here without calling fail() or exiting unsuccessfully, then we exit successfully
    return 0;
}
