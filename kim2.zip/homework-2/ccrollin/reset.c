/**
    @file reset.c
    @author Caleb Rollins (ccrollin)
    This is the reset.c program for the Lights Out board game that will reset the current
    state of the game board to restart play. In addition this program will set the new
    board representation to the state given in a board-file passed as a command line argument.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message and exit.
static void usage()
{
    fprintf( stderr, "usage: reset <board-file>\n" );
    exit( 1 );
}

// This function reads from our file pointer that has a board state to load in and
// sets up the struct that holds the state of the game for later use. Here we are
// returning a status of 0 for a successful call or 1 for an unsuccessful call
static int initBoard( GameState *state, FILE *fp )
{
    int currentChar;
    for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
            currentChar = fgetc( fp );
            if ( currentChar == '*' ) {
                state->boardStatus[r][c] = true;
            }
            else if ( currentChar == '.' ) {
                state->boardStatus[r][c] = false;
            }
            else if ( currentChar == '\n' ) {
                continue;
            }
            else {
                return 1;
            }
        }
    }
    return 0;
}

// This is the main entry-point where the program begins
// We are now using shared-memory as a mechanism to achieve inter-process communication
// as opposed to message queues like in the previous homework assignment. Instead of passing
// a buffer to the shared memory segment we are now using a reference to a struct called GameStruct.
// This struct maintains various fields such as the most recent cell with a move operation, the overall
// board configuration, and a boolean if the most recent operation was an undo.
int main( int argc, char *argv[] )
{
    // Check that when we call reset we are providing the initial board file to load from
    if ( argc < 2 || argc > 2 ) {
        usage();
    }

    // Here we are creating the shared memory if it does not already exist, allocating the size of a GameState struct
    // for this shared memory sector. Note: the  ftok() call ensures that the id of the shared memory is unique to myself
    // by using my home directory path in AFS
    int shmID = shmget( ftok( "/afs/unity.ncsu.edu/users/c/ccrollin", 0 ), sizeof( GameState ), 0666 | IPC_CREAT );
    // Handle the case where we have an issue creating shared memory
    if ( shmID == -1 ) {
        fail( "Can't create shared memory" );
    }

    // Now we can attach to the shared memory segment and get a reference (pointer) back
    // that we can now use as we see fit later on in the program
    char *sharedBuff = ( char * ) shmat( shmID, NULL, 0 );
    // Handle the case where we have an issue mapping the shared memory segment into address space
    if ( sharedBuff == ( char * ) -1 ) {
        fail( "Can't map shared memory segment into address space" );
    }

    // At first, we have access to only this shared buffer as a sequence of bytes
    // Since we know that only a GameState struct will be passed and the memory is the
    // correct size of a GameState struct, we can cast sharedBuff to a GameState ptr
    GameState *state = ( GameState * ) ( sharedBuff );

    //Set the variable in our GameState struct to prohibit completing an undo from the start
    state->undoCompleted = true;

    // Open the board file and ensure that it can be read from
    FILE *fp = fopen( argv[1], "r" );
    if ( !fp ) {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
    }

    // Set up the board with the provided input file
    int statusRet = initBoard( state, fp );

    // If the setup of the board was unsuccessful then respond appropriately
    if ( statusRet == 1 ) {
        fclose( fp );
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
    }
    else {
        // Otherwise, continue executing later code but close the file pointer now that we have no use for it
        fclose( fp );
    }

    // Release our reference to the shared memory segment
    shmdt( sharedBuff );

    // If we made it here without calling fail() or exiting unsuccessfully, then we exit successfully
    return 0;
}
