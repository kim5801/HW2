// Height and width of the playing area.
#define GRID_SIZE 5

// Define a single struct to hold the state of the current game
// including the grid, the most recent move, and if an undo operation was the last operation
// Here we are typedef-ing the struct for ease of use
typedef struct {
    bool boardStatus[GRID_SIZE][GRID_SIZE];
    int mostRecentMoveR;
    int mostRecentMoveC;
    bool undoCompleted;
} GameState;
