import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {

	static int threadNum = 0;
	static ArrayList<Integer> numList;
	static int max = 0;

	static class MyThread extends Thread {
		/**
		 * Effectively, a parameter we're passing the thread, which fibonacci number
		 * it's supposed to compute. Here, we can just store this in a field of the
		 * thread itself.
		 */
		private int x;

		private String report;

		/** Make a new Thread, giving it a parameter value to store. */
		public MyThread(int x) {
			this.x = x;
		}

		/** When run, I report in and compute a fibonacci number. */
		public void run() {

			// Compute our requested fibonacci number.
			int maxSum = 0;

			for (int i = x; i < numList.size(); i += threadNum) {

				if (i > numList.size()) {
					break;
				}

				int sum = 0;

				for (int j = i; j < numList.size(); j++) {
					sum += numList.get(j);
					if (sum > maxSum) {
						maxSum = sum;
					}
				}
			}

			if (maxSum > max) {
				max = maxSum;
			}

			report = "I'm thread " + this.getId() + ". The maximum sum I found is value " + maxSum + ".";
		}
	}

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		numList = new ArrayList<Integer>();
		boolean report = false;

		while (in.hasNextInt()) {
			numList.add(in.nextInt());
		}

		//threadNum = 4;
		threadNum = Integer.parseInt(args[0]);
		if(args.length > 1) {
			if("report".equals(args[1])) {
				report = true;
			}
		}

		MyThread[] threads = new MyThread[threadNum];

		for (int i = 0; i < threads.length; i++) {

			threads[i] = new MyThread(i);
			threads[i].start();
		}

		// Wait for each of the threads to terminate.
		try {
			for (int i = 0; i < threads.length; i++) {
				threads[i].join();
				if(report) {
					System.out.println(threads[i].report);
				}

				// System.out.println( "Thread terminated: " + threads[ i ].x);
			}
		} catch (InterruptedException e) {
			System.out.println("Interrupted during join!");
		}

		System.out.println("Maximum Sum: " + max);

		in.close();

	}

}
