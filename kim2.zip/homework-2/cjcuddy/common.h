// Height and width of the playing area.
#define GRID_SIZE 5

// Board total size
#define GRID_TOTAL 25

// Code for move
#define MOVE_COMMAND 'm'

// Code for undo
#define UNDO_COMMAND 'u'

// Code for report
#define REPORT_COMMAND 'r'

// Code for success
#define SUCCESSFUL 's'

// Code for error
#define ERROR 'e'

// Light on representation
#define LIGHT_ON '*'

// Light off representation
#define LIGHT_OFF '.'

// Game State struct
typedef struct
{
  // Game Board
  char board[GRID_SIZE * GRID_SIZE];
  // Undo Board
  char undoBoard[GRID_SIZE * GRID_SIZE];
  int lastMoveUndo;
} GameState;