#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// read the initial game board state just like
// the server did in the previous assignment and create a shared memory segment containing any needed
// information about the game. The reset.c program will just exit after creating the shared memory
// segment and initializing it based on the board description file.

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message and exit.
static void usage()
{
  fprintf(stderr, "usage: reset <game-state-file>\n");
  exit(1);
}

/// Reads the board from an input file into a 25-length array
/// @param fd file descriptor number for the file containing the board
/// @param board buffer that will hold the board state for the duration of the game
/// @param filename name of the file being read, used for error reporting
static void readBoard(int fd, char *board, char *filename)
{
  char buffer;
  int i = 0;
  while ((read(fd, &buffer, 1) == 1) && i < GRID_TOTAL)
  {
    if (buffer == '\n')
      continue;
    if (buffer == LIGHT_OFF || buffer == LIGHT_ON)
    {
      board[i++] = buffer;
    }
    else
    {
      char message[] = "Invalid input file: ";
      fail(strcat(message, filename));
    }
  }
}

int main(int argc, char *argv[])
{
  // board to read from file
  char board[GRID_TOTAL];
  // error handling for args
  if (argc != 2)
    usage();

  // file error handling
  int readFile = open(argv[1], O_RDONLY);
  if (readFile == -1)
  {
    fail("Invalid input file: bad-filename");
  }

  readBoard(readFile, board, argv[1]);

  GameState *state;

  // Get key of shared memory
  key_t key = ftok("/afs/unity.ncsu.edu/users/c/cjcuddy/", 'c');
  int shmid = shmget(key, sizeof(GameState), IPC_CREAT | 0666);

  // get pointer to block of memory and save state
  state = (GameState *)shmat(shmid, 0, 0); // attach shared memory
  // set game board state
  memcpy(state->board, board, sizeof(board));
  memcpy(state->undoBoard, board, sizeof(board));
  state->lastMoveUndo = false;

  return 0;
}
