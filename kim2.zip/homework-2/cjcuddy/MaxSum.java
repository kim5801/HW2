import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MaxSum {

  public static ArrayList<Integer> nums;

  static class Worker extends Thread {
    private int id;
    private int start;

    private int end;

    public int localMax;

    public Worker(int id, int start, int end) {
      this.id = id;
      this.start = start;
      this.end = end;
      localMax = 0;
    }

    // Find local max sum
    public void run() {
      int n = nums.size();
      int max = nums.get(0);
      for (int i = start; i < end; i++) {
        int sum = 0;
        for (int j = i; j < n; j++) {
          sum += nums.get(j);
          if (max < sum) {
            max = sum;
          }
        }
      }

      localMax = max;
    }
  }

  /** Make a thread and wait for it to do something. */
  public static void main(String[] args) throws IOException {
    int workers = 0;
    boolean report = false;
    nums = new ArrayList<>();

    if (args.length == 1) {
      workers = Integer.valueOf(args[0]);
    } else if (args.length == 2) {
      workers = Integer.valueOf(args[0]);
      report = true;
    } else {
      System.out.println("usage: java MaxSum <workers>");
      return;
    }

    // Process file input
    BufferedReader f = new BufferedReader(new InputStreamReader(System.in));
    String x = null;
    while ((x = f.readLine()) != null) {
      nums.add(Integer.valueOf(x));
    }

    // Init thread array and variables
    Worker[] threads = new Worker[workers];
    int n = nums.size();
    int indexesPerWorker = (n + workers - 1) / workers;
    int startIndex = 0;
    int maxSum = nums.get(0);

    // Make thread and assign it start + end index
    for (int i = 0; i < threads.length; i++) {
      int endIndex = startIndex + indexesPerWorker;
      if (endIndex >= n) {
        endIndex = n;
      }

      threads[i] = new Worker(i, startIndex, endIndex);
      threads[i].start();
      startIndex += indexesPerWorker;
    }

    // Wait for each of the threads to terminate.
    // Determine max sum
    try {
      for (int i = 0; i < threads.length; i++) {
        threads[i].join();
        if (report) {
          System.out.println("I'm thread " + threads[i].id +
              ". The maximum sum I found is " + threads[i].localMax);
        }
        maxSum = Math.max(maxSum, threads[i].localMax);
      }
    } catch (InterruptedException e) {
      System.out.println("Interrupted during join!");
    }

    System.out.println("Maximum sum: " + maxSum);
  }
}
