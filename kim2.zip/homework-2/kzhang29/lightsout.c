#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Writes the second 2d array's content into the first 2d array
 * 
 * @param oldGrid the 2d array being written over
 * @param newGrid the 2d array copied
 */
static void saveGrid(char oldGrid[5][5], char newGrid[5][5]) {
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      oldGrid[i][j] = newGrid[i][j];
    }
  }
}

/**
 * @brief Receives and processes command from user
 * 
 * @param argc the number of commands user gives
 * @param argv the arguments
 * @return int 0 if successful
 */
int main( int argc, char *argv[] ) {
  //error checking
  if(argc != 2 && argc != 4) {
    fail("usage: lightsout move r c| undo | report");
  }
  //retrieves the board from memory into address space
  struct board *board1;
  int shmid = shmget(ftok(PATH, 1), sizeof(board1), 0);
  board1 = (struct board *)shmat(shmid, 0, 0);
  //matches each of the commands to a set of processes
  if(argc == 2 && strcmp(argv[1], "report") == 0) {
    for(int i = 0; i < GRID_SIZE; i++) {
      for(int j = 0; j < GRID_SIZE; j++) {
        printf("%c", board1->currentBoard[i][j]);
      }
      printf("\n");
    }
  } else if(argc == 2 && strcmp(argv[1], "undo") == 0) {
    if(board1->hasPrevious == 1) {
      saveGrid(board1->currentBoard, board1->previousBoard);
      board1->hasPrevious = 0;
      printf("success\n");
    } else {
      shmdt(board1);
      fail("error");
    }
  } else if(argc == 4 && strcmp(argv[1], "move") == 0) {
    int row = 0;
    int col = 0;
    if(sscanf(argv[2], "%d", &row) == 0 || sscanf(argv[3], "%d", &col) == 0) {
        //disconnect from the shared memory before exiting
        shmdt(board1);
        fail("error");
    }
    //bounds check if the move is valid
    if((row < 0 || row > 4) || (col < 0 || col > 4)) {
        shmdt(board1);
        fail("error");
    }
    //save current grid and set previous = 1
    saveGrid(board1->previousBoard, board1->currentBoard);
    board1->hasPrevious = 1;
    //now flipping the light switches
    if(board1->currentBoard[row][col] == '*') {
      board1->currentBoard[row][col] = '.';
    } else {
      board1->currentBoard[row][col] = '*';
    }
    if(row - 1 >= 0) {
      if(board1->currentBoard[row - 1][col] == '*') {
        board1->currentBoard[row - 1][col] = '.';
      } else {
        board1->currentBoard[row - 1][col] = '*';
      }
    }
    if(row + 1 < GRID_SIZE) {
      if(board1->currentBoard[row + 1][col] == '*') {
        board1->currentBoard[row + 1][col] = '.';
      } else {
        board1->currentBoard[row + 1][col] = '*';
      }
    }
    if(col - 1 >= 0) {
      if(board1->currentBoard[row][col - 1] == '*') {
        board1->currentBoard[row][col - 1] = '.';
      } else {
        board1->currentBoard[row][col - 1] = '*';
      }
    }
    if(col + 1 < GRID_SIZE) {
      if(board1->currentBoard[row][col + 1] == '*') {
        board1->currentBoard[row][col + 1] = '.';
      } else {
        board1->currentBoard[row][col + 1] = '*';
      }
    }
    printf("success\n");
  } else {
    shmdt(board1);
    fail("usage: lightsout move r c| undo | report");
  }
  shmdt(board1);

  return 0;
}
