#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

/**
 * @brief This class creates a shared board and initializes it
 * 
 * @param argc number of arguments
 * @param argv the arguments
 * @return int 0 if successful
 */
int main( int argc, char *argv[] ) {
  //error checking
  if(argc != 2) {
    usage();
  }
  FILE *fp = fopen(argv[1], "r");
  char str[80];
  strcat(str, "Invalid input file: ");
  strcat(str, argv[1]);
  if (!fp) {
    fail(str);
  }
  
  //makes the board struct
  struct board *board1;
  int shmid = shmget(ftok(PATH, 1), sizeof(board1), 0);

  //before making the new board, we need to clear the previous board
  if(shmid != -1) {
    shmctl(shmid, IPC_RMID, 0);
  }
  //create it again
  shmid = shmget(ftok(PATH, 1), sizeof(board1), 0666 | IPC_CREAT);
  board1 = (struct board *)shmat(shmid, 0, 0);

  //initializes the board
  board1->hasPrevious = 0;
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      char cha = fgetc(fp);
      if(!(cha == '.' || cha == '*')) {
        fail(str);
      }
      board1->currentBoard[i][j] = cha;
    }
    char cha = fgetc(fp);
    if((cha != '\n')) {
        fail(str);
    }
  }

  //closes the connection between this process and the shared memory
  shmdt(board1);
  return 0;
}
