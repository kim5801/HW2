package hw2;

import java.util.*;

/**
 * class finds the continuous array with the largest sum in a file
 */
public class Maxsum {

    /**
     * global array that holds all the numbers in the file
     */
    public static ArrayList<Integer> arr = new ArrayList<Integer>();

    /** the number of threads a user wants */
    public static int numThreads;

    /**
     * subroutine for each individual thread
     * calculates the max number it finds and stores it in the localMax var
     */
    static class mythread extends Thread {
        /** the assigned thread number */
        private int threadnumber;

        /** the max contiguous array that this thread finds */
        public int localMax = Integer.MIN_VALUE;

        /** 
         * constructor, initiating the threadnumber
        */
        public mythread(int i) {
            this.threadnumber = i;
        }

        /**
         * loops through the array and for every threadnumber-th slot
         * calculate the max array it finds from there
         */
        public void run() {
            for(int i = 0; i < arr.size(); i++) {
                if(i % numThreads == threadnumber) {
                    int current = 0;
                    for(int j = i; j < arr.size(); j++) {
                        current += arr.get(j);
                        if(current > localMax) {
                            localMax = current;
                        }
                    }
                }
            }
            
        }

    }

    /**
     * calculates the max contiguous array sum found in a list of integers
     * @param args user input(number of threads)
     */
    public static void main(String[] args) {
        Scanner tmal = new Scanner(System.in);
        numThreads = Integer.parseInt(args[0]);
        int max = Integer.MIN_VALUE;
        mythread[] threads = new mythread[numThreads];
        while(tmal.hasNext()) {
            arr.add(Integer.parseInt(tmal.next()));
        }
        //creating a thread for each worker
        for(int i = 0; i < numThreads; i++) {
            threads[i] = new mythread(i);
            threads[i].start();
        }

        // Wait for each of the threads to terminate.
        try {
            for ( int i = 0; i < threads.length; i++ ) {
            threads[ i ].join();
            max = Integer.max(max, threads[i].localMax);
            if(args.length > 1) {
                System.out.println("I'm thread " + threads[i].getId() + ". The maximum I found is " + threads[i].localMax + ".");
            }
            }
        } catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }
        System.out.println("Maximum sum: " + max);
        tmal.close();

    }
}