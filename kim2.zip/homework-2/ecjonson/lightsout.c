/**
 * @file lightsout.c
 * @author Evan Jonson (ecjonson)
 * User program for my shared memory lightsout game. Provided that a board
 * already exists, it runs the given command to play the game.
 */

#include "common.h"

#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

/** ASCII char to int conversion difference */
#define CHAR_TO_I 48

/**
 * Prints the given error message to standard error and exits unsuccessfully.
 * @param msg The given error message to print.
 */
static void fail( char *msg ) {
    fprintf( stderr, "%s\n", msg );
    exit( EXIT_FAILURE );
}

/**
 * Prints error to standard output and exits unsuccessfully.
 */
static void error() {
    printf( "error\n" );
    exit( EXIT_FAILURE );
}

/**
 * Flip the lights for the given character. Changes
 * '.' to '*' and vice versa. Any other characters results in
 * error.
 * @param c The character to flip.
 * @return '.' or '*'. The flipped light.
 */
static char flip( char c ) {
    
    switch( c ) {
        // on to off
        case '*':
            c = '.';
            break;
        // off to on
        case '.':
            c = '*';
            break;
        // invalid character
        default:
            error();
    }

    return c;
}

/**
 * Make a move. Updates the board with the given move.
 * @param board The board to update.
 * @param r The row of the move.
 * @param c The collumn of the move.
 */
static void move( GameState *board, int r, int c ) {
    
    // flip the lights
    board->state[ r ][ c ] = flip(board->state[ r ][ c ]);

    // edge case r = 0
    if ( r )
        board->state[ r - 1 ][ c ] = flip(board->state[ r - 1 ][ c ]);
    
    // edge case r = 4
    if ( r != 4 )
        board->state[ r + 1 ][ c ] = flip(board->state[ r + 1 ][ c ]);

    // edge case c = 0
    if ( c )
        board->state[ r ][ c - 1 ] = flip(board->state[ r ][ c - 1 ]);

    // edge case c = 4
    if ( c != 4 )
        board->state[ r ][ c + 1 ] = flip(board->state[ r ][ c + 1 ]);

    // update undo flag
    board->undo = true;

    // update the last move tracker
    board->last[ 0 ] = r;
    board->last[ 1 ] = c;

    printf("success\n");
}

/**
 * Undo the last move. Repeats the last move if there was one.
 * @param board The board to update.
 */
static void undo( GameState *board ) {
    
    // check if there was a previous move
    if ( board->undo ) {

        // undo the last move
        move( board, board->last[ 0 ], board->last[ 1 ] );

        // update the boards undo flag
        board->undo = false;
    }

    else
        error();
}

/**
 * Prints a report of the current state of the board.
 * @param board The board to report.
 */
static void report( GameState *board ) {

    // print the board state
    for ( int i = 0; i < GRID_SIZE; ++i ) {
        for ( int j = 0; j < GRID_SIZE; ++j )
            printf( "%c", board->state[ i ][ j ] );

        printf( "\n" );
    }
}

/**
 * Parses a digit (int) from the passed string.
 * @param str The string to parse.
 * @return The parsed digit (int).
 */
static int parse( char const *str ) {

    // check for a single digit
    if ( strlen( str ) != 1 || !isdigit( str[ 0 ] ) )
        error();

    // parse the char
    int i = str[ 0 ] - CHAR_TO_I;

    // check range
    if ( i < 0 || i > 4 )
        error();

    // return the parsed int
    return i;
}

/**
 * Program starting point. Run the given command.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 */
int main( int argc, char *argv[] ) {

    // get a unique id for my shared memory
    key_t key = ftok( "/afs/unity.ncsu.edu/users/e/ecjonson", PROJ_ID );
    // check for errors
    if ( key == -1 )
        fail( strerror( errno ) );

    // get the id of the shared memory
    int shmid = shmget( key, 0, 0 );
    // check for errors
    if ( shmid == -1 )
        fail( strerror( errno ) );

    // map the address of the attached shared memory segment
    GameState *board = (GameState *)shmat( shmid, 0, 0 );
    // check for errors
    if ( board == (GameState *)-1 )
        fail( strerror( errno ) );

    // move command
    if ( argc == 4 && strcmp( "move", argv[ 1 ] ) == 0 ) {
        int i = parse( argv[ 2 ] );
        int j = parse( argv[ 3 ] );
        move( board, i, j );
    }

    // undo command
    else if ( argc == 2 && strcmp( "undo", argv[ 1 ] ) == 0 )
        undo( board );

    // report command
    else if ( argc == 2 && strcmp( "report", argv[ 1 ] ) == 0 )
        report( board );

    // invalid command
    else
        error();

    // detach from the shared memory
    shmdt( board );

    return EXIT_SUCCESS;
}
