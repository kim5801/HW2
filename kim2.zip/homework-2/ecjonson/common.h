/**
 * @file common.h
 * @author Evan Jonson (ecjonson)
 * Common header file for reset.c and lightsout.c, for my shared memory lightsout game.
 * Defines some common terms and the GameState struct, which tracks
 * the state of the current game board.
 */

#include <stdbool.h>

// Height and width of the playing area.
#define GRID_SIZE 5

/** The project id for ftok, and the meaning of life */
#define PROJ_ID 42

/**
 * A struct that defines the state of the game board.
 */
typedef struct {
    // the current board state
    char state[ GRID_SIZE ][ GRID_SIZE ];
    // tracks if a previous move is available
    bool undo;
    // tracks the last move
    int last[ 2 ];
} GameState;
