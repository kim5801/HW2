/**
 * @file reset.c
 * @author Evan Jonson (ecjonson)
 * Reset program for my shared memory lightsout game. Resets the state
 * of the current board with the given input file.
 */

#include "common.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <string.h>
#include <errno.h>

/**
 * Closes the given file descriptor if it's open, prints
 * the invalid file message to standard error and exits unsuccessfully.
 * @param fd The file descriptor.
 * @param filename The name of the invalid file.
 */
static void invalid( int fd, char const *filename ) {
    // close the file if it's open
    if ( fd != -1 )
        close( fd );

    fprintf( stderr, "Invalid input file: %s\n", filename );
    exit( EXIT_FAILURE );
}

/**
 * Checks if the given file exists and is properly formatted.
 * Updates the given board with the contents of filename.
 * @param board The board to update.
 * @param filename The file to read from.
 */
static void update( GameState *board, char const *filename ) {

    // open the board text file
    int fd = open( filename, O_RDONLY );

    // check for errors
    if ( fd == -1 )
        invalid( fd, filename );

    // set the undo flag
    board->undo = false;

    char c;
    int i = 0, j = 0;

    // read the board state
    while ( read( fd, &c, 1 ) == 1 ) {

        // move to the next row
        if ( c == '\n' ) {
            j = 0;
            ++i;
            continue;
        }

        // check board size
        if ( i == GRID_SIZE || j == GRID_SIZE )
            invalid( fd, filename );

        // check the character read
        switch ( c ) {

            // update the board with bleed through cases
            case '.':
            case '*':
                board->state[ i ][ j++ ] = c;
                break;

            // invalid character
            default:
                invalid( fd, filename );
        }
    }

    // close the file
    close( fd );
}

/**
 * Prints the given error message to standard error and exits unsuccessfully.
 * @param msg The given error message to print.
 */
static void fail( char *msg ) {
    fprintf( stderr, "%s\n", msg );
    exit( EXIT_FAILURE );
}

/**
 * Program starting point. Resets the state of the curent board with
 * the given input file.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 */
int main( int argc, char *argv[] ) {

    // check usage
    if ( argc != 2 )
        fail( "usage: reset <board-file>" );

    // get a unique id for my shared memory
    key_t key = ftok( "/afs/unity.ncsu.edu/users/e/ecjonson", PROJ_ID );
    // check for errors
    if ( key == -1 )
        fail( strerror( errno ) );

    // create the shared memory
    int shmid = shmget( key, sizeof( GameState ), 0666 | IPC_CREAT );
    // check for errors
    if ( shmid == -1 )
        fail( strerror( errno ) );

    // map the address of the attached shared memory segment
    GameState *board = (GameState *)shmat( shmid, 0, 0 );
    // check for errors
    if ( board == (GameState *)-1 )
        fail( strerror( errno ) );

    // load the board from the given file and update the shared memory
    update( board, argv[ 1 ] );

    // detach from the shared memory
    shmdt( board );

    return EXIT_SUCCESS;
}
