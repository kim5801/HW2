import java.util.*;

/**
 * This is an exercise on multi-threading in Java. This program reads the redirected
 * input file containing a list of integers and reports the maximum contiguous sum. This is
 * an expensive calculation, so the work is divided evenly among the specified number of worker
 * threads to speed up the calculation.
 * @author Evan Jonson (ecjonson)
 */
public class Maxsum {

    /** The list of integers from file */
    private static List<Integer> vList;
    /** True if each worker should report their results */
    private static boolean report;

    /**
     * Prints the command line usage message and exits unsuccessfully.
     */
    private static void usage() {
        System.out.println( "usage: maxsum <workers>" );
        System.out.println( "       maxsum <workers> report" );
        System.exit( 1 );
    }

    /**
     * Prints the given message to the error output stream and exits.
     * @param message The eror message to print.
     */
    private static void fail( String message ) {
        System.err.println( message );
        System.exit( 1 );
    }

    /**
     * Reads the input file and stores the list of integers.
     */
    private static void readList() {

        // initialize the array
        vList = new ArrayList<>();

        // try (with resources) to open the file
        try ( Scanner input = new Scanner( System.in ) ) {
        
            // get the next ling
            while ( input.hasNextLine() )
                // add it to the list
                vList.add( Integer.parseInt( input.nextLine() ) );
        
        } catch ( Exception e ) {
            fail( "file is not formatted correctly." );
        }
    }

    /**
     * Custom thread used to divide the work of calculating the maximum contiguous
     * sum of an array of integers. Has a public getMax() method that returns the
     * maximum value calculated by this thread.
     */
    private static class WorkerThread extends Thread {

        /** Tracks the maximum value found by this worker thread */
        private int max;
        /** The starting point */
        private int s;
        /** The number of workers running, used to divvy the work */
        private int workers;

        /**
         * Initializes this workers fields.
         * @param s The starting point of the list.
         * @param workers The number of workers.
         */
        WorkerThread( int s, int workers ) {
            max = Integer.MIN_VALUE;
            this.s = s;
            this.workers = workers;
        }

        /**
         * Runs when the thread starts. Calculates this threads portion of the work.
         */
        public void run() {

            // check if there is any work for this thread
            if ( s < vList.size() ) {

                // buffer for the maxSumStartingAt return value
                int temp;

                // do my work
                for ( int i = s; i < vList.size(); i += workers ) {
                    // get the max starting at i
                    temp = maxSumStartingAt( i );
                    
                    // new max
                    if ( temp > max )
                        max = temp;
                }

                // report results
                if ( report )
                    System.out.println( "I'm thread " + getId() + ". The maximum sum I found is " + getMax() + "." );
            }
        }

        /**
         * Getter method for the max value.
         * @return The max value found by this thread.
         */
        public int getMax() {
            return max;
        }
    }

    /**
     * Calculates the maximum sum from the provided start to finish.
     * @param s The starting index of the range.
     * @return The maximum sum in the provided range.
     */
    private static int maxSumStartingAt( int s ) {

        // tracks the current max sum in this range
        int temp = 0, max = Integer.MIN_VALUE;

        // check all ranges from the starting point
        for ( int f = s; f < vList.size(); ++f ) {

            // sum the range
            temp += vList.get( f );

            // new maximum found
            if ( temp > max )
                max = temp;
        }

        return max;
    }

    /**
     * Program starting point. Verify command line input, create the workers
     * and let them work.
     * @param args The command line arguments
     */
    public static void main( String[] args ) {

        // the number of command line arguments
        int numArgs = args.length;

        // set the report flag
        report = false;

        // check for command line arguments
        if ( numArgs < 1 || numArgs > 2 )
            usage();

        // the number of worker threads
        int workers = Integer.parseInt( args[ 0 ] );

        // check if we should report
        if ( numArgs == 2 ) {
            if ( !"report".equals( args[ 1 ] ) )
                usage();
            report = true;
        }

        // read the input file
        readList();

        // make the worker threads
        WorkerThread[] thread = new WorkerThread[ workers ];

        // start the worker threads
        for ( int i = 0; i < workers; ++i ) {
            thread[ i ] = new WorkerThread( i, workers );
            thread[ i ].start();
        }

        // try to join the worker threads.
        try {
            // wait for the threads to finish
            for ( int i = 0; i < workers; ++i )
                thread[ i ].join();

        } catch ( InterruptedException e ) {
            fail( "Interrupted during join." );
        }

        // tracks the current max sum in this range
        int temp, max = Integer.MIN_VALUE;

        // get the max of each reported value from the workers
        for ( int i = 0; i < workers && i < vList.size(); ++i ) {
            // get the next threads reported max
            temp = thread[ i ].getMax();

            // new max
            if ( temp > max )
                max = temp;
        }

        // print the results
        System.out.println( "Maximum Sum: " + max );
    }
}
