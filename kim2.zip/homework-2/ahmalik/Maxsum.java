public class Maxsum
{

    // Input sequence of values.
    private static volatile int vList[];

    // Number of values on the list.
    private static volatile int vCount = 0;

    // Capacity of the list of values.
    private static volatile int vCap = 0;

    // Starting index for reading values list
    private static volatile int startIndex = 0;

    // Current sum being calculated
    private static volatile int currentSum = 0;

    // Maximum sum found
    private static volatile int maximumSum = 0;

    public static void readList()
    {
        // Set up initial list and capacity.
        vCap = 5;
        vList = new int[vCap];

        // Keep reading as many values as we can.
        int v;
        while ( scanf( "%d", v ) == 1 ) {
            // Grow the list if needed.
            if ( vCount >= vCap ) {
                vCap *= 2;
                vList = new int[vCap];
            }

            // Store the latest value in the next array slot.
            vList[ vCount++ ] = v;
        }
    }

    public static void main(String args[])
    {
        bool report = false;
        int workers = 4;
        int threadNum = 0;

        // Parse command-line arguments.
        if ( args.length < 2 || args.length > 3 )
            usage();
        
        
        System.out.println("I am thread %d. The maximum sum I found is %d\n", threadNum, currentSum);
    }
}