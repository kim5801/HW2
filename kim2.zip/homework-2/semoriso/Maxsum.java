import java.util.*;
import java.io.*;

public class Maxsum {

  /** Arraylist to store values in */
  private static ArrayList<Integer> list;

  
  /** Number of threads to be used  */
  private static int threadCount;

  static class MyThread extends Thread {
    /** A parameter to store in a Thread */
    private int x;

    /** The maxsum the threads will solve for */
    public int maxsum;
 
    /** Make a new Thread, giving it a parameter value to store. */
    public MyThread( int x ) {
      this.x = x;
    }

    /** When run, calculates the maximum sum */
    public void run() {
        this.maxsum = list.get(0);
        int tempV = 0;
        for (int i = this.x; i < list.size(); i = i + threadCount) { //iterate from current tested idx to end
            tempV = 0;
            for (int j = i; j < list.size(); j++) {
                tempV += list.get(j);
                if (tempV > this.maxsum) { //test current maxSum value against newly calc'd
                    this.maxsum = tempV;
                }
            }
        } 
    }
  }

  public static void usage() {
    System.out.println("usage: maxsum <workers>");
    System.out.println("maxsum <workers> report");
    System.exit(1);
  }
  
  /**
   Utilizes the Scanner class to read in input to Arraylist
   */
  public static void readInput() {
    Scanner scan = new Scanner(System.in);
    int count = 0;
    while (scan.hasNextInt()) {
       int val = scan.nextInt();
       list.add(Integer.valueOf(val));
    }
  }
  
  public static void main( String[] args ) throws InterruptedException {
    if (args.length != 1 && args.length != 2) { //check either 1 or 2 command line args num and report
      usage();
    }
    boolean report = false;
    if (args.length == 2) {
      if (args[1].equalsIgnoreCase("report")) { //check if threads should report
        report = true;
      }
      else { //invalid command line arg
        usage();
      }
    }
    try {
      threadCount = Integer.parseInt(args[0]);
    }
    catch (NumberFormatException e) {
        usage();
    }
    list = new ArrayList<>();
    readInput(); 
    if (list.size() != 0) {
        MyThread[] threads = new MyThread[threadCount];
        int place = -1; //dummy value to be incremented when for loop begins
        for ( int i = 0; i < threadCount; i++ ) {
            // Start them all.
            place++; //increment place of where thread should start
            threads[i] = new MyThread(place); //pass in different indexes for threads
            threads[i].start();
        }
        try {
            int maxSum = threads[0].maxsum;
            for (int i = 0; i < threadCount; i++) {
                //join thread
                threads[i].join();
                if (report) { //report all vals if specified
                System.out.println("I'm thread " + threads[i].getId() 
                        + ". The maximum sum I found is " + threads[i].maxsum);
                }
                if (maxSum < threads[i].maxsum) { //find overall max sum
                    maxSum = threads[i].maxsum;
                }
            }
            System.out.println("Maximum Sum: " + maxSum);
        }
        catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        } 
    }
  }
}