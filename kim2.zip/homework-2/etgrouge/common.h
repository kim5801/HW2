/**
  @file common.h
  @author Erin Grouge
  This program contains common data needed for reset.c and lightsout.c
 */

/** Height and width of the playing area. */
#define GRID_SIZE 5
/** The size of memory block needed to store a GameState in shared memory */
#define BLOCK_SIZE sizeof(GameState)
/** Integer representation for light off */
#define OFF 0
/** Integer representation for light on */
#define ON 1

/** 
  Game Board Struct. 
  It stores the status of the board in a 2d int array, its
  last move, and if an undo can be performed.
 */
typedef struct {
  int lastMove[2]; /** The last move performed by the player */
  int gameboard[GRID_SIZE][GRID_SIZE]; /** The board stored as 0s and 1s */
  bool canUndo; /** Whether or not the player can perform an undo */
}GameState;
