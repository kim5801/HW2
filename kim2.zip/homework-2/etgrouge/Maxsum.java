import java.util.ArrayList;
import java.util.Scanner;
import java.lang.System;

/**
    The Max Sum program reads in a list of integers and reports the greatest
    sum for a stretch of numbers within the list using threads to divide and 
    conquer. 
    @author Erin Grouge
    Citation: Referenced the ThreadArguments.java file from class.
 */
public class Maxsum {
    /** The number of values in the list */
    private static int vCount = 0;
    /** The number of threads used to find the max sum */
    private static int workers = 4;
    /** The list of integer values */
    private static ArrayList<Integer> vList;

    /**
        The Worker class represents a custom thread used to solve the max sum problem
     */
    static class Worker extends Thread {
        /** It's max sum found */
        public int max;
        /** The index it starts summing at */
        private int startingIndex;
        
        /**
            Constructs a new worker thread and sets its starting index and max
            @param start the starting index for summation
         */
        public Worker(int start){
            this.startingIndex = start;
            max = 0;
        }
        /**
            Iterates through the list of integers, finding partial sums 
            and recording the greatest sum found.
         */
        public void run(){
            int globalMax = 0;

            // Start at starting index and jump by the number of threads working
            for(int i = startingIndex; i < vCount; i+= workers){

                int localMax = Integer.MIN_VALUE;
                int sum = 0;

                // Iterate through the end of the list, recording the greatest 
                // sum found till the end of the list is reached. 
                for(int j = i; j < vCount; j++){
                    sum += vList.get(j);
                    if(sum > localMax)
                        localMax = sum;
                }

                // If the sum found is greater than the recorded max, update it
                if(localMax > globalMax)
                    globalMax = localMax;
                
            }

            // Save max in its field
            this.max = globalMax;
            
        }

    }
    /**
        Prints the correct usage and exits with error.
     */
    private static void usage(){
        System.out.println("usage: maxsum <workders>");
        System.out.println("       maxsum <workders> report");
        System.exit(1);
    }

    /**
        Reads in the list of integers, creates worker threads to divide up the work
        and find the greatest sum, waits for them to terminate, and prints the max
        sum to standard output.
     */
    public static void main(String[] args) {
        boolean report = false;

        // Check argument values for validity and store valid args
        if(args.length < 1 || args.length > 2)
            usage();
        try{
            workers = Integer.parseInt(args[0]);
        } catch (NumberFormatException e){
            usage();
        }
        if(workers < 1)
            usage();
        if(args.length == 2 && !args[1].equals("report")){
            usage();
        } else if (args[1].equals("report")){
            report = true;
        }

        // Read list of numbers and store in list
        vList = new ArrayList<Integer>();
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            vList.add(scanner.nextInt());
            vCount++;
        }
        scanner.close();
        
        // Create worker threads and tell them to start working
        Worker[] threads = new Worker[workers];
        for(int i = 0; i < workers; i++){
            threads[i] = new Worker(i);
            threads[i].start();
        }

        // Wait for the threads to terminate, figuring out which thread 
        // found the greatest sum and reporting if report=true
        int maxSum = Integer.MIN_VALUE;
        try{
            for(int i = 0; i < workers; i++){
                threads[i].join();
                int sum = threads[i].max;
                if(report){
                    System.out.println("I'm thread " + threads[i].getId() + ". The maximum sum I found is " + sum + ".");
                }
                if(sum > maxSum)
                    maxSum = sum;
            }
        } catch (InterruptedException e ){
            System.out.println("Interrupted during join!");
        }
        
        // Report the maximum sum to user
        System.out.println("Maximum Sum: " + maxSum);
    }


}