/**
  @file lightsout.c
  @author Erin Grouge
  This program uses the GameState in the shared memory block to perform
  the desired game operations (report, move, undo). It prints the result 
  of the operation, detaches from the shared memory, and exits. 
 */
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

/** Print out an error message and exit. 
    @param message the error message to print
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Checks if the character is a valid number (0-9)
  @param ch the character to check
  @return true if the character is valid
 */
static int isValid(char ch)
{
  return (ch >= '0' && ch <= '9');
}

/** Parses the given string to an integer value
  @param the string to parse
  @return val the integer value of the string
 */
static int parse(char * str)
{
  int val = 0;
  int i = 0;
  // While not at the end, read digits left to right, updating decimal value as you go.
  while(str[i] != '\0'){
    // If not valid characters, return -1
    if(!isValid(str[i])){
      return -1;
    }
    // Convert to integer value
    int num = str[i] - '0';
    // Shift left digits over by multiplying by 10
    val = val * 10 + num;
    i++;
  }
  return val;
}

/** Constructs the report message based on board status. 
    @param board the board to report
*/
static void printBoard(GameState *board){
  int index = 0;
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      if(board->gameboard[i][j] == ON){
        printf("*");
      } else {
        printf(".");
      }
      index++;
    }
    printf("\n");
    index++;
  }
}

/** Performs the move operation by updating the board status. 
    @param board the board to perform the move on
 */
static void move(int r, int c, GameState *board){
  // Switch the pressed tile
  if(board->gameboard[r][c] == ON){
    board->gameboard[r][c] = OFF;
  } else {
    board->gameboard[r][c] = ON;
  }

  //Switch tile above if exists
  if(r - 1 >= 0){
    if(board->gameboard[r - 1][c] == ON){
      board->gameboard[r - 1][c] = OFF;
    } else {
      board->gameboard[r - 1][c] = ON;
    }
  }

  //Switch tile below if exists
  if(r + 1 <= 4){
    if(board->gameboard[r + 1][c] == ON){
      board->gameboard[r + 1][c] = OFF;
    } else {
      board->gameboard[r + 1][c] = ON;
    }
  }

  //Switch tile left if exists
  if(c - 1 >= 0){
    if(board->gameboard[r][c - 1] == ON){
      board->gameboard[r][c - 1] = OFF;
    } else {
      board->gameboard[r][c - 1] = ON;
    }
  }

  //Switch tile right if exists
  if(c + 1 <= 4){
    if(board->gameboard[r][c + 1] == ON){
      board->gameboard[r][c + 1] = OFF;
    } else {
      board->gameboard[r][c + 1] = ON;
    }
  }
}

/** Starting point of the program.
    Gets access to the board in shared memory, reads in the user input,
    performs the operation if valid, and prints back to the user.
    @param argc the number of arguments
    @param argv the array of arguments
 */
int main( int argc, char *argv[] ) {
  // Check number of arguments
  if(argc < 2 || argc > 4){
    fail("error");
  }
  // Get shared memory
  key_t key = ftok("/afs/unity.ncsu.edu/users/e/etgrouge", 1234);
  int shmid = shmget(key, BLOCK_SIZE, 0);
  GameState *board = (GameState *)shmat(shmid, 0, 0);

  // Check arguments and perform operations accordingly
  // If report, print board status
  if(strcmp(argv[1], "report") == 0){
    // Check for correct number of arguments
    if(argc != 2)
      fail("error");
    
    printBoard(board);

  } // If undo, perform the undo
  else if(strcmp(argv[1], "undo") == 0){
    // Check for correct number of arguments
    if(argc != 2)
      fail("error");
    // If undo operation allowed, undo or error if not.
    if(board->canUndo){
        // Update the board struct fields and report success back to client. 
        move(board->lastMove[0], board->lastMove[1], board);
        board->canUndo = false;
        printf("success\n");
      } else {
        fail("error");
      }

  } // If move, perform the move operation
  else if(strcmp(argv[1], "move") == 0){
    // Check for correct number of arguments
    if(argc != 4)
      fail("error");

    // Parse the row and column as integers
    int row = parse(argv[2]);
    int col = parse(argv[3]);

    // If invalid, exit with error.
    if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE)
      fail("error");

    // Set the boards last move to this move and update that it can undo.
    board->lastMove[0] = row;
    board->lastMove[1] = col;
    board->canUndo = true;
    // Perform the move operation and report back to client success.
    move(row, col, board);
    printf("success\n");

  } // If the argument is anything else, fail.
  else {
    fail("error");
  }

  // Detach from memory and exit successfully.
  shmdt(board);

  return EXIT_SUCCESS;
}
