#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

// Print out the error message and exit.
static void fail() {
  printf("error\n");
  exit(1);
}

//the success ending
static void succeed() {
  printf("success\n");
}

//flip a bit
// we flipped the order of rows and columns because the data is stored backwards
void flip(char *board, int c, int r) {
  board[r+GRID_SIZE*c] = !board[r+GRID_SIZE*c];
  if(r-1 >= 0) { //bounds check
    board[r-1+GRID_SIZE*c] = !board[r-1+GRID_SIZE*c]; //assignment
  }
  if(r+1 < GRID_SIZE) { 
    board[r+1+GRID_SIZE*c] = !board[r+1+GRID_SIZE*c];
  }
  if(c-1 >= 0) {
    board[r+GRID_SIZE*(c-1)] = !board[r+GRID_SIZE*(c-1)];
  }
  if(c+1 < GRID_SIZE) {
    board[r+GRID_SIZE*(c+1)] = !board[r+GRID_SIZE*(c+1)]; 
  }
}

//main runtime
int main( int argc, char *argv[] ) {
  //setup access to shared memory
  int shmid = shmget(SM_KEY, BLOCK_SIZE, 0);
  //the access point
  char *sbuffer = (char *)shmat(shmid, 0, 0);

  //criteria for undo command
  if(argc == 2 && strcmp(argv[1], "undo") == 0) {
    if(sbuffer[BLOCK_SIZE - 1] == 1) { //if our last char is set then we are able to undo
      flip(sbuffer, sbuffer[BLOCK_SIZE - 3], sbuffer[BLOCK_SIZE - 2]); //an undo is just a flip
      sbuffer[BLOCK_SIZE - 1] = 0; // we used up the undo
      succeed();
    } else {
      fail();
    }
  //criteria for reporting
  } else if(argc == 2 && strcmp(argv[1], "report") == 0) {
    for(int i = 0; i < GRID_SIZE*GRID_SIZE; i++) {
      if(i != 0 && i % 5 == 0) {
        putchar('\n'); //our board is not stored in 2D array in memory so create appearance on printing
      }
      if(sbuffer[i] == 1) { //on
        putchar('*');
      } else { //off
        putchar('.');
      }
    }
    putchar('\n');
    //criteria for a move command
  } else if(argc == 4 && strcmp(argv[1], "move") == 0) {
    //Valid that the arguments are actually numbers prior to conversion
    short valid = 1; //we can set this so we know if we can actually move
    for(char *val = argv[2]; *val != 0; val++) {
      if(!isdigit(*val)) {
        valid = 0;
        break;
      }
    }

    for(char *val = argv[3]; *val != 0; val++) {
      if(!isdigit(*val)) {
        valid = 0;
        break;
      }
    }
    //end integer validation

    //convert to numbers
    int r = atoi(argv[2]);
    int c =  atoi(argv[3]);

    if(r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE) { //no out of bounds errors please
      valid = 0;
    }

    if(valid) {  
      flip(sbuffer, r, c); //move
      sbuffer[BLOCK_SIZE - 1] = 1; //since we moved we can undo
      sbuffer[BLOCK_SIZE - 2] = atoi(argv[3]); //store our move
      sbuffer[BLOCK_SIZE - 3] = atoi(argv[2]);      
      succeed();
    } else {
      fail();
    }
  } else {
    fail();
  }


  return 0;
}
