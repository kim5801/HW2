#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  //check parameters and make sure the files are correct
  if(argc != 2) {
    usage();
  }

  //open out file
  FILE *fptr = fopen(argv[1], "r");

  if(fptr == NULL) {
    //cant use fail because of filename arg
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit( 1 );
  }


  //create the shared memory 
  int shmid = shmget(SM_KEY, BLOCK_SIZE, 0666 | IPC_CREAT);
  //the shared memory segment
  char *sbuffer = (char *) shmat(shmid, 0, 0);


  char c;
  int i = 0;  //iterator for 5 chars in line
  int j = 0;  //iterator for 5 total lines
  //while there are spots on the board
  while((c = fgetc(fptr)) != EOF) {
    if(c == '\n' && i == GRID_SIZE) {
      i = 0;
      j++;
    } else if(c == '.' && i < GRID_SIZE && j < GRID_SIZE) {
      sbuffer[i+GRID_SIZE*j] = 0; //write no light to shared memory
      i++;
    } else if(c == '*' && i < GRID_SIZE && j < GRID_SIZE) {
      sbuffer[i+GRID_SIZE*j] = 1; //write a light to shared memory
      i++;
    } else {
      //cant use fail because of filename arg
      fprintf(stderr, "Invalid input file: %s\n", argv[1]);
      exit( 1 );
    }
  }

  return 0;
}
