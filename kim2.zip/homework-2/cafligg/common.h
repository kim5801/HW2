// Height and width of the playing area.
#define GRID_SIZE 5

//the key to access the shared memory
#define SM_KEY ftok("/afs/unity.ncsu.edu/users/c/cafligg", 0)

//memory size = board size (5*5) + 2 [coordinates of last move] + 1 [if can undo]
#define BLOCK_SIZE 28