import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Maxsum {

  /*
   * function to help by printing out usage and exiting
   */
  private static void usage() {
    System.out.println("usage: maxsum <workers>\n       maxsum <workers> report");
    System.exit(1);
  }

  /*
   * our worker thread that calculates the max
   */
  public static class Worker implements Runnable {
    int val;
    int workers;
    ArrayList<Integer> nums;
    int localmax;
    boolean report;

    //function so we can pass each thread arguments
    public Worker(int workernum, int workeramt, ArrayList<Integer> n, boolean r) {
      val = workernum;
      workers = workeramt;
      nums = n;
      report = r;
    }

    public void run() {
      //main logic that controls the max calculation
      for(int i = val; i < nums.size(); i += workers) { //each worker is only responsible for a few numbers
        int sum = 0;
        for(int j = i; j < nums.size(); j++) {
          sum += nums.get(j);
          if(sum >= localmax) {
            localmax = sum;
          }
        }
      }

      if(report) {
        System.out.printf("I'm thread %d. The maximum sum I found is %d\n", Thread.currentThread().getId(), localmax); //report this workers max
      }

    }

    public int getMax() { //function to allow us to access data from the thread
      return localmax;
    }
  }


  public static void main(String[] args) {
    //simple check to see if we have the right amount of arguments
    if(args.length < 1 || args.length > 2) {
      usage();
    }


    int workers = 0;
    boolean report = false;
    try {
      report = args[1].compareTo("report") == 0;
      if(report == false) {
        usage(); // a bad term should be ignored
      }
    } catch(ArrayIndexOutOfBoundsException e) { //if the argument doesn't exist we are not reporting 
      report = false;
    } 
    try {
      workers = Integer.parseInt(args[0]); //get the number of workers
    } catch (Exception e) { //it probably isnt a number
      usage();
    }

    //input reader
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    //arraylist of all input numbers
    ArrayList<Integer> nums = new ArrayList<Integer>(10); //create a new arraylist 10 long


    try {
      while(true) { //while there are more numbers read them in
        nums.add( Integer.parseInt(br.readLine()) );
      }
    } catch(Exception e) { //a non number was encountered
      //do nothing
    }


    Thread[] workerArr = new Thread[workers]; //track the current threads
    Worker[] workerT = new Worker[workers]; //track the workers running in the threads
    for(int i = 0; i < workers; i++) {
      workerT[i] = new Worker(i, workers, nums, report); //create a new worker

      workerArr[i] = new Thread(workerT[i]);
      workerArr[i].start(); //run it on its thread
    }

    int maximum = workerT[0].getMax();
    for(int i = 0; i < workerArr.length; i++) { 
      try {
        workerArr[i].join(); //wait for the threads to complete
      } catch(InterruptedException e) {
        System.exit(100);
      }
      
      if(workerT[i].getMax() > maximum) { //now that the thread is done ask the worker for its maximum
        maximum = workerT[i].getMax();
      }
    }

    System.out.printf("Maximum: %d\n", maximum); //the maximum value
  }
}