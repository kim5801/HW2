#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//makes a move on the board
void makeMove(GameState *game, int row, int col) {
  for (int i = 0; i < GRID_SIZE; ++i) {
    strcpy(game->prevBoardLook[i], game->boardLook[i]);
  }

  //changing center grid
  if (game->boardLook[row][col] == '*') {
    game->boardLook[row][col] = '.';
  }
  else {
    game->boardLook[row][col] = '*';
  }

  //changing bottom row
  if ((row + 1) < 5) {
    if (game->boardLook[row + 1][col] == '*') {
      game->boardLook[row + 1][col] = '.';
    }
    else {
      game->boardLook[row + 1][col] = '*';
    }
  }

  //changing top row
  if ((row - 1) >= 0) {
    if (game->boardLook[row - 1][col] == '*') {
      game->boardLook[row - 1][col] = '.';
    }
    else {
      game->boardLook[row - 1][col] = '*';
    }
  }

  //changing next column
  if ((col + 1) < 5) {
    if (game->boardLook[row][col + 1] == '*') {
      game->boardLook[row][col + 1] = '.';
    }
    else {
      game->boardLook[row][col + 1] = '*';
    }
  }

  //changing prev column
  if ((col - 1) >= 0) {
    if (game->boardLook[row][col - 1] == '*') {
      game->boardLook[row][col - 1] = '.';
    }
    else {
      game->boardLook[row][col - 1] = '*';
    }
  }
}

//reverts board back to previous state
bool undoBoard(GameState *game) {
  if (game->moveMade) {
    for (int i = 0; i < GRID_SIZE; ++i) {
      strcpy(game->boardLook[i], game->prevBoardLook[i]);
    }
    game->moveMade = false;
    return true;
  }

  return false;
}

//reports current state of board
void reportBoard(GameState *game) {
  for (int i = 0; i < GRID_SIZE; ++i) {
    printf("%s", game->boardLook[i]);
  }
}

int main( int argc, char *argv[] ) {
  //no commands were given
  if (argc == 1) {
    fail("error");
  }

  //trying to access shared memory
  int shmid = shmget(ftok(myAFS, 0), 0, 0);
  if (shmid == -1) {
    fail("Unable to create shared memory.");
  }

  //trying to get GameState struct from memory
  GameState *game = (GameState *)shmat(shmid, 0, 0);
  if (game == (GameState *)-1) {
    fail("Can't map shared memory segment into address space");
  }

  //MOVE COMMAND
  if (strcmp("move", argv[1]) == 0) {
    //needs to be a total of 4 arguments
    if (argc != GRID_SIZE - 1) {
      fail("error");
    }
    int row;
    int col;

    //trying to get row and column
    if (sscanf(argv[2], "%d", &row) != 1) {
      fail("error");
    }
    if (sscanf(argv[3], "%d", &col) != 1) {
      fail("error");
    }

    //making sure user's row and column are within range
    if (row < 0 || row > GRID_SIZE - 1 || col < 0 || col > GRID_SIZE - 1) {
      fail("error");
    } 

    makeMove(game, row, col);
    printf("success\n");
        
    game->moveMade = true;
  }
  //UNDO COMMAND
  else if (strcmp("undo", argv[1]) == 0) {
    //must have total of two commands
    if (argc != 2) {
      fail("error");
    }
    //move was made previously so board was set to previous state
    if (undoBoard(game)) {
      printf("success\n");
    }
    //undo was not able to be done
    else {
      printf("error\n");
    }
  }
  //REPORT COMMAND
  else if (strcmp("report", argv[1]) == 0) {
    if (argc != 2) {
      fail("error");
    }
    reportBoard(game);
  }
  //invalid command
  else {
    fail("error");
  }

  return 0;
}
