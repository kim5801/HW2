#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

//max characters that should be in file (5 rows * 5 columns + a new line char for each line)
#define MAX_CHAR 30

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <game-state-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // fails if user gives more than a file name
  if (argc != 2) {
    usage();
  }

  // Reading a file
  int forRead = open(argv[1], O_RDONLY);

  if (forRead < 0) {
    close(forRead);
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  char fileStuff[MAX_CHAR];
  int rd = read(forRead, fileStuff, sizeof(fileStuff));
  //not enough characters in file
  if (rd != MAX_CHAR) {
    close(forRead);
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  char board[GRID_SIZE][GRID_SIZE + 2];
  int charCount = 0;
  int lineNum = 0;
  //making sure each character is . or * and making sure there are 6 characters
  for (int i = 0; i < GRID_SIZE; ++i) {
    for (int j = 0; j < GRID_SIZE + 1; ++j) {
      //checking if at end of line
      if (((lineNum % GRID_SIZE) == 0) && charCount != 0 && lineNum != 0) {
        if (fileStuff[charCount] != '\n') {
          close(forRead);
          fprintf(stderr, "Invalid input file: %s\n", argv[1]);
          exit(1);
        }
        lineNum = 0;
      }
      else {
        if (fileStuff[charCount] != '.' && fileStuff[charCount] != '*') {
          close(forRead);
          fprintf(stderr, "Invalid input file: %s\n", argv[1]);
          exit(1);
        }
        ++lineNum;
      }
      board[i][j] = fileStuff[charCount];
      if (j == GRID_SIZE) {
        board[i][j + 1] = '\0';
      }
      ++charCount;
    }
  }
  //if more lines than 5
  if (read(forRead, fileStuff, sizeof(fileStuff)) != 0) {
    close(forRead);
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  close(forRead);

  int shmid = shmget(ftok(myAFS, 0), sizeof(GameState), 0666 | IPC_CREAT);
  if (shmid < 0) {
    fail("Unable to create shared memory.");
  }

  GameState *game = (GameState *)shmat(shmid, 0, 0);
  if (game == (GameState *)-1) {
    fail("Can't map shared memory segment into address space");
  }
  for (int i = 0; i < GRID_SIZE; ++i) {
    strcpy(game->boardLook[i], board[i]);
  }
  game->moveMade = false;

  return 0;
}
