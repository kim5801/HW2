/**
 * Jessica Bui (jtbui)
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {

    private static ArrayList<Integer> numsForSum;
    private static int workers;

    /** Thread subclass */
    static class MyThread extends Thread {
        /** Which worker this thread is */
        private int worker;
        /** To report or not to report */
        private boolean reporter;
        /** The max this worker found */
        public int max;
    
        /** Make a new Thread, giving it a parameter value to store. */
        public MyThread(int worker, boolean reporter) {
            this.worker = worker;
            this.reporter = reporter;
        }

        /** When run, I report in and compute a max num. */
        public void run() {
            //for the process to calculate each range
            for (int i = worker; i < numsForSum.size(); i += workers) {
                int total = 0;
        
                //to keep adding
                for (int h = i; h < numsForSum.size(); ++h) {
                    total += numsForSum.get(h);
                    //found a max
                    if (total > max) {
                        max = total;
                    }
                }
            }

            //report process id and sum found if user wants it reported
            if (reporter) {
                System.out.println("I'm thread " + Thread.currentThread().getId() + ". The maximum sum I found is " + max + ".");
            }
        }
    }

    public static void main(String[] args) {
        boolean report = false;
        workers = 4;
        numsForSum = new ArrayList<Integer>();
    
        // Parse command-line arguments.
        if ( args.length < 1 || args.length > 2 ) {
            throw new IllegalArgumentException("usage: maxsum <workers> or maxsum <workers> report");
        }
    
        // If there's a second argument, it better be the word, report
        if (args.length == 2) {
            if (!args[1].equals("report")) {
                System.out.println(args[1]);
                throw new IllegalArgumentException("usage: maxsum <workers> or maxsum <workers> report"); 
            }
            report = true;
        }
    
        //scanner to determine if the first argument is an int or not
        Scanner scnr = new Scanner(args[0]);
        if (!scnr.hasNextInt()) {
            scnr.close();
            throw new IllegalArgumentException("usage: maxsum <workers> or maxsum <workers> report");
        }
        workers = scnr.nextInt();
        scnr.close();
    
        readList();
    
        //overall max found
        int finalMax = 0;

        // making thread workers list
        MyThread[] workersList = new MyThread[workers];
        for (int i = 0; i < workers; ++i) {
            workersList[i] = new MyThread(i, report);
            workersList[i].start();
        }

        //joining and finding total max max
        try {
            for (int i = 0; i < workers; ++i) {
                workersList[i].join();
                if (workersList[i].max > finalMax) {
                    finalMax = workersList[i].max;
                }
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
        }

        System.out.println("Maximum sum: " + finalMax);
    }

    /** Reading the numbers list */
    public static void readList() {
        Scanner numScnr = new Scanner(System.in);

        while (numScnr.hasNextInt()) {
            numsForSum.add(numScnr.nextInt());
        }

        numScnr.close();
    }
}



