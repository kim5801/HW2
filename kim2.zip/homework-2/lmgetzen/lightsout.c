#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// // Print out an error message and exit.
// static void fail(char const *message) {
//     fprintf(stderr, "%s\n", message);
//     exit(1);
// }

/**
 * switch functionality for move command argument
 * 
 * @param g game to used
 * @param r row to be moved
 * @param c column to be moved
 */
static void switchFunc(GameState *g, int r, int c) {
    if (g->board[r][c] == '.') {
        g->board[r][c] = '*';
    }
    else if (g->board[r][c] == '*') {
        g->board[r][c] = '.';
    }
    else if (g->board[r][c] == '\n') {
        //do nothing
    }
}

int main(int argc, char *argv[]) {
    
    //create key to get access to shared memory
    key_t key = ftok(PATH, 28);             
    //get shared memory identifier with key
    int memID = shmget(key, 0, 0);


    //get game structure from memory saved from reset
    GameState *game = (GameState *) shmat(memID, 0, 0);

    

        
    //if command argument is report
    if (strcmp(argv[1], "report") == 0) {
        //print out the board
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j <= GRID_SIZE; j++) {
                printf("%c", game->board[i][j]);
            }
        }
        printf("\n");
    }

    //check for invalid numbers
    else if (argc == 4 && ((atoi(argv[2]) > 4 || atoi(argv[2]) < 0) || (atoi(argv[3]) > 4 || atoi(argv[3]) < 0))) {
        printf("error\n");
    }



    //if command argument is move
    else if (argc == 4 && (strcmp(argv[1], "move") == 0)) {


        //saving oldboard state for undo function later on
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j <= GRID_SIZE; j++) {
                game->oldBoard[i][j] = game->board[i][j];
            }
        }
        



        //converting each string from command line to integer
        game->rowM = atoi(argv[2]);
        game->colM = atoi(argv[3]);

        //setting undo boolean to true so that functionality can be used next
        game->undo = true;

        
        //check origin first
        if (game->rowM == 0 && game->colM == 0) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM + 1, game->colM);
            switchFunc(game, game->rowM, game->colM + 1);
        }
        
        //bottom left corner
        else if (game->rowM == 4 && game->colM == 0) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM - 1, game->colM);
            switchFunc(game, game->rowM, game->colM + 1);
        }
        //bottom right corner
        else if (game->rowM == 4 && game->colM == 4) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM - 1, game->colM);
            switchFunc(game, game->rowM, game->colM - 1);
        }
        //top right corner
        else if (game->rowM == 0 && game->colM == 4) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM + 1, game->colM);
            switchFunc(game, game->rowM, game->colM - 1);
        }
        //left column
        else if ((game->rowM >= 1 && game->rowM <= 3) && game->colM == 0) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM + 1, game->colM);
            switchFunc(game, game->rowM - 1, game->colM);
            switchFunc(game, game->rowM, game->colM + 1);
        }
        //upper row
        else if (game->rowM == 0 && (game->colM >= 1 && game->colM <= 3)) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM + 1, game->colM);
            switchFunc(game, game->rowM, game->colM - 1);
            switchFunc(game, game->rowM, game->colM + 1);
        }
        //right column
        else if ((game->rowM >= 1 && game->rowM <= 3) && game->colM == 4) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM + 1, game->colM);
            switchFunc(game, game->rowM - 1, game->colM);
            switchFunc(game, game->rowM, game->colM - 1);
        }
        //bottom row
        else if (game->rowM == 4 && (game->colM >= 1 && game->colM <= 3)) {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM - 1, game->colM);
            switchFunc(game, game->rowM, game->colM - 1);
            switchFunc(game, game->rowM, game->colM + 1);
        }
        //anything without special conditions
        else {
            switchFunc(game, game->rowM, game->colM);
            switchFunc(game, game->rowM - 1, game->colM);
            switchFunc(game, game->rowM + 1, game->colM);
            switchFunc(game, game->rowM, game->colM - 1);
            switchFunc(game, game->rowM, game->colM + 1);
        }

        printf("success\n");

        

    }

    //if undo functionality has been selected
    else if (strcmp(argv[1], "undo") == 0) {
        //if game is able to use undo functionality
        if (game->undo) {
            //copy over old saved board into the actual game board
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j <= GRID_SIZE; j++) {
                    game->board[i][j] = game->oldBoard[i][j];
                }
            }
            game->undo = false;
            printf("success\n");
        }

        //otherwise print error if undo has already been done or is not allowed
        else {
            printf("error\n");
        }

        

    
    }

    else {
        printf("error\n");
    }




    
    

    return 0;

}
