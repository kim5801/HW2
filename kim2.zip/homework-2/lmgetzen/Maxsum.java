import java.util.Scanner;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * program to use multiple threads to find the largest sum
 * from an input file
 */
public class Maxsum {

    // Print out an error message and exit.
    public static void fail(String message) {
        System.err.print(message);
        System.exit(1);
    }

    // Print out a usage message, then exit.
    public static void usage() {
        System.out.print("usage: maxsum <workers>\n");
        System.out.print("       maxsum <workers> report\n");
        System.exit(1);
    }


     // Input sequence of values.
     static int[] vList;

     // Number of values on the list.
     static int vCount = 0;
 
     // Capacity of the list of values.
     static int vCap = 0;
 
     // Read the list of values.
 
     //look over this when debgugging
     public static void readList(Scanner fileReader) throws FileNotFoundException {
         // Set up initial list and capacity.
         vCap = 5;
         //vList = (int *)malloc(vCap * sizeof(int));
         vList = new int[5];
 
         // Keep reading as many values as we can.
         int v;
         // String fileName;
        //  Scanner fileReader = new Scanner(new FileInputStream(fileName));
         while (fileReader.hasNext()) {
             // Grow the list if needed.
             if (vCount >= vCap) {
                 vCap *= 2;
                 //vList = (int *)realloc(vList, vCap * sizeof(int));
                 int[] list2 = new int[vCap];
                 for (int i = 0; i < vList.length; i++) {
                     list2[i] = vList[i];
                 }
                 vList = list2;
             }
             v = fileReader.nextInt();
             // Store the latest value in the next array slot.
             vList[vCount++] = v;
         }
     }

    static class MyThread extends Thread {
        /** Effectively, a parameter we're passing the thread, which fibonacci
            number it's supposed to compute.  Here, we can just store this in
            a field of the thread itself. */
        private int id;

        /**
         * sum to be stored
         */
        private int tempMax;
       
        /**
         * worker field
         */
        private int workers;

        /**
         * report field
         */
        private boolean report;

        /** Make a new Thread, giving it a parameter value to store. */
        public MyThread( int id, int workers, boolean report ) {
            this.id = id;
            this.workers = workers;
            this.tempMax = 0;
            this.report = report;

        }

        /** When run, I report in and compute a fibonacci number. */
        public void run() {
            
            
            for (int j = id; j < vCount; j += workers) {
                int tempSum = 0;
                for (int k = j; k < vCount; k++) {
                    tempSum += vList[k];
                    if (tempSum > tempMax) {
                        tempMax = tempSum;
                    }
                }
                
            }

            //print out process and sum found
            if (report) {
                System.out.print("I’m process " + getId() + ". The maximum sum I found is " + tempMax + ".\n");
            }
  
        }

    }


    





   

    public static void main(String[] args) throws FileNotFoundException {


        boolean report = false;
        int workers = 4;
        int maxSum = 0;

        
        
        // Parse command-line arguments.
        if (args.length < 1 || args.length > 2) {
            usage();
        }

        
        
        
        // if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1) {
        //     usage();
        // }
        workers = Integer.parseInt(args[0]);
        if (workers < 1) {
            usage();
        }

        
        
        
        
        // If there's a second argument, it better be the word, report
        if (args.length == 2) {
            if (args[1].compareTo("report") != 0) {
                usage();
            }
            report = true;
        }

        
        
        
        
        Scanner scanner = new Scanner(System.in);
        readList(scanner);
        // else if (args.length == 3) {
        //     readList(args[2]);
        // }        

        
        // System.out.println(vCount);
        // System.out.println(vCap);

        
        
        //create threads and workers
        MyThread[] thread = new MyThread[workers];
        for (int i = 0; i < workers; i++) {
            thread[i] = new MyThread(i, workers, report);
            thread[i].start();
        }

        
        
        
        
        
        
        int[] arr = new int[workers];
        // Wait for each of the threads to terminate.
        try {
            for (int i = 0; i < workers; i++) {
            thread[i].join();
            arr[i] = thread[i].tempMax;
            }
        } 
        catch ( InterruptedException e ) {
            System.out.println( "Interrupted during join!" );
        }

       
       
       
       
        //compare sum values from children stored in array
        maxSum = 0;
        for (int i = 0; i < workers; i++) {
            if (arr[i] > maxSum) {
                maxSum = arr[i];
            }
        }
       
       
       
        System.out.println("Maximum Sum: " + maxSum);
    }
    



}