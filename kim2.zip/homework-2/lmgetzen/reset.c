#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include <sys/ipc.h>

// // Print out an error message and exit.
// static void fail(char const *message) {
//     fprintf(stderr, "%s\n", message);
//     exit(1);
// }

// Print out a usage message and exit.
static void usage() {
    fprintf(stderr, "usage: reset <board-file>\n");
    exit(1);
}

int main(int argc, char *argv[]) {

    //check length of command argument
    if (argc != 2) {
        usage();
    }
    
    //open file specified in command argument
    FILE *input = fopen(argv[1], "r");
    
    //if can't be opened print error message
    if (input == NULL) {
        fprintf(stderr, "%s %s\n", "Invalid input file:", argv[1]);
        exit(1);
    }

    //create key to get access to shared memory
    key_t key = ftok(PATH, 28);
    //get shared memory identifier with key
    int memID = shmget(key, MESSAGE_LIMIT, 0666 | IPC_CREAT);

    //create game struct and put it in shared memory
    GameState *game = (GameState*) shmat(memID, 0, 0);


    //assign board in struct to every character in the file opened
    char ch;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j <= GRID_SIZE; j++) {
            ch = fgetc(input);
            if (ch == '.' || ch == '*' || ch == '\n')
                game->board[i][j] = ch;
            else {
                //if invalid print error message
                fprintf(stderr, "%s %s\n", "Invalid input file:", argv[1]);
                exit(1);
            }
        }
    }




    
    return 0;
}
