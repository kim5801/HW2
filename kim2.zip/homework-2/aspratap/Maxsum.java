import java.util.Scanner;
import java.util.ArrayList;

/**
 * @author Abhinav Pratap, aspratap
 * @file Maxsum.java
 *
 *  find a contiguous non-empty subsequence within the sequence that has the largest sum.
 */
public class Maxsum {

    /*
     * Worker thread to help with calculations
     */
    static class TClass extends Thread {
        ArrayList<Integer> numList;
        int numWorkers;
        int startIndex;
        boolean report;
        public int maxSum;

        /**
         * Create a new worker threads
         * 
         * @param numList list of numbers to compute from
         * @param numWorkers number of workers being used
         * @param startIndex the index of the list to start computing from
         * @param report whether or not to report this thread's maxsum
         */
        public TClass(ArrayList<Integer> numList, int numWorkers, int startIndex, boolean report) {
            this.numList = numList;
            this.numWorkers = numWorkers;
            this.startIndex = startIndex;
            this.report = report;
        }

        /**
         * run the thread
         */
        public void run() {
            if (numList.size() < 1)
                return;

            int maxSum = numList.get(startIndex);

            for (int i = startIndex; i < numList.size(); i += numWorkers) {
                int sum = numList.get(i);
                if (sum > maxSum)
                    maxSum = sum;

                if (i < numList.size() - 1) {
                    for (int j = i + 1; j < numList.size(); j++) {
                        sum += numList.get(j);
                        if (sum > maxSum)
                            maxSum = sum;
                    }
                }
            }

            if (report)
                System.out.printf("I'm process %d. The maximum sum I found is %d.\n", getId(), maxSum);

            this.maxSum = maxSum;
        }
    }

    /**
     * Read the list of values from the command line
     * @return list of values from the command line
     */
    public static ArrayList<Integer> readList() {
        Scanner scan = new Scanner(System.in);
        ArrayList<Integer> numList = new ArrayList<Integer>();

        while (scan.hasNextLine()) {
            numList.add(Integer.parseInt(scan.nextLine()));
        }
        scan.close();

        return numList;

    }

    // Print out a usage message, then exit.
    public static void usage() {
        System.out.print("usage: maxsum <workers>\n");
        System.out.println("       maxsum <workers> report\n");
        System.exit(1);
    }

    /**
     * starts maxsum
     * @param args the arguments provided from the command line
     */
    public static void main(String[] args) {

        // Parse command-line arguments.
        if (args.length < 1 || args.length > 2)
            usage();

        boolean report = false;
        int workers = 4;
        try {
            workers = Integer.parseInt(args[0]);
        } catch (Exception e) {
            usage();
        }

        if (args.length == 2) {
            if (args[1].equals("report")) {
                report = true;
            }
        }

        ArrayList<Integer> nums = readList();


        if (workers > nums.size()) {
            workers = nums.size();
        }

        TClass[] thread = new TClass[workers];

        for (int w = 0; w < workers; w++) {
            thread[w] = new TClass(nums, workers, w, report);
            thread[w].start();
        }

        int[] maxSums = new int[workers];
        try {
            for (int i = 0; i < thread.length; i++) {
                thread[i].join();
                maxSums[i] = thread[i].maxSum;
                // System.out.println("Thread terminated: " + thread[i].maxSum);
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted during join!");
            System.exit(1);
        }

        int maxSum = maxSums[0];
        for (int i = 0; i < workers; i++) {
            if (maxSums[i] > maxSum) {
                maxSum = maxSums[i];
            }
        }

        System.out.println("Maximum Sum: " + maxSum);
    }
}
