/**
 * @author Abhinav Pratap, aspratap
 * @file lightsout.c
 * Start out a lights out game
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <sys/shm.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stdout, "%s\n", message);
  exit(1);
}

/**
 * Prints the current grid in a formatted manner
 */
void printGrid(struct BoardState *state)
{
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      printf("%c", state->currGrid[i][j]);
    }

    printf("\n");
  }
}

/**
 * Updates the prev game state so that it reflects the current game state.
 * Copies the current grid into the prev grid so that undos are possible.
 */
void updatePrevBoard(struct BoardState *state)
{
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      state->prevGrid[i][j] = state->currGrid[i][j];
    }
  }
}

/**
 * flips the light at specific location of the board.
 * returns without making changes if invalid row and column is provided.
 * @param r row number
 * @param c column number
 */
void flip(int r, int c, struct BoardState *state)
{
  if (r > GRID_SIZE - 1 || r < 0 || c < 0 || c > GRID_SIZE - 1)
    return;
  if (state->currGrid[r][c] == '*')
  {
    state->currGrid[r][c] = '.';
  }
  else
  {
    state->currGrid[r][c] = '*';
  }
}

/**
 * plays a move on the gameboard
 * @param r the row of the light
 * @param c the column of the light
 */
void move(int r, int c, struct BoardState *state)
{
  updatePrevBoard(state);

  flip(r, c, state);
  flip(r - 1, c, state);
  flip(r, c + 1, state);
  flip(r, c - 1, state);
  flip(r + 1, c, state);
  state->undoAvailable = true;
}

/**
 * Play undo and copy previous board into current board
 */
void undoBoard(struct BoardState *state)
{
  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      state->currGrid[i][j] = state->prevGrid[i][j];
    }
  }

  state->undoAvailable = false;
}

/**
 * starts the client for lights out
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/aspratap", ID), sizeof(struct BoardState), 0);

  struct BoardState *state = (struct BoardState *)shmat(shmid, 0, 0);

  if (argc < 2 || argc > 4)
  {
    fail("Invalid arguments");
  }

  if (strcmp(argv[1], "move") == 0)
  {
    if (argc != 4 || strlen(argv[2]) != 1 || strlen(argv[3]) != 1)
      fail("error");

    int r = *argv[2] - '0';
    int c = *argv[3] - '0';

    if (r > GRID_SIZE - 1 || r < 0 || c < 0 || c > GRID_SIZE - 1)
      fail("error");
    // printf("row: %d\n", r);
    // printf("col: %d\n", c);

    move(r, c, state);
    printf("success\n");
  }
  else if (strcmp(argv[1], "undo") == 0)
  {
    if (argc != 2)
    {
      fail("error");
    }
    if (!state->undoAvailable)
    {
      fail("error");
    }
    undoBoard(state);
    printf("success\n");
  }
  else if (strcmp(argv[1], "report") == 0)
  {
    if (argc != 2)
    {
      fail("Too many arguments for report");
    }

    printGrid(state);
  }
  else
  {
    fail("error");
  }

  shmdt(state);

  return 0;
}