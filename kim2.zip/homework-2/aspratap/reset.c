/**
 * @author Abhinav Pratap, aspratap
 * @file reset.c
 * Sets up the gameboard for lights out
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <sys/shm.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

/**
 * Reads in a file and updated the board state
 * @param fileName name of the file to read from
 */
void readFileState(char *fileName, struct BoardState *state)
{
  FILE *fp = fopen(fileName, "r");

  if (fp == NULL)
  {
    fprintf(stderr, "Invalid input file: %s\n", fileName);
    exit(1);
  }

  for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      int input = fgetc(fp);
      if (input != '*' && input != '.')
      {
        fprintf(stderr, "Invalid input file: %s\n", fileName);
        exit(1);
      }

      state->currGrid[i][j] = input;
    }

    int input = fgetc(fp);
    if (input != '\n' && i != GRID_SIZE - 1)
    {
      fprintf(stderr, "Invalid input file: %s\n", fileName);
      exit(1);
    }
  }

  int input = fgetc(fp);
  if (input != '\n' && input != EOF)
  {
    fprintf(stderr, "Invalid input file: %s\n", fileName);
    exit(1);
  }

  state->undoAvailable = false;
}

/**
 * starts the server for light out
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{

  int shmid = shmget(ftok("/afs/unity.ncsu.edu/users/a/aspratap", ID), sizeof(struct BoardState),
                     0666 | IPC_CREAT);

  struct BoardState *state = (struct BoardState *)shmat(shmid, 0, 0);

  if (argc != 2)
  {
    fail("usage: reset <board-file>");
  }

  readFileState(argv[1], state);

  shmdt(state);

  return 0;
}
