#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//fails when an invalid file is given
static void invalidFile(char *fileName){
    fprintf(stderr, "%s", "Invalid input file: ");
    fail(fileName);
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

 if(argc != 2){
    usage();
  }

  //create shared memory and put the state in it
  key_t id = ftok("/afs/unity.ncsu.edu/users/m/mpwarren", 1);

  int shmid = shmget(id, sizeof(GameState), 0666 | IPC_CREAT);
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  //Map shared memory into address space
  GameState * stateBuffer = (GameState *) shmat(shmid, 0, 0);
  if ( stateBuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  //read and create board
  FILE *boardFile = fopen(argv[1], "r");
  if(!boardFile){
    invalidFile(argv[1]);
  }

  //read input file and create game board
  char c;
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      //read first 5 chars on a line
      c = fgetc(boardFile);
      //make sure they are . or *
      if(c != '.' && c != '*'){
        invalidFile(argv[1]);
      }
      //put in game board
      stateBuffer->gameBoard[i][j] = c;
    }
    //get the newline character, we should be at the end of the line now
    c = fgetc(boardFile);
    if(c != '\n'){
      invalidFile(argv[1]);
    }
  }
  //make sure we are at EOF
  c = fgetc(boardFile);
  if(c != EOF){
    invalidFile(argv[1]);
  }


  fclose(boardFile);

  stateBuffer->canUndo = false;

  //release reference to shared memory
  shmdt(stateBuffer);

  return 0;
}
