// Height and width of the playing area.
#define GRID_SIZE 5

//game board struct
typedef struct _GameState {
  char gameBoard[GRID_SIZE][GRID_SIZE];
  int prevMove[2];
  bool canUndo;
} GameState;
