import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum{

    //number of workers being used
    public static int numWorkers;

    //The list of values to find the maxsum of
    public static ArrayList<Integer> values;

    //holds if each worker needs to report their findings
    public static boolean report;

    //Used for when the program needs to exit
    //param message to display when failing
    private static void fail(String message){
        System.out.println(message);
        System.exit(1);
    }

    //used when the program is called incorrectly
    private static void usage(){
        System.out.println("usage: maxsum <workers>" );
        System.out.println("       maxsum <workers> report");
        System.exit(1);
    }
    
    //reads the list of values from standard input
    private static void readList(ArrayList<Integer> values){
        //make a scanner
        Scanner scnr = new Scanner(System.in);
        //while there is a value to read
        while(scnr.hasNext()){
            //if its an integer, read it
            if(scnr.hasNextInt()){
                values.add(scnr.nextInt());
            }
            //invalid if a non int is entered
            else{
                fail("Invalid file");
            }
        }
        scnr.close();
    }

    //worker thread class
    private static class Worker extends Thread {

        //the position the thread starts at with the values
        private int startingPoint;

        //the highest sum value the worker finds
        private int maxSum;

        //constructor
        //param the position to start it
        public Worker(int startingPoint){
            this.startingPoint = startingPoint;
        }

        //returns the maxsum this worker found
        public int getMaxSum(){
            return this.maxSum;
        }

        //goes through the values and calculates the max sum for its values
        public void run(){
            maxSum = values.get(startingPoint);
            //loop through starting values
            for(int i = this.startingPoint; i < values.size(); i+=numWorkers){
                int sum = values.get(i);
                //calculate sum from starting point to end of array
                for(int j = i + 1; j < values.size(); j++){
                    sum += values.get(j);
                    if(sum > maxSum){
                        maxSum = sum;
                    }
                }
            }

            //print out report if needed
            if(report){
                System.out.printf("I’m thread %d. The maximum sum I found is %d.\n", getId(), maxSum);
            }
        }
    }

    //makes sure program was called correctly and runs program
    public static void main(String[] args){

        //make sure the right number of args was given
        if(args.length != 1 && args.length != 2){
            usage();
        }

        //make sure the first command line argument was an integer
        try{
            numWorkers = Integer.parseInt(args[0]);
        } catch(NumberFormatException e){
            usage();
        }

        //if there was a second argument, make sure it was report
        if(args.length == 2 && !args[1].equals("report")){
            usage();
        }

        //if there are 2 arguments, report was specified
        report = args.length == 2;

        //read values into this list
        values = new ArrayList<Integer>();
        readList(values);
        
        //creater n workers and give each of them a different starting value
        int startingPoint = 0;
        ArrayList<Worker> workers = new ArrayList<Worker>();
        for(int i = 0; i < numWorkers; i++){
            workers.add(new Worker(startingPoint));
            startingPoint++;
        }

        //run all threads
        for(int i = 0; i < numWorkers; i++){
            workers.get(i).start();
        }

        //join all threads
        try{
            for(int i = 0; i < numWorkers; i++){
                workers.get(i).join();
            }
        } catch(InterruptedException e){
            fail("Error when joining");
        }

        //find the worker that got the highest value
        int totalHighest = workers.get(0).getMaxSum();
        for(int i = 1; i < numWorkers; i++){
            if(workers.get(i).getMaxSum() > totalHighest){
                totalHighest = workers.get(i).getMaxSum();
            }
        }

        System.out.printf("Maximum Sum: %d\n", totalHighest);

    }
}