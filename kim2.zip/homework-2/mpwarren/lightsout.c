#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//determines if the given character in move is a valid board position
bool isValidPos(char c){
    return c >= 48 && c <= 52;
}

//Updates the game board at the given space
void updateSpace(GameState *bo, int r, int c){
  //only update space if its in the board
  //printf("Updating space %d %d", r, c);
  if((r >= 0 && r <= 4) && (c >= 0 && c <= 4)){
    bo->gameBoard[r][c] = bo->gameBoard[r][c] == '.' ? '*' : '.';
  }
}

//method that preforms a move at the given space
void updateBoard(GameState *bo, int r, int c){
  //calculate indexes of surrounding spaces
  int left[2] = {r, c - 1};
  int right[2] = {r, c + 1};
  int top[2] = {r - 1, c};
  int bottom[2] = {r + 1, c};

  //change the middle and surrounding spaces
  updateSpace(bo, r,c);
  updateSpace(bo, left[0],left[1]);
  updateSpace(bo, right[0],right[1]);
  updateSpace(bo, top[0],top[1]);
  updateSpace(bo, bottom[0],bottom[1]);

}

//prints out the game board to standard output
void printBoard(GameState *bo){
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      printf("%c", bo->gameBoard[i][j]);
    }
    printf("%s", "\n");
  }
}

int main( int argc, char *argv[] ) {

  //get id from file path to my directory
  key_t id = ftok("/afs/unity.ncsu.edu/users/m/mpwarren", 1);
  //create shared memory
  int shmid = shmget(id, sizeof(GameState), 0);
  if ( shmid == -1 )
    fail( "Can't create shared memory" );

  //add shared memory into address space
  GameState * stateBuffer = (GameState *) shmat(shmid, 0, 0); 
  if ( stateBuffer == (GameState *)-1 )
    fail( "Can't map shared memory segment into address space" );

  //move command
  if(argc == 4 && strcmp(argv[1], "move") == 0){
    //make sure only 1 char is given 
    if(strlen(argv[2]) != 1 || strlen(argv[3]) != 1){
      fail("error");
    }

    //get row and col number
    char r = argv[2][0];
    char c = argv[3][0];

    //make sure indexes are valid in the board
    if(isValidPos(r) && isValidPos(c)){
      //update board state if valid
      updateBoard(stateBuffer, r - 48, c - 48);
      stateBuffer->canUndo = true;
      stateBuffer->prevMove[0] = r - 48;
      stateBuffer->prevMove[1] = c - 48;
      printf("%s", "success\n");
    }
    else{
      fail("error");
    }
  }
  //undo command
  else if(argc == 2 && strcmp(argv[1], "undo") == 0){
    if(stateBuffer->canUndo){
      //update board at previous spot
      updateBoard(stateBuffer, stateBuffer->prevMove[0], stateBuffer->prevMove[1]);
      //can't undo again until player moves again
      stateBuffer->canUndo = false;
      printf("%s", "success\n");
    }
    else{
      fail("error");
    }
  }
  //report command
  else if(argc == 2 && strcmp(argv[1], "report") == 0){
    printBoard(stateBuffer);
  }
  else{
    fail("error");
  }

  //detach from shared memory
  shmdt(stateBuffer);
  

  return 0;
}
