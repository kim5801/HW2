/**
  A file for modifying a game of lights out stored in
  the system's shared memory
  @file lightsout.c
  @author Jaden Abrams (jlabrams)
*/
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"


/**
  Prints out an error message then exits
  @param message the message to print
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// The board we do stuff with
GameState *gBoard;


/**
  Reports out the current board state
*/
static void report() {
  printf("\n");// print out board after execution
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      putchar(gBoard->board[i][j]);
    }
    putchar('\n');
  }
  printf("\n");
}
/**
  a helper method to make flipping the lights easier
  @param j the row coordinate
  @param k the column coordinate
*/
static void flipHelper(int j, int k) {
  if(gBoard->board[j][k] == '.') {
    gBoard->board[j][k] = '*';
  }
  else {
    gBoard->board[j][k] = '.';
  }
}

/**
  Performs the move function on the board
  @param j the row
  @param k the column
  @return 0 if successful, -1 if it fails
*/
static int move(int j, int k) {
  if( j < GRID_SIZE && k < GRID_SIZE) {
    flipHelper(j, k);
    // corners
    if( j == 0 && k == 0) {
      flipHelper(j, k+1);
      flipHelper(j+1, k);
    }
    else if( j == 0 && k == (GRID_SIZE - 1) ) {
      flipHelper(j, k - 1);
      flipHelper(j + 1, k);

    }
    else if(j == (GRID_SIZE - 1) && k == 0) {
      flipHelper(j - 1, k);
      flipHelper(j, k + 1);
    }
    else if(j == (GRID_SIZE - 1) && k == (GRID_SIZE - 1)) {
      flipHelper(j - 1, k);
      flipHelper(j, k - 1);
    }
    // edges
    else if(j == 0) {
      flipHelper(j, k - 1);
      flipHelper(j + 1, k);
      flipHelper(j, k + 1);
    }
    else if(j == (GRID_SIZE - 1)) {
      flipHelper(j, k - 1);
      flipHelper(j - 1, k);
      flipHelper(j, k + 1);
    }
    else if(k == 0) {
      flipHelper(j - 1, k);
      flipHelper(j, k + 1);
      flipHelper(j + 1, k);
    }
    else if(k == (GRID_SIZE - 1)) {
      flipHelper(j - 1, k);
      flipHelper(j, k - 1);
      flipHelper(j + 1, k);
    }
    // everything else
    else {
      flipHelper(j - 1, k);
      flipHelper(j, k - 1);
      flipHelper(j + 1, k);
      flipHelper(j, k + 1);
    }

    gBoard->lastRow = j;
    gBoard->lastCol = k;
    return 0;
  }
  return -1;
}

/**
  Undos the last move
  @return -1 if there is no move to undo
*/
static int undo() {
  if(gBoard->lastRow != -1 || gBoard->lastCol != -1) {
    move(gBoard->lastRow, gBoard->lastCol);
    gBoard->lastRow = -1;
    gBoard->lastCol = -1;
    return 0;
  }
  return -1;
}

/**
  the main thing that controls execution
  @param argc the number of arguments given
  @param argv the arguments given
  @return program exit status
*/
int main( int argc, char *argv[] ) {
  // make the key and get the shared memory
  key_t key = ftok(PATH, PROJECT_ID);
  int shmid = shmget(key, STRUCT_SIZE, 0);
  if(shmid == -1) {
    fail("Couldn't get the shared memory!");
  }
  // check that we got the right number of args
  if(argc != 4 && argc != 2) {
    fail("Invalid command");
  }
  // mount the sharedmemory to the board
  gBoard = (GameState *)shmat(shmid, 0, 0);
  // check that we got a valid move
  if(argc == 4 ) {
    if(strcmp("move", argv[1]) != 0) {
      fail("Invalid command");
    }

    int r, c;
    //scan the input for the position
    if(sscanf(argv[2], "%d", &r) == 0 || sscanf(argv[3], "%d", &c) == 0) {
      fail("Invalid command");
    }
    // make the move and see if it was a valid move
    if(move(r, c) == -1) {
      fail("error");
    }
    else {
      printf("success\n");
      return 0;
    }
  }
  // 2 args, so see if its an undo or a report
  if(argc == 2) {
    if(strcmp(argv[1], "undo") == 0) {
      if(undo() == -1) {
        fail("error");
      }
      else {
        printf("success\n");
        return 0;
      }
    }
    else if(strcmp(argv[1], "report") == 0) {
      report();
    }
    else {
      fail("Invalid command");
    }
  }
  return 0;
}
