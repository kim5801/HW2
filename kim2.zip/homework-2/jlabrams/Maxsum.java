import java.util.ArrayList;
import java.util.Scanner;

/**
 * 	Multi-threaded program for finding the largest sum in a range of numbers
 * 
 * @author Jaden Abrams (jlabrams)
 */
public class Maxsum {
	
	/* Holds the numbers read in from stdin*/
	private static ArrayList<Integer> numbers;
	/* Holds the ranges calculated by the workers */
	private static ArrayList<Integer> results;
	/* holds if the user wants the threads to report their sums */
	private static boolean report = false;
	/* Holds how many workers the user wants */
	private static int workers;
	/* Holds the maximum number found so far */
	private static int max;
	/* Used to control output so we can tell the user that there was an interrupt */
	private static boolean interrupt = false;
	
	/**
	 * Read in the list from stdin
	 * @return an ArrayList of numbers
	 */
	private static ArrayList<Integer> readList() {
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> n = new ArrayList<Integer>();
		while(sc.hasNext()) {
			n.add(Integer.parseInt(sc.nextLine()));
		}
		sc.close();
		return n;
	}

	/**
	 * 	Use this to tell the user how to do things and exit
	 */
	private static void usage() {
		System.out.println("usage: java Maxsum <workers>");
		System.out.println("       java Maxsum <workers> report");
		System.exit(0);
	}

	/**
	 * Prints out an error message and exits
	 * @param message the message to print
	 */
	private static void fail(String message) {
		System.out.println(message);
		System.exit(0);
	}
	
	/**
	 * 	A worker to calculate assigned ranges
	 */
	static class Worker extends Thread {
		/* The place we are to start at */
		int place;
		/* The biggest sum we have found */
		int maximum = Integer.MIN_VALUE;
		
		/**
		 * Create a new Worker thread
		 * @param place the starting point of our calculations
		 */
		public Worker(int place) {
			this.place = place;
		}
		/**
		 * Starting point for worker thread execution.
		 * Here, we calculate our ranges and set our max to the biggest one we found, and report our result
		 */
		public void run() {
			for(int i = place; i < numbers.size() - 1; i += workers) {
				int contender = numbers.get(i);
				maximum = Math.max(contender, maximum);
				for(int j = i + 1; j < numbers.size(); j++) {
					contender += numbers.get(j);
					maximum = Math.max(contender, maximum);
				}				
			}
			if(report == true) {
				System.out.println("I'm process " + super.getId() + ". The maximum sum I found is " + maximum + ".");
			}
			results.add(maximum);
		}
	}

	/**
	 * Starting point for the main thread
	 * @param args arguments given from the user
	 */
	public static void main(String[] args) {

		if(args.length < 1 || args.length > 2) {
			usage();
		}
		if(args.length > 1) {
			if("report".equals(args[1])) {
				report = true;
			}
			else {
				usage();
			}
		}
		
		try {
			workers = Integer.parseInt(args[0]);
		} catch(Exception e) {
			usage();
		}

		if(workers < 1) {
			fail("Invalid number of workers");
		}
		
		numbers = readList();
		
		max = Integer.MIN_VALUE;
		Worker[] team = new Worker[workers];
		results = new ArrayList<Integer>();
		for(int i = 0; i < workers; i++) {
			team[i] = new Worker(i);
			team[i].run();
		}
		try {
			for(int i = 0; i < workers; i++) {
				team[i].join();
			}
		} catch(InterruptedException e) {
			interrupt = true;
			fail("Interrupted during join!");
		}
		
		
		if(interrupt == false) {
			for(int i = 0; i < results.size(); i++) {
				max = Math.max(max, results.get(i));
			}
			System.out.println("Maximum Sum: "+ max);
		}
		
	}
}
