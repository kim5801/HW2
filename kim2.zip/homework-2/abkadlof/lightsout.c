#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

//a copy of the board to reference
struct GameState *boardState;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/// @brief copies one 2d char array representation of the board to another
/// @param to the 2d char array to copy to
/// @param from the 2d char array to copy from
void copyBoard(char to[GRID_SIZE][GRID_SIZE + 2], char from[GRID_SIZE][GRID_SIZE + 2]) {
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 2; j++) {
      to[i][j] = from[i][j];
    }
  }
}

/// @brief Converts a string to an int. Sets the success flag if it parsed successfully
/// @param str the string to parse
/// @param success the success of the conversion
/// @return the integer if the parsing was successful, otherwise -1
int strToInt(char *str, bool *success) {
  char *endPtr = NULL;
  int retVal = strtol(str, &endPtr, 10);
  //check that errno is not set, that the string is not empty, and that the whole string was parsed
  if (errno == 0 && (str != endPtr) && *endPtr == '\0') {
    *success = true;
    return retVal;
  } else {
    *success = false;
    return -1;
  }
}

/// @brief flips the light on or off depending on its state. If it is not one of 
/// two expected chars, nothing happens
/// @param light a char pointer to either '*' or '.'
void flipLight(char *light) {
  if (*light == '*') {
    *light = '.';
  } else if (*light == '.') {
    *light = '*';
  }
}

/// @brief checks if a coordinate is out of bounds for the grid
/// @param coord the coord to check
/// @return true if out of bounds, otherwise false
bool isOutOfBounds(int coord) {
  return coord < 0 || coord > GRID_SIZE - 1;
}

/// @brief Executes a move at the specified coordinates
/// @param x the x coord
/// @param y the y coord
void moveCommand(char *x, char *y) {
  //error check coords
  bool success;
  int xCoord = strToInt(x, &success);
  if (!success || isOutOfBounds(xCoord)) {
    fail("error");
  }
  int yCoord = strToInt(y, &success);
  if (!success || isOutOfBounds(xCoord)) {
    fail("error");
  }

  //save board for undo
  copyBoard(boardState->last, boardState->current);

  //flip lights if possible
  flipLight(&boardState->current[xCoord][yCoord]);
  if (!isOutOfBounds(xCoord + 1)) {
    flipLight(&boardState->current[xCoord + 1][yCoord]);
  }
  if (!isOutOfBounds(xCoord - 1)) {
    flipLight(&boardState->current[xCoord - 1][yCoord]);
  }
  if (!isOutOfBounds(yCoord + 1)) {
    flipLight(&boardState->current[xCoord][yCoord + 1]);
  }
  if (!isOutOfBounds(yCoord - 1)) {
    flipLight(&boardState->current[xCoord][yCoord - 1]);
  }
  boardState->lastDiff = true;
  printf("success\n");
}

/// @brief Sets the current board state to the last board state
void undoCommand() {
  if (!boardState->lastDiff) {
    fail("error");
  }
  copyBoard(boardState->current, boardState->last);
  boardState->lastDiff = false;
  printf("success\n");
}

/// @brief prints out the board to the viewer
void reportCommand() {
  for (int i = 0; i < GRID_SIZE; i++) {
    printf(boardState->current[i]);
  }
}

//parses command like in hw1
void parseCommand(int argc, char *argv[]) {
  if (strcmp("move", argv[1]) == 0) {
    //parse and check the remaining arguments for move command
    if (argc != 4) {
      fail("error");
    }
    moveCommand(argv[2], argv[3]);

  } else if (strcmp("undo", argv[1]) == 0) {
    //if there are more arguments throw an error
    if (argc != 2) {
      fail("error");
    }
    undoCommand();

  } else if (strcmp("report", argv[1]) == 0) {
    //if there are more arguments throw an error
    if (argc != 2) {
      fail("error");
    }
    reportCommand();
    
  } else {
    fail("error");
  }
}

//initializes board
int main( int argc, char *argv[] ) {
  if (argc > 4 || argc < 2) {
    usage();
  }
  int sharedId = ftok(SHARED_MEM_NAME, PROJ_ID);
  int shmid = shmget(sharedId, 0, 0);
  boardState = (struct GameState *)shmat(shmid, 0, 0);

  parseCommand(argc, argv);
  return 0;
}
