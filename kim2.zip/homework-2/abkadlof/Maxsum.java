import java.util.ArrayList;
import java.util.Scanner;

public class Maxsum {
  //main method that checks the command line arguments and triggers methods to complete tasks and print output
  public static void main(String[] args) {
    boolean report = false;
    int workers = 0;
    // determine if number of command line arguments is correct
    if (args.length != 1 && args.length != 2)
      usage();

    // determine if the first argument is a valid integer, otherwise fail
    try {
      workers = Integer.parseInt(args[0]);
    } catch (NumberFormatException e) {
      usage();
    }

    // if determine if the second argument specified (if there is one) is "report",
    // otherwise fail
    if (args.length == 2) {
      if (!"report".equals(args[1])) {
        usage();
      } else {
        report = true;
      }
    }

    // once the first one/two main arguments are parsed, parse the list of integers
    ArrayList<Integer> inputList = parseList();

    // call function that most work occurs in
    calculateMaxSum(inputList, workers, report);
  }

  //reads integers from standard in using a scanner and returns the ints in the form of an ArrayList
  private static ArrayList<Integer> parseList() {
    ArrayList<Integer> retVal = new ArrayList<Integer>();
    //init and continuously scan ints (from csc116)
    Scanner scnr = new Scanner(System.in);
    while (scnr.hasNextInt()) {
      retVal.add(scnr.nextInt());
    }
    scnr.close();
    return retVal;
  }

  //creates the threads for calculating the max sums and prints reports
  private static void calculateMaxSum(ArrayList<Integer> intList, int numWorkers, boolean report) {
    int globalMax = Integer.MIN_VALUE;
    SumCalcThread[] threads = new SumCalcThread[numWorkers];
    for (int i = 0; i < numWorkers; i++) {
      /* 
        the strategy used for dividing work is taking the current worker number, and adding the increment (the number of workers) 
        to it. This effectively makes it so that each worker only does every n process, offset by one for each worker.
      */
      threads[i] = new SumCalcThread(intList, i, numWorkers);
      threads[i].start();
    }

    // Wait for each of the threads to terminate.
    try {
      for ( int i = 0; i < numWorkers; i++ ) {
        threads[ i ].join();
        int thisThreadHighestSum = threads[i].getHighestSum();
        //determine if the sum that this thread found is higher than the max found so far
        if (thisThreadHighestSum > globalMax) {
          globalMax = thisThreadHighestSum;
        }

        if (report) {
          System.out.printf("I'm thread %d. The maximum sum I found is %d.\n", threads[i].getId(), thisThreadHighestSum);
        }
      }
    } catch ( InterruptedException e ) {
      System.out.println( "Interrupted during join!" );
    }
    System.out.printf("Maximum Sum: %d\n", globalMax);
  }

  // Print out a usage message, then exit.
  private static void usage() {
    System.out.println("usage: maxsum <workers>\n       maxsum <workers> report");
    System.exit(1);
  }

  private static class SumCalcThread extends Thread {
    //holds the start index of this thread
    private int _startIndex;
    //holds the highest sum founds by this thread
    private int _highestSum;
    //holds the list of inputed integers
    private ArrayList<Integer> _intList;
    //the increment to increase by
    private int _increment;

    public SumCalcThread(ArrayList<Integer> intList, int startIndex, int increment) {
      _intList = intList;
      _startIndex = startIndex;
      _increment = increment;
    }

    public int getHighestSum() {
      return _highestSum;
    }

    public void run() {
      //algorithm to find the highest sum starting at every _startIndex + _increment*x index
      int highestSum = Integer.MIN_VALUE;
      for (int i = _startIndex; i < _intList.size(); i += _increment) {
        int totalSum = 0;
        for (int j = i; j < _intList.size(); j++) {
          totalSum += _intList.get(j);
          if (totalSum > highestSum) {
            highestSum = totalSum;
          } // else continue through the list (do not stop) cuz a future integer may be big
            // and make a new highest sum
        }
      }
      _highestSum = highestSum;
    }
  }
}