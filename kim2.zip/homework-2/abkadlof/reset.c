#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "common.h"

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: reset <board-file>\n" );
  exit( 1 );
}

/// @brief Reads from the input file and initializes the boardState based on the file.
/// this can stop the program running if something with the file is invalid
/// @param filename the file to read from
int main( int argc, char *argv[] ) {
  if (argc != 2) {
    usage();
  }
  char *filename = argv[1];
  //try to open file
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", filename);
    exit(1);
  }
  //initialize shared memory
  key_t sharedId = ftok(SHARED_MEM_NAME, PROJ_ID);
  int shmid = shmget(sharedId, sizeof(struct GameState), 0777 | IPC_CREAT);
  
  struct GameState *gameState = (struct GameState *)shmat(shmid, 0, 0);
  
  //iterate thru file
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 2; j++) {
      //if we are past the newline, add a null terminator so that we can print 
      //as string, and then continue in the loop
      if (j == GRID_SIZE + 1) {
        gameState->current[i][j] = '\0';
        continue;
      }

      char currChar = fgetc(fp);
      //if currChar is not an allowed char, then close the file and exit
      if (currChar != '.' && currChar != '*' && currChar != '\n') {
        fclose(fp);
        fprintf(stderr, "Invalid input file: %s\n", filename);
        exit(1);
      }
      //otherwise add the char into the corresponding element in the 2D array
      gameState->current[i][j] = currChar;
    }
  }
  gameState->lastDiff = false;
  fclose(fp);

  return 0;
}
